export const conConfig = {
  user: "sa",
  password: "Iotserver@1",
  server: "10.129.214.56",
  database: "PDM",
  options: {
    encrypt: false,
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  requestTimeout: 60000, // 60 seconds
  connectionTimeout: 30000,
};