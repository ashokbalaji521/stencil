import sql from "mssql";
import { conConfig } from '../DB/db.js';

export const summarydetails = async (req, res) => {
    try {

      let{startDate,endDate,Status}=req.body

      console.log(req.body);
        
    const pool = await sql.connect(conConfig);
  
    const request = pool.request()
          .input("startDate", sql.VarChar, startDate)
          .input("endDate", sql.VarChar, endDate)
          // .input("Status", sql.Bit, Status);

    let query = (`
          Select A.Category
          ,A.CP_ID
          ,A.ECN_STI_Number
          ,A.Receieved_Date
          ,A.Product_Family
          ,A.Product_Name
          ,B.OPENSTATUS
          ,B.Username
          ,B.Sign_off_Status
        from [ECN/STI] A join [Assign_STI/CN_Owners] B on A.CP_ID=B.CP_ID 
        Where A.Receieved_Date between @startDate and @endDate
          `);

    if (Status !== "All") {
      request.input("Status", sql.Bit, Status); // Use VarChar if you're sending string values like "Open"
      query += " AND B.OPENSTATUS = @Status";
    }

    const result = await request.query(query);
    console.log(result.recordset);   
      
    res.status(200).json(result.recordset);
  } catch (error) {
    console.error("Error to fetch data:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};


export const getusernamebycountbypostimp = async (req, res) => {
  try {
    let { status, count, TeamId } = req.body;

    // Validation
    if (status === undefined || count === undefined || TeamId === undefined) {
      return res.status(400).json({ error: "status, count, and TeamId are required" });
    }

    const pool = await sql.connect(conConfig);

    // 1️⃣ Get team column name from TeamMaster
    const teamResult = await pool
      .request()
      .input("TeamId", sql.Int, TeamId)
      .query(`SELECT TeamName FROM [PDM].[dbo].[TeamMaster] WHERE TeamId=@TeamId`);

    if (teamResult.recordset.length === 0) {
      return res.status(400).json({ error: "Invalid TeamId" });
    }

    const teamColumn = teamResult.recordset[0].TeamName; // e.g., "SQA"

    // 2️⃣ Build dynamic query (with A.TeamId filter)
    const query = `
      SELECT TOP (${count})
        A.Username,
        A.Emailid,
        A.CP_ID,
        B.${teamColumn} as StatusValue
      FROM [PDM].[dbo].[Assign_STI/CN_Owners] A
      JOIN [PDM].[dbo].[POST_IMPLEMENTATION_STATUS] B
        ON A.CP_ID = B.CP_ID
      WHERE B.${teamColumn} = @status
        AND A.TeamId = @TeamId
    `;

    const result = await pool.request()
      .input("status", sql.Int, status)
      .input("TeamId", sql.Int, TeamId)
      .query(query);

    res.status(200).json({
      team: teamColumn,
      status,
      count: result.recordset.length,
      users: result.recordset
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};


export const getusernamebycountbypreimp = async (req, res) => {
  try {
    let { status, count, TeamId } = req.body;

    // Validation
    if (status === undefined || count === undefined || TeamId === undefined) {
      return res.status(400).json({ error: "status, count, and TeamId are required" });
    }

    const pool = await sql.connect(conConfig);

    // 1️⃣ Get team column name from TeamMaster
    const teamResult = await pool
      .request()
      .input("TeamId", sql.Int, TeamId)
      .query(`SELECT TeamName FROM [PDM].[dbo].[TeamMaster] WHERE TeamId=@TeamId`);

    if (teamResult.recordset.length === 0) {
      return res.status(400).json({ error: "Invalid TeamId" });
    }

    const teamColumn = teamResult.recordset[0].TeamName;

    // 2️⃣ Build dynamic query (with A.TeamId filter)
    const query = `
      SELECT TOP (${count})
        A.Username,
        A.Emailid,
        A.CP_ID,
        B.${teamColumn} as StatusValue
      FROM [PDM].[dbo].[Assign_STI/CN_Owners] A
      JOIN [PDM].[dbo].[PRE_IMPLEMENTATION_STATUS] B
        ON A.CP_ID = B.CP_ID
      WHERE B.${teamColumn} = @status
        AND A.TeamId = @TeamId
    `;

    const result = await pool.request()
      .input("status", sql.Int, status)
      .input("TeamId", sql.Int, TeamId)
      .query(query);

    res.status(200).json({
      team: teamColumn,
      status,
      count: result.recordset.length,
      users: result.recordset
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};


export const getuserteammemberswithmail = async (req, res) => {
  try {
    const email = req.body.email?.trim();

    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }

    const pool = await sql.connect(conConfig);

    // Step 1: Get user from Users_PDM
    const userResult = await pool
      .request()
      .input("email", sql.NVarChar, email)
      .query(`
        SELECT TOP 1 ID, Username, Role, UpdatedDateTime, RoleId, Email, Team, TeamId 
        FROM Users_PDM 
        WHERE Email = @email
      `);

    if (userResult.recordset.length === 0) {
      return res.status(404).json({ error: "User not found with this email" });
    }

    const user = userResult.recordset[0];

    // Step 2: Get records from Assign_STI/CN_Owners based on Team and Emailid
    const teamAssignResult = await pool
      .request()
      .input("team", sql.NVarChar, user.Team)
      .query(`
        SELECT ID, Username, Role, UpdatedDateTime, RoleId, OPENSTATUS, Emailid, Assign, Team, EmailStatus, CP_ID, Sign_off_Status, TeamId, ApprovedStatus, ApprovalToken, SignoffApproved
        FROM [Assign_STI/CN_Owners]
        WHERE Team = @team AND Assign = 1
      `);

    const emailAssignResult = await pool
      .request()
      .input("email", sql.NVarChar, email)
      .input("team", sql.NVarChar, user.Team)
      .query(`
        SELECT ID, Username, Role, UpdatedDateTime, RoleId, OPENSTATUS, Emailid, Assign, Team, EmailStatus, CP_ID, Sign_off_Status, TeamId, ApprovedStatus, ApprovalToken, SignoffApproved
        FROM [Assign_STI/CN_Owners]
        WHERE Emailid = @email AND Assign = 1 AND Team = @team
      `);

    // ✅ Send response
    return res.status(200).json({
      user: {
        ID: user.ID,
        Username: user.Username,
        Role: user.Role,
        RoleId: user.RoleId,
        Email: user.Email,
        Team: user.Team,
        TeamId: user.TeamId,
        UpdatedDateTime: user.UpdatedDateTime
      },
      teamAssignments: {
        count: teamAssignResult.recordset.length,
        data: teamAssignResult.recordset
      },
      YourAssignments: {
        count: emailAssignResult.recordset.length,
        data: emailAssignResult.recordset
      }
    });

  } catch (err) {
    console.error("Get User Team Members with Email Error:", err);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};



// Assignment confirmation endpoint
export const assignmentConfirmation = async (req, res) => {
  try {
    const { id } = req.params;
    const pool = await sql.connect(conConfig);

    // Verify the record exists and is not yet acknowledged
    const checkQuery = `
      SELECT ID
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID AND Assign = 0
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, id);
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).json({ message: 'Invalid or already acknowledged assignment' });
    }

    // Update the database to mark as acknowledged
    const updateQuery = `
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET Assign = 1, ApprovedStatus = 1, UpdatedDateTime = GETDATE()
      WHERE ID = @ID
    `;
    const updateRequest = pool.request();
    updateRequest.input('ID', sql.Int, id);
    await updateRequest.query(updateQuery);

    return res.status(200).json({ message: 'Assignment acknowledged successfully' });
  } catch (err) {
    console.error('AssignmentConfirmation Error:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    try {
      await sql.close();
    } catch (closeError) {
      console.error('Error closing SQL connection:', closeError);
    }
  }
};

// Sign-off confirmation endpoint
export const signOffConfirmation = async (req, res) => {
  try {
    const { id } = req.params;
    const pool = await sql.connect(conConfig);

    // Verify the record exists and is pending sign-off
    const checkQuery = `
      SELECT ID
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID AND Sign_off_Status = 1 AND SignoffApproved = 0
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, id);
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).json({ message: 'Invalid or already approved sign-off' });
    }

    // Update the database to mark as sign-off approved
    const updateQuery = `
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET SignoffApproved = 1, UpdatedDateTime = GETDATE()
      WHERE ID = @ID
    `;
    const updateRequest = pool.request();
    updateRequest.input('ID', sql.Int, id);
    await updateRequest.query(updateQuery);

    return res.status(200).json({ message: 'Sign-off approved successfully' });
  } catch (err) {
    console.error('SignOffConfirmation Error:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    try {
      await sql.close();
    } catch (closeError) {
      console.error('Error closing SQL connection:', closeError);
    }
  }
};



//-----------------------------------------------------------------------------------//
export const AssignmentConfirmationnotification = async (req, res) => {
  try {
    const id = req.params.id; // Assuming route is /AssignmentConfirmation/:id
    const { email } = req.body;

    console.log('Received assignment confirmation request for ID:', id, 'and Emailid:', email); // Debug log

    if (!id || isNaN(id) || !email || typeof email !== 'string') {
      return res.status(400).json({ error: 'Valid ID and Emailid are required' });
    }

    // Trim and normalize email to avoid whitespace or case issues
    const normalizedEmail = email.trim().toLowerCase();
    console.log('Normalized Email:', normalizedEmail); // Debug log

    const pool = await sql.connect(conConfig);
    console.log('Database connection established'); // Debug log

    // Explicitly declare the parameters and update query
    const request = pool.request();
    request.input('id', sql.Int, parseInt(id));
    request.input('email', sql.VarChar(255), normalizedEmail);

    const result = await request.query(`
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET [ApprovedStatus] = 1
      WHERE [ID] = @id
        AND LOWER([Emailid]) = @email
        AND [Assign] = 1
    `);

    console.log('Update executed, rows affected:', result.rowsAffected[0]); // Debug log

    if (result.rowsAffected[0] === 0) {
      return res.status(400).json({ error: 'Cannot confirm assignment: Record not found or not eligible (Assign must be 1)' });
    }

    return res.status(200).json({ message: 'Assignment confirmed successfully' });

  } catch (error) {
    console.error('Error confirming assignment:', error);
    return res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message,
      sqlError: error.originalError ? error.originalError.info : null 
    });
  } finally {
    // Ensure the connection is closed
    try {
      await sql.close();
    } catch (closeError) {
      console.error('Error closing SQL connection:', closeError);
    }
  }
};

export const SignOffConfirmationnotification = async (req, res) => {
  try {
    const id = req.params.id; // Assuming route is /SignOffConfirmation/:id
    const { email } = req.body;

    console.log('Received sign-off confirmation request for ID:', id, 'and Emailid:', email); // Debug log

    if (!id || isNaN(id) || !email || typeof email !== 'string') {
      return res.status(400).json({ error: 'Valid ID and Emailid are required' });
    }

    // Trim and normalize email to avoid whitespace or case issues
    const normalizedEmail = email.trim().toLowerCase();
    console.log('Normalized Email:', normalizedEmail); // Debug log

    const pool = await sql.connect(conConfig);
    console.log('Database connection established'); // Debug log

    // Explicitly declare the parameters and update query
    const request = pool.request();
    request.input('id', sql.Int, parseInt(id));
    request.input('email', sql.VarChar(255), normalizedEmail);

    const result = await request.query(`
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET [SignoffApproved] = 1
      WHERE [ID] = @id
        AND LOWER([Emailid]) = @email
        AND [Sign_off_Status] = 1
    `);

    console.log('Update executed, rows affected:', result.rowsAffected[0]); // Debug log

    if (result.rowsAffected[0] === 0) {
      return res.status(400).json({ error: 'Cannot confirm sign-off: Record not found or not eligible (Sign_off_Status must be 1)' });
    }

    return res.status(200).json({ message: 'Sign-off confirmed successfully' });

  } catch (error) {
    console.error('Error confirming sign-off:', error);
    return res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message,
      sqlError: error.originalError ? error.originalError.info : null 
    });
  } finally {
    // Ensure the connection is closed
    try {
      await sql.close();
    } catch (closeError) {
      console.error('Error closing SQL connection:', closeError);
    }
  }
};
export const getcountofnotify = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);

    // 1. All records (for reference)
    const recordsQuery = `
      SELECT [ID]
            ,[Username]
            ,[Role]
            ,[UpdatedDateTime]
            ,[RoleId]
            ,[OPENSTATUS]
            ,[Emailid]
            ,[Assign]
            ,[Team]
            ,[EmailStatus]
            ,[CP_ID]
            ,[Sign_off_Status]
            ,[TeamId]
            ,[ApprovedStatus]
            ,[ApprovalToken]
            ,[SignoffApproved]
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
    `;
    const recordsResult = await pool.request().query(recordsQuery);

    // 2. Records where Assign = 1 and ApprovedStatus = 0
    const query1 = `
      SELECT *
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE Assign = 1 AND [ApprovedStatus] = 0
    `;
    const result1 = await pool.request().query(query1);

    // 3. Records where Sign_off_Status = 1 OR SignoffApproved = 0
    const query2 = `
      SELECT *
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE [Sign_off_Status] = 1 OR [SignoffApproved] = 0
    `;
    const result2 = await pool.request().query(query2);

    // 4. Total count = sum of both arrays
    const totalCount = result1.recordset.length + result2.recordset.length;

    res.status(200).json({
      records: recordsResult.recordset,  // all records
      Assign: result1.recordset,   // objects for condition 1
      signoff: result2.recordset,   // objects for condition 2
      totalCount: totalCount             // total from only these 2 sets
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};
