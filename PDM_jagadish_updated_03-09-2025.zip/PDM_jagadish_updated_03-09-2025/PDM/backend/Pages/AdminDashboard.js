import sql from "mssql";
import { conConfig } from '../DB/db.js';

import dotenv from "dotenv";

dotenv.config();


function getISTDate() {
  const now = new Date();
  const offset = 5.5 * 60 * 60 * 1000;
  return new Date(now.getTime() + offset);
}


export const addECN = async (req, res) => {
    try {
        let {
            Change_Note_Cateogry,
            CP_ID,
            ECN_STI_Type, // 'ECN' or 'STI'
            ECN_Number,
            STI_Number,
            Receieved_Date,
            STI_From_Date,
            STI_To_Date,
            Product_Family,
            Product_Sale_code,
            Product_Name,
            Category,
            Brief_Details
        } = req.body;

        const pool = await sql.connect(conConfig);

        // Check if CP_ID already exists
        const checkQuery = `
            SELECT COUNT(*) as count 
            FROM [dbo].[ECN/STI] 
            WHERE CP_ID = @CP_ID
        `;
        
        const checkResult = await pool
            .request()
            .input("CP_ID", sql.VarChar, CP_ID)
            .query(checkQuery);

        if (checkResult.recordset[0].count > 0) {
            return res.status(400).json({ error: "CP_ID already exists in the database" });
        }

        // Determine Change_Note_Cateogry_ID based on Change_Note_Cateogry
        let Change_Note_Cateogry_ID;
        switch (Change_Note_Cateogry) {
            case "Materials":
                Change_Note_Cateogry_ID = 1;
                break;
            case "Tools & Jigs":
                Change_Note_Cateogry_ID = 2;
                break;
            case "Documents":
                Change_Note_Cateogry_ID = 3;
                break;
            default:
                Change_Note_Cateogry_ID = null; // or handle invalid category as needed
        }

        // Insert into [ECN/STI] table
        const insertECNQuery = `
            INSERT INTO [dbo].[ECN/STI] (
                [Change_Note_Cateogry]
                ,[CP_ID]
                ,[ECN_STI_Type]
                ,[ECN_Number]
                ,[STI_Number]
                ,[Receieved_Date]
                ,[STI_From_Date]
                ,[STI_To_Date]
                ,[Product_Family]
                ,[Product_Sale_code]
                ,[Product_Name]
                ,[Category]
                ,[Brief_Details]
                ,[Change_Note_Cateogry_ID]
            )
            VALUES (
                @Change_Note_Cateogry
                ,@CP_ID
                ,@ECN_STI_Type
                ,@ECN_Number
                ,@STI_Number
                ,@Receieved_Date
                ,@STI_From_Date
                ,@STI_To_Date
                ,@Product_Family
                ,@Product_Sale_code
                ,@Product_Name
                ,@Category
                ,@Brief_Details
                ,@Change_Note_Cateogry_ID
            )`;

        await pool
            .request()
            .input("Change_Note_Cateogry", sql.VarChar, Change_Note_Cateogry)
            .input("CP_ID", sql.VarChar, CP_ID)
            .input("ECN_STI_Type", sql.VarChar, ECN_STI_Type)
            .input("ECN_Number", sql.VarChar, ECN_STI_Type === "ECN" ? ECN_Number : null)
            .input("STI_Number", sql.VarChar, ECN_STI_Type === "STI" ? STI_Number : null)
            .input("Receieved_Date", sql.DateTime, ECN_STI_Type === "ECN" ? Receieved_Date : null)
            .input("STI_From_Date", sql.DateTime, ECN_STI_Type === "STI" ? STI_From_Date : null)
            .input("STI_To_Date", sql.DateTime, ECN_STI_Type === "STI" ? STI_To_Date : null)
            .input("Product_Family", sql.VarChar, Product_Family)
            .input("Product_Sale_code", sql.VarChar, Product_Sale_code)
            .input("Product_Name", sql.VarChar, Product_Name)
            .input("Category", sql.VarChar, Category)
            .input("Brief_Details", sql.VarChar, Brief_Details)
            .input("Change_Note_Cateogry_ID", sql.Int, Change_Note_Cateogry_ID)
            .query(insertECNQuery);

        // Insert into [PRE_IMPLEMENTATION_STATUS] table
        const insertPreQuery = `
            INSERT INTO [dbo].[PRE_IMPLEMENTATION_STATUS] (
                [CP_ID]
                ,[PDM]
                ,[MM_Buyer]
                ,[MM_logistics]
                ,[SQA]
                ,[WH]
                ,[MC]
                ,[SMT]
                ,[MS_SMT]
                ,[MS_IE]
                ,[MS_TEST]
                ,[MS_PT]
                ,[MS_PE]
                ,[MS_IT]
                ,[OPS]
            )
            VALUES (
                @CP_ID
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
            )`;

        await pool
            .request()
            .input("CP_ID", sql.VarChar, CP_ID)
            .query(insertPreQuery);

        // Insert into [TRAIL_PRODUCTION_STATUS] table
        const insertTrailQuery = `
            INSERT INTO [dbo].[TRAIL_PRODUCTION_STATUS] (
                [CP_ID]
                ,[PDM]
                ,[MM_Buyer]
                ,[MM_logistics]
                ,[SQA]
                ,[WH]
                ,[MC]
                ,[SMT]
                ,[MS_SMT]
                ,[MS_IE]
                ,[MS_TEST]
                ,[MS_PT]
                ,[MS_PE]
                ,[MS_IT]
                ,[OPS]
            )
            VALUES (
                @CP_ID
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
            )`;

        await pool
            .request()
            .input("CP_ID", sql.VarChar, CP_ID)
            .query(insertTrailQuery);

        // Insert into [POST_IMPLEMENTATION_STATUS] table
        const insertPostQuery = `
            INSERT INTO [dbo].[POST_IMPLEMENTATION_STATUS] (
                [CP_ID]
                ,[PDM]
                ,[MM_Buyer]
                ,[MM_logistics]
                ,[SQA]
                ,[WH]
                ,[MC]
                ,[SMT]
                ,[MS_SMT]
                ,[MS_IE]
                ,[MS_TEST]
                ,[MS_PT]
                ,[MS_PE]
                ,[MS_IT]
                ,[OPS]
            )
            VALUES (
                @CP_ID
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
            )`;

        await pool
            .request()
            .input("CP_ID", sql.VarChar, CP_ID)
            .query(insertPostQuery);

        res.status(200).json({ message: "Data inserted successfully into all tables" });
    } catch (error) {
        console.error("Insert Error:", error);
        res.status(500).json({ error: "Failed to insert data" });
    }
};

export const preimp = async (req, res) => {
    try {
       
    const pool = await sql.connect(conConfig);
 
    const result = await pool
    .request().query(`
      SELECT B.[Category]
      ,B.[CP_ID]      
      ,B.[ECN_STI_Number]
      ,B.[Product_Family]
      ,B.[Product_Name]      
      ,A.[PDM]
      ,A.[MM_Buyer]
      ,A.[MM_logistics]
      ,A.[SQA]
      ,A.[WH]
      ,A.[MC]
      ,A.[SMT]
      ,A.[MS_SMT]
      ,A.[MS_IE]
      ,A.[MS_TEST]
      ,A.[MS_PT]
      ,A.[MS_PE]
      ,A.[MS_IT]
      ,A.[OPS]
  FROM [PDM].[dbo].[PRE_IMPLEMENTATION_STATUS] A join [PDM].[dbo].[ECN/STI] B on A.CP_ID=B.CP_ID

        `);
    console.log(result.recordset);  
     
 const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {},
      close: {},
      inprogress: {}
    };

  
    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });

  
    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};
 
export const TrailStatus = async (req, res) => {
    try {
       
    const pool = await sql.connect(conConfig);
 
    const result = await pool
    .request().query(`
      SELECT B.[Category]
      ,B.[CP_ID]      
      ,B.[ECN_STI_Number]
      ,B.[Product_Family]
      ,B.[Product_Name]      
      ,A.[PDM]
      ,A.[MM_Buyer]
      ,A.[MM_logistics]
      ,A.[SQA]
      ,A.[WH]
      ,A.[MC]
      ,A.[SMT]
      ,A.[MS_SMT]
      ,A.[MS_IE]
      ,A.[MS_TEST]
      ,A.[MS_PT]
      ,A.[MS_PE]
      ,A.[MS_IT]
      ,A.[OPS]
  FROM [PDM].[dbo].[TRAIL_PRODUCTION_STATUS] A join [PDM].[dbo].[ECN/STI] B on A.CP_ID=B.CP_ID
  

        `);
    console.log(result.recordset);  
     
  const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {},
      close: {},
      inprogress: {}
    };

  
    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });

    
    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};
 
export const postimp = async (req, res) => {
    try {
       
    const pool = await sql.connect(conConfig);
 
    const result = await pool
    .request().query(`
      SELECT B.[Category]
      ,B.[CP_ID]      
      ,B.[ECN_STI_Number]
      ,B.[Product_Family]
      ,B.[Product_Name]      
      ,A.[PDM]
      ,A.[MM_Buyer]
      ,A.[MM_logistics]
      ,A.[SQA]
      ,A.[WH]
      ,A.[MC]
      ,A.[SMT]
      ,A.[MS_SMT]
      ,A.[MS_IE]
      ,A.[MS_TEST]
      ,A.[MS_PT]
      ,A.[MS_PE]
      ,A.[MS_IT]
      ,A.[OPS]
  FROM [PDM].[dbo].[POST_IMPLEMENTATION_STATUS] A join [PDM].[dbo].[ECN/STI] B on A.CP_ID=B.CP_ID
  
        `);
    console.log(result.recordset);  
     
 const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {},
      close: {},
      inprogress: {}
    };

    
    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });


    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};

export const updatestatuspreimp = async (req, res) => {
    try {
        let {
    field,Status,CP_ID
  } = req.body;
 
    const pool = await sql.connect(conConfig);
 
    const insertQuery = `
      update [PRE_IMPLEMENTATION_STATUS] set ${field}=@Status where CP_ID=@CP_ID`;
    await pool
    .request()
    .input("Status", sql.Int, Status)
    .input("CP_ID", sql.VarChar, CP_ID)
    .query(insertQuery);
     
     
    res.status(200).json({ message: "Data inserted successfully" });
  } catch (error) {
    console.error("Insert Error:", error);
    res.status(500).json({ error: "Failed to insert data" });
  }
};
 
export const updatestatuspostimp = async (req, res) => {
    try {
        let {
    field,Status,CP_ID
  } = req.body;
 
    const pool = await sql.connect(conConfig);
 
    const insertQuery = `
      update [POST_IMPLEMENTATION_STATUS] set ${field}=@Status where CP_ID=@CP_ID`;
    await pool
    .request()
    .input("Status", sql.Int, Status)
    .input("CP_ID", sql.VarChar, CP_ID)
    .query(insertQuery);
     
     
    res.status(200).json({ message: "Data inserted successfully" });
  } catch (error) {
    console.error("Insert Error:", error);
    res.status(500).json({ error: "Failed to insert data" });
  }
};
 
export const updatestatustrailstatus = async (req, res) => {
    try {
        let {
    field,Status,CP_ID
  } = req.body;
 
    const pool = await sql.connect(conConfig);
 
    const insertQuery = `
      update [TRAIL_PRODUCTION_STATUS] set ${field}=@Status where CP_ID=@CP_ID`;
    await pool
    .request()
    .input("Status", sql.Int, Status)
    .input("CP_ID", sql.VarChar, CP_ID)
    .query(insertQuery);
     
     
    res.status(200).json({ message: "Data inserted successfully" });
  } catch (error) {
    console.error("Insert Error:", error);
    res.status(500).json({ error: "Failed to insert data" });
  }
};
 

export const getallstatusbypackageid = async (req, res) => {
  try {
    // Get cp_id from body (case-insensitive)
    let cp_id = req.body.cp_id || req.body.CP_ID;

    if (!cp_id || typeof cp_id !== "string") {
      return res.status(400).json({ error: "cp_id is required" });
    }

    cp_id = cp_id.trim().toUpperCase(); // Normalize

    const pool = await sql.connect(conConfig);

    const getStatusQuery = (table) => `
      SELECT TOP 1 * 
      FROM [PDM].[dbo].[${table}]
      WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @cp_id
    `;

    // --- Fetch ECN/STI record ---
    const ecnStiResult = await pool
      .request()
      .input("cp_id", sql.VarChar, cp_id)
      .query(getStatusQuery("ECN/STI"));

    let ecnStiRecord = ecnStiResult.recordset[0] || null;

    // --- Calculate Closure_Target_Date & Status ---
    if (ecnStiRecord && ecnStiRecord.ECN_STI_Type === "STI" && ecnStiRecord.STI_From_Date !== null) {
      const categoryId = ecnStiRecord.Change_Note_Cateogry_ID;
      let daysToAdd = null;

      if (categoryId === 1) {
        daysToAdd = 90;
      } else if (categoryId === 2) {
        daysToAdd = 14;
      } else if (categoryId === 3) {
        daysToAdd = 70;
      }

      if (daysToAdd !== null) {
        // ✅ Base calculation on STI_From_Date
        const calculatedDate = addBusinessDays(ecnStiRecord.STI_From_Date, daysToAdd);

        // ✅ Determine CN/STI Status (only 2 outcomes)
        let cnStatus = null;
        if (ecnStiRecord.Actual_Closure_Date) {
          if (calculatedDate < ecnStiRecord.Actual_Closure_Date) {
            cnStatus = "delay";
          } else {
            cnStatus = "ontime";
          }
        }

        // ✅ Update database
        const updateQuery = `
          UPDATE [dbo].[ECN/STI]
          SET [Closure_Target_Date] = @Closure_Target_Date,
              [CN/STI Status] = @CNStatus
          WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID
        `;

        await pool
          .request()
          .input("Closure_Target_Date", sql.DateTime, calculatedDate)
          .input("CNStatus", sql.VarChar, cnStatus)
          .input("CP_ID", sql.VarChar, cp_id)
          .query(updateQuery);

        // ✅ Update record for response
        ecnStiRecord.Closure_Target_Date = calculatedDate;
        ecnStiRecord["CN/STI Status"] = cnStatus;
      }
    }

    // --- Fetch other statuses ---
    const trailProdResult = await pool
      .request()
      .input("cp_id", sql.VarChar, cp_id)
      .query(getStatusQuery("TRAIL_PRODUCTION_STATUS"));

    const preImplResult = await pool
      .request()
      .input("cp_id", sql.VarChar, cp_id)
      .query(getStatusQuery("PRE_IMPLEMENTATION_STATUS"));

    const postImplResult = await pool
      .request()
      .input("cp_id", sql.VarChar, cp_id)
      .query(getStatusQuery("POST_IMPLEMENTATION_STATUS"));

    // --- Build response ---
    const response = {
      ecn_sti: ecnStiRecord,
      trail_production_status: trailProdResult.recordset[0] || null,
      pre_implementation_status: preImplResult.recordset[0] || null,
      post_implementation_status: postImplResult.recordset[0] || null,
    };

    res.status(200).json(response);
  } catch (error) {
    console.error("Error in getallstatusbypackageid:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// --- Helper function to add business days (excluding weekends) ---
function addBusinessDays(startDate, daysToAdd) {
  let date = new Date(startDate);
  let added = 0;

  while (added < daysToAdd) {
    date.setDate(date.getDate() + 1);
    const dayOfWeek = date.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      added++;
    }
  }

  return date;
}





export const addECNbyexcel = async (req, res) => {
  try {
    const data = Array.isArray(req.body) ? req.body : [req.body]; // Handle both single object and array
    const insertedRecords = [];

    const pool = await sql.connect(conConfig);

    for (const item of data) {
      const {
        Change_Note_Cateogry,
        CP_ID,
        ECN_STI_Number,
        Receieved_Date,
        Product_Family,
        Product_Sale_code,
        Product_Name,
        Category,
        Brief_Details
      } = item;

      // Insert into ECN/STI table
      const insertECNQuery = `
        INSERT INTO [dbo].[ECN/STI] (
          [Change_Note_Cateogry],
          [CP_ID],
          [ECN_STI_Number],
          [Receieved_Date],
          [Product_Family],
          [Product_Sale_code],
          [Product_Name],
          [Category],
          [Brief_Details]
        )
        OUTPUT INSERTED.*
        VALUES (
          @Change_Note_Cateogry,
          @CP_ID,
          @ECN_STI_Number,
          @Receieved_Date,
          @Product_Family,
          @Product_Sale_code,
          @Product_Name,
          @Category,
          @Brief_Details
        )`;

      const result = await pool
        .request()
        .input("Change_Note_Cateogry", sql.VarChar, Change_Note_Cateogry || null)
        .input("CP_ID", sql.VarChar, CP_ID || null)
        .input("ECN_STI_Number", sql.VarChar, ECN_STI_Number || null)
        .input("Receieved_Date", sql.DateTime, Receieved_Date ? new Date(Receieved_Date) : null)
        .input("Product_Family", sql.VarChar, Product_Family || null)
        .input("Product_Sale_code", sql.VarChar, Product_Sale_code || null)
        .input("Product_Name", sql.VarChar, Product_Name || null)
        .input("Category", sql.VarChar, Category || null)
        .input("Brief_Details", sql.VarChar, Brief_Details || null)
        .query(insertECNQuery);

      // Save the result
      if (result.recordset && result.recordset.length > 0) {
        insertedRecords.push(result.recordset[0]);
      }

      // Insert into the 3 additional status tables with only CP_ID
      const statusTables = [
        "POST_IMPLEMENTATION_STATUS",
        "PRE_IMPLEMENTATION_STATUS",
        "TRAIL_PRODUCTION_STATUS"
      ];

      for (const table of statusTables) {
        const statusInsertQuery = `
          INSERT INTO [dbo].[${table}] ([CP_ID])
          VALUES (@CP_ID)
        `;
        await pool.request()
          .input("CP_ID", sql.VarChar, CP_ID || null)
          .query(statusInsertQuery);
      }
    }

    res.status(200).json({
      message: "Data inserted successfully into ECN and status tables.",
      insertedRecords
    });
  } catch (error) {
    console.error("Insert Error:", error);
    res.status(500).json({
      error: "Failed to insert data",
      details: error.message
    });
  }
};



export const TrailStatusSearch = async (req, res) => {
  try {
    const { search } = req.body; // input field for CP_ID or Product_Name

    const pool = await sql.connect(conConfig);

    let query = `
      SELECT B.[Category],
             B.[CP_ID],
             B.[ECN_STI_Number],
             B.[Product_Family],
             B.[Product_Name],
             A.[PDM],
             A.[MM_Buyer],
             A.[MM_logistics],
             A.[SQA],
             A.[WH],
             A.[MC],
             A.[SMT],
             A.[MS_SMT],
             A.[MS_IE],
             A.[MS_TEST],
             A.[MS_PT],
             A.[MS_PE],
             A.[MS_IT],
             A.[OPS]
        FROM [PDM].[dbo].[TRAIL_PRODUCTION_STATUS] A
        JOIN [PDM].[dbo].[ECN/STI] B ON A.CP_ID = B.CP_ID
    `;

    if (search && search.trim() !== "") {
      query += ` WHERE LOWER(B.CP_ID) LIKE LOWER('%${search.trim()}%')
                    OR LOWER(B.Product_Name) LIKE LOWER('%${search.trim()}%')`;
    }

    const result = await pool.request().query(query);
    const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {}, close: {}, inprogress: {}
    };

    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });

    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};

export const postimpSearch = async (req, res) => {
  try {
    const { search } = req.body; // input field for CP_ID or Product_Name

    const pool = await sql.connect(conConfig);

    let query = `
      SELECT B.[Category],
             B.[CP_ID],
             B.[ECN_STI_Number],
             B.[Product_Family],
             B.[Product_Name],
             A.[PDM],
             A.[MM_Buyer],
             A.[MM_logistics],
             A.[SQA],
             A.[WH],
             A.[MC],
             A.[SMT],
             A.[MS_SMT],
             A.[MS_IE],
             A.[MS_TEST],
             A.[MS_PT],
             A.[MS_PE],
             A.[MS_IT],
             A.[OPS]
        FROM [PDM].[dbo].[POST_IMPLEMENTATION_STATUS] A
        JOIN [PDM].[dbo].[ECN/STI] B ON A.CP_ID = B.CP_ID
    `;

    if (search && search.trim() !== "") {
      query += ` WHERE LOWER(B.CP_ID) LIKE LOWER('%${search.trim()}%')
                    OR LOWER(B.Product_Name) LIKE LOWER('%${search.trim()}%')`;
    }

    const result = await pool.request().query(query);
    const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {}, close: {}, inprogress: {}
    };

    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });

    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};


export const preimpSearch = async (req, res) => {
  try {
    const { search } = req.body; // search could be CP_ID or Product_Name

    const pool = await sql.connect(conConfig);

    let query = `
      SELECT B.[Category],
             B.[CP_ID],
             B.[ECN_STI_Number],
             B.[Product_Family],
             B.[Product_Name],
             A.[PDM],
             A.[MM_Buyer],
             A.[MM_logistics],
             A.[SQA],
             A.[WH],
             A.[MC],
             A.[SMT],
             A.[MS_SMT],
             A.[MS_IE],
             A.[MS_TEST],
             A.[MS_PT],
             A.[MS_PE],
             A.[MS_IT],
             A.[OPS]
        FROM [PDM].[dbo].[PRE_IMPLEMENTATION_STATUS] A
        JOIN [PDM].[dbo].[ECN/STI] B ON A.CP_ID = B.CP_ID
    `;

    if (search && search.trim() !== "") {
      query += ` WHERE LOWER(B.CP_ID) LIKE LOWER('%${search.trim()}%') 
                    OR LOWER(B.Product_Name) LIKE LOWER('%${search.trim()}%')`;
    }

    const result = await pool.request().query(query);
    const records = result.recordset;

    const statusFields = [
      "PDM", "MM_Buyer", "MM_logistics", "SQA", "WH", "MC",
      "SMT", "MS_SMT", "MS_IE", "MS_TEST", "MS_PT", "MS_PE",
      "MS_IT", "OPS"
    ];

    const statusCount = {
      open: {}, close: {}, inprogress: {}
    };

    statusFields.forEach(field => {
      statusCount.open[field] = 0;
      statusCount.close[field] = 0;
      statusCount.inprogress[field] = 0;
    });

    records.forEach(row => {
      statusFields.forEach(field => {
        const value = row[field];
        if (value === 0) statusCount.open[field]++;
        else if (value === 1) statusCount.close[field]++;
        else if (value === 2) statusCount.inprogress[field]++;
      });
    });

    res.status(200).json({
      data: records,
      statusCount
    });

  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};

export const addOrUpdateOrDeletePTOComment = async (req, res) => {
  try {
    let { ID, CP_ID, PTO_Comment, Action } = req.body;

    if (!CP_ID || !Action || (Action !== "delete" && !PTO_Comment)) {
      return res.status(400).json({
        error: "CP_ID, PTO_Comment (except for delete), and Action are required"
      });
    }

    if (Action === "edit" || Action === "delete") {
      if (!ID) {
        return res.status(400).json({
          error: "ID is required for edit and delete actions"
        });
      }
    }

    const pool = await sql.connect(conConfig);
    const currentDateTime = new Date();

    // =================== ADD ===================
    if (Action === "add") {
      const existing = await pool.request()
        .input("CP_ID", sql.NVarChar, CP_ID)
        .input("PTO_Comment", sql.NVarChar, PTO_Comment)
        .query(`
          SELECT * FROM [dbo].[PTO_comment]
          WHERE [CP_ID] = @CP_ID AND [PTO Comment] = @PTO_Comment
        `);

      if (existing.recordset.length > 0) {
        return res.status(409).json({ message: "PTO Comment already exists" });
      }

      const query = ID ? 
        `
          INSERT INTO [dbo].[PTO_comment] (
            [Id], [PTO Comment], [Action], [DateTime], [Role], [CP_ID],
            [Team], [RoleId], [edited], [Assign]
          ) VALUES (
            @ID, @PTO_Comment, @Action, @DateTime, @Role, @CP_ID,
            @Team, @RoleId, @edited, @Assign
          )
        ` : 
        `
          INSERT INTO [dbo].[PTO_comment] (
            [PTO Comment], [Action], [DateTime], [Role], [CP_ID],
            [Team], [RoleId], [edited], [Assign]
          ) VALUES (
            @PTO_Comment, @Action, @DateTime, @Role, @CP_ID,
            @Team, @RoleId, @edited, @Assign
          )
        `;

      const request = pool.request()
        .input("PTO_Comment", sql.NVarChar, PTO_Comment)
        .input("Action", sql.NVarChar, Action)
        .input("DateTime", sql.DateTime, currentDateTime)
        .input("Role", sql.NVarChar, null)
        .input("CP_ID", sql.NVarChar, CP_ID)
        .input("Team", sql.NVarChar, null)
        .input("RoleId", sql.Int, null)
        .input("edited", sql.Bit, 0)
        .input("Assign", sql.Bit, 0);

      if (ID) {
        request.input("ID", sql.Int, ID);
      }

      await request.query(query);

      return res.status(201).json({ message: "✅ PTO Comment added successfully" });
    }

    // =================== EDIT ===================
    else if (Action === "edit") {
      const existing = await pool.request()
        .input("CP_ID", sql.NVarChar, CP_ID)
        .input("ID", sql.Int, ID)
        .query(`
          SELECT * FROM [dbo].[PTO_comment]
          WHERE [CP_ID] = @CP_ID AND [Id] = @ID
        `);

      if (existing.recordset.length === 0) {
        return res.status(404).json({ message: "No PTO Comment found to edit for this CP_ID and ID" });
      }

      await pool.request()
        .input("ID", sql.Int, ID)
        .input("PTO_Comment", sql.NVarChar, PTO_Comment)
        .input("DateTime", sql.DateTime, currentDateTime)
        .input("edited", sql.Bit, 1)
        .query(`
          UPDATE [dbo].[PTO_comment]
          SET [PTO Comment] = @PTO_Comment,
              [edited] = @edited,
              [DateTime] = @DateTime
          WHERE Id = @ID
        `);

      return res.status(200).json({ message: "✏️ PTO Comment updated successfully" });
    }

    // =================== DELETE (HARD DELETE) ===================
    else if (Action === "delete") {
      const existing = await pool.request()
        .input("CP_ID", sql.NVarChar, CP_ID)
        .input("ID", sql.Int, ID)
        .query(`
          SELECT * FROM [dbo].[PTO_comment]
          WHERE [CP_ID] = @CP_ID AND [Id] = @ID
        `);

      if (existing.recordset.length === 0) {
        return res.status(404).json({ message: "No PTO Comment found to delete for this CP_ID and ID" });
      }

      // Hard delete - actually remove the record from the database
      await pool.request()
        .input("ID", sql.Int, ID)
        .query(`
          DELETE FROM [dbo].[PTO_comment]
          WHERE Id = @ID
        `);

      return res.status(200).json({ message: "🗑️ PTO Comment deleted successfully" });
    }

    // =================== INVALID ACTION ===================
    else {
      return res.status(400).json({ error: "❌ Invalid action. Use 'add', 'edit', or 'delete'." });
    }

  } catch (error) {
    console.error("❌ PTO comment error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};






export const getPTOComments = async (req, res) => {
  {
    let { CP_ID, ID } = req.body;

    // Validate CP_ID if provided
    if (CP_ID && typeof CP_ID !== 'string') {
      return res.status(400).json({
        error: "CP_ID must be a string (e.g., 'CP1002')"
      });
    }

    // Validate ID if provided
    if (ID && typeof ID !== 'string' && typeof ID !== 'number') {
      return res.status(400).json({
        error: "ID must be a string or number when provided"
      });
    }

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    let query = `
      SELECT
        [Id],
        [PTO Comment] AS comment,
        [Action] AS action,
        [DateTime] AS date,
        [Role] AS role,
        [Team] AS team,
        [RoleId] AS roleId,
        [edited] AS edited,
        [Assign] AS assign,
        [CP_ID] AS cpId
      FROM [dbo].[PTO_comment]
    `;

    let conditions = [];

    if (CP_ID) {
      conditions.push(`[CP_ID] = @CP_ID`);
      request.input("CP_ID", sql.NVarChar, CP_ID);
    }

    if (ID) {
      conditions.push(`[Id] = @ID`);
      request.input("ID", sql.Int, ID);
    }

    if (conditions.length > 0) {
      query += " WHERE " + conditions.join(" AND ");
    }

    query += " ORDER BY [DateTime] DESC;";

    const result = await request.query(query);

  
    res.status(200).json(result.recordset);

  } 
};

// DELETE /deletePackage/:cpId
export const deletePackage = async (req, res) => {
  const { cpId } = req.params;
  try {
    const pool = await sql.connect(conConfig);
    await pool.request()
      .input("CP_ID", sql.VarChar, cpId)
      .query(`
        DELETE FROM [dbo].[ECN/STI] WHERE CP_ID = @CP_ID;
        DELETE FROM [dbo].[PRE_IMPLEMENTATION_STATUS] WHERE CP_ID = @CP_ID;
        DELETE FROM [dbo].[TRAIL_PRODUCTION_STATUS] WHERE CP_ID = @CP_ID;
        DELETE FROM [dbo].[POST_IMPLEMENTATION_STATUS] WHERE CP_ID = @CP_ID;
      `);
    res.status(200).json({ message: 'Package and statuses deleted successfully.' });
  } catch (error) {
    console.error('Delete Error:', error);
    res.status(500).json({ error: 'Deletion failed', details: error.message });
  }
};

export const updateEcnStiRecord = async (req, res) => {
  try {
    let cp_id = req.body.cp_id || req.body.CP_ID;

    if (!cp_id || typeof cp_id !== 'string') {
      return res.status(400).json({ error: "cp_id is required" });
    }

    cp_id = cp_id.trim().toUpperCase();

    const { 
      Actual_Closure_Date, 
      ECN_STI_Notes, 
      Trail_Tentative_Plan_Date, 
      PDM_Action_Owner 
    } = req.body;

    if (!Actual_Closure_Date && !ECN_STI_Notes && !Trail_Tentative_Plan_Date && !PDM_Action_Owner) {
      return res.status(400).json({
        error: "Provide either Actual_Closure_Date, ECN_STI_Notes, Trail_Tentative_Plan_Date, or PDM_Action_Owner to update"
      });
    }

    const pool = await sql.connect(conConfig);

    // Build dynamic update query
    let updateFields = [];
    let request = pool.request().input("CP_ID", sql.VarChar, cp_id);

    if (Actual_Closure_Date) {
      updateFields.push("[Actual_Closure_Date] = @Actual_Closure_Date");
      request.input("Actual_Closure_Date", sql.DateTime, new Date(Actual_Closure_Date));
    }

    if (ECN_STI_Notes) {
      updateFields.push("[ECN/STI_Notes] = @ECN_STI_Notes");
      request.input("ECN_STI_Notes", sql.VarChar, ECN_STI_Notes);
    }

    if (Trail_Tentative_Plan_Date) {
      updateFields.push("[Trail_Tentative_Plan_Date] = @Trail_Tentative_Plan_Date");
      request.input("Trail_Tentative_Plan_Date", sql.DateTime, new Date(Trail_Tentative_Plan_Date));
    }

    if (PDM_Action_Owner) {
      updateFields.push("[PDM_Action_Owner] = @PDM_Action_Owner");
      request.input("PDM_Action_Owner", sql.VarChar, PDM_Action_Owner);
    }

    // First update normal fields
    const updateQuery = `
      UPDATE [PDM].[dbo].[ECN/STI]
      SET ${updateFields.join(", ")}
      WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID
    `;

    const result = await request.query(updateQuery);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: "No record found for given CP_ID" });
    }

    // ✅ Fetch record again to calculate CN/STI Status
    const fetchQuery = `
      SELECT [Closure_Target_Date], [Actual_Closure_Date]
      FROM [PDM].[dbo].[ECN/STI]
      WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID
    `;

    const recordResult = await pool
      .request()
      .input("CP_ID", sql.VarChar, cp_id)
      .query(fetchQuery);

    const record = recordResult.recordset[0];

    if (record && record.Closure_Target_Date && record.Actual_Closure_Date) {
      let cnStatus = null;

      if (record.Closure_Target_Date < record.Actual_Closure_Date) {
        cnStatus = "delay";
      } else {
        cnStatus = "ontime";
      }

      // Update CN/STI Status
      await pool
        .request()
        .input("CP_ID", sql.VarChar, cp_id)
        .input("CNStatus", sql.VarChar, cnStatus)
        .query(`
          UPDATE [PDM].[dbo].[ECN/STI]
          SET [CN/STI Status] = @CNStatus
          WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID
        `);
    }

    res.status(200).json({ message: "Record updated successfully, CN/STI Status recalculated" });
  } catch (error) {
    console.error("Error in updateEcnStiRecord:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};



export const getStatusRecordsByCpId = async (req, res) => {
  try {
    let cp_id = req.body.cp_id || req.body.CP_ID;

    if (!cp_id || typeof cp_id !== "string") {
      return res
        .status(400)
        .json({ error: "cp_id is required and must be a string" });
    }

    cp_id = cp_id.trim().toUpperCase();

    const pool = await sql.connect(conConfig);

    const query = `
      SELECT 
        [ID],
        [Username],
        [Role],
        [UpdatedDateTime],
        [RoleId],
        [OPENSTATUS],
        [Emailid],
        CAST([Assign] AS INT) AS Assign,
        [Team],
        [EmailStatus],
        [CP_ID],
        CAST([Sign_off_Status] AS INT) AS Sign_off_Status,
        [TeamId],
        [ApprovedStatus],
        [ApprovalToken],
        [SignoffApproved]
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID
      ORDER BY UpdatedDateTime DESC
    `;

    const request = pool.request().input("CP_ID", sql.NVarChar, cp_id);
    const result = await request.query(query);

    if (result.recordset.length === 0) {
      return res.status(404).json({
        error: `No records found for CP_ID: ${cp_id}`,
      });
    }

    // Assign and SignOff filters
    let assignRecords = result.recordset.filter((record) => record.Assign === 1);
    let signOffRecords = result.recordset.filter(
      (record) => record.Sign_off_Status === 1
    );

    // Fallback check for boolean true values
    if (assignRecords.length === 0) {
      assignRecords = result.recordset.filter(
        (record) => record.Assign === true
      );
    }
    if (signOffRecords.length === 0) {
      signOffRecords = result.recordset.filter(
        (record) => record.Sign_off_Status === true
      );
    }

    res.status(200).json({
      assignRecords,
      signOffRecords,
      allRecords: result.recordset, // includes ALL fields now
    });
  } catch (error) {
    console.error("Error in getStatusRecordsByCpId:", error.message, error.stack);
    res.status(500).json({ error: "Internal server error" });
  }
};



// Backend: DELETE endpoint for Assign records
export const deleteAssignRecord = async (req, res) => {
  try {
    const { id } = req.params;
    const { CP_ID } = req.body;

    if (!id || !CP_ID) {
      return res.status(400).json({ error: "id and CP_ID are required" });
    }

    const pool = await sql.connect(conConfig);
    const query = `
      DELETE FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID AND UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID AND Assign = 1
    `;
    const request = pool.request()
      .input("ID", sql.Int, id)
      .input("CP_ID", sql.VarChar, CP_ID.trim().toUpperCase());

    const result = await request.query(query);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: "No Assign record found for given ID and CP_ID" });
    }

    res.status(200).json({ message: "Assign record deleted successfully" });
  } catch (error) {
    console.error("Error in deleteAssignRecord:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Backend: DELETE endpoint for Sign-off records
export const deleteSignOffRecord = async (req, res) => {
  try {
    const { id } = req.params;
    const { CP_ID } = req.body;

    if (!id || !CP_ID) {
      return res.status(400).json({ error: "id and CP_ID are required" });
    }

    const pool = await sql.connect(conConfig);
    const query = `
      DELETE FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID AND UPPER(LTRIM(RTRIM([CP_ID]))) = @CP_ID AND Sign_off_Status = 1
    `;
    const request = pool.request()
      .input("ID", sql.Int, id)
      .input("CP_ID", sql.VarChar, CP_ID.trim().toUpperCase());

    const result = await request.query(query);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({ error: "No Sign-off record found for given ID and CP_ID" });
    }

    res.status(200).json({ message: "Sign-off record deleted successfully" });
  } catch (error) {
    console.error("Error in deleteSignOffRecord:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};