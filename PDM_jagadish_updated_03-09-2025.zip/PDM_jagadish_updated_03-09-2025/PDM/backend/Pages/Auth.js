import sql from "mssql";
import { conConfig } from '../DB/db.js';
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import nodemailer from 'nodemailer';


dotenv.config();
const jwtSecret = "TMS";

function getISTDate() {
  const now = new Date();
  const offset = 5.5 * 60 * 60 * 1000;
  return new Date(now.getTime() + offset);
}

export const RegisterUser = async (req, res) => {
  try {
    const username = req.body.username?.replace(/\s+/g, '');
    const password = req.body.password?.replace(/\s+/g, '');
    const roleId = parseInt(req.body.roleid); // now we expect roleid only

    if (!username || !password || !roleId) {
      return res.status(400).send({ error: "All fields are required" });
    }

    const pool = await sql.connect(conConfig);

    // Get RoleName from RoleMaster
    const roleResult = await pool
      .request()
      .input("roleId", sql.Int, roleId)
      .query("SELECT RoleName FROM TeamMaster WHERE RoleId = @roleId");

    if (roleResult.recordset.length === 0) {
      return res.status(400).send({ error: "Invalid RoleId" });
    }

    const roleName = roleResult.recordset[0].RoleName;

    // Check for duplicate username
    const checkUser = await pool
      .request()
      .input("username", sql.NVarChar, username)
      .query("SELECT * FROM Users_PDM WHERE Username = @username");

    if (checkUser.recordset.length > 0) {
      return res.status(409).send({ error: "Username already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user with both RoleId and RoleName
    await pool
      .request()
      .input("username", sql.NVarChar, username)
      .input("password", sql.NVarChar, password)
      .input("role", sql.NVarChar, roleName)
      .input("roleId", sql.Int, roleId)
      .input("updatedDateTime", sql.DateTime, getISTDate())
      .query(`
        INSERT INTO Users_PDM (Username, Password, Role, RoleId, UpdatedDateTime)
        VALUES (@username, @password, @role, @roleId, @updatedDateTime)
      `);

    return res.status(201).send({ message: "User registered successfully" });
  } catch (err) {
    console.error("Registration Error:", err);
    return res.status(500).send({ error: "Internal Server Error" });
  }
};

export const LoginUser = async (req, res) => {
  try {
    const { email } = req.body;

    console.log('Received login request for email:', email); // Debug log

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const pool = await sql.connect(conConfig);

    // First, try to find user with any role (not just 'User')
    const result = await pool.request()
      .input('email', sql.VarChar, email)
      .query(`
        SELECT [Team], [TeamId], [Role], [Email]
        FROM [PDM].[dbo].[Users_PDM] 
        WHERE [Email] = @email
      `);

    console.log('Database query result:', result.recordset); // Debug log

    if (result.recordset.length === 0) {
      // Try with different email formats (in case of domain issues)
      const emailVariations = [
        email.toLowerCase(),
        email.toUpperCase(),
        email.split('@')[0] + '@nokia.com', // If your domain is different
        email.split('@')[0] + '@company.com' // Add your actual domain
      ];

      for (const emailVar of emailVariations) {
        const retryResult = await pool.request()
          .input('email', sql.VarChar, emailVar)
          .query(`
            SELECT [Team], [TeamId], [Role], [Email]
            FROM [PDM].[dbo].[Users_PDM] 
            WHERE [Email] = @email
          `);

        if (retryResult.recordset.length > 0) {
          const userTeam = retryResult.recordset[0];
          console.log('Found user with email variation:', emailVar, userTeam);
          return res.json({
            team: userTeam.Team || 'Default Team',
            teamId: userTeam.TeamId || 1,
            role: userTeam.Role,
            email: userTeam.Email
          });
        }
      }

      return res.status(404).json({
        error: 'User not found in database',
        searchedEmail: email,
        suggestion: 'Please contact administrator to add your email to the system'
      });
    }

    const userTeam = result.recordset[0];

    // Return team data regardless of role
    res.json({
      team: userTeam.Team || 'Default Team',
      teamId: userTeam.TeamId || 1,
      role: userTeam.Role,
      email: userTeam.Email
    });

  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};



export const AssignUser = async (req, res) => {
  try {
    // Check for both username/Username and team/Team to handle case variations
    const username = (req.body.username || req.body.Username)?.replace(/\s+/g, '');
    const password = (req.body.password || req.body.Password)?.replace(/\s+/g, '');
    const team = (req.body.team || req.body.Team)?.trim();

    if (!username && !team) {
      return res.status(400).send({ error: "Username or Team is required" });
    }

    const pool = await sql.connect(conConfig);
    let query = "SELECT * FROM Users_PDM WHERE 1=1";
    const request = pool.request();

    // Handle multiple usernames
    if (username) {
      const usernameArray = username.split(',').map(u => u.trim()).filter(u => u);
      if (usernameArray.length > 0) {
        query += " AND (";
        usernameArray.forEach((u, index) => {
          query += `LOWER(Username) LIKE LOWER(@username${index})`;
          if (index < usernameArray.length - 1) query += " OR ";
          request.input(`username${index}`, sql.NVarChar, `%${u}%`);
        });
        query += ")";
      }
    }

    // Handle multiple teams
    if (team) {
      const teamArray = team.split(',').map(t => t.trim()).filter(t => t);
      if (teamArray.length > 0) {
        query += " AND (";
        teamArray.forEach((t, index) => {
          query += `LOWER(Team) LIKE LOWER(@team${index})`;
          if (index < teamArray.length - 1) query += " OR ";
          request.input(`team${index}`, sql.NVarChar, `%${t}%`);
        });
        query += ")";
      }
    }

    const result = await request.query(query);

    if (result.recordset.length === 0) {
      return res.status(404).send({ error: "No matching user(s) found" });
    }

    // If password is provided, treat it as login
    if (password) {
      const user = result.recordset[0];

      if (password !== user.Password) {
        return res.status(401).send({ error: "Invalid credentials" });
      }

      const token = jwt.sign(
        {
          id: user.ID,
          role: user.Role,
          roleid: user.RoleId
        },
        jwtSecret,
        { expiresIn: "2h" }
      );

      return res.status(200).json({
        token,
        role: user.Role,
        roleid: user.RoleId
      });
    }

    // If password not provided, just return the data
    return res.status(200).json({ users: result.recordset });

  } catch (err) {
    console.error("Login Error:", err);
    return res.status(500).send({ error: "Internal Server Error" });
  }
};
export const getowners = async (req, res) => {
  try {
    const { TeamId } = req.body; // Input: { "TeamId": 2 }

    if (!TeamId) {
      return res.status(400).send({ error: "TeamId is required" });
    }

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    request.input("TeamId", sql.Int, TeamId);
    const result = await request.query(`
      SELECT 
          u.Username,
          u.Email,
          u.RoleId,
          u.Role,
          t.TeamName
      FROM [PDM].[dbo].[Users_PDM] u
      INNER JOIN [PDM].[dbo].[TeamMaster] t
          ON u.TeamId = t.TeamId
      WHERE u.TeamId = @TeamId
    `);

    if (result.recordset.length === 0) {
      return res.status(404).send({ error: "No users found for this team" });
    }

    return res.status(200).json({ users: result.recordset });

  } catch (err) {
    console.error("getowners Error:", err);
    return res.status(500).send({ error: "Internal Server Error" });
  }
};

//--------------------------------------------------------------------------------------------------------------//



export const SignOffUsersFromSTICN = async (req, res) => {
  try {
    const username = (req.body.username || req.body.Username)?.replace(/\s+/g, '');
    const cpId = req.body.CP_ID;

    if (!username) {
      return res.status(400).send({ error: "Username is required" });
    }
    if (!cpId) {
      return res.status(400).send({ error: "CP_ID is required" });
    }

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    const usernameArray = username.split(',').map(u => u.trim()).filter(u => u);
    if (usernameArray.length === 0) {
      return res.status(400).send({ error: "At least one valid username is required" });
    }

    let query = "SELECT ID, Username, Role, RoleId, Email, Team FROM Users_PDM WHERE 1=1";
    query += " AND (";
    usernameArray.forEach((u, index) => {
      query += `LOWER(Username) LIKE LOWER(@username${index})`;
      if (index < usernameArray.length - 1) query += " OR ";
      request.input(`username${index}`, sql.NVarChar, `%${u}%`);
    });
    query += ")";

    const result = await request.query(query);

    if (result.recordset.length === 0) {
      return res.status(404).send({ error: "No matching user(s) found" });
    }

    const validTeams = [
      'PDM', 'MM_Buyer', 'MM_logistics', 'SQA', 'WH', 'MC', 'SMT',
      'MS_SMT', 'MS_IE', 'MS_TEST', 'MS_PT', 'MS_PE', 'MS_IT', 'OPS'
    ];

    const processedUsers = [];
    for (const user of result.recordset) {
      const team = user.Team?.trim().replace(/[\s\-]+/g, '_');
      if (!team || !validTeams.includes(team)) {
        console.warn(` or missing team for user ${user.Username}: ${user.Team}`);
        continue;
      }

      const mergeQuery = `
        MERGE INTO [PDM].[dbo].[Assign_STI/CN_Owners] AS target
        USING (SELECT @Username AS Username, @CP_ID AS CP_ID) AS source
        ON target.Username = source.Username AND target.CP_ID = source.CP_ID
        WHEN MATCHED THEN
          UPDATE SET
            Role = @Role,
            RoleId = @RoleId,
            Emailid = @Email,
            Team = @Team,
            UpdatedDateTime = GETDATE(),
            OPENSTATUS = @OPENSTATUS,
            Assign = @Assign,
            EmailStatus = @EmailStatus,
            Sign_off_Status = @SignOffStatus,
            CP_ID = @CP_ID
        WHEN NOT MATCHED THEN
          INSERT (Username, Role, RoleId, Emailid, Team, UpdatedDateTime, OPENSTATUS, Assign, EmailStatus, Sign_off_Status, CP_ID)
          VALUES (@Username, @Role, @RoleId, @Email, @Team, GETDATE(), @OPENSTATUS, @Assign, @EmailStatus, @SignOffStatus, @CP_ID);
      `;

      const mergeRequest = pool.request();
      mergeRequest.input('Username', sql.NVarChar, user.Username);
      mergeRequest.input('Role', sql.NVarChar, user.Role);
      mergeRequest.input('RoleId', sql.Int, user.RoleId);
      mergeRequest.input('Email', sql.NVarChar, user.Email);
      mergeRequest.input('Team', sql.NVarChar, user.Team);
      mergeRequest.input('OPENSTATUS', sql.Bit, 1);
      mergeRequest.input('Assign', sql.Bit, 0);
      mergeRequest.input('EmailStatus', sql.Bit, 0);
      mergeRequest.input('SignOffStatus', sql.Bit, 1);
      mergeRequest.input('CP_ID', sql.NVarChar, cpId);

      await mergeRequest.query(mergeQuery);

      processedUsers.push({
        ID: user.ID,
        Username: user.Username,
        Role: user.Role,
        RoleId: user.RoleId,
        Email: user.Email,
        Team: user.Team,
        CP_ID: cpId
      });
    }

    if (processedUsers.length === 0) {
      return res.status(404).send({ error: "No users with valid teams found" });
    }

    return res.status(200).json({
      message: "Users signed off successfully",
      users: processedUsers
    });

  } catch (err) {
    console.error("SignOffUsersFromSTICN Error:", err);
    return res.status(500).send({ error: "Internal Server Error" });
  }
};
export const AssignUsersToSTICN = async (req, res) => {
  try {
    const username = (req.body.username || req.body.Username)?.replace(/\s+/g, '');
    const cpId = req.body.CP_ID;

    if (!username) {
      return res.status(400).send({ error: "Username is required" });
    }
    if (!cpId) {
      return res.status(400).send({ error: "CP_ID is required" });
    }

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    const usernameArray = username.split(',').map(u => u.trim()).filter(u => u);
    if (usernameArray.length === 0) {
      return res.status(400).send({ error: "At least one valid username is required" });
    }

    let query = "SELECT ID, Username, Role, RoleId, Email, Team FROM Users_PDM WHERE 1=1";
    query += " AND (";
    usernameArray.forEach((u, index) => {
      query += `LOWER(Username) LIKE LOWER(@username${index})`;
      if (index < usernameArray.length - 1) query += " OR ";
      request.input(`username${index}`, sql.NVarChar, `%${u}%`);
    });
    query += ")";

    const result = await request.query(query);

    if (result.recordset.length === 0) {
      return res.status(404).send({ error: "No matching user(s) found" });
    }

    const validTeams = [
      'PDM', 'MM_Buyer', 'MM_logistics', 'SQA', 'WH', 'MC', 'SMT',
      'MS_SMT', 'MS_IE', 'MS_TEST', 'MS_PT', 'MS_PE', 'MS_IT', 'OPS'
    ];

    const processedUsers = [];
    for (const user of result.recordset) {
      const team = user.Team?.trim().replace(/[\s\-]+/g, '_');
      if (!team || !validTeams.includes(team)) {
        console.warn(`Invalid or missing team for user ${user.Username}: ${user.Team}`);
        continue;
      }

      // 🔹 Get TeamId from TeamMaster
      const teamIdQuery = `
        SELECT TeamId FROM [PDM].[dbo].[TeamMaster] WHERE TeamName = @TeamName
      `;
      const teamReq = pool.request();
      teamReq.input('TeamName', sql.NVarChar, user.Team);
      const teamRes = await teamReq.query(teamIdQuery);

      if (teamRes.recordset.length === 0) {
        console.warn(`No TeamId found for team ${user.Team}`);
        continue;
      }
      const teamId = teamRes.recordset[0].TeamId;

      // 🔹 Reset in status tables
      const statusTables = [
        '[PDM].[dbo].[TRAIL_PRODUCTION_STATUS]',
        '[PDM].[dbo].[PRE_IMPLEMENTATION_STATUS]',
        '[PDM].[dbo].[POST_IMPLEMENTATION_STATUS]'
      ];

      for (const table of statusTables) {
        const updateQuery = `UPDATE ${table} SET ${team} = 0 WHERE CP_ID = @CP_ID`;
        const updateRequest = pool.request();
        updateRequest.input('CP_ID', sql.NVarChar, cpId);
        await updateRequest.query(updateQuery);
      }

      // 🔹 Insert/Update in Assign_STI/CN_Owners including TeamId
      const mergeQuery = `
        MERGE INTO [PDM].[dbo].[Assign_STI/CN_Owners] AS target
        USING (SELECT @Username AS Username, @CP_ID AS CP_ID) AS source
        ON target.Username = source.Username AND target.CP_ID = source.CP_ID
        WHEN MATCHED THEN
          UPDATE SET
            Role = @Role,
            RoleId = @RoleId,
            Emailid = @Email,
            Team = @Team,
            TeamId = @TeamId,
            UpdatedDateTime = GETDATE(),
            OPENSTATUS = @OPENSTATUS,
            Assign = @Assign,
            EmailStatus = @EmailStatus,
            Sign_off_Status = CASE WHEN @Assign = 1 THEN 0 ELSE target.Sign_off_Status END,
            CP_ID = @CP_ID
        WHEN NOT MATCHED THEN
          INSERT (Username, Role, RoleId, Emailid, Team, TeamId, UpdatedDateTime, OPENSTATUS, Assign, EmailStatus, Sign_off_Status, CP_ID)
          VALUES (@Username, @Role, @RoleId, @Email, @Team, @TeamId, GETDATE(), @OPENSTATUS, @Assign, @EmailStatus, 0, @CP_ID);
      `;

      const mergeRequest = pool.request();
      mergeRequest.input('Username', sql.NVarChar, user.Username);
      mergeRequest.input('Role', sql.NVarChar, user.Role);
      mergeRequest.input('RoleId', sql.Int, user.RoleId);
      mergeRequest.input('Email', sql.NVarChar, user.Email);
      mergeRequest.input('Team', sql.NVarChar, user.Team);
      mergeRequest.input('TeamId', sql.Int, teamId);
      mergeRequest.input('OPENSTATUS', sql.Bit, 1);
      mergeRequest.input('Assign', sql.Bit, 1);
      mergeRequest.input('EmailStatus', sql.Bit, 0);
      mergeRequest.input('CP_ID', sql.NVarChar, cpId);

      await mergeRequest.query(mergeQuery);

      processedUsers.push({
        ID: user.ID,
        Username: user.Username,
        Role: user.Role,
        RoleId: user.RoleId,
        Email: user.Email,
        Team: user.Team,
        TeamId: teamId,
        CP_ID: cpId
      });
    }

    if (processedUsers.length === 0) {
      return res.status(404).send({ error: "No users with valid teams found" });
    }

    return res.status(200).json({
      message: "Users assigned and status tables updated successfully",
      users: processedUsers
    });

  } catch (err) {
    console.error("AssignUsersAndUpdateStatus Error:", err);
    return res.status(500).send({ error: "Internal Server Error" });
  }
};

export const SendSignOffEmailsAndUpdateStatus = async (req, res) => {
  try {
    const transporter = nodemailer.createTransport({
      host: 'mailrelay.int.nokia.com',
      port: 25,
      secure: false,
    });

    const pool = await sql.connect(conConfig);
    const query = `
      SELECT ID, Username, Emailid, Team, CP_ID
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE EmailStatus = 0 AND Sign_off_Status = 1
    `;
    const result = await pool.request().query(query);

    if (result.recordset.length === 0) {
      return res.status(200).json({ message: 'No users with Sign_off_Status = 1 and EmailStatus = 0 found' });
    }

    const processedUsers = [];
    const failedUsers = [];

    for (const user of result.recordset) {
      try {
        // Create approval URL for frontend with query parameters
        const approvalUrl = `http://localhost:3000/pdm/login`;

        // HTML email content with approval button
        const htmlContent = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Sign-Off Notification</title>
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0; font-size: 24px;">STI/CN Sign-Off Notification</h1>
            </div>
            <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #ddd;">
              <h2 style="color: #333; margin-top: 0;">Dear ${user.Username},</h2>
              <p style="font-size: 16px; margin-bottom: 20px;">
                You have been signed off from the <strong>${user.Team}</strong> team in the STI/CN system for 
                <strong>CP_ID: ${user.CP_ID}</strong>.
              </p>
              <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h4 style="margin-top: 0; color: #1976d2;">Sign-Off Details:</h4>
                <ul style="margin: 10px 0; padding-left: 20px;">
                  <li><strong>Username:</strong> ${user.Username}</li>
                  <li><strong>Team:</strong> ${user.Team}</li>
                  <li><strong>CP_ID:</strong> ${user.CP_ID}</li>
                </ul>
              </div>
              <div style="text-align: center; margin: 20px 0;">
                <!-- Show the raw URL -->
                <p style="font-size: 14px; color: #555; margin-bottom: 10px;">
                  Approval URL: <a href="${approvalUrl}" style="color: #8A2BE2; text-decoration: underline;">${approvalUrl}</a>
                </p>
                <!-- Instruction text -->
                <p style="font-size: 16px; color: #333; font-weight: bold; margin-bottom: 15px;">
                  Click below to approve your Sign-Off Acknowledgement:
                </p>
                <!-- Styled Button -->
                <a href="${approvalUrl}" 
                   style="background: linear-gradient(135deg, #dd1515ff 1000%, #6A0DAD 100%);
                          color: white;
                          padding: 16px 40px;
                          border-radius: 30px;
                          font-size: 18px;
                          font-weight: bold;
                          text-decoration: none;
                          box-shadow: 0 6px 12px rgba(0,0,0,0.25);
                          display: inline-block;
                          transition: background 0.3s ease;
                          letter-spacing: 1px;">
                  🚨 APPROVE SIGN-OFF
                </a>
              </div>
              <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
              <p style="font-size: 14px; color: #666; text-align: center;">
                Best regards,<br>
                <strong>STI/CN Support Team</strong><br>
                Nokia PDM System
              </p>
            </div>
          </body>
          </html>
        `;

        const mailOptions = {
          from: 'support.int@nokia.com',
          to: user.Emailid,
          subject: `STI/CN Sign-Off Notification - Action Required (CP_ID: ${user.CP_ID})`,
          html: htmlContent,
          text: `Dear ${user.Username},

You have been signed off from the ${user.Team} team in the STI/CN system for CP_ID: ${user.CP_ID}.

Please approve your sign-off by visiting: ${approvalUrl}

Sign-Off Details:
- Username: ${user.Username}
- Team: ${user.Team}
- CP_ID: ${user.CP_ID}
- Assignment ID: ${user.ID}

Best regards,
STI/CN Support Team`,
        };

        await transporter.sendMail(mailOptions);

        const updateQuery = `
          UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
          SET EmailStatus = 1, UpdatedDateTime = GETDATE()
          WHERE ID = @ID
        `;
        const updateRequest = pool.request();
        updateRequest.input('ID', sql.Int, user.ID);
        await updateRequest.query(updateQuery);

        processedUsers.push({
          ID: user.ID,
          Username: user.Username,
          Emailid: user.Emailid,
          Team: user.Team,
          CP_ID: user.CP_ID,
          approvalUrl: approvalUrl,
        });
      } catch (emailErr) {
        console.error(`Failed to send sign-off email for user ${user.Username}:`, emailErr);
        failedUsers.push({
          ID: user.ID,
          Username: user.Username,
          Emailid: user.Emailid,
          Team: user.Team,
          error: emailErr.message,
        });
      }
    }

    return res.status(200).json({
      message: processedUsers.length > 0
        ? 'Sign-off emails sent and statuses updated successfully'
        : 'No emails sent successfully',
      processedUsers,
      failedUsers,
    });
  } catch (err) {
    console.error('SendSignOffEmailsAndUpdateStatus Error:', err);
    return res.status(500).send({ error: 'Internal Server Error' });
  }
};

// New endpoint to show sign-off confirmation page
export const showSignOffConfirmation = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Invalid Request</h2>
          <p>Sign-Off ID is required.</p>
        </body>
        </html>
      `);
    }

    const pool = await sql.connect(conConfig);
    const checkQuery = `
      SELECT ID, Username, Team, CP_ID, SignoffApproved, Emailid
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, parseInt(id));
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Sign-Off Not Found</h2>
          <p>The sign-off with ID ${id} was not found.</p>
        </body>
        </html>
      `);
    }

    const signOff = checkResult.recordset[0];

    if (signOff.SignoffApproved === 1) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Already Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5;">
          <div style="background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto;">
            <h2 style="color: #ff9800;">⚠️ Already Approved</h2>
            <p style="font-size: 16px; color: #666;">
              Dear <strong>${signOff.Username}</strong>,<br><br>
              Your sign-off from the <strong>${signOff.Team}</strong> team 
              for <strong>CP_ID: ${signOff.CP_ID}</strong> has already been approved.
            </p>
            <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <p style="color: #4caf50; margin: 0;">✓ Status: Already Approved</p>
            </div>
          </div>
        </body>
        </html>
      `);
    }

    // Confirmation page with Approve button
    return res.status(200).send(`
      <html>
      <head>
        <meta charset="utf-8">
        <title>Confirm Sign-Off</title>
      </head>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0;">
        <div style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); max-width: 500px; margin: 0 auto;">
          <h2 style="color: #333;">Confirm Sign-Off</h2>
          <p style="font-size: 16px; color: #666;">
            Dear <strong>${signOff.Username}</strong>,<br><br>
            Please confirm your sign-off from the <strong>${signOff.Team}</strong> team 
            for <strong>CP_ID: ${signOff.CP_ID}</strong>.
          </p>
          <div style="text-align: left; background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #333;">Sign-Off Details:</h3>
            <p style="margin: 5px 0;"><strong>Username:</strong> ${signOff.Username}</p>
            <p style="margin: 5px 0;"><strong>Team:</strong> ${signOff.Team}</p>
            <p style="margin: 5px 0;"><strong>CP_ID:</strong> ${signOff.CP_ID}</p>
            <p style="margin: 5px 0;"><strong>Email:</strong> ${signOff.Emailid}</p>
          </div>
          <div style="text-align: center; margin: 20px 0;">
            <button onclick="approveSignOff(${signOff.ID})"
                    style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                           color: white;
                           padding: 16px 40px;
                           border-radius: 30px;
                           font-size: 18px;
                           font-weight: bold;
                           border: none;
                           cursor: pointer;
                           box-shadow: 0 6px 12px rgba(0,0,0,0.25);
                           transition: background 0.3s ease;">
              🚨 CONFIRM SIGN-OFF
            </button>
          </div>
          <script>
            async function approveSignOff(userId) {
              const button = document.querySelector('button');
              button.innerHTML = '⏳ APPROVING...';
              button.disabled = true;
              button.style.background = '#ffa726';
              button.style.cursor = 'not-allowed';

              try {
                const response = await fetch('/PDM_API/approveSignOff/' + userId, {
                  method: 'GET',
                });
                if (response.ok) {
                  button.innerHTML = '✅ APPROVED';
                  button.style.background = '#4caf50';
                  button.style.cursor = 'default';
                  const successMsg = document.createElement('div');
                  successMsg.innerHTML = '<p style="color: #4caf50; font-weight: bold; text-align: center; margin-top: 10px;">Sign-off approved successfully!</p>';
                  button.parentNode.appendChild(successMsg);
                } else {
                  throw new Error('Failed to approve');
                }
              } catch (error) {
                button.innerHTML = '❌ ERROR - TRY AGAIN';
                button.disabled = false;
                button.style.background = '#f44336';
                button.style.cursor = 'pointer';
                setTimeout(() => {
                  button.innerHTML = '🚨 CONFIRM SIGN-OFF';
                  button.style.background = 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)';
                }, 3000);
              }
            }
          </script>
        </div>
      </body>
      </html>
    `);
  } catch (err) {
    console.error('ShowSignOffConfirmation Error:', err);
    return res.status(500).send(`
      <html>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
        <h2 style="color: #f44336;">❌ Server Error</h2>
        <p>An internal server error occurred. Please try again later.</p>
        <p style="font-size: 12px; color: #999;">Error: ${err.message}</p>
      </body>
      </html>
    `);
  }
};

// Approve sign-off endpoint
export const approveSignOff = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Invalid Request</h2>
          <p>Sign-Off ID is required.</p>
        </body>
        </html>
      `);
    }

    const pool = await sql.connect(conConfig);
    const checkQuery = `
      SELECT ID, Username, Team, CP_ID, SignoffApproved, Emailid
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, parseInt(id));
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Sign-Off Not Found</h2>
          <p>The sign-off with ID ${id} was not found.</p>
        </body>
        </html>
      `);
    }

    const signOff = checkResult.recordset[0];

    if (signOff.SignoffApproved === 1) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Already Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5;">
          <div style="background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto;">
            <h2 style="color: #ff9800;">⚠️ Already Approved</h2>
            <p style="font-size: 16px; color: #666;">
              Dear <strong>${signOff.Username}</strong>,<br><br>
              Your sign-off from the <strong>${signOff.Team}</strong> team 
              for <strong>CP_ID: ${signOff.CP_ID}</strong> has already been approved.
            </p>
            <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <p style="color: #4caf50; margin: 0;">✓ Status: Already Approved</p>
            </div>
          </div>
        </body>
        </html>
      `);
    }

    const updateQuery = `
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET SignoffApproved = 1, UpdatedDateTime = GETDATE()
      WHERE ID = @ID
    `;
    const updateRequest = pool.request();
    updateRequest.input('ID', sql.Int, parseInt(id));
    const updateResult = await updateRequest.query(updateQuery);

    if (updateResult.rowsAffected[0] > 0) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Sign-Off Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0;">
          <div style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); max-width: 500px; margin: 0 auto;">
            <div style="margin-bottom: 30px;">
              <div style="width: 80px; height: 80px; background: #4caf50; border-radius: 50%; margin: 0 auto 20px auto; display: flex; align-items: center; justify-content: center;">
                <span style="color: white; font-size: 40px;">✓</span>
              </div>
              <h1 style="color: #4caf50; margin: 0;">Sign-Off Approved!</h1>
            </div>
            <div style="text-align: left; background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #333;">Sign-Off Details:</h3>
              <p style="margin: 5px 0;"><strong>Username:</strong> ${signOff.Username}</p>
              <p style="margin: 5px 0;"><strong>Team:</strong> ${signOff.Team}</p>
              <p style="margin: 5px 0;"><strong>CP_ID:</strong> ${signOff.CP_ID}</p>
              <p style="margin: 5px 0;"><strong>Email:</strong> ${signOff.Emailid}</p>
              <p style="margin: 5px 0;"><strong>Status:</strong> <span style="color: #4caf50; font-weight: bold;">✓ Approved</span></p>
            </div>
            <p style="color: #666; font-size: 14px;">
              Thank you for approving your sign-off. You can now close this window.
            </p>
          </div>
        </body>
        </html>
      `);
    } else {
      return res.status(500).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Update Failed</h2>
          <p>Failed to update the sign-off status. Please try again.</p>
        </body>
        </html>
      `);
    }
  } catch (err) {
    console.error('ApproveSignOff Error:', err);
    return res.status(500).send(`
      <html>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
        <h2 style="color: #f44336;">❌ Server Error</h2>
        <p>An internal server error occurred. Please try again later.</p>
        <p style="font-size: 12px; color: #999;">Error: ${err.message}</p>
      </body>
      </html>
    `);
  }
};

export const SendEmailsAndUpdateStatus = async (req, res) => {
  try {
    const transporter = nodemailer.createTransport({
      host: 'mailrelay.int.nokia.com',
      port: 25,
      secure: false,
    });

    const pool = await sql.connect(conConfig);
    const query = `
      SELECT ID, Username, Emailid, Team, CP_ID
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE EmailStatus = 0
    `;
    const result = await pool.request().query(query);

    if (result.recordset.length === 0) {
      return res.status(200).json({ message: 'No users with EmailStatus = 0 found' });
    }

    const processedUsers = [];
    const failedUsers = [];

    for (const user of result.recordset) {
      try {
        // Create approval URL for frontend with query parameters
        const approvalUrl = `http://localhost:3000/pdm/login`;

        // HTML email content with approval button
        const htmlContent = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Assignment Notification</title>
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0; font-size: 24px;">STI/CN Assignment Notification</h1>
            </div>
            <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; border: 1px solid #ddd;">
              <h2 style="color: #333; margin-top: 0;">Dear ${user.Username},</h2>
              <p style="font-size: 16px; margin-bottom: 20px;">
                You have been assigned to the <strong>${user.Team}</strong> team in the STI/CN system for 
                <strong>CP_ID: ${user.CP_ID}</strong>.
              </p>
              <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h4 style="margin-top: 0; color: #1976d2;">Assignment Details:</h4>
                <ul style="margin: 10px 0; padding-left: 20px;">
                  <li><strong>Username:</strong> ${user.Username}</li>
                  <li><strong>Team:</strong> ${user.Team}</li>
                  <li><strong>CP_ID:</strong> ${user.CP_ID}</li>
                </ul>
              </div>
              <div style="text-align: center; margin: 20px 0;">
                <!-- Show the raw URL -->
                <p style="font-size: 14px; color: #555; margin-bottom: 10px;">
                  Approval URL: <a href="${approvalUrl}" style="color: #8A2BE2; text-decoration: underline;">${approvalUrl}</a>
                </p>
                <!-- Instruction text -->
                <p style="font-size: 16px; color: #333; font-weight: bold; margin-bottom: 15px;">
                  Click below to approve your Assignment Acknowledgement:
                </p>
                <!-- Styled Button -->
                <a href="${approvalUrl}" 
                   style="background: linear-gradient(135deg, #ed1313ff 10000%, #6A0DAD 100%);
                          color: white;
                          padding: 16px 40px;
                          border-radius: 30px;
                          font-size: 18px;
                          font-weight: bold;
                          text-decoration: none;
                          box-shadow: 0 6px 12px rgba(0,0,0,0.25);
                          display: inline-block;
                          transition: background 0.3s ease;
                          letter-spacing: 1px;">
                  🚨 APPROVE ASSIGNMENT
                </a>
              </div>
              <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
              <p style="font-size: 14px; color: #666; text-align: center;">
                Best regards,<br>
                <strong>STI/CN Support Team</strong><br>
                Nokia PDM System
              </p>
            </div>
          </body>
          </html>
        `;

        const mailOptions = {
          from: 'support.int@nokia.com',
          to: user.Emailid,
          subject: `STI/CN Assignment Notification - Action Required (CP_ID: ${user.CP_ID})`,
          html: htmlContent,
          text: `Dear ${user.Username},

You have been assigned to the ${user.Team} team in the STI/CN system for CP_ID: ${user.CP_ID}.

Please approve your assignment by visiting: ${approvalUrl}

Assignment Details:
- Username: ${user.Username}
- Team: ${user.Team}
- CP_ID: ${user.CP_ID}
- Assignment ID: ${user.ID}

Best regards,
STI/CN Support Team`,
        };

        await transporter.sendMail(mailOptions);

        const updateQuery = `
          UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
          SET EmailStatus = 1, UpdatedDateTime = GETDATE()
          WHERE ID = @ID
        `;
        const updateRequest = pool.request();
        updateRequest.input('ID', sql.Int, user.ID);
        await updateRequest.query(updateQuery);

        processedUsers.push({
          ID: user.ID,
          Username: user.Username,
          Emailid: user.Emailid,
          Team: user.Team,
          CP_ID: user.CP_ID,
          approvalUrl: approvalUrl,
        });
      } catch (emailErr) {
        console.error(`Failed to send email for user ${user.Username}:`, emailErr);
        failedUsers.push({
          ID: user.ID,
          Username: user.Username,
          Emailid: user.Emailid,
          Team: user.Team,
          error: emailErr.message,
        });
      }
    }

    return res.status(200).json({
      message: processedUsers.length > 0
        ? 'Emails sent and statuses updated successfully'
        : 'No emails sent successfully',
      processedUsers,
      failedUsers,
    });
  } catch (err) {
    console.error('SendEmailsAndUpdateStatus Error:', err);
    return res.status(500).send({ error: 'Internal Server Error' });
  }
};

// New endpoint to show assignment confirmation page
export const showAssignmentConfirmation = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Invalid Request</h2>
          <p>Assignment ID is required.</p>
        </body>
        </html>
      `);
    }

    const pool = await sql.connect(conConfig);
    const checkQuery = `
      SELECT ID, Username, Team, CP_ID, ApprovedStatus, Emailid
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, parseInt(id));
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Assignment Not Found</h2>
          <p>The assignment with ID ${id} was not found.</p>
        </body>
        </html>
      `);
    }

    const assignment = checkResult.recordset[0];

    if (assignment.ApprovedStatus === 1) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Already Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5;">
          <div style="background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto;">
            <h2 style="color: #ff9800;">⚠️ Already Approved</h2>
            <p style="font-size: 16px; color: #666;">
              Dear <strong>${assignment.Username}</strong>,<br><br>
              Your assignment to the <strong>${assignment.Team}</strong> team 
              for <strong>CP_ID: ${assignment.CP_ID}</strong> has already been approved.
            </p>
            <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <p style="color: #4caf50; margin: 0;">✓ Status: Already Approved</p>
            </div>
          </div>
        </body>
        </html>
      `);
    }

    // Confirmation page with Approve button
    return res.status(200).send(`
      <html>
      <head>
        <meta charset="utf-8">
        <title>Confirm Assignment</title>
      </head>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0;">
        <div style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); max-width: 500px; margin: 0 auto;">
          <h2 style="color: #333;">Confirm Assignment</h2>
          <p style="font-size: 16px; color: #666;">
            Dear <strong>${assignment.Username}</strong>,<br><br>
            Please confirm your assignment to the <strong>${assignment.Team}</strong> team 
            for <strong>CP_ID: ${assignment.CP_ID}</strong>.
          </p>
          <div style="text-align: left; background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #333;">Assignment Details:</h3>
            <p style="margin: 5px 0;"><strong>Username:</strong> ${assignment.Username}</p>
            <p style="margin: 5px 0;"><strong>Team:</strong> ${assignment.Team}</p>
            <p style="margin: 5px 0;"><strong>CP_ID:</strong> ${assignment.CP_ID}</p>
            <p style="margin: 5px 0;"><strong>Email:</strong> ${assignment.Emailid}</p>
          </div>
          <div style="text-align: center; margin: 20px 0;">
            <button onclick="approveAssignment(${assignment.ID})"
                    style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                           color: white;
                           padding: 16px 40px;
                           border-radius: 30px;
                           font-size: 18px;
                           font-weight: bold;
                           border: none;
                           cursor: pointer;
                           box-shadow: 0 6px 12px rgba(0,0,0,0.25);
                           transition: background 0.3s ease;">
              🚨 CONFIRM ASSIGNMENT
            </button>
          </div>
          <script>
            async function approveAssignment(userId) {
              const button = document.querySelector('button');
              button.innerHTML = '⏳ APPROVING...';
              button.disabled = true;
              button.style.background = '#ffa726';
              button.style.cursor = 'not-allowed';

              try {
                const response = await fetch('/PDM_API/approveAssignment/' + userId, {
                  method: 'GET',
                });
                if (response.ok) {
                  button.innerHTML = '✅ APPROVED';
                  button.style.background = '#4caf50';
                  button.style.cursor = 'default';
                  const successMsg = document.createElement('div');
                  successMsg.innerHTML = '<p style="color: #4caf50; font-weight: bold; text-align: center; margin-top: 10px;">Assignment approved successfully!</p>';
                  button.parentNode.appendChild(successMsg);
                } else {
                  throw new Error('Failed to approve');
                }
              } catch (error) {
                button.innerHTML = '❌ ERROR - TRY AGAIN';
                button.disabled = false;
                button.style.background = '#f44336';
                button.style.cursor = 'pointer';
                setTimeout(() => {
                  button.innerHTML = '🚨 CONFIRM ASSIGNMENT';
                  button.style.background = 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)';
                }, 3000);
              }
            }
          </script>
        </div>
      </body>
      </html>
    `);
  } catch (err) {
    console.error('ShowAssignmentConfirmation Error:', err);
    return res.status(500).send(`
      <html>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
        <h2 style="color: #f44336;">❌ Server Error</h2>
        <p>An internal server error occurred. Please try again later.</p>
        <p style="font-size: 12px; color: #999;">Error: ${err.message}</p>
      </body>
      </html>
    `);
  }
};

// Approve assignment endpoint
export const approveAssignment = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Invalid Request</h2>
          <p>Assignment ID is required.</p>
        </body>
        </html>
      `);
    }

    const pool = await sql.connect(conConfig);
    const checkQuery = `
      SELECT ID, Username, Team, CP_ID, ApprovedStatus, Emailid
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE ID = @ID
    `;
    const checkRequest = pool.request();
    checkRequest.input('ID', sql.Int, parseInt(id));
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      return res.status(404).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Assignment Not Found</h2>
          <p>The assignment with ID ${id} was not found.</p>
        </body>
        </html>
      `);
    }

    const assignment = checkResult.recordset[0];

    if (assignment.ApprovedStatus === 1) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Already Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5;">
          <div style="background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto;">
            <h2 style="color: #ff9800;">⚠️ Already Approved</h2>
            <p style="font-size: 16px; color: #666;">
              Dear <strong>${assignment.Username}</strong>,<br><br>
              Your assignment to the <strong>${assignment.Team}</strong> team 
              for <strong>CP_ID: ${assignment.CP_ID}</strong> has already been approved.
            </p>
            <div style="background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <p style="color: #4caf50; margin: 0;">✓ Status: Already Approved</p>
            </div>
          </div>
        </body>
        </html>
      `);
    }

    const updateQuery = `
      UPDATE [PDM].[dbo].[Assign_STI/CN_Owners]
      SET ApprovedStatus = 1, UpdatedDateTime = GETDATE()
      WHERE ID = @ID
    `;
    const updateRequest = pool.request();
    updateRequest.input('ID', sql.Int, parseInt(id));
    const updateResult = await updateRequest.query(updateQuery);

    if (updateResult.rowsAffected[0] > 0) {
      return res.status(200).send(`
        <html>
        <head>
          <meta charset="utf-8">
          <title>Assignment Approved</title>
        </head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0;">
          <div style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); max-width: 500px; margin: 0 auto;">
            <div style="margin-bottom: 30px;">
              <div style="width: 80px; height: 80px; background: #4caf50; border-radius: 50%; margin: 0 auto 20px auto; display: flex; align-items: center; justify-content: center;">
                <span style="color: white; font-size: 40px;">✓</span>
              </div>
              <h1 style="color: #4caf50; margin: 0;">Assignment Approved!</h1>
            </div>
            <div style="text-align: left; background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #333;">Assignment Details:</h3>
              <p style="margin: 5px 0;"><strong>Username:</strong> ${assignment.Username}</p>
              <p style="margin: 5px 0;"><strong>Team:</strong> ${assignment.Team}</p>
              <p style="margin: 5px 0;"><strong>CP_ID:</strong> ${assignment.CP_ID}</p>
              <p style="margin: 5px 0;"><strong>Email:</strong> ${assignment.Emailid}</p>
              <p style="margin: 5px 0;"><strong>Status:</strong> <span style="color: #4caf50; font-weight: bold;">✓ Approved</span></p>
            </div>
            <p style="color: #666; font-size: 14px;">
              Thank you for approving your assignment. You can now close this window.
            </p>
          </div>
        </body>
        </html>
      `);
    } else {
      return res.status(500).send(`
        <html>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h2 style="color: #f44336;">❌ Update Failed</h2>
          <p>Failed to update the assignment status. Please try again.</p>
        </body>
        </html>
      `);
    }
  } catch (err) {
    console.error('ApproveAssignment Error:', err);
    return res.status(500).send(`
      <html>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
        <h2 style="color: #f44336;">❌ Server Error</h2>
        <p>An internal server error occurred. Please try again later.</p>
        <p style="font-size: 12px; color: #999;">Error: ${err.message}</p>
      </body>
      </html>
    `);
  }
};


export const GetAssignStatus = async (req, res) => {
  let pool;
  try {
    const { email } = req.body;

    console.log("Received status request for Emailid:", email);

    if (!email || typeof email !== "string") {
      return res.status(400).json({ error: "Valid Emailid is required" });
    }

    // Normalize email
    const normalizedEmail = email.trim().toLowerCase();
    console.log("Normalized Email:", normalizedEmail);

    // Connect to the database
    pool = await sql.connect(conConfig);
    console.log("Database connection established");

    const request = pool.request();
    request.input("email", sql.VarChar(255), normalizedEmail);

    const result = await request.query(`
      SELECT 
        [ID],
        [Username],
        [Role],
        [UpdatedDateTime],
        [RoleId],
        [OPENSTATUS],
        [Emailid],
        [Assign],
        [Team],
        [EmailStatus],
        [CP_ID],
        [Sign_off_Status],
        [TeamId],
        [ApprovedStatus],
        [ApprovalToken],
        [SignoffApproved]
      FROM [PDM].[dbo].[Assign_STI/CN_Owners]
      WHERE LOWER([Emailid]) = @email
    `);

    console.log("Query executed, records found:", result.recordset.length);

    // Classification
    const ACKNOWLEDGED = result.recordset.filter(
      (record) => record.ApprovedStatus === true
    );

    const NOTACKNOWLEDGED = result.recordset.filter(
      (record) =>
        (record.ApprovedStatus === false || record.ApprovedStatus === null) &&
        record.Assign === true
    );

    const signedOff_Approved = result.recordset.filter(
      (record) => record.SignoffApproved === true
    );

    const notSignedOff_not_Approved = result.recordset.filter(
      (record) =>
        (record.SignoffApproved === false || record.SignoffApproved === null) &&
        record.Sign_off_Status === true
    );

    return res.status(200).json({
      ACKNOWLEDGED,
      NOTACKNOWLEDGED,
      signedOff_Approved,
      notSignedOff_not_Approved,
    });
  } catch (error) {
    console.error("Error fetching assign status:", error);
    return res.status(500).json({
      error: "Internal server error",
      details: error.message,
      sqlError: error.originalError ? error.originalError.info : null,
    });
  }
};