import express from "express";
import requestIp from "request-ip";
import { RegisterUser, LoginUser,AssignUser,AssignUsersToSTICN ,SendEmailsAndUpdateStatus,SendSignOffEmailsAndUpdateStatus,SignOffUsersFromSTICN,getowners,approveAssignment,approveSignOff,showAssignmentConfirmation,showSignOffConfirmation,GetAssignStatus} from "./Pages/Auth.js";
import { addECN,postimp,TrailStatus,preimp ,updatestatuspreimp,updatestatuspostimp,updatestatustrailstatus,preimpSearch,getallstatusbypackageid,postimpSearch,addECNbyexcel,TrailStatusSearch

,addOrUpdateOrDeletePTOComment,getPTOComments,deletePackage,updateEcnStiRecord,getStatusRecordsByCpId,deleteAssignRecord,deleteSignOffRecord} from "./Pages/AdminDashboard.js";
import {addUser,userdetails,deleteuser,getTeams} from "./UserAccess.js"
import {summarydetails,getusernamebycountbypreimp,getusernamebycountbypostimp ,getuserteammemberswithmail ,signOffConfirmation,assignmentConfirmation, AssignmentConfirmationnotification,SignOffConfirmationnotification  ,getcountofnotify } from "./Pages/Summary.js"      
 

const router = express.Router();
router.use(requestIp.mw());

// Auth-related routes
router.post("/register", RegisterUser);
router.post("/login", LoginUser);
router.post("/addECN", addECN);
router.post("/preimp", preimp);
router.post("/postimp", postimp);
router.post("/TrailStatus", TrailStatus);
router.post("/updatestatuspreimp", updatestatuspreimp);
router.post("/updatestatuspostimp", updatestatuspostimp);
router.post("/updatestatustrailstatus", updatestatustrailstatus);
router.post("/getallstatusbypackageid", getallstatusbypackageid);
router.post("/addECNbyexcel", addECNbyexcel);
router.post("/preimpSearch", preimpSearch);
router.post("/postimpSearch", postimpSearch);
router.post("/TrailStatusSearch", TrailStatusSearch);
router.post("/AssignUser", AssignUser);
router.post("/AssignUsersToSTICN", AssignUsersToSTICN);
router.post("/SendEmailsAndUpdateStatus", SendEmailsAndUpdateStatus);
router.post("/SignOffUsersFromSTICN", SignOffUsersFromSTICN);
router.post("/SendSignOffEmailsAndUpdateStatus",SendSignOffEmailsAndUpdateStatus);
router.post("/addOrUpdateOrDeletePTOComment",addOrUpdateOrDeletePTOComment);
router.post("/getPTOComments",getPTOComments);
router.post("/adduser",addUser)
router.post("/userdetails",userdetails)
router.post("/deleteuser",deleteuser)
router.post("/summarydetails",summarydetails)
router.delete('/deletePackage/:cpId', deletePackage);
router.post('/updateEcnStiRecord', updateEcnStiRecord);
router.post('/getStatusRecordsByCpId', getStatusRecordsByCpId);
router.delete('/deleteAssignRecord/:id', deleteAssignRecord);
router.delete('/deleteSignOffRecord/:id', deleteSignOffRecord);
router.post('/getusernamebycountbypreimp', getusernamebycountbypreimp);
router.post('/getusernamebycountbypostimp', getusernamebycountbypostimp); 
router.post('/getTeams', getTeams); 
router.post('/getowners', getowners);  
router.post('/getuserteammemberswithmail', getuserteammemberswithmail); 
router.get('/approveAssignment/:id', approveAssignment);

router.get('/approveSignOff/:id', approveSignOff);
router.get('/SignOffConfirmation/:id', showSignOffConfirmation);
router.get('/AssignmentConfirmation/:id', showAssignmentConfirmation);
router.post('/GetAssignStatus', GetAssignStatus); 

router.post('/signOffConfirmation', signOffConfirmation);  
router.post('/assignmentConfirmation', assignmentConfirmation); getcountofnotify



router.post('/AssignmentConfirmationnotification/:id', AssignmentConfirmationnotification);

// Route for approving sign-offs
router.post('/SignOffConfirmationnotification/:id', SignOffConfirmationnotification);

router.post('/getcountofnotify', getcountofnotify); 
export default router;
