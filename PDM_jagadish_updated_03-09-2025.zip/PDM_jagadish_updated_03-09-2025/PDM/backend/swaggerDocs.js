import swaggerUi from "swagger-ui-express";
import swaggerAutogen from "swagger-autogen";
import fs from "fs";

export const swaggerDocs = async (app) => {
  const doc = {
    info: {
      title: "PDM",
      description: "API Documentation for PDM System",
      version: "1.0.0",
    },
    externalDocs: {
      description: "swagger.json",
      url: "/PDM/swagger.json",
    },
    host: "localhost:4000",
    basePath: "/",
    schemes: ["http"],
    consumes: ["application/json"],
    produces: ["application/json"],
    tags: [
      {
        name: "PDM",
        description: "Operations related to PDM system",
      },
    ],
    definitions: {
      ExampleModel: {
        type: "object",
        properties: {
          ID: {
            type: "integer",
            description: "Unique identifier for the record",
          },
          Name: {
            type: "string",
            description: "Example field for demonstration",
          },
        },
      },
    },
  };

  const outputFile = "./swagger-api.json";
  const endpointsFiles = ["./server.js", "./routes.js"];

  try {
    // Generate swagger file
    await swaggerAutogen()(outputFile, endpointsFiles, doc);

    // Read the generated file
    const file = JSON.parse(fs.readFileSync(outputFile, "utf8"));

    // Serve Swagger UI
    app.use("/PDM/docs", swaggerUi.serve, swaggerUi.setup(file, {
      explorer: true,
      customCss: '.swagger-ui .topbar { display: none }',
      customSiteTitle: "PDM API Documentation"
    }));

    // Serve raw JSON
    app.get("/PDM/swagger.json", (req, res) => {
      res.setHeader("Content-Type", "application/json");
      res.send(file);
    });

    console.log("✅ Swagger documentation setup completed for PDM");
  } catch (error) {
    console.error("❌ Error setting up Swagger documentation:", error);
  }
};
