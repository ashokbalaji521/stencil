import sql from "mssql";
import { conConfig } from "./DB/db.js";

// Add this new function to get teams from TeamMaster table
export const getTeams = async (req, res) => {
    try {
        const pool = await sql.connect(conConfig);
        
        const result = await pool
            .request()
            .query(`SELECT TeamId, TeamName FROM [PDM].[dbo].[TeamMaster]`);
        
        console.log("Teams:", result.recordset);   
        res.status(200).json(result.recordset);
    } catch (error) {
        console.error("Get Teams Error:", error);
        res.status(500).json({ error: "Failed to fetch teams" });
    }
};

// Updated addUser function
export const addUser = async (req, res) => {
    try {
        let {
            email,
            username,    // Username is now required from frontend
            role,
            teamId,    // Changed from team to teamId
            teamName   // Added teamName
        } = req.body;

        // Generate password if not provided (you might want to implement proper password generation)
        const password = username + "123"; // Simple password generation - consider using a proper password generator

        const pool = await sql.connect(conConfig);
        
        const insertQuery = `
            INSERT INTO [dbo].[Users_PDM] (
                [Email],
                [Username],
                [Password],
                [Role],
                [Team],      -- This will store TeamName
                [TeamId],    -- This will store TeamId
                [UpdatedDateTime]
            )
            VALUES (
                @email,
                @username,
                @password,
                @role,
                @teamName,   -- Store team name
                @teamId,     -- Store team id
                @UpdatedDateTime
            )`;
            
        await pool
            .request()
            .input("email", sql.VarChar, email)
            .input("username", sql.VarChar, username)
            .input("password", sql.VarChar, password)
            .input("role", sql.VarChar, role)
            .input("teamName", sql.VarChar, teamName)
            .input("teamId", sql.Int, teamId)
            .input("UpdatedDateTime", sql.DateTime, new Date())
            .query(insertQuery);
        
        res.status(200).json({ message: "User added successfully" });
    } catch (error) {
        console.error("Insert Error:", error);
        res.status(500).json({ error: "Failed to insert data" });
    }
};

// Updated userdetails function (no changes needed, but included for completeness)
export const userdetails = async (req, res) => {
    try {
        const pool = await sql.connect(conConfig);
        
        const result = await pool
            .request()
            .query(`
                SELECT ID, Email, Username, Password, Role, Team, TeamId, UpdatedDateTime
                FROM [PDM].[dbo].[Users_PDM] 
            `); 
            
        console.log(result.recordset);   
        res.status(200).json(result.recordset);
    } catch (error) {
        console.error("Get Users Error:", error);
        res.status(500).json({ error: "Failed to fetch user data" });
    }
};

export const deleteuser = async (req, res) => {
  
    try {
        const { username } = req.body;

        const pool = await sql.connect(conConfig);
        
        const deleteQuery = `DELETE FROM [dbo].[Users_PDM] WHERE Username = @username`;
        
        await pool
            .request()
            .input("username", sql.VarChar, username)
            .query(deleteQuery);
        
        res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
        console.error("Delete Error:", error);
        res.status(500).json({ error: "Failed to delete user" });
    }
};