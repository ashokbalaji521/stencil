import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import http from "http";
import path from "path";
import router from "./routes.js";
import { swaggerDocs } from "./swaggerDocs.js";

const app = express();
const server = http.createServer(app);

// Middleware
app.use(cors());
app.use("/uploads", express.static(path.join(path.resolve(), "uploads")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// API Routes
app.use("/PDM_API", router); // All API routes under /PDM_API

// Swagger Docs
// swaggerDocs(app);

// Server Port
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`✅ Server is running on port ${PORT}`);
  // console.log(`📚 Swagger documentation available at: http://localhost:${PORT}/PDM_API/docs`);
});
