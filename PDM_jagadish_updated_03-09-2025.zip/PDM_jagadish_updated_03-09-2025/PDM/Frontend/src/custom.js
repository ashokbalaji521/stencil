const host = window.location.hostname;

export const Data = {
  url: `http://${host}:4000/PDM_API`,
  //url: `https://${host}/PDM_API/`,
  // imagePath: `http://${host}:4000/uploads/`  // if needed for image uploads
};
