import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { MsalProvider } from "@azure/msal-react";
import { msalInstance } from "./Auth/msalConfig";
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Box, CircularProgress, Typography } from '@mui/material';

// import Layout from './Pages/Layout';
import Login from './Auth/Login';
import Dashboard from './Pages/Dashboard';
import UserDashboard from './Pages/UserDashboard';
import UpdatePackageOwner1 from './Pages/UpdatePackageOwner1';
import UpdatePackageOwner2 from './Pages/UpdatePackageOwner2';
import AddSTIECN from './Pages/AddSTIECN';
import UserAccess from './Pages/UserAccess';
import Summary from './Pages/Summary';
import Notifications from './Pages/Notifications';

import './App.css';

// Create custom theme
const theme = createTheme({
  palette: {
    primary: {
      main: '#134380',
      light: '#1976d2',
      dark: '#0d2f5c'
    },
    secondary: {
      main: '#e0e7ff',
      light: '#f0f4ff',
      dark: '#c5d2ff'
    },
    background: {
      default: '#f8fafc',
      paper: '#ffffff'
    }
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: { fontWeight: 700 },
    h2: { fontWeight: 600 },
    h3: { fontWeight: 600 },
    h4: { fontWeight: 600 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 }
  },
  shape: {
    borderRadius: 12
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 8,
          fontWeight: 600
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12
        }
      }
    }
  }
});

function App() {
  const [msalInitialized, setMsalInitialized] = useState(false);

  useEffect(() => {
    const initializeMsal = async () => {
      try {
        await msalInstance.initialize();
        setMsalInitialized(true);
      } catch (error) {
        console.error('MSAL initialization failed:', error);
        // Set as initialized anyway to prevent infinite loading
        setMsalInitialized(true);
      }
    };

    initializeMsal();
  }, []);

  // Show loading screen while MSAL initializes
  if (!msalInitialized) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100vh',
            backgroundColor: 'background.default'
          }}
        >
          <CircularProgress size={48} sx={{ mb: 2 }} />
          <Typography variant="h6" color="primary.main">
            Initializing Application...
          </Typography>
        </Box>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <MsalProvider instance={msalInstance}>
        <Router basename="/pdm">
          <Routes>
            {/* Routes WITHOUT Layout (no header/navbar) */}
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/UserDashboard" element={<UserDashboard />} />
             <Route path="/Notifications" element={<Notifications />} />

            {/* Routes WITH Layout (header + navbar) */}
            {/* <Route element={<Layout />}> */}
            <Route path="/Dashboard" element={<Dashboard />} />
            <Route path="/AddSTIECN" element={<AddSTIECN />} />
            <Route path="/UpdatePackageOwner1/:cpId" element={<UpdatePackageOwner1 />} />
            <Route path="/UpdatePackageOwner2/:cpId" element={<UpdatePackageOwner2 />} />
            <Route path="/useraccess" element={<UserAccess />} />
            <Route path="/summary" element={<Summary />} />
            {/* </Route> */}
          </Routes>
        </Router>
      </MsalProvider>
    </ThemeProvider>
  );
}

export default App;
