import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  Box,
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  TextField,
  Grid,
  Card,
  CardContent,
  Chip,
  IconButton,
  CircularProgress,
  Alert,
  Autocomplete,
  Checkbox,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { Delete as DeleteIcon, Email as EmailIcon } from "@mui/icons-material";
import axios from "axios";
import { Data } from "../custom";
import Header from "../Pages/Header";
import Footer from "../Pages/Footer";
import "./UpdatePackageOwner.css";

const UpdatePackageOwner = () => {
  const { cpId } = useParams();
  const [selectedSection, setSelectedSection] = useState("");
  const [trackerData, setTrackerData] = useState({
    category: "",
    packageId: "",
    ecnStiNumber: "",
    productFamily: "",
    productName: "",
    productCategory: "",
    productSaleCode: "",
    receivedDate: "",
    tentativeTrialDate: "",
    closureTargetDate: "",
    actualClosureDate: "",
    turnaroundTime: "",
    cnStiStatus: "",
    pdmActionOwner: "",
    shortNotes: "",
    cnStiSignoffStatus: "",
  });

  const [actionStatuses, setActionStatuses] = useState({
    "Pre-Implementation": {
      PDM: "NA",
      "MM Buyer": "NA",
      "MM Logistics": "NA",
      SQA: "NA",
      WH: "NA",
      MC: "NA",
      SMT: "NA",
      "MS-SMT": "NA",
      "MS-IE": "NA",
      "MS-TEST": "NA",
      "MS-PT": "NA",
      "MS-PE": "NA",
      "MS-IT": "NA",
      OPS: "NA",
    },
    "During Trial Production": {
      PDM: "NA",
      "MM Buyer": "NA",
      "MM Logistics": "NA",
      SQA: "NA",
      WH: "NA",
      MC: "NA",
      SMT: "NA",
      "MS-SMT": "NA",
      "MS-IE": "NA",
      "MS-TEST": "NA",
      "MS-PT": "NA",
      "MS-PE": "NA",
      "MS-IT": "NA",
      OPS: "NA",
    },
    "Post Implementation": {
      PDM: "NA",
      "MM Buyer": "NA",
      "MM Logistics": "NA",
      SQA: "NA",
      WH: "NA",
      MC: "NA",
      SMT: "NA",
      "MS-SMT": "NA",
      "MS-IE": "NA",
      "MS-TEST": "NA",
      "MS-PT": "NA",
      "MS-PE": "NA",
      "MS-IT": "NA",
      OPS: "NA",
    },
  });

  const [ownerComments, setOwnerComments] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState("");
  const [selectedOwners, setSelectedOwners] = useState([]);
  const [availableOwners, setAvailableOwners] = useState([]);
  const [selectedSignOffTeam, setSelectedSignOffTeam] = useState("");
  const [selectedSignOffOwners, setSelectedSignOffOwners] = useState([]);
  const [ptoComment, setPtoComment] = useState("");
  const [ptoCommands, setPtoCommands] = useState([]);
  const [signOffRequests, setSignOffRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showSuccessSnackbar, setShowSuccessSnackbar] = useState(false);
  const [statusDialog, setStatusDialog] = useState({
    open: false,
    phase: null,
    team: null,
    currentStatus: null,
    newStatus: "",
  });

  const teams = [
    "PDM",
    "MM Buyer",
    "MM Logistics",
    "SQA",
    "WH",
    "MC",
    "SMT",
    "MS-SMT",
    "MS-IE",
    "MS-TEST",
    "MS-PT",
    "MS-PE",
    "MS-IT",
    "OPS",
  ];

  const statusMap = {
    0: "Open",
    1: "Closed",
    2: "In Progress",
  };

  const showSuccessMessage = (message) => {
    setSuccessMessage(message);
    setShowSuccessSnackbar(true);
  };

  const handleCloseSuccessSnackbar = () => {
    setShowSuccessSnackbar(false);
  };

  const fetchTrackerData = async () => {
    if (!cpId) {
      setError("No Package ID provided");
      return;
    }

    try {
      setLoading(true);
      setError("");
      const response = await axios.post(`${Data.url}/getallstatusbypackageid`, { cp_id: cpId });

      const data = response.data;

      setTrackerData({
        category: data.ecn_sti?.Change_Note_Cateogry || "",
        packageId: data.ecn_sti?.CP_ID || cpId,
        ecnStiNumber: data.ecn_sti?.ECN_STI_Number || "",
        productFamily: data.ecn_sti?.Product_Family || "",
        productName: data.ecn_sti?.Product_Name || "",
        productCategory: data.ecn_sti?.Category || "",
        productSaleCode: data.ecn_sti?.Product_Sale_code || "",
        receivedDate: data.ecn_sti?.Receieved_Date
          ? new Date(data.ecn_sti.Receieved_Date).toISOString().split("T")[0]
          : "",
        tentativeTrialDate: "",
        closureTargetDate: "",
        actualClosureDate: "",
        turnaroundTime: "",
        cnStiStatus: "",
        pdmActionOwner: "",
        shortNotes: data.ecn_sti?.Brief_Details || "",
        cnStiSignoffStatus: "",
      });

      const mapStatuses = (statusData) => {
        if (!statusData) return {};
        return {
          PDM: statusMap[statusData.PDM] || "NA",
          "MM Buyer": statusMap[statusData.MM_Buyer] || "NA",
          "MM Logistics": statusMap[statusData.MM_logistics] || "NA",
          SQA: statusMap[statusData.SQA] || "NA",
          WH: statusMap[statusData.WH] || "NA",
          MC: statusMap[statusData.MC] || "NA",
          SMT: statusMap[statusData.SMT] || "NA",
          "MS-SMT": statusMap[statusData.MS_SMT] || "NA",
          "MS-IE": statusMap[statusData.MS_IE] || "NA",
          "MS-TEST": statusMap[statusData.MS_TEST] || "NA",
          "MS-PT": statusMap[statusData.MS_PT] || "NA",
          "MS-PE": statusMap[statusData.MS_PE] || "NA",
          "MS-IT": statusMap[statusData.MS_IT] || "NA",
          OPS: statusMap[statusData.OPS] || "NA",
        };
      };

      setActionStatuses({
        "Pre-Implementation": mapStatuses(data.pre_implementation_status),
        "During Trial Production": mapStatuses(data.trail_production_status),
        "Post Implementation": mapStatuses(data.post_implementation_status),
      });
    } catch (err) {
      setError(`Failed to fetch data: ${err.response?.data?.error || err.message}`);
      console.error("Error fetching tracker data:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchOwners = async (team) => {
    try {
      const response = await axios.post(`${Data.url}/AssignUser`, { team });
      setAvailableOwners(response.data.users || []);
    } catch (err) {
      console.error("Error fetching owners:", err);
      setError("Failed to fetch owners");
    }
  };

  const fetchPtoCommands = async () => {
    try {
      const response = await axios.get(`${Data.url}/pto-commands`);
      setPtoCommands(response.data);
    } catch (err) {
      console.error("Error fetching PTO commands:", err);
    }
  };

  const fetchOwnerComments = async () => {
    try {
      const response = await axios.get(`${Data.url}/owner-comments`);
      setOwnerComments(response.data);
    } catch (err) {
      console.error("Error fetching owner comments:", err);
    }
  };

  const fetchSignOffRequests = async () => {
    try {
      const response = await axios.get(`${Data.url}/signoff-requests`);
      setSignOffRequests(response.data);
    } catch (err) {
      console.error("Error fetching sign off requests:", err);
    }
  };

  useEffect(() => {
    fetchTrackerData();
    fetchPtoCommands();
    fetchOwnerComments();
    fetchSignOffRequests();
  }, [cpId]);

  useEffect(() => {
    if (selectedTeam || selectedSignOffTeam) {
      fetchOwners(selectedTeam || selectedSignOffTeam);
    } else {
      setAvailableOwners([]);
      setSelectedOwners([]);
      setSelectedSignOffOwners([]);
    }
  }, [selectedTeam, selectedSignOffTeam]);

  const getStatusColor = (status) => {
    switch (status) {
      case "Open":
        return "status-chip-open";
      case "Closed":
        return "status-chip-closed";
      case "In Progress":
        return "status-chip-in-progress";
      case "NA":
        return "status-chip-na";
      default:
        return "status-chip-default";
    }
  };

  const handleStatusClick = (phase, team, currentStatus) => {
    setStatusDialog({
      open: true,
      phase,
      team,
      currentStatus,
      newStatus: currentStatus || "NA",
    });
  };

  const handleStatusChange = async () => {
    try {
      setLoading(true);
      setActionStatuses((prev) => ({
        ...prev,
        [statusDialog.phase]: {
          ...prev[statusDialog.phase],
          [statusDialog.team]: statusDialog.newStatus,
        },
      }));

      const statusToNumber = {
        Open: 0,
        Closed: 1,
        "In Progress": 2,
        NA: null,
      };

      const endpointMap = {
        "Pre-Implementation": "updatestatuspreimp",
        "During Trial Production": "updatestatustrailstatus",
        "Post Implementation": "updatestatuspostimp",
      };

      const updateData = {
        field: statusDialog.team,
        Status: statusToNumber[statusDialog.newStatus],
        CP_ID: trackerData.packageId,
      };

      const endpoint = endpointMap[statusDialog.phase];
      await axios.post(`${Data.url}/${endpoint}`, updateData);

      showSuccessMessage(`Status updated successfully for ${statusDialog.team}`);
    } catch (err) {
      console.error("Error updating status:", err);
      setError("Failed to update status");
    } finally {
      setLoading(false);
      setStatusDialog({ ...statusDialog, open: false });
    }
  };

  const handleAssignOwner = async () => {
    if (selectedTeam && selectedOwners.length > 0) {
      try {
        setLoading(true);
        const usernameString = selectedOwners.map((owner) => owner.Username).join(",");
        const response = await axios.post(`${Data.url}/AssignUsersToSTICN`, {
          username: usernameString,
        });

        const newComments = response.data.users.map((user) => ({
          copId: trackerData.packageId,
          team: user.Team,
          email: user.Email,
          preImplementation: "",
      
          postImplementation: "",
          id: user.ID,
        }));

        setOwnerComments([...ownerComments, ...newComments]);
        setSelectedTeam("");
        setSelectedOwners([]);
        setAvailableOwners([]);
        setError("");
        showSuccessMessage("Owners assigned successfully!");
      } catch (err) {
        console.error("Error assigning owners:", err);
        setError("Failed to assign owners");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAssignSignOffOwner = async () => {
    if (selectedSignOffTeam && selectedSignOffOwners.length > 0) {
      try {
        setLoading(true);
        const usernameString = selectedSignOffOwners.map((owner) => owner.Username).join(",");
        const response = await axios.post(`${Data.url}/SignOffUsersFromSTICN`, {
          username: usernameString,
        });

        const newRequests = response.data.users.map((user) => ({
          copId: trackerData.packageId,
          team: user.Team,
          email: user.Email,
          comment: "",
          signOffStatus: "Pending",
          id: user.ID,
        }));

        setSignOffRequests([...signOffRequests, ...newRequests]);
        setSelectedSignOffTeam("");
        setSelectedSignOffOwners([]);
        setAvailableOwners([]);
        setError("");
        showSuccessMessage("Sign-off owners assigned successfully!");
      } catch (err) {
        console.error("Error assigning sign-off owners:", err);
        setError("Failed to assign sign-off owners");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleDeleteOwnerComment = async (index, commentId) => {
    try {
      await axios.delete(`${Data.url}/owner-comments/${commentId}`);
      setOwnerComments(ownerComments.filter((_, i) => i !== index));
    } catch (err) {
      console.error("Error deleting owner comment:", err);
      setError("Failed to delete owner comment");
    }
  };

  const handleDeleteSignOffRequest = async (index, requestId) => {
    try {
      await axios.delete(`${Data.url}/signoff-requests/${requestId}`);
      setSignOffRequests(signOffRequests.filter((_, i) => i !== index));
    } catch (err) {
      console.error("Error deleting sign-off request:", err);
      setError("Failed to delete sign-off request");
    }
  };

  const handleSubmitPTO = async () => {
    if (ptoComment.trim()) {
      try {
        const newCommand = {
          date: new Date().toISOString().split("T")[0],
          comment: ptoComment,
          action: "Submitted",
        };

        const response = await axios.post(`${Data.url}/pto-commands`, newCommand);
        setPtoCommands([...ptoCommands, response.data]);
        setPtoComment("");
      } catch (err) {
        console.error("Error submitting PTO comment:", err);
        setError("Failed to submit PTO comment");
      }
    }
  };

  const handleSendEmailNotification = async (type) => {
    try {
      const endpoint = type === "signoff" ? "SendSignOffEmailsAndUpdateStatus" : "SendEmailsAndUpdateStatus";
      const response = await axios.post(`${Data.url}/${endpoint}`, {
        type,
        packageId: trackerData.packageId,
      });
      setError("");
      const messageMap = {
        owner: "Owner email notifications sent successfully!",
        signoff: "Sign-off email notifications sent successfully!",
      };
      showSuccessMessage(messageMap[type] || "Email notifications sent successfully!");
    } catch (err) {
      console.error("Error sending email notification:", err);
      setError("Failed to send email notification");
    }
  };

  const renderStatusCell = (phase, team, status) => {
    const statusClassMap = {
      Open: 0,
      Closed: 1,
      "In Progress": 2,
      NA: "NA",
    };
    const statusClass = statusClassMap[status] ?? "NA";

    return (
      <TableCell
        className={`status-cell status-${statusClass}`}
        onClick={() => handleStatusClick(phase, team, status)}
        title={`Click to update ${team} status. Current: ${status}`}
      >
        {status}
      </TableCell>
    );
  };

  return (
    <Box className="update-package-owner">
      <Header />
      <Container className="container">
        {loading && (
          <Box className="loading-container">
            <CircularProgress />
          </Box>
        )}

        {error && (
          <Alert severity="error" className="error-alert">
            {error}
          </Alert>
        )}

        <Snackbar
          open={showSuccessSnackbar}
          autoHideDuration={4000}
          onClose={handleCloseSuccessSnackbar}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert
            onClose={handleCloseSuccessSnackbar}
            severity="success"
            sx={{ width: '100%' }}
          >
            {successMessage}
          </Alert>
        </Snackbar>

        <Box className="section-select">
          <FormControl>
            <InputLabel>Select Section</InputLabel>
            <Select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              label="Select Section"
            >
              <MenuItem value="">Select Section</MenuItem>
              <MenuItem value="section1">Section 1</MenuItem>
              <MenuItem value="section2">Section 2</MenuItem>
            </Select>
          </FormControl>
        </Box>

        <Card className="card">
          <CardContent className="card-content">
            <Grid container spacing={2} className="grid-container">
              <Grid item xs={12} md={6}>
                <TableContainer component={Paper} className="table-container">
                  <Table size="small">
                    <TableBody>
                      <TableRow className="table-row">
                        {[
                          "Category",
                          "Package ID",
                          "ECN/STI Number",
                          "Product Family",
                          "Product Name",
                          "Product Category",
                          "Product Sale Code",
                          "Received Date",
                        ].map((header) => (
                          <TableCell key={header} className="table-header">
                            {header}
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow className="table-row">
                        {[
                          trackerData.category,
                          trackerData.packageId,
                          trackerData.ecnStiNumber,
                          trackerData.productFamily,
                          trackerData.productName,
                          trackerData.productCategory,
                          trackerData.productSaleCode,
                          trackerData.receivedDate,
                        ].map((value, index) => (
                          <TableCell key={index} className="table-cell">
                            {value}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>

              <Grid item xs={12} md={6}>
                <TableContainer component={Paper} className="table-container">
                  <Table size="small">
                    <TableBody>
                      <TableRow className="table-row">
                        <TableCell className="table-header">If STI Valid</TableCell>
                        <TableCell className="table-header">FROM</TableCell>
                        <TableCell className="table-header">TO</TableCell>
                      </TableRow>
                      <TableRow className="table-row">
                        <TableCell className="table-cell">-</TableCell>
                        <TableCell className="table-cell">-</TableCell>
                        <TableCell className="table-cell">-</TableCell>
                      </TableRow>
                      <TableRow className="table-row">
                        <TableCell className="table-header">Tentative Trial Plan Date</TableCell>
                        <TableCell className="table-header">Closure Target Date</TableCell>
                        <TableCell className="table-header">Actual Closure Date</TableCell>
                      </TableRow>
                      <TableRow className="table-row">
                        <TableCell className="table-cell">{trackerData.tentativeTrialDate}</TableCell>
                        <TableCell className="table-cell">{trackerData.closureTargetDate}</TableCell>
                        <TableCell className="table-cell">{trackerData.actualClosureDate}</TableCell>
                      </TableRow>
                      <TableRow className="table-row">
                        <TableCell className="table-header">Turnaround Time (TAT)</TableCell>
                        <TableCell className="table-header">CN/STI Status</TableCell>
                        <TableCell className="table-header">PDM Action Owner</TableCell>
                      </TableRow>
                      <TableRow className="table-row">
                        <TableCell className="table-cell">{trackerData.turnaroundTime}</TableCell>
                        <TableCell className="table-cell">
                          <Chip
                            label={trackerData.cnStiStatus}
                            className={getStatusColor(trackerData.cnStiStatus)}
                            size="small"
                          />
                        </TableCell>
                        <TableCell className="table-cell">{trackerData.pdmActionOwner}</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>

              <Grid item xs={12}>
                <Box className="notes-signoff-container">
                  <Box>
                    <Typography className="notes-title">Short Notes of the CN/STI</Typography>
                    <Box className="notes-content">{trackerData.shortNotes}</Box>
                  </Box>
                  <Box>
                    <Typography className="signoff-title">CN/STI Signoff Status</Typography>
                    <Box className={`signoff-content ${getStatusColor(trackerData.cnStiSignoffStatus)}`}>
                      {trackerData.cnStiSignoffStatus}
                    </Box>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        <Card className="card">
          <CardContent className="card-content">
            <Typography variant="h6" className="action-status-title">
              Actions Status Update - Click on status cells to select new status
            </Typography>
            <TableContainer component={Paper} className="table-container action-status-table">
              <Table size="small">
                <TableHead>
                  <TableRow className="table-row">
                    <TableCell className="table-header">Action</TableCell>
                    {teams.map((team) => (
                      <TableCell key={team} className="table-header">
                        {team}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.keys(actionStatuses).map((phase) => (
                    <TableRow key={phase} className="table-row">
                      <TableCell className="table-cell">{phase}</TableCell>
                      {teams.map((team) => (
                        renderStatusCell(phase, team, actionStatuses[phase][team] || "NA")
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>

        <Card className="card">
          <CardContent className="card-content">
            <Typography variant="h6" className="pto-comment-title">
              Update PTO Comment*
            </Typography>
            <Box className="pto-comment-container">
              <TextField
                fullWidth
                multiline
                rows={3}
                value={ptoComment}
                onChange={(e) => setPtoComment(e.target.value)}
                placeholder="Enter PTO comment..."
              />
              <Button variant="contained" onClick={handleSubmitPTO}>
                Submit
              </Button>
            </Box>
          </CardContent>
        </Card>

        <Card className="card">
          <CardContent className="card-content">
            <Typography variant="h6" className="pto-commands-title">
              PTO Commands
            </Typography>
            <TableContainer component={Paper} className="table-container">
              <Table>
                <TableHead>
                  <TableRow className="table-row">
                    <TableCell className="table-header">Date</TableCell>
                    <TableCell className="table-header">Comment</TableCell>
                    <TableCell className="table-header">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {ptoCommands.map((command, index) => (
                    <TableRow key={index} className="table-row">
                      <TableCell className="table-cell">{command.date}</TableCell>
                      <TableCell className="table-cell">{command.comment}</TableCell>
                      <TableCell className="table-cell">{command.action}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>

        <Card className="card">
          <CardContent className="card-content">
            <Typography variant="h6" className="owner-assignment-title" sx={{ mb: 3 }}>
              Assign STI/CN Owners*
            </Typography>
            <Box className="owner-assignment-container" sx={{ mb: 4 }}>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} sm={6} md={3}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Select Team</InputLabel>
                    <Select
                      value={selectedTeam}
                      onChange={(e) => setSelectedTeam(e.target.value)}
                      label="Select Team"
                    >
                      {teams.map((team) => (
                        <MenuItem key={team} value={team}>
                          {team}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Autocomplete
                    multiple
                    options={availableOwners}
                    getOptionLabel={(option) => option.Username}
                    value={selectedOwners}
                    onChange={(event, newValue) => setSelectedOwners(newValue)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Owners"
                        placeholder="Select multiple owners"
                        size="small"
                      />
                    )}
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox
                          checked={selected}
                          style={{ marginRight: 8 }}
                        />
                        {option.Username} ({option.Email})
                      </li>
                    )}
                    disabled={!selectedTeam}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={2}>
                  <Button
                    variant="contained"
                    onClick={handleAssignOwner}
                    disabled={selectedOwners.length === 0}
                    fullWidth
                    size="small"
                    sx={{
                      backgroundColor: '#1976d2',
                      '&:hover': { backgroundColor: '#115293' },
                      textTransform: 'none'
                    }}
                  >
                    Assign Owners
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="contained"
                    onClick={() => handleSendEmailNotification("owner")}
                    startIcon={<EmailIcon />}
                    fullWidth
                    size="small"
                    sx={{
                      backgroundColor: '#2e7d32',
                      '&:hover': { backgroundColor: '#1b5e20' },
                      textTransform: 'none'
                    }}
                  >
                    Send Email Notifications
                  </Button>
                </Grid>
              </Grid>
            </Box>

            <Typography variant="h6" className="owner-comments-title" sx={{ mb: 2 }}>
              Owner Comments
            </Typography>
            <TableContainer component={Paper} className="table-container owner-comments-table">
              <Table>
                <TableHead>
                  <TableRow className="table-row">
                    <TableCell className="table-header">COP ID</TableCell>
                    <TableCell className="table-header">Team</TableCell>
                    <TableCell className="table-header">Email</TableCell>
                    <TableCell className="table-header">Pre-Implementation</TableCell>
                    <TableCell className="table-header">During Trial</TableCell>
                    <TableCell className="table-header">Post Implementation</TableCell>
                    <TableCell className="table-header">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {ownerComments.map((comment, index) => (
                    <TableRow key={index} className="table-row">
                      <TableCell className="table-cell">{comment.copId}</TableCell>
                      <TableCell className="table-cell">{comment.team}</TableCell>
                      <TableCell className="table-cell">{comment.email}</TableCell>
                      <TableCell className="table-cell">{comment.preImplementation}</TableCell>
              
                      <TableCell className="table-cell">{comment.postImplementation}</TableCell>
                      <TableCell className="table-cell">
                        <Button
                          variant="contained"
                          color="error"
                          size="small"
                          onClick={() => handleDeleteOwnerComment(index, comment.id)}
                          sx={{ textTransform: 'none' }}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>

        <Card className="card">
          <CardContent className="card-content">
            <Typography variant="h6" className="signoff-assignment-title" sx={{ mb: 3 }}>
              Assign Sign off Owner*
            </Typography>
            <Box className="signoff-assignment-container" sx={{ mb: 4 }}>
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} sm={6} md={3}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Select Team</InputLabel>
                    <Select
                      value={selectedSignOffTeam}
                      onChange={(e) => setSelectedSignOffTeam(e.target.value)}
                      label="Select Team"
                    >
                      {teams.map((team) => (
                        <MenuItem key={team} value={team}>
                          {team}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Autocomplete
                    multiple
                    options={availableOwners}
                    getOptionLabel={(option) => option.Username}
                    value={selectedSignOffOwners}
                    onChange={(event, newValue) => setSelectedSignOffOwners(newValue)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Sign-off Owners"
                        placeholder="Select multiple owners"
                        size="small"
                      />
                    )}
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox
                          checked={selected}
                          style={{ marginRight: 8 }}
                        />
                        {option.Username} ({option.Email})
                      </li>
                    )}
                    disabled={!selectedSignOffTeam}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={2}>
                  <Button
                    variant="contained"
                    onClick={handleAssignSignOffOwner}
                    disabled={selectedSignOffOwners.length === 0}
                    fullWidth
                    size="small"
                    sx={{
                      textTransform: 'none',
                      backgroundColor: '#1976d2',
                      '&:hover': { backgroundColor: '#115293' }
                    }}
                  >
                    Assign Sign-off Owners
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Button
                    variant="contained"
                    onClick={() => handleSendEmailNotification("signoff")}
                    startIcon={<EmailIcon />}
                    fullWidth
                    size="small"
                    sx={{
                      textTransform: 'none',
                      backgroundColor: '#2e7d32',
                      '&:hover': { backgroundColor: '#1b5e20' }
                    }}
                  >
                    Send Email Notifications
                  </Button>
                </Grid>
              </Grid>
            </Box>

            <Typography variant="h6" className="signoff-requests-title">
              Sign Off Requested Owner Details
            </Typography>
            <TableContainer component={Paper} className="table-container">
              <Table>
                <TableHead>
                  <TableRow className="table-row">
                    <TableCell className="table-header">COP ID</TableCell>
                    <TableCell className="table-header">Team</TableCell>
                    <TableCell className="table-header">Email</TableCell>
                    <TableCell className="table-header">Comment</TableCell>
                    <TableCell className="table-header">Sign off Status</TableCell>
                    <TableCell className="table-header">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {signOffRequests.map((request, index) => (
                    <TableRow key={index} className="table-row">
                      <TableCell className="table-cell">{request.copId}</TableCell>
                      <TableCell className="table-cell">{request.team}</TableCell>
                      <TableCell className="table-cell">{request.email}</TableCell>
                      <TableCell className="table-cell">{request.comment}</TableCell>
                      <TableCell className="table-cell">{request.signOffStatus}</TableCell>
                      <TableCell className="table-cell">
                        <Button
                          variant="contained"
                          color="error"
                          size="small"
                          onClick={() => handleDeleteSignOffRequest(index, request.id)}
                          sx={{ textTransform: 'none' }}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>

        <Dialog
          open={statusDialog.open}
          onClose={() => setStatusDialog({ ...statusDialog, open: false })}
          fullWidth
          maxWidth="xs"
        >
          <DialogTitle>Update Status</DialogTitle>
          <DialogContent>
            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel>Select Status</InputLabel>
              <Select
                value={statusDialog.newStatus}
                onChange={(e) => setStatusDialog({ ...statusDialog, newStatus: e.target.value })}
                label="Select Status"
              >
                <MenuItem value="Open">Open</MenuItem>
                <MenuItem value="Closed">Closed</MenuItem>
                <MenuItem value="In Progress">In Progress</MenuItem>
                <MenuItem value="NA">NA</MenuItem>
              </Select>
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setStatusDialog({ ...statusDialog, open: false })}
              color="secondary"
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={handleStatusChange}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Update'}
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
      <Box className="footer">
        <Typography variant="body2">© 2025 NOKIA. All rights reserved.</Typography>
      </Box>
    </Box>
  );
};

export default UpdatePackageOwner;