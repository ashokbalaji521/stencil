import React, { useState, useEffect } from "react";
import {
  AppBar, Toolbar, Typography, Box, Avatar, IconButton,
  Menu, MenuItem, Fade, Divider, ListItemIcon, ListItemText,
  Badge, Tooltip, Popover, List, ListItem, ListItemAvatar,
  Chip, Paper
} from "@mui/material";
import {
  PowerSettingsNew as PowerIcon,
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  Assessment as AssessmentIcon,
  Settings as SettingsIcon,
  Home as HomeIcon,
  Person as PersonIcon,
  Notifications as NotificationsIcon,
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  Pending as PendingIcon
} from "@mui/icons-material";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import { Data } from "../custom";
import logo from "../Assets/Images/nokia.png";

const HEADER_HEIGHT = 44; // reduced height
const HEADER_GAP = 10;     // small gap below header for sidebar/main alignment

const Header = () => {
  const [username, setUsername] = useState("");
  const [userRole, setUserRole] = useState("");
  const [userMenuAnchor, setUserMenuAnchor] = useState(null);
  const [navMenuAnchor, setNavMenuAnchor] = useState(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [notificationData, setNotificationData] = useState({
    records: [],      // all records
    Assign: [],       // pending approval records
    signoff: [],      // pending signoff records
    totalCount: 0     // combined count
  });
  const [notificationAnchor, setNotificationAnchor] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const storedUsername = sessionStorage.getItem("username");
    const role = sessionStorage.getItem('role') || sessionStorage.getItem('userRole') || 'User';
    if (storedUsername) setUsername(storedUsername);
    setUserRole(role);
    
    // Check for notifications count
    checkNotificationCount();
  }, []);

  // Function to check notification count from API
  const checkNotificationCount = async () => {
    try {
      const email = sessionStorage.getItem('email') || sessionStorage.getItem('userEmail');
      if (email) {
        const response = await axios.post(`${Data.url}/getcountofnotify`, {
          email: email
        });

        if (response.status === 200) {
          const data = response.data;
          // Set the notification count from API (totalCount from backend)
          setNotificationCount(data.totalCount);
          setNotificationData(data);
        }
      }
    } catch (error) {
      console.error('Error fetching notification count:', error);
    }
  };

  // Handle notification hover
  const handleNotificationHover = (event) => {
    setNotificationAnchor(event.currentTarget);
  };

  const handleNotificationLeave = () => {
    setNotificationAnchor(null);
  };

  const handleNotificationClick = () => {
    // Navigate to notifications page
    navigate('/Notifications');
    setNotificationAnchor(null);
  };

  // All navigation items
  const allNavItems = [
    {
      label: 'Home',
      icon: <HomeIcon />,
      path: '/login',
      color: '#1976d2',
      roles: ['Admin']
    },
    {
      label: 'Dashboard',
      icon: <DashboardIcon />,
      path: '/Dashboard',
      color: '#2196f3',
      roles: ['Admin']
    },
    {
      label: 'User Access',
      icon: <AssessmentIcon />,
      path: '/useraccess',
      color: '#ff9800',
      roles: ['Admin']
    },
    {
      label: 'Summary',
      icon: <SettingsIcon />,
      path: '/summary',
      color: '#4caf50',
      roles: ['Admin']
    },
    {
      label: 'UserDashboard',
      icon: <PersonIcon />,
      path: '/UserDashboard',
      color: '#9c27b0',
      roles: ['User']
    }
  ];

  // Filter navigation items based on user role
  const navItems = allNavItems.filter(item =>
    item.roles.includes(userRole) ||
    (userRole === 'Admin' && item.label !== 'UserDashboard') ||
    (userRole === 'User' && item.label === 'UserDashboard')
  );

  const isActive = (path) => location.pathname === path;

  const handleNavigation = (path) => {
    navigate(path);
    setNavMenuAnchor(null);
  };

  const handleLogout = () => {
    sessionStorage.clear();
    navigate("/login");
    setUserMenuAnchor(null);
  };

  const getInitials = (name) =>
    !name ? "G" : name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2);

  // Get status color and text for notification items
  const getNotificationStatus = (record, isAssignType) => {
    if (isAssignType) {
      return {
        color: '#f44336', // Red for pending approval
        text: 'Pending Approval',
        icon: <PendingIcon fontSize="small" />
      };
    } else {
      return {
        color: '#ff9800', // Orange for pending signoff
        text: 'Pending Signoff',
        icon: <AssignmentIcon fontSize="small" />
      };
    }
  };

  // Combine and format notification records for display
  const getDisplayRecords = () => {
    const assignRecords = (notificationData.Assign || []).map(record => ({
      ...record,
      type: 'assign',
      isAssignType: true
    }));
    
    const signoffRecords = (notificationData.signoff || []).map(record => ({
      ...record,
      type: 'signoff',
      isAssignType: false
    }));

    // Combine both arrays and sort by UpdatedDateTime (newest first)
    const combinedRecords = [...assignRecords, ...signoffRecords].sort((a, b) => {
      const dateA = new Date(a.UpdatedDateTime || 0);
      const dateB = new Date(b.UpdatedDateTime || 0);
      return dateB - dateA;
    });

    return combinedRecords;
  };

  const displayRecords = getDisplayRecords();

  return (
    <AppBar
      position="fixed"
      elevation={3}
      sx={{
        zIndex: 1300,
        background: "linear-gradient(135deg, #134380 0%, #1976d2 100%)",
        height: HEADER_HEIGHT,
        justifyContent: "center",
        borderBottom: "1px solid rgba(255,255,255,0.08)"
      }}
    >
      <Toolbar sx={{ minHeight: HEADER_HEIGHT, px: { xs: 1.5, md: 2 }, gap: 1 }}>
        {/* Left - Logo and Navigation Menu */}
        <Box sx={{ display: "flex", alignItems: "center", minWidth: 200, gap: 1 }}>
          {/* Navigation Menu Icon */}
          <IconButton
            onClick={(e) => setNavMenuAnchor(e.currentTarget)}
            sx={{
              color: "#fff",
              p: 0.5,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.1)'
              }
            }}
          >
            <MenuIcon fontSize="small" />
          </IconButton>

          <Box
            component="img"
            src={logo}
            alt="Nokia Logo"
            sx={{ height: 28, width: "auto", filter: "brightness(0) invert(1)" }}
          />
        </Box>

        {/* Center - Title */}
        <Box sx={{ flexGrow: 1, display: "flex", justifyContent: "center" }}>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 800,
              color: "#fff",
              fontSize: { xs: "1rem", md: "2rem" },
              letterSpacing: 0.2
            }}
          >
            PDM Smart View @360°
          </Typography>
        </Box>

        {/* Right - Notifications and User */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.75, minWidth: 160, justifyContent: "flex-end" }}>
          {/* Notification Icon with Hover */}
          <IconButton
            onClick={handleNotificationClick}
            onMouseEnter={handleNotificationHover}
            onMouseLeave={handleNotificationLeave}
            sx={{
              color: "#fff",
              p: 0.5,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.1)'
              }
            }}
          >
            <Badge badgeContent={notificationCount} color="error">
              <NotificationsIcon fontSize="small" />
            </Badge>
          </IconButton>

          {/* Notification Hover Popover */}
          <Popover
            open={Boolean(notificationAnchor)}
            anchorEl={notificationAnchor}
            onClose={handleNotificationLeave}
            disableRestoreFocus
            sx={{
              pointerEvents: 'none',
              '& .MuiPopover-paper': {
                pointerEvents: 'auto',
                mt: 1,
                maxWidth: 450,
                maxHeight: 600,
                borderRadius: 2,
                boxShadow: 6
              }
            }}
            transformOrigin={{ horizontal: "center", vertical: "top" }}
            anchorOrigin={{ horizontal: "center", vertical: "bottom" }}
            onMouseEnter={() => setNotificationAnchor(notificationAnchor)}
            onMouseLeave={handleNotificationLeave}
          >
            <Paper sx={{ p: 0 }}>
              {/* Header */}
              <Box sx={{ px: 2, py: 1.5, bgcolor: "#134380", color: "white" }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 1 }}>
                  <NotificationsIcon fontSize="small" />
                  Notifications ({notificationCount})
                </Typography>
              </Box>

              {/* Stats */}
              <Box sx={{ p: 2, bgcolor: "#f8f9fa" }}>
                <Box sx={{ display: 'flex', gap: 2, justifyContent: 'space-around' }}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" sx={{ fontWeight: 700, color: '#f44336' }}>
                      {notificationData.Assign?.length || 0}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#666' }}>
                      Pending Approval
                    </Typography>
                  </Box>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" sx={{ fontWeight: 700, color: '#ff9800' }}>
                      {notificationData.signoff?.length || 0}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#666' }}>
                      Pending Signoff
                    </Typography>
                  </Box>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" sx={{ fontWeight: 700, color: '#134380' }}>
                      {notificationCount}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#666' }}>
                      Total Pending
                    </Typography>
                  </Box>
                </Box>
              </Box>

              <Divider />

              {/* Recent Records */}
              <Box sx={{ maxHeight: 400, overflow: 'auto' }}>
                {displayRecords && displayRecords.length > 0 ? (
                  <List dense sx={{ py: 0 }}>
                    {displayRecords.slice(0, 15).map((record, index) => {
                      const status = getNotificationStatus(record, record.isAssignType);
                      return (
                        <ListItem key={`${record.ID}-${record.type}-${index}`} divider>
                          <ListItemAvatar>
                            <Avatar sx={{ 
                              width: 32, 
                              height: 32, 
                              bgcolor: status.color,
                              fontSize: '0.75rem'
                            }}>
                              {status.icon}
                            </Avatar>
                          </ListItemAvatar>
                          <ListItemText
                            primary={
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                  {record.Username || 'Unknown User'}
                                </Typography>
                                <Chip
                                  label={status.text}
                                  size="small"
                                  sx={{
                                    bgcolor: status.color,
                                    color: 'white',
                                    fontSize: '0.65rem',
                                    height: 20
                                  }}
                                />
                              </Box>
                            }
                            secondary={
                              <Box>
                                <Typography variant="caption" sx={{ color: '#666' }}>
                                  Role: {record.Role} | Team: {record.Team || 'N/A'}
                                </Typography>
                                <br />
                                <Typography variant="caption" sx={{ color: '#999' }}>
                                  Updated: {record.UpdatedDateTime ? 
                                    new Date(record.UpdatedDateTime).toLocaleDateString() : 'N/A'}
                                </Typography>
                                <br />
                                <Typography variant="caption" sx={{ color: '#666', fontWeight: 500 }}>
                                  Type: {record.isAssignType ? 'Approval Required' : 'Signoff Required'}
                                </Typography>
                              </Box>
                            }
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                ) : (
                  <Box sx={{ p: 3, textAlign: 'center' }}>
                    <NotificationsIcon sx={{ fontSize: 48, color: '#ddd', mb: 1 }} />
                    <Typography variant="body2" sx={{ color: '#666' }}>
                      No pending notifications
                    </Typography>
                  </Box>
                )}
              </Box>

              {/* Footer */}
              {displayRecords && displayRecords.length > 15 && (
                <>
                  <Divider />
                  <Box sx={{ p: 1.5, textAlign: 'center', bgcolor: '#f8f9fa' }}>
                    <Typography variant="caption" sx={{ color: '#666' }}>
                      Showing 15 of {displayRecords.length} records
                    </Typography>
                    <Typography
                      variant="caption"
                      sx={{
                        color: '#134380',
                        cursor: 'pointer',
                        textDecoration: 'underline',
                        ml: 1,
                        '&:hover': { color: '#1976d2' }
                      }}
                      onClick={handleNotificationClick}
                    >
                      View All
                    </Typography>
                  </Box>
                </>
              )}
            </Paper>
          </Popover>

          <Avatar
            sx={{
              bgcolor: "#fff",
              color: "#134380",
              width: 32,
              height: 32,
              fontSize: "0.85rem",
              fontWeight: 700,
              cursor: "pointer"
            }}
            onClick={(e) => setUserMenuAnchor(e.currentTarget)}
          >
            {getInitials(username)}
          </Avatar>

          <IconButton onClick={(e) => setUserMenuAnchor(e.currentTarget)} sx={{ color: "#fff", p: 0.5 }}>
            <PowerIcon fontSize="small" />
          </IconButton>

          {/* Navigation Menu */}
          <Menu
            anchorEl={navMenuAnchor}
            open={Boolean(navMenuAnchor)}
            onClose={() => setNavMenuAnchor(null)}
            TransitionComponent={Fade}
            PaperProps={{
              sx: {
                mt: 1,
                minWidth: 220,
                borderRadius: 2,
                boxShadow: 6,
                maxHeight: 400,
                overflow: 'auto'
              }
            }}
            transformOrigin={{ horizontal: "left", vertical: "top" }}
            anchorOrigin={{ horizontal: "left", vertical: "bottom" }}
          >
            {/* Navigation Header */}
            <Box sx={{ px: 2, py: 1.2, bgcolor: "#f8f9fa" }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: "#134380" }}>
                Navigation
              </Typography>
              <Typography variant="caption" sx={{ color: "#666" }}>
                {userRole === 'Admin' ? 'Admin Panel' : 'User Panel'}
              </Typography>
            </Box>
            <Divider />

            {/* Navigation Items */}
            {navItems.length > 0 ? (
              navItems.map((item) => (
                <MenuItem
                  key={item.label}
                  onClick={() => handleNavigation(item.path)}
                  sx={{
                    py: 1.25,
                    px: 2,
                    backgroundColor: isActive(item.path) ? `${item.color}12` : 'transparent',
                    borderLeft: isActive(item.path) ? `4px solid ${item.color}` : '4px solid transparent',
                    '&:hover': {
                      backgroundColor: isActive(item.path)
                        ? `${item.color}20`
                        : 'rgba(0, 0, 0, 0.04)'
                    }
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 40 }}>
                    <Box
                      sx={{
                        width: 32,
                        height: 32,
                        borderRadius: 1,
                        background: isActive(item.path)
                          ? `linear-gradient(135deg, ${item.color} 0%, ${item.color}80 100%)`
                          : '#f2f5f9',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        '& svg': {
                          fontSize: '1.1rem',
                          color: isActive(item.path) ? '#fff' : item.color
                        }
                      }}
                    >
                      {item.icon}
                    </Box>
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    primaryTypographyProps={{
                      fontSize: '0.9rem',
                      fontWeight: isActive(item.path) ? 600 : 500,
                      color: isActive(item.path) ? item.color : '#333'
                    }}
                  />
                </MenuItem>
              ))
            ) : (
              <MenuItem disabled>
                <ListItemText
                  primary="No navigation items available"
                  primaryTypographyProps={{ fontSize: '0.85rem', color: '#666' }}
                />
              </MenuItem>
            )}

            <Divider />
            {/* Footer in navigation menu */}
            <Box sx={{ px: 2, py: 1, bgcolor: "#f8f9fa" }}>
              <Typography variant="caption" sx={{ color: '#666', fontSize: '0.7rem' }}>
                © 2025 Nokia Corporation
              </Typography>
              <Typography variant="caption" sx={{ color: '#999', fontSize: '0.65rem', display: 'block', mt: 0.5 }}>
                Role: {userRole}
              </Typography>
            </Box>
          </Menu>

          {/* User Menu */}
          <Menu
            anchorEl={userMenuAnchor}
            open={Boolean(userMenuAnchor)}
            onClose={() => setUserMenuAnchor(null)}
            TransitionComponent={Fade}
            PaperProps={{ sx: { mt: 1, minWidth: 180, borderRadius: 2, boxShadow: 6 } }}
            transformOrigin={{ horizontal: "right", vertical: "top" }}
            anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
          >
            <Box sx={{ px: 2, py: 1.2, bgcolor: "#f8f9fa" }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: "#134380" }}>
                {username || "Guest User"}
              </Typography>
              <Typography variant="caption" sx={{ color: "#666" }}>
                {userRole}
              </Typography>
            </Box>
            <Divider />
            <MenuItem onClick={handleLogout} sx={{ py: 1.25, color: "#d32f2f" }}>
              <PowerIcon sx={{ mr: 1 }} /> Sign Out
            </MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
export { HEADER_HEIGHT, HEADER_GAP };