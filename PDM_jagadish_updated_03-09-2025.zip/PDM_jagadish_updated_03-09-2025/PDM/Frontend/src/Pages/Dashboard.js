import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import * as XLSX from "xlsx";
import { Trash2, Upload, Plus, Search, Sparkles, Zap, Target } from "lucide-react";
import {
  Dialog, DialogTitle, DialogContent, DialogActions, MenuItem, Select, FormControl, InputLabel,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  Box, Container, TextField, Button, Typography, CircularProgress, Alert, Snackbar,
  Card, CardContent, Grid, Chip, Tooltip, IconButton, useTheme, Fade, Zoom, Slide
} from "@mui/material";
import { FilterList as FilterListIcon, TrendingUp, Assessment, Speed, AutoAwesome } from "@mui/icons-material";
import { styled, alpha, keyframes } from '@mui/material/styles';
import Header from "../Pages/Header";
import Footer from "../Pages/Footer";
import { Data } from "../custom";
import AddSTIECN from "./AddSTIECN";
import "./Dashboard.css";
import { useMsal } from "@azure/msal-react";
import { jwtDecode } from "jwt-decode";

// Ultra-compact table controls
const TABLE_FONT = 10;
const ROW_HEIGHT = 36;
const HEADER_FONT = 10;
const CHIP_FONT = 9;

// Limit visible rows to reduce page scrolling.
const VISIBLE_ROWS = 6;

// Equal widths so columns align and stay tight
const COL_WIDTHS = {
  summaryStatus: 65,
  summaryEach: 50,
  cat: 75,
  pkg: 75,
  ecn: 75,
  fam: 80,
  name: 100,
  status: 48,
  action: 45
};

// Enhanced Animations
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const pulse = keyframes`
  0%, 100% { transform: scale(1); opacity: 0.9; }
  50% { transform: scale(1.05); opacity: 1; }
`;

const slideInLeft = keyframes`
  from { transform: translateX(-20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 5px rgba(33, 150, 243, 0.5); }
  50% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.8), 0 0 30px rgba(33, 150, 243, 0.6); }
`;

// Glowing bulb animations
const redGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #f44336, 0 0 10px #f44336, 0 0 15px #f44336;
    background: radial-gradient(circle, #ff6b6b, #f44336);
  }
  50% { 
    box-shadow: 0 0 10px #f44336, 0 0 20px #f44336, 0 0 30px #f44336;
    background: radial-gradient(circle, #ff8a80, #ff5722);
  }
`;

const yellowGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #ff9800, 0 0 10px #ff9800, 0 0 15px #ff9800;
    background: radial-gradient(circle, #ffb74d, #ff9800);
  }
  50% { 
    box-shadow: 0 0 10px #ff9800, 0 0 20px #ff9800, 0 0 30px #ff9800;
    background: radial-gradient(circle, #ffc947, #f57c00);
  }
`;

const greenGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #4caf50, 0 0 10px #4caf50, 0 0 15px #4caf50;
    background: radial-gradient(circle, #81c784, #4caf50);
  }
  50% { 
    box-shadow: 0 0 10px #4caf50, 0 0 20px #4caf50, 0 0 30px #4caf50;
    background: radial-gradient(circle, #a5d6a7, #2e7d32);
  }
`;

const silverGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #C0C0C0, 0 0 10px #C0C0C0, 0 0 15px #C0C0C0;
    background: radial-gradient(circle, #D3D3D3, #C0C0C0);
  }
  50% { 
    box-shadow: 0 0 10px #C0C0C0, 0 0 20px #C0C0C0, 0 0 30px #C0C0C0;
    background: radial-gradient(circle, #E5E5E5, #A9A9A9);
  }
`;

// Enhanced Styled Components
const ShellCard = styled(Card)(({ theme }) => ({
  borderRadius: 12,
  background: '#ffffff',
  boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.1)',
  border: `1px solid ${alpha(theme.palette.divider, 0.12)}`,
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 25px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.08)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '3px',
    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
  }
}));

const InstructionCard = styled(ShellCard)(({ theme }) => ({
  animation: `${fadeIn} 0.6s ease-out`,
  background: '#ffffff',
  border: `2px solid ${alpha(theme.palette.info.main, 0.2)}`,
  transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
  '&:hover': {
    transform: 'translateY(-3px) scale(1.02)',
    boxShadow: `0 12px 24px ${alpha(theme.palette.info.main, 0.15)}`,
    '&::before': {
      background: `linear-gradient(90deg, ${theme.palette.info.main}, ${theme.palette.info.dark})`,
      height: '4px',
    }
  }
}));

const TightTableContainer = styled(TableContainer)(({ theme }) => ({
  borderRadius: 8,
  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  overflow: 'hidden',
  background: '#ffffff',
  boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
  '&:hover': {
    boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
  }
}));

const FixedTable = styled(Table)({
  tableLayout: 'fixed',
  width: '100%'
});

const TightHead = styled(TableHead)(({ theme }) => ({
  '& .MuiTableCell-head': {
    background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
    color: theme.palette.primary.contrastText,
    fontWeight: 800,
    fontSize: `${HEADER_FONT}px`,
    padding: '3px 3px',
    lineHeight: 1.05,
    whiteSpace: 'pre-line',
    textAlign: 'center',
    position: 'relative',
    textShadow: '0 1px 2px rgba(0,0,0,0.1)',
    '&::after': {
      content: '""',
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      height: '2px',
      background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
    }
  }
}));

const HeadCell = styled(TableCell)({
  fontSize: `${HEADER_FONT}px`,
  padding: '6px 3px',
  lineHeight: 1.05,
  whiteSpace: 'pre-line',
  textAlign: 'center',
  overflow: 'hidden',
  textOverflow: 'ellipsis'
});

const BodyCell = styled(TableCell)(({ theme }) => ({
  fontSize: `${TABLE_FONT}px`,
  padding: '6px 3px',
  height: ROW_HEIGHT,
  textAlign: 'center',
  verticalAlign: 'middle',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

const CompactButton = styled(Button)(({ theme }) => ({
  borderRadius: 8,
  padding: '6px 12px',
  fontWeight: 700,
  textTransform: 'none',
  fontSize: '0.76rem',
  minHeight: 26,
  boxShadow: '0 3px 12px rgba(0, 0, 0, 0.15)',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 100%)`,
    transform: 'translateY(-1px)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
    transition: 'left 0.5s',
  },
  '&:hover::before': {
    left: '100%',
  }
}));

const GlowingBulb = styled(Box)(({ status }) => {
  let animation = '';
  if (status === '0' || status === 0) {
    animation = redGlow;
  } else if (status === '1' || status === 1) {
    animation = greenGlow;
  } else if (status === '2' || status === 2) {
    animation = yellowGlow;
  } else {
    animation = silverGlow;
  }

  return {
    width: 16,
    height: 16,
    borderRadius: '50%',
    animation: `${animation} 2s ease-in-out infinite`,
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    display: 'inline-block',
    '&:hover': {
      transform: 'scale(1.2)',
    }
  };
});

const EnhancedTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: 10,
    transition: 'all 0.3s ease',
    background: '#ffffff',
    '&:hover': {
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
    },
    '&.Mui-focused': {
      animation: `${glow} 2s infinite`,
      transform: 'translateY(-1px)',
    }
  }
}));

const StatusRow = styled(TableRow)(({ theme }) => ({
  animation: `${slideInLeft} 0.5s ease-out`,
  transition: 'all 0.3s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.02),
    transform: 'translateX(4px)',
    boxShadow: `inset 4px 0 0 ${theme.palette.primary.main}`,
  }
}));

const clickableCellStyle = () => ({
  cursor: 'pointer',
  padding: '8px',
  textAlign: 'center',
  transition: 'all 0.3s ease',
  '&:hover': {
    transform: 'scale(1.05)',
    boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
  }
});

const LoadingOverlay = styled(Box)({
  position: 'fixed',
  inset: 0,
  background: 'linear-gradient(135deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.5) 100%)',
  backdropFilter: 'blur(8px)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 9999,
});

const LoadingCard = styled(ShellCard)(({ theme }) => ({
  padding: theme.spacing(3),
  textAlign: 'center',
  minWidth: 240,
  background: '#ffffff',
  animation: `${pulse} 2s infinite`,
}));

const Dashboard = () => {
  // State Management
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [excelData, setExcelData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPhase, setCurrentPhase] = useState("preimp");
  const [updateLoading, setUpdateLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [summaryData, setSummaryData] = useState([]);
  const [detailData, setDetailData] = useState([]);
  const [openPopup, setOpenPopup] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCpId, setSelectedCpId] = useState(null);
  const [username, setUsername] = useState("");
  const [statusDialog, setStatusDialog] = useState({ open: false, cpId: null, fieldKey: null, currentStatus: null, newStatus: "" });
  const [detailedUserData, setDetailedUserData] = useState([]);
  const [userDetailModal, setUserDetailModal] = useState(false);
  const [userDetailInfo, setUserDetailInfo] = useState({ team: '', status: '', count: 0 });

  const navigate = useNavigate();
  const theme = useTheme();
  const { instance, accounts } = useMsal();

  // Field mapping configuration
  const fieldMapping = {
    pdm: "PDM", mmBuyer: "MM_Buyer", mmLogistics: "MM_logistics", sqa: "SQA", wh: "WH",
    mc: "MC", smt: "SMT", msSmt: "MS_SMT", msJe: "MS_IE", msTest: "MS_TEST",
    msPt: "MS_PT", msPe: "MS_PE", msIt: "MS_IT", ops: "OPS",
  };

  // TeamId mapping for API
  const teamIdMapping = {
    pdm: 1, mmBuyer: 2, mmLogistics: 3, sqa: 4, wh: 5, mc: 6, smt: 7,
    msSmt: 8, msJe: 9, msTest: 10, msPt: 11, msPe: 12, msIt: 13, ops: 14,
  };

  // Utility functions
  const getUpdateEndpoint = (phase) => {
    const endpoints = { preimp: 'updatestatuspreimp', TrailStatus: 'updatestatustrailstatus', postimp: 'updatestatustrailstatus' };
    return endpoints[phase] || 'updatestatuspreimp';
  };

  const getPhaseTitle = (phase) => {
    const titles = { preimp: 'Pre-Implementation Status', postimp: 'Post-Implementation Status' };
    return titles[phase] || 'Action Status';
  };

  const getStatusText = (status) => {
    const map = { '0': 'Open', 0: 'Open', '1': 'Closed', 1: 'Closed', '2': 'Progress', 2: 'Progress' };
    return map[status] || 'NA';
  };

  const getStatusBulb = (status) => {
    return <GlowingBulb status={status} />;
  };

  const handleViewColumnData = async (fieldKey, statusValue, count = 50) => {
    if (statusValue === '1' || statusValue === 1) {
      setSnackbar({
        open: true,
        message: "👁️ View details only available for Open and In Progress items",
        severity: "info"
      });
      return;
    }

    try {
      setLoading(true);
      const teamId = teamIdMapping[fieldKey];

      if (!teamId) {
        setSnackbar({
          open: true,
          message: "❌ Invalid team selection",
          severity: "error"
        });
        return;
      }

      const response = await axios.post(`${Data.url}/getusernamebycountbypreimp`, {
        status: parseInt(statusValue),
        count: count,
        TeamId: teamId
      });

      if (response.data && response.data.users) {
        const userData = response.data.users;
        const teamName = response.data.team;
        const statusText = statusValue === 0 ? 'Open' : 'In Progress';

        setDetailedUserData(userData);
        setUserDetailInfo({
          team: teamName,
          status: statusText,
          count: userData.length
        });
        setUserDetailModal(true);

        setSnackbar({
          open: true,
          message: `👥 Found ${userData.length} users for ${teamName} team - ${statusText} status`,
          severity: "success"
        });

        console.log('User Details:', {
          team: teamName,
          status: statusText,
          count: userData.length,
          users: userData
        });
      } else {
        setSnackbar({
          open: true,
          message: "❌ No user details found",
          severity: "warning"
        });
      }
    } catch (error) {
      console.error('Error fetching user details:', error);
      setSnackbar({
        open: true,
        message: `❌ Error: ${error.response?.data?.error || error.message}`,
        severity: "error"
      });
    } finally {
      setLoading(false);
    }
  };

  // Effects
  useEffect(() => {
    const fetchName = async () => {
      try {
        const request = {
          account: accounts[0],
          scopes: ["User.Read"],
          prompt: "select_account"
        };

        const response = await instance.acquireTokenSilent(request);
        const decoded = jwtDecode(response.idToken);
        const name = decoded?.name || "Unknown User";
        setUsername(name);
        sessionStorage.setItem("username", name);
      } catch (error) {
        console.error('Token acquisition failed:', error);
        if (error.errorCode === "consent_required" ||
          error.errorCode === "interaction_required") {
          try {
            const interactiveRequest = {
              scopes: ["User.Read"],
              prompt: "consent"
            };
            await instance.loginPopup(interactiveRequest);
            fetchName();
          } catch (interactiveError) {
            console.error("Interactive login failed:", interactiveError);
          }
        }
      }
    };

    if (accounts.length > 0) {
      fetchName();
    } else {
      instance.loginPopup({
        scopes: ["User.Read"],
        prompt: "select_account"
      }).catch(console.error);
    }
  }, [accounts, instance]);

  useEffect(() => {
    fetchStatusData(currentPhase);
    sessionStorage.removeItem('currentCpId');
  }, [searchTerm, currentPhase]);

  // API functions
  const fetchStatusData = async (endpoint) => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.post(`${Data.url}/${endpoint}`, { search: searchTerm.trim() });
      processApiData(response.data);
      setCurrentPhase(endpoint);
    } catch (err) {
      setError(`Failed to fetch data: ${err.message || 'An error occurred'}`);
    } finally {
      setLoading(false);
    }
  };

  const processApiData = (response) => {
    if (response && response.data && response.statusCount) {
      const data = response.data;
      const statusCount = response.statusCount;

      const processed = data.map(item => ({
        category: item.Category || 'N/A',
        packageId: item.CP_ID || 'N/A',
        ecnStiNumber: item.ECN_STI_Number || 'N/A',
        productFamily: item.Product_Family || 'N/A',
        productName: item.Product_Name || 'N/A',
        pdm: item.PDM ?? 'NA',
        mmBuyer: item.MM_Buyer ?? 'NA',
        mmLogistics: item.MM_logistics ?? 'NA',
        sqa: item.SQA ?? 'NA',
        wh: item.WH ?? 'NA',
        mc: item.MC ?? 'NA',
        smt: item.SMT ?? 'NA',
        msSmt: item.MS_SMT ?? 'NA',
        msJe: item.MS_IE ?? 'NA',
        msTest: item.MS_TEST ?? 'NA',
        msPt: item.MS_PT ?? 'NA',
        msPe: item.MS_PE ?? 'NA',
        msIt: item.MS_IT ?? 'NA',
        ops: item.OPS ?? 'NA',
      }));
      setDetailData(processed);

      const summaryRows = [
        {
          team: "Open",
          pdm: statusCount.open.PDM || 0, mmBuyer: statusCount.open.MM_Buyer || 0, mmLogistics: statusCount.open.MM_logistics || 0,
          sqa: statusCount.open.SQA || 0, wh: statusCount.open.WH || 0, mc: statusCount.open.MC || 0, smt: statusCount.open.SMT || 0,
          msSmt: statusCount.open.MS_SMT || 0, msJe: statusCount.open.MS_IE || 0, msTest: statusCount.open.MS_TEST || 0,
          msPt: statusCount.open.MS_PT || 0, msPe: statusCount.open.MS_PE || 0, msIt: statusCount.open.MS_IT || 0, ops: statusCount.open.OPS || 0,
        },
        {
          team: "Progress",
          pdm: statusCount.inprogress.PDM || 0, mmBuyer: statusCount.inprogress.MM_Buyer || 0, mmLogistics: statusCount.inprogress.MM_logistics || 0,
          sqa: statusCount.inprogress.SQA || 0, wh: statusCount.inprogress.WH || 0, mc: statusCount.inprogress.MC || 0, smt: statusCount.inprogress.SMT || 0,
          msSmt: statusCount.inprogress.MS_SMT || 0, msJe: statusCount.inprogress.MS_IE || 0, msTest: statusCount.inprogress.MS_TEST || 0,
          msPt: statusCount.inprogress.MS_PT || 0, msPe: statusCount.inprogress.MS_PE || 0, msIt: statusCount.inprogress.MS_IT || 0, ops: statusCount.inprogress.OPS || 0,
        },
      ];
      setSummaryData(summaryRows);
    } else {
      setDetailData([]);
      setSummaryData([]);
      setError("Invalid API response format or no data.");
    }
  };

  // Event handlers
  const handleStatusClick = (cpId, fieldKey, currentStatus) => {
    setStatusDialog({
      open: true, cpId, fieldKey, currentStatus,
      newStatus: currentStatus != null ? currentStatus.toString() : "0",
    });
  };

  const handleStatusUpdate = async () => {
    try {
      setUpdateLoading(true);
      if (!["0", "1", "2"].includes(statusDialog.newStatus)) throw new Error("Invalid status value");
      const updateData = { field: fieldMapping[statusDialog.fieldKey], Status: statusDialog.newStatus, CP_ID: statusDialog.cpId };
      const endpoint = getUpdateEndpoint(currentPhase);
      const response = await axios.post(`${Data.url}/${endpoint}`, updateData);
      if (response.status === 200) {
        setSnackbar({ open: true, message: `✨ Status updated successfully for ${fieldMapping[statusDialog.fieldKey]}`, severity: "success" });
        setTimeout(() => fetchStatusData(currentPhase), 400);
      }
    } catch (error) {
      setSnackbar({ open: true, message: `❌ Failed to update status: ${error.response?.data?.message || error.message}`, severity: "error" });
    } finally {
      setStatusDialog({ ...statusDialog, open: false });
      setUpdateLoading(false);
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const validTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
      if (!validTypes.includes(file.type)) {
        setSnackbar({ open: true, message: "⚠️ Please upload a valid Excel file (.xlsx or .xls)", severity: "error" });
        setSelectedFile(null);
        setExcelData([]);
        return;
      }
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.SheetNames[0];
        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet], { defval: null });
        setExcelData(jsonData);
      };
      reader.readAsArrayBuffer(file);
    } else {
      setSelectedFile(null);
      setExcelData([]);
    }
  };

  const handleUpdateECNSTI = async () => {
    if (!selectedFile || excelData.length === 0) {
      setSnackbar({ open: true, message: "⚠️ Please select an Excel file first", severity: "error" });
      return;
    }
    try {
      setUpdateLoading(true);
      const formattedData = excelData.map(row => ({
        Change_Note_Cateogry: row.Change_Note_Cateogry || null,
        CP_ID: row.CP_ID || null,
        ECN_STI_Number: row.ECN_STI_Number || null,
        Receieved_Date: row.Receieved_Date ? new Date(row.Receieved_Date).toISOString() : null,
        Product_Family: row.Product_Family || null,
        Product_Sale_code: row.Product_Sale_code || null,
        Product_Name: row.Product_Name || null,
        Category: row.Category || null,
        Brief_Details: row.Brief_Details || null,
      }));
      const response = await axios.post(`${Data.url}/addECNbyexcel`, formattedData);
      if (response.status === 200) {
        setSnackbar({ open: true, message: "🎉 ECN/STI data updated successfully", severity: "success" });
        setSelectedFile(null);
        setExcelData([]);
        fetchStatusData(currentPhase);
      }
    } catch (error) {
      setSnackbar({ open: true, message: `❌ Failed to update ECN/STI: ${error.response?.data?.message || error.message}`, severity: "error" });
    } finally {
      setUpdateLoading(false);
    }
  };

  const handlePackageIdClick = (cpId) => {
    sessionStorage.setItem('currentCpId', cpId);
    navigate(`/UpdatePackageOwner1/${cpId}`);
  };

  const handleConfirmDelete = async () => {
    try {
      setUpdateLoading(true);
      const response = await axios.delete(`${Data.url}/deletePackage/${selectedCpId}`);
      if (response.status === 200) {
        setSnackbar({ open: true, message: `🗑️ Package ${selectedCpId} deleted successfully.`, severity: 'success' });
        fetchStatusData(currentPhase);
      }
    } catch (err) {
      setSnackbar({ open: true, message: `❌ Failed to delete ${selectedCpId}: ${err.response?.data?.error || err.message}`, severity: 'error' });
    } finally {
      setUpdateLoading(false);
      setDeleteDialogOpen(false);
      setSelectedCpId(null);
    }
  };

  const filteredDetailData = detailData.filter(item =>
    item.packageId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.ecnStiNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Header username={username} />

      <Box sx={{
        height: 'calc(100vh - 86px)',
        backgroundColor: '#ffffff',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
      }}>

        {(updateLoading || loading) && (
          <Fade in={updateLoading || loading}>
            <LoadingOverlay>
              <Zoom in={updateLoading || loading}>
                <LoadingCard>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                    <CircularProgress size={32} sx={{ mr: 2 }} />
                    <AutoAwesome style={{ fontSize: 24, color: theme.palette.primary.main }} />
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 700, color: 'primary.main' }}>Processing...</Typography>
                  <Typography variant="body2" sx={{ color: 'text.secondary', mt: 1 }}>Please wait while we update your data</Typography>
                </LoadingCard>
              </Zoom>
            </LoadingOverlay>
          </Fade>
        )}

        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          TransitionComponent={Slide}
        >
          <Alert
            onClose={() => setSnackbar({ ...snackbar, open: false })}
            severity={snackbar.severity}
            sx={{
              width: '100%',
              borderRadius: 2,
              fontWeight: 600,
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>

        <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', px: 2, py: 1, position: 'relative', zIndex: 1 }}>
          <Container maxWidth="xl" sx={{ px: 1 }}>

            <Fade in timeout={800}>
              <Box sx={{ mb: 2, mt: 7, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Assessment sx={{ mr: 1, color: 'primary.main', fontSize: '2rem' }} />
                  <Typography
                    variant="h4"
                    component="h1"
                    sx={{
                      fontWeight: 800,
                      color: 'primary.main',
                      fontSize: '1.8rem',
                      mb: 0.5,
                      textShadow: '0 2px 4px rgba(0,0,0,0.1)',
                    }}
                  >
                    PDM Dashboard
                  </Typography>
                </Box>
                <EnhancedTextField
                  placeholder="🔍 Search by Package ID, Product Name, or ECN/STI..."
                  size="small"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  InputProps={{
                    startAdornment: <Search size={16} style={{ marginRight: 8, color: theme.palette.primary.main }} />
                  }}
                  sx={{
                    width: 280,
                    '& .MuiInputBase-input': { fontSize: 12, py: 0.4, fontWeight: 500 }
                  }}
                />
              </Box>
            </Fade>

            {error && (
              <Slide direction="down" in={!!error}>
                <Alert
                  severity="error"
                  sx={{
                    py: 0.6,
                    fontSize: 12,
                    mb: 1,
                    borderRadius: 2,
                    border: '1px solid #f44336',
                  }}
                >
                  <strong>❌ Error:</strong> {error}
                </Alert>
              </Slide>
            )}

            <Fade in timeout={1000}>
              <ShellCard sx={{
                mb: 1,
                background: '#ffffff',
                border: '2px solid rgba(33,150,243,0.2)',
              }}>
                <CardContent sx={{ p: 0.8, '&:last-child': { pb: 0.8 } }}>
                  <Grid container spacing={0.8} alignItems="center">
                    <Grid item xs={12} sm={6} md={3}>
                      <CompactButton component="label" startIcon={<Upload size={14} />} fullWidth>
                        📄 Choose Excel
                        <input type="file" hidden accept=".xlsx,.xls" onChange={handleFileChange} />
                      </CompactButton>
                    </Grid>
                    <Grid item xs={12} sm={6} md={3.5}>
                      <Box sx={{
                        p: 0.8,
                        border: '3px dashed',
                        borderColor: selectedFile ? 'success.main' : 'primary.light',
                        borderRadius: 3,
                        textAlign: 'center',
                        background: '#ffffff',
                        minHeight: 28,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'scale(1.02)',
                        }
                      }}>
                        <Typography variant="body2" sx={{
                          color: selectedFile ? 'success.dark' : 'primary.main',
                          fontWeight: selectedFile ? 700 : 500,
                          fontSize: 11
                        }}>
                          {selectedFile ? (
                            <>
                              <Zap size={12} style={{ marginRight: 4, verticalAlign: 'middle' }} />
                              {selectedFile.name.substring(0, 20)}
                              {selectedFile.name.length > 20 ? '...' : ''}
                            </>
                          ) : (
                            <>
                              <Target size={12} style={{ marginRight: 4, verticalAlign: 'middle' }} />
                              No file selected
                            </>
                          )}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={6} sm={4} md={2}>
                      <CompactButton
                        onClick={handleUpdateECNSTI}
                        disabled={updateLoading || !selectedFile}
                        startIcon={updateLoading ? <CircularProgress size={12} /> : <Upload size={13} />}
                        fullWidth
                      >
                        🚀 Update ECN/STI
                      </CompactButton>
                    </Grid>
                    <Grid item xs={6} sm={4} md={1.7}>
                      <CompactButton onClick={() => setOpenPopup(true)} startIcon={<Plus size={13} />} fullWidth>
                        ➕ Add STI/ECN
                      </CompactButton>
                    </Grid>
                    <Grid item xs={6} sm={4} md={1.4}>
                      <Button
                        onClick={() => fetchStatusData('preimp')}
                        disabled={loading}
                        startIcon={loading && currentPhase === 'preimp' ? <CircularProgress size={12} /> : <TrendingUp sx={{ fontSize: 16 }} />}
                        fullWidth
                        sx={{
                          background: currentPhase === 'preimp'
                            ? 'linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)'
                            : 'linear-gradient(135deg, #42a5f5 0%, #1e88e5 100%)',
                          color: '#fff',
                          fontWeight: 700,
                          fontSize: '0.7rem',
                          minHeight: 28,
                          borderRadius: 3,
                          textTransform: 'none',
                          padding: '6px 4px',
                          boxShadow: currentPhase === 'preimp' ? '0 4px 12px rgba(25, 118, 210, 0.4)' : '0 2px 8px rgba(66, 165, 245, 0.3)',
                          transition: 'all 0.3s ease',
                          '&:hover': {
                            transform: 'translateY(-2px)',
                            boxShadow: '0 6px 16px rgba(25, 118, 210, 0.5)',
                          }
                        }}
                      >
                        🔄 Pre-implementation
                      </Button>
                    </Grid>
                    <Grid item xs={6} sm={4} md={1.4}>
                      <Button
                        onClick={() => fetchStatusData('postimp')}
                        disabled={loading}
                        startIcon={loading && currentPhase === 'postimp' ? <CircularProgress size={12} /> : <Speed sx={{ fontSize: 16 }} />}
                        fullWidth
                        sx={{
                          background: currentPhase === 'postimp'
                            ? 'linear-gradient(135deg, #f57c00 0%, #e65100 100%)'
                            : 'linear-gradient(135deg, #ffa726 0%, #ff9800 100%)',
                          color: '#fff',
                          fontWeight: 700,
                          fontSize: '0.7rem',
                          minHeight: 28,
                          borderRadius: 3,
                          textTransform: 'none',
                          padding: '6px 4px',
                          boxShadow: currentPhase === 'postimp' ? '0 4px 12px rgba(245, 124, 0, 0.4)' : '0 2px 8px rgba(255, 167, 38, 0.3)',
                          transition: 'all 0.3s ease',
                          '&:hover': {
                            transform: 'translateY(-2px)',
                            boxShadow: '0 6px 16px rgba(245, 124, 0, 0.5)',
                          }
                        }}
                      >
                        ⚡ Post-implementation
                      </Button>
                    </Grid>
                  </Grid>
                </CardContent>
              </ShellCard>
            </Fade>

            {!loading && summaryData.length > 0 && (
              <Fade in timeout={1200}>
                <ShellCard sx={{ mb: 1 }}>
                  <CardContent sx={{ p: 0.8, '&:last-child': { pb: 0.8 } }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <TrendingUp sx={{ mr: 1, color: 'primary.main' }} />
                      <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 800, fontSize: '1.2rem' }}>
                        {getPhaseTitle(currentPhase)} - Summary Overview
                      </Typography>
                    </Box>

                    <TightTableContainer component={Paper}>
                      <FixedTable size="small">
                        <TightHead>
                          <TableRow>
                            <HeadCell sx={{ width: COL_WIDTHS.summaryStatus, minWidth: COL_WIDTHS.summaryStatus }}>
                              Status
                            </HeadCell>
                            {[
                              'PDM', 'MM\nBuyer', 'MM\nLogistics', 'SQA', 'WH', 'MC', 'SMT',
                              'MS-\nSMT', 'MS-\nIE', 'MS-\nTEST', 'MS-\nPT', 'MS-\nPE', 'MS-\nIT', 'OPS'
                            ].map((label, idx) => (
                              <HeadCell key={idx} sx={{ width: COL_WIDTHS.summaryEach, minWidth: COL_WIDTHS.summaryEach }}>
                                {label}
                              </HeadCell>
                            ))}
                          </TableRow>
                        </TightHead>
                        <TableBody>
                          {summaryData.map((row, index) => (
                            <StatusRow key={index}>
                              <BodyCell sx={{ textAlign: 'center', fontWeight: 800, color: 'primary.main' }}>
                                {row.team}
                              </BodyCell>
                              {[row.pdm, row.mmBuyer, row.mmLogistics, row.sqa, row.wh, row.mc, row.smt, row.msSmt, row.msJe, row.msTest, row.msPt, row.msPe, row.msIt, row.ops]
                                .map((val, i2) => {
                                  const columnKeys = ['pdm', 'mmBuyer', 'mmLogistics', 'sqa', 'wh', 'mc', 'smt', 'msSmt', 'msJe', 'msTest', 'msPt', 'msPe', 'msIt', 'ops'];
                                  const statusValue = row.team === 'Open' ? 0 : 2;

                                  return (
                                    <BodyCell
                                      key={i2}
                                      sx={{
                                        fontWeight: 600,
                                        color: val > 0 ? 'primary.main' : 'text.secondary',
                                        position: 'relative',
                                        cursor: val > 0 && statusValue !== 1 ? 'pointer' : 'default',
                                        '&:hover': {
                                          backgroundColor: val > 0 ? alpha(theme.palette.primary.main, 0.05) : 'transparent',
                                          transform: val > 0 && statusValue !== 1 ? 'scale(1.05)' : 'none',
                                        }
                                      }}
                                      onClick={() => val > 0 && statusValue !== 1 && handleViewColumnData(columnKeys[i2], statusValue, val)}
                                    >
                                      <Tooltip
                                        title={val > 0 && statusValue !== 1 ? `View users: ${fieldMapping[columnKeys[i2]] || columnKeys[i2]} - ${row.team}` : ''}
                                        placement="top"
                                      >
                                        <Typography sx={{ fontSize: `${TABLE_FONT}px`, fontWeight: 600 }}>
                                          {val}
                                        </Typography>
                                      </Tooltip>
                                    </BodyCell>
                                  );
                                })}
                            </StatusRow>
                          ))}
                        </TableBody>
                      </FixedTable>
                    </TightTableContainer>
                  </CardContent>
                </ShellCard>
              </Fade>
            )}

            <InstructionCard sx={{ my: 1 }}>
              <CardContent sx={{ p: 1.2, '&:last-child': { pb: 1.2 } }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Box sx={{
                    p: 1,
                    borderRadius: '50%',
                    background: `linear-gradient(135deg, ${theme.palette.info.main}, ${theme.palette.info.dark})`,
                    mr: 1.5,
                    animation: `${pulse} 2s infinite`,
                  }}>
                    <Sparkles size={16} style={{ color: '#fff' }} />
                  </Box>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', color: 'info.dark', fontWeight: 700 }}>
                    💡 <strong>Quick Actions:</strong> Click status cells to update • Click{' '}
                    <Box component="span" sx={{
                      px: 1,
                      py: 0.3,
                      borderRadius: 1,
                      background: 'linear-gradient(45deg, #1976d2, #42a5f5)',
                      color: '#fff',
                      fontWeight: 800,
                      display: 'inline-block',
                    }}>
                      Package ID
                    </Box>{' '}
                    for detailed view
                  </Typography>
                </Box>
              </CardContent>
            </InstructionCard>

            {!loading && detailData.length > 0 && (
              <Fade in timeout={1400}>
                <ShellCard>
                  <CardContent sx={{ p: 0.8, '&:last-child': { pb: 0.8 } }}>
                    <Box sx={{ mb: 0.4, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Assessment sx={{ mr: 1, color: 'primary.main' }} />
                        <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 800, fontSize: '1.2rem' }}>
                          Detailed Action Status
                        </Typography>
                      </Box>
                      <Chip
                        label={`${filteredDetailData.length} Records`}
                        color="primary"
                        size="small"
                        sx={{ fontWeight: 700 }}
                      />
                    </Box>

                    <Box sx={{
                      mb: 1,
                      p: 1.5,
                      backgroundColor: alpha(theme.palette.primary.main, 0.02),
                      border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
                      borderRadius: 2,
                    }}>
                      <Typography variant="body2" sx={{
                        fontSize: '0.85rem',
                        fontWeight: 700,
                        color: 'primary.main',
                        mb: 1
                      }}>
                        📊 Status Indicators:
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', alignItems: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box sx={{
                            width: 16,
                            height: 16,
                            borderRadius: '50%',
                            animation: `${redGlow} 2s infinite`,
                            border: '2px solid #f44336',
                          }} />
                          <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                            Open
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box sx={{
                            width: 16,
                            height: 16,
                            borderRadius: '50%',
                            animation: `${greenGlow} 2s infinite`,
                            border: '2px solid #4caf50',
                          }} />
                          <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                            Closed
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box sx={{
                            width: 16,
                            height: 16,
                            borderRadius: '50%',
                            animation: `${yellowGlow} 2s infinite`,
                            border: '2px solid #ff9800',
                          }} />
                          <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                            In Progress
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box sx={{
                            width: 16,
                            height: 16,
                            borderRadius: '50%',
                            animation: `${silverGlow} 2s infinite`,
                            border: `2px solid ${alpha('#C0C0C0', 0.7)}`,
                          }} />
                          <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                            NA
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    <TightTableContainer component={Paper}>
                      <FixedTable size="small">
                        <TightHead>
                          <TableRow>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>Category</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>Package ID</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>ECN/STI</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>Product Family</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>Product Name</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>PDM</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MM Buyer</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MM Logistics</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>SQA</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>WH</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MC</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>SMT</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-SMT</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-IE</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-TEST</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-PT</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-PE</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>MS-IT</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.status, minWidth: COL_WIDTHS.status }}>OPS</HeadCell>
                            <HeadCell sx={{ width: COL_WIDTHS.action, minWidth: COL_WIDTHS.action }}>Action</HeadCell>
                          </TableRow>
                        </TightHead>
                        <TableBody>
                          {filteredDetailData.slice(0, VISIBLE_ROWS).map((row, index) => (
                            <StatusRow key={index} style={{ animationDelay: `${index * 100}ms` }}>
                              <BodyCell sx={{ fontWeight: 600, textAlign: 'center' }}>{row.category}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>
                                <Button
                                  onClick={() => handlePackageIdClick(row.packageId)}
                                  sx={{
                                    textTransform: 'none',
                                    fontWeight: 800,
                                    color: 'primary.main',
                                    fontSize: `${TABLE_FONT}px`,
                                    p: 0,
                                    minWidth: 0,
                                    transition: 'all 0.3s ease',
                                    '&:hover': {
                                      color: 'primary.dark',
                                      transform: 'scale(1.1)',
                                    }
                                  }}
                                >
                                  🔗 {row.packageId}
                                </Button>
                              </BodyCell>
                              <BodyCell sx={{ fontWeight: 600, textAlign: 'center' }}>{row.ecnStiNumber}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>{row.productFamily}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>{row.productName}</BodyCell>

                              {['pdm', 'mmBuyer', 'mmLogistics', 'sqa', 'wh', 'mc', 'smt', 'msSmt', 'msJe', 'msTest', 'msPt', 'msPe', 'msIt', 'ops'].map((field) => (
                                <BodyCell
                                  key={field}
                                  align="center"
                                  sx={clickableCellStyle()}
                                  onClick={() => handleStatusClick(row.packageId, field, row[field])}
                                >
                                  <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    {getStatusBulb(row[field])}
                                  </Box>
                                </BodyCell>
                              ))}

                              <BodyCell align="center">
                                <Tooltip title="Delete Package" placement="top">
                                  <IconButton
                                    size="small"
                                    color="error"
                                    onClick={() => { setSelectedCpId(row.packageId); setDeleteDialogOpen(true); }}
                                    sx={{
                                      p: '3px',
                                      borderRadius: 2,
                                      transition: 'all 0.3s ease',
                                      '&:hover': {
                                        transform: 'scale(1.2)',
                                        backgroundColor: alpha('#f44336', 0.1),
                                      }
                                    }}
                                  >
                                    <Trash2 size={13} />
                                  </IconButton>
                                </Tooltip>
                              </BodyCell>
                            </StatusRow>
                          ))}
                        </TableBody>
                      </FixedTable>
                    </TightTableContainer>

                    {filteredDetailData.length > VISIBLE_ROWS && (
                      <Typography sx={{
                        mt: 0.6,
                        fontSize: 11,
                        color: 'text.secondary',
                        textAlign: 'center',
                        fontStyle: 'italic',
                      }}>
                        📊 Showing first {VISIBLE_ROWS} rows to optimize performance. Use search to filter specific items.
                      </Typography>
                    )}
                  </CardContent>
                </ShellCard>
              </Fade>
            )}
          </Container>
        </Box>

        <AddSTIECN
          open={openPopup}
          onClose={() => setOpenPopup(false)}
          onSuccess={() => { setOpenPopup(false); fetchStatusData(currentPhase); }}
        />

        <Dialog
          open={userDetailModal}
          onClose={() => setUserDetailModal(false)}
          fullWidth
          maxWidth="md"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
          TransitionComponent={Zoom}
        >
          <DialogTitle sx={{
            pb: 1,
            fontSize: 17,
            fontWeight: 900,
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            textAlign: 'center',
          }}>
            👥 {userDetailInfo.team} Team - {userDetailInfo.status} Status Details
          </DialogTitle>
          <DialogContent sx={{ pt: 2, pb: 2 }}>
            {detailedUserData.length > 0 ? (
              <Box>
                <Typography variant="body1" sx={{ mb: 2, fontWeight: 600, color: 'primary.main' }}>
                  Found {userDetailInfo.count} users in {userDetailInfo.team} team with {userDetailInfo.status} status:
                </Typography>
                <Box sx={{ maxHeight: 400, overflowY: 'auto' }}>
                  {detailedUserData.map((user, index) => (
                    <Card key={index} sx={{ mb: 1, p: 1.5, border: '1px solid rgba(0,0,0,0.1)', borderRadius: 2 }}>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <Typography variant="body2" sx={{ fontSize: 13 }}>
                            <strong>👤 Username:</strong> {user.Username}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <Typography variant="body2" sx={{ fontSize: 13 }}>
                            <strong>📧 Email:</strong> {user.Emailid}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <Typography variant="body2" sx={{ fontSize: 13 }}>
                            <strong>📦 Package ID:</strong> {user.CP_ID}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Card>
                  ))}
                </Box>
              </Box>
            ) : (
              <Typography sx={{ textAlign: 'center', color: 'text.secondary', py: 4 }}>
                No user data available
              </Typography>
            )}
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2 }}>
            <CompactButton
              onClick={() => setUserDetailModal(false)}
              sx={{ minWidth: 120 }}
            >
              Close
            </CompactButton>
          </DialogActions>
        </Dialog>

        <Dialog
          open={statusDialog.open}
          onClose={() => setStatusDialog({ ...statusDialog, open: false })}
          fullWidth
          maxWidth="xs"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
          TransitionComponent={Zoom}
        >
          <DialogTitle sx={{
            pb: 1,
            fontSize: 17,
            fontWeight: 900,
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            textAlign: 'center',
          }}>
            ⚙️ Update Status
          </DialogTitle>
          <DialogContent sx={{
            pt: 3,
            pb: 3,
            px: 3,
            minHeight: 120
          }}>
            <Box sx={{ mt: 2 }}>
              <FormControl fullWidth size="small">
                <InputLabel
                  id="select-status-label"
                  sx={{
                    fontWeight: 700,
                    fontSize: 14,
                    color: 'primary.main',
                    '&.Mui-focused': {
                      color: 'primary.main',
                    },
                    '&.MuiInputLabel-shrink': {
                      transform: 'translate(14px, -9px) scale(0.75)',
                      backgroundColor: '#fff',
                      padding: '0 8px',
                    }
                  }}
                >
                  Select Status
                </InputLabel>
                <Select
                  value={statusDialog.newStatus}
                  onChange={(e) => setStatusDialog({ ...statusDialog, newStatus: e.target.value })}
                  label="Select Status"
                  labelId="select-status-label"
                  sx={{
                    borderRadius: 2,
                    fontWeight: 700,
                    fontSize: 15,
                    mt: 1,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 2,
                    },
                    '& .MuiSelect-select': {
                      paddingTop: 1.5,
                      paddingBottom: 1.5,
                    }
                  }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        mt: 0.5,
                        borderRadius: 2,
                        boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                        maxHeight: 200,
                      }
                    },
                    anchorOrigin: {
                      vertical: 'bottom',
                      horizontal: 'left',
                    },
                    transformOrigin: {
                      vertical: 'top',
                      horizontal: 'left',
                    },
                  }}
                >
                  <MenuItem
                    value="0"
                    sx={{
                      fontWeight: 700,
                      fontSize: 14,
                      py: 1.5,
                      '&:hover': {
                        backgroundColor: 'rgba(244, 67, 54, 0.1)',
                      }
                    }}
                  >
                    🔴 Open
                  </MenuItem>
                  <MenuItem
                    value="1"
                    sx={{
                      fontWeight: 700,
                      fontSize: 14,
                      py: 1.5,
                      '&:hover': {
                        backgroundColor: 'rgba(76, 175, 80, 0.1)',
                      }
                    }}
                  >
                    🟢 Closed
                  </MenuItem>
                  <MenuItem
                    value="2"
                    sx={{
                      fontWeight: 700,
                      fontSize: 14,
                      py: 1.5,
                      '&:hover': {
                        backgroundColor: 'rgba(255, 152, 0, 0.1)',
                      }
                    }}
                  >
                    🟡 In Progress
                  </MenuItem>
                </Select>
              </FormControl>
            </Box>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1 }}>
            <Button
              onClick={() => setStatusDialog({ ...statusDialog, open: false })}
              color="inherit"
              size="small"
              sx={{ borderRadius: 2, fontWeight: 800, fontSize: 13 }}
            >
              Cancel
            </Button>
            <CompactButton
              onClick={handleStatusUpdate}
              disabled={updateLoading}
              startIcon={updateLoading ? <CircularProgress size={12} /> : <Zap size={12} />}
            >
              ✨ Update
            </CompactButton>
          </DialogActions>
        </Dialog>

        <Dialog
          open={deleteDialogOpen}
          onClose={() => setDeleteDialogOpen(false)}
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              border: '2px solid #f44336',
            }
          }}
          TransitionComponent={Zoom}
        >
          <DialogTitle sx={{
            fontSize: 16,
            background: 'linear-gradient(135deg, #f44336, #d32f2f)',
            color: '#fff',
            textAlign: 'center',
          }}>
            <Typography variant="inherit" fontWeight={800}>🗑️ Confirm Delete</Typography>
          </DialogTitle>
          <DialogContent sx={{ pt: 2 }}>
            <Typography sx={{ fontSize: 13, textAlign: 'center', fontWeight: 600 }}>
              Are you sure you want to delete package{' '}
              <Box component="span" sx={{
                color: 'error.main',
                fontWeight: 800,
                background: alpha('#f44336', 0.1),
                px: 1,
                py: 0.3,
                borderRadius: 1,
              }}>
                {selectedCpId}
              </Box>
              ? This action cannot be undone.
            </Typography>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1, justifyContent: 'center' }}>
            <Button
              onClick={() => setDeleteDialogOpen(false)}
              color="inherit"
              size="small"
              sx={{ borderRadius: 2 }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmDelete}
              color="error"
              variant="contained"
              size="small"
              sx={{
                borderRadius: 2,
                fontWeight: 700,
                background: 'linear-gradient(135deg, #f44336, #d32f2f)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #d32f2f, #b71c1c)',
                }
              }}
              startIcon={<Trash2 size={12} />}
            >
              🗑️ Delete
            </Button>
          </DialogActions>
        </Dialog>
      </Box>

      <Footer />
    </>
  );
};

export default Dashboard;