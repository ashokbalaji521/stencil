import React, { useState, useEffect } from "react";
import Header from "./Header";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { Box,Button,TextField, Typography,TableBody,Table,FormControl,InputLabel,Select,MenuItem,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper, } from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { Data } from "../custom";
import axios from "axios";



const Summary = () =>
{
    const username='User'
    const [searchTerm,setSearchTerm]=useState("")
    const [fromDate,setFromDate]=useState(dayjs())
    const [toDate,setToDate]=useState(dayjs())
    const [summary,setSummary]=useState([])
    const [formData,setFormData]=useState({
      Status:"All"
    })
    const Functions=['All','Open','Closed']
    const statusMap = {
    All:'All',
    Open: 1,
    // InProgress: 1,
    Closed: 0,
    };

    useEffect(() => {
  const fetchData = async () => {
    const details = {
      startDate: fromDate,
      endDate: toDate,
      Status: statusMap[formData.Status],
    };

    console.log("Data",details)

    try {
      const response = await axios.post(`${Data.url}/summarydetails`, details);

      
      const result = response.data;

      const summarydetails = result.map((item) => ({
        Category: item.Category,
        CP_ID: item.CP_ID,
        ECN_STI_Number: item.ECN_STI_Number,
        Received_Date: item.Receieved_Date,
        Product_Family: item.Product_Family,
        Product_Name: item.Product_Name,
        Open_Status: item.OPENSTATUS,
        Owner: item.Username,
        Sign_Off_Status: item.Sign_off_Status,
      }));

      setSummary(summarydetails);
    } catch (error) {
      console.error("Error fetching summary details:", error);
    }
  };

  if (fromDate && toDate) {
    fetchData();
  }
}, [fromDate, toDate,formData.Status]);


      const handleChange= (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

      const handleDownload = () =>{

      }  

    
    return(
        <>
        <Header username={username} />
        <div style={{ paddingTop: 70, padding: 20 }}>

        <Box display="flex" alignItems="center" gap={4} mb={8}> 
               
        <TextField
        placeholder="Search..."
        variant="outlined"
        size="small"
        value={searchTerm}
        
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ minWidth: 400,'& .MuiInputBase-root': {
            height: 56, // outer input container
            },
            '& input': {
            padding: '16px 14px', // inner input field padding
            }, 
        }}
        />
        <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
            label="From Date"
            value={fromDate}
            onChange={(newValue) => setFromDate(newValue)}
            renderInput={(params) => <TextField {...params} />}
        />
        </LocalizationProvider>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
            label="To Date"
            value={toDate}
            onChange={(newValue) => setToDate(newValue)}
            renderInput={(params) => <TextField {...params} />}
        />
        </LocalizationProvider>
        <FormControl size="small">
                <InputLabel>Select Status</InputLabel>
                <Select
                  value={formData.Status}
                  name="Status"
                  label="Select Status"
                  onChange={handleChange}
                  sx={{ minWidth: 200,
                  '& .MuiSelect-select': {
                    height: '64px', // adjust this value as needed
                    padding: '10px 14px',
                    display: 'flex',
                    alignItems: 'center',},  }}
                            >
                  {Functions.map((role) => (
                    <MenuItem key={role} value={role}>
                      {role}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <Button
              variant="outlined"
              onClick={() => handleDownload()}
              sx={{
              backgroundColor: '#003366',
                color: '#fff',
              borderColor: '#003366',
              '&:hover': {
                backgroundColor: '#003366',
                color: '#fff',
              },
            }}
            >
              Download
            </Button>
        </Box>
        
        <Box mb={2}> 
           <Typography variant="h6">SUMMARY OF STATUS</Typography> 
        </Box>
        <Box mb={2}> 
           {/* <Typography>OPEN:</Typography>  */}
        </Box>
        <TableContainer component={Paper} sx={{ marginTop: 4 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff',width:'100px'}}>Category</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff'}}>Package ID</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff'}}>ECN/STI Number</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff'}}>Received Date</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff'}}>Product Family</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff',width:'100px'}}>Product Name</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff',width:'100px'}}>Open Status</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff',width:'100px'}}>Owner</TableCell>
                <TableCell sx={{ backgroundColor: '#003366', color: '#fff',width:'100px'}}>Sign Off Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {summary.map((user, index) => (
                <TableRow key={index}>
                  <TableCell>{user.Category}</TableCell>
                  <TableCell>{user.CP_ID}</TableCell>
                  <TableCell>{user.ECN_STI_Number}</TableCell>
                  <TableCell>{user.Received_Date}</TableCell>
                  <TableCell>{user.Product_Family}</TableCell>
                  <TableCell>{user.Product_Name}</TableCell>
                  <TableCell>{user.Open_Status?"Open":"closed"}</TableCell>
                  <TableCell>{user.Owner}</TableCell>
                  <TableCell>{user.Sign_Off_Status?"Open":"closed"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        
        </div>
        </>
    )
}

export default Summary