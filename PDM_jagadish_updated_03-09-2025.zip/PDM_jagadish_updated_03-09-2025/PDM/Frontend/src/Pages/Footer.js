import { Box, Typography } from "@mui/material";

const Footer = () => {
    return(
        <Box
          sx={{
            backgroundColor: "#1e3a8a",
            color: "#ffffff",
            padding: "16px",
            textAlign: "center",
            marginTop: 4,
          }}
        >
          <Typography variant="body2">
            © 2025 NOKIA. All rights reserved.Version_25.7.1
          </Typography>
        </Box>
    );
}

export default Footer