// import React, { useState } from 'react';
// import { Box } from '@mui/material';
// import { Outlet } from 'react-router-dom';
// import Header, { HEADER_HEIGHT, HEADER_GAP } from '../Pages/Header'; // adjust path if needed
// import Sidebar from '../Pages/Sidebar';

// const Layout = () => {
//     const [collapsed, setCollapsed] = useState(false);

//     // Keep in sync with Sidebar
//     const sidebarWidth = collapsed ? 52 : 200;

//     return (
//         <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
//             <Header />

//             <Box sx={{ display: 'flex', flex: 1 }}>
//                 <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

//                 <Box
//                     component="main"
//                     sx={{
//                         flexGrow: 1,
//                         marginLeft: `${sidebarWidth}px`,
//                         marginTop: `${HEADER_HEIGHT + HEADER_GAP}px`,
//                         padding: '16px',
//                         transition: 'margin-left 0.2s ease',
//                         backgroundColor: '#f8fafc',
//                         minHeight: `calc(100vh - ${HEADER_HEIGHT + HEADER_GAP}px)`
//                     }}
//                 >
//                     <Outlet />
//                 </Box>
//             </Box>
//         </Box>
//     );
// };

// export default Layout;
