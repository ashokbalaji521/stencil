import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useParams } from "react-router-dom";
import {
  Box, Container, Typography, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Button, Select, MenuItem, FormControl, InputLabel,
  TextField, Card, CardContent, Chip, CircularProgress, Alert, Snackbar,
  Dialog, DialogTitle, DialogContent, DialogActions, IconButton, useTheme, Grow, Tooltip
} from "@mui/material";
import { Edit, Delete, Save, Cancel, Timeline, Comment, Assessment, AutoAwesome, Lock as LockIcon } from "@mui/icons-material";
import { styled, alpha, keyframes } from "@mui/material/styles";
import axios from "axios";
import Header from "../Pages/Header";
import Footer from "../Pages/Footer";
import UpdatePackageOwner2 from "./UpdatePackageOwner2";
import { Data } from "../custom";

// Enhanced Animations (same as Dashboard)
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0%, 100% { transform: scale(1); opacity: 0.9; }
  50% { transform: scale(1.05); opacity: 1; }
`;

const slideInLeft = keyframes`
  from { transform: translateX(-20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 5px rgba(33, 150, 243, 0.5); }
  50% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.8), 0 0 30px rgba(33, 150, 243, 0.6); }
`;

// UPDATED: Full Blinking Animations for Status Indicators (no white center)
const redGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #f44336, 0 0 10px #f44336, 0 0 15px #f44336;
    background: radial-gradient(circle, #ff6b6b, #f44336);
  }
  50% { 
    box-shadow: 0 0 10px #f44336, 0 0 20px #f44336, 0 0 30px #f44336;
    background: radial-gradient(circle, #ff8a80, #ff5722);
  }
`;

const greenGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #4caf50, 0 0 10px #4caf50, 0 0 15px #4caf50;
    background: radial-gradient(circle, #81c784, #4caf50);
  }
  50% { 
    box-shadow: 0 0 10px #4caf50, 0 0 20px #4caf50, 0 0 30px #4caf50;
    background: radial-gradient(circle, #a5d6a7, #66bb6a);
  }
`;

const yellowGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #ff9800, 0 0 10px #ff9800, 0 0 15px #ff9800;
    background: radial-gradient(circle, #ffb74d, #ff9800);
  }
  50% { 
    box-shadow: 0 0 10px #ff9800, 0 0 20px #ff9800, 0 0 30px #ff9800;
    background: radial-gradient(circle, #ffcc02, #ffa000);
  }
`;

const silverGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #C0C0C0, 0 0 10px #C0C0C0, 0 0 15px #C0C0C0;
    background: radial-gradient(circle, #D3D3D3, #C0C0C0);
  }
  50% { 
    box-shadow: 0 0 10px #C0C0C0, 0 0 20px #C0C0C0, 0 0 30px #C0C0C0;
    background: radial-gradient(circle, #E5E5E5, #A9A9A9);
  }
`;

// Enhanced Styled Components (same style as Dashboard)
const ShellCard = styled(Card)(({ theme }) => ({
  borderRadius: 12,
  background: '#ffffff',
  boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.1)',
  border: `1px solid ${alpha(theme.palette.divider, 0.12)}`,
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  animation: `${fadeIn} 0.6s ease-out`,
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 25px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.08)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '3px',
    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
  }
}));

const CompactContent = styled(CardContent)(({ theme }) => ({
  padding: 16,
  "&:last-child": { paddingBottom: 16 },
  animation: `${slideInLeft} 0.5s ease-out`,
}));

const TightTableContainer = styled(TableContainer)(({ theme }) => ({
  borderRadius: 8,
  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  overflow: 'hidden',
  background: '#ffffff',
  boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
  '&:hover': {
    boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
  }
}));

const HeaderCell = styled(TableCell)(({ theme }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  fontWeight: 800,
  fontSize: "0.7rem",
  padding: "8px 4px",
  borderBottom: "none",
  textAlign: "center",
  whiteSpace: "pre-line",
  lineHeight: 1.2,
  width: "12.5%",
  position: 'relative',
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
  }
}));

const DataCell = styled(TableCell)(({ theme }) => ({
  borderBottom: "1px solid rgba(0,0,0,0.06)",
  padding: "6px 4px",
  fontSize: "0.7rem",
  fontWeight: 500,
  textAlign: "center",
  width: "12.5%",
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

// Action Status Table with enhanced styling
const ActionHeaderCell = styled(TableCell)(({ theme }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  fontWeight: 800,
  fontSize: "0.65rem",
  padding: "6px 2px",
  borderBottom: "none",
  textAlign: "center",
  whiteSpace: "pre-line",
  lineHeight: 1.1,
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
  }
}));

const ActionDataCell = styled(TableCell)(({ theme }) => ({
  borderBottom: "1px solid rgba(0,0,0,0.06)",
  padding: "4px 2px",
  fontSize: "0.65rem",
  fontWeight: 500,
  textAlign: "center",
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

// Comments History Table with enhanced styling
const CommentHeaderCell = styled(TableCell)(({ theme }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  fontWeight: 800,
  fontSize: "0.7rem",
  padding: "8px 6px",
  borderBottom: "none",
  textAlign: "center",
  whiteSpace: "pre-line",
  lineHeight: 1.2,
  width: "16.67%",
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
  }
}));

const CommentDataCell = styled(TableCell)(({ theme }) => ({
  borderBottom: "1px solid rgba(0,0,0,0.06)",
  padding: "6px 8px",
  fontSize: "0.7rem",
  fontWeight: 500,
  textAlign: "center",
  width: "16.67%",
  verticalAlign: "middle",
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

// UPDATED: Glowing Bulb Component with lock icon overlay for disabled teams
const GlowingBulb = styled(Box)(({ status, disabled }) => {
  let animation = '';

  // Keep same animations/colors regardless of disabled state
  if (status === 'Open') {
    animation = redGlow;
  } else if (status === 'Closed') {
    animation = greenGlow;
  } else if (status === 'In Progress') {
    animation = yellowGlow;
  } else {
    animation = silverGlow;
  }

  return {
    width: 20,
    height: 20,
    borderRadius: '50%',
    animation: `${animation} 2s ease-in-out infinite`,
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.3s ease',
    display: 'inline-block',
    position: 'relative',
    '&:hover': {
      transform: disabled ? 'none' : 'scale(1.2)',
    },
    // Add lock icon overlay for disabled bulbs
    '&::after': disabled ? {
      content: '"🔒"',
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      fontSize: '10px',
      color: '#333',
      fontWeight: 'bold',
      textShadow: '0 0 2px #fff',
      zIndex: 2,
    } : {}
  };
});

// UPDATED: Status Indicator Component with Full Blinking (No White Center) and lock support
const StatusIndicator = styled(Box)(({ status, disabled, theme }) => {
  const getStatusProps = (status) => {
    switch (status?.toLowerCase()) {
      case 'open':
        return {
          color: '#f44336',
          animation: `${redGlow} 2s infinite`,
          border: '2px solid #f44336',
        };
      case 'closed':
        return {
          color: '#4caf50',
          animation: `${greenGlow} 2s infinite`,
          border: '2px solid #4caf50',
        };
      case 'in progress':
        return {
          color: '#ff9800',
          animation: `${yellowGlow} 2s infinite`,
          border: '2px solid #ff9800',
        };
      case 'na':
      default:
        return {
          color: '#9e9e9e',
          backgroundColor: '#9e9e9e',
          border: `2px solid ${alpha('#9e9e9e', 0.3)}`,
          // No animation for NA
        };
    }
  };

  const props = getStatusProps(status);

  return {
    width: 20,
    height: 20,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '0 auto',
    position: 'relative',
    transition: 'all 0.3s ease',
    cursor: disabled ? 'not-allowed' : 'pointer',
    ...props,
    '&:hover': {
      transform: disabled ? 'none' : 'scale(1.2)',
    },
    // Add lock icon overlay for disabled bulbs
    '&::after': disabled ? {
      content: '"🔒"',
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      fontSize: '8px',
      color: '#333',
      fontWeight: 'bold',
      textShadow: '0 0 2px #fff',
      zIndex: 2,
    } : {}
  };
});

const StatusChip = styled(Chip)(({ status, theme }) => {
  const colors = {
    open: { bg: alpha('#ff9800', 0.1), color: '#e65100', border: '#ff9800' },
    closed: { bg: alpha('#4caf50', 0.1), color: '#2e7d32', border: '#4caf50' },
    "in progress": { bg: alpha('#2196f3', 0.1), color: '#1565c0', border: '#2196f3' },
    ontime: { bg: alpha('#4caf50', 0.1), color: '#2e7d32', border: '#4caf50' },
    delay: { bg: alpha('#f44336', 0.1), color: '#c62828', border: '#f44336' },
    default: { bg: alpha('#9e9e9e', 0.1), color: '#616161', border: '#9e9e9e' }
  };
  const color = colors[status?.toLowerCase()] || colors.default;
  return {
    backgroundColor: color.bg,
    color: color.color,
    border: `1px solid ${color.border}`,
    fontWeight: 700,
    fontSize: "0.6rem",
    height: "22px",
    minWidth: "50px",
    borderRadius: '12px',
    transition: 'all 0.3s ease',
    '&:hover': {
      transform: 'scale(1.05)',
      boxShadow: `0 2px 8px ${alpha(color.border, 0.3)}`,
    },
    "& .MuiChip-label": { padding: "0 8px" },
  };
});

// Updated clickable cell style with disabled state
const ClickableCell = styled(ActionDataCell)(({ status, disabled, theme }) => {
  const colors = {
    open: { bg: alpha('#ff9800', 0.08), hover: alpha('#ff9800', 0.15) },
    closed: { bg: alpha('#4caf50', 0.08), hover: alpha('#4caf50', 0.15) },
    "in progress": { bg: alpha('#2196f3', 0.08), hover: alpha('#2196f3', 0.15) },
    default: { bg: alpha('#9e9e9e', 0.05), hover: alpha('#9e9e9e', 0.1) }
  };
  const color = colors[status?.toLowerCase()] || colors.default;
  return {
    backgroundColor: color.bg,
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
    "&:hover": disabled ? {} : {
      backgroundColor: color.hover,
      transform: "scale(1.02)",
      boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
    },
    border: "1px solid rgba(0,0,0,0.08)",
    fontWeight: 600,
    borderRadius: '4px',
    // Add visual indication for disabled state
    opacity: disabled ? 0.7 : 1,
  };
});

const SectionTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 800,
  fontSize: "1.1rem",
  color: theme.palette.primary.main,
  marginBottom: 12,
  display: "flex",
  alignItems: "center",
  gap: 8,
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
}));

const EnhancedTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: 8,
    transition: 'all 0.3s ease',
    background: '#ffffff',
    '&:hover': {
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
    },
    '&.Mui-focused': {
      animation: `${glow} 2s infinite`,
      transform: 'translateY(-1px)',
    }
  }
}));

const CompactButton = styled(Button)(({ theme }) => ({
  borderRadius: 8,
  padding: '6px 16px',
  fontWeight: 700,
  textTransform: 'none',
  fontSize: '0.8rem',
  minHeight: 32,
  boxShadow: '0 3px 12px rgba(0, 0, 0, 0.15)',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 100%)`,
    transform: 'translateY(-2px)',
    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.2)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
    transition: 'left 0.5s',
  },
  '&:hover::before': {
    left: '100%',
  }
}));

const LoadingOverlay = styled(Box)({
  position: 'fixed',
  inset: 0,
  background: 'linear-gradient(135deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.5) 100%)',
  backdropFilter: 'blur(8px)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 9999,
});

const LoadingCard = styled(ShellCard)(({ theme }) => ({
  padding: theme.spacing(3),
  textAlign: 'center',
  minWidth: 240,
  background: '#ffffff',
  animation: `${pulse} 2s infinite`,
}));

// Constants
const STATUS_LABEL = { 0: "Open", 1: "Closed", 2: "In Progress" };
const STATUS_VALUE = { Open: 0, Closed: 1, "In Progress": 2, NA: null };
const FIELD_MAP = {
  PDM: "PDM", "MM Buyer": "MM_Buyer", "MM Logistics": "MM_logistics", SQA: "SQA",
  WH: "WH", MC: "MC", SMT: "SMT", "MS-SMT": "MS_SMT", "MS-IE": "MS_IE",
  "MS-TEST": "MS_TEST", "MS-PT": "MS_PT", "MS-PE": "MS_PE", "MS-IT": "MS_IT", OPS: "OPS",
};
const ENDPOINT_BY_PHASE = {
  "Pre-Implementation": "updatestatuspreimp",
  "Post Implementation": "updatestatuspostimp",
};

// Team to field mapping (same as dashboard)
const TEAM_TO_FIELD_MAPPING = {
  "PDM": "PDM",
  "MM_Buyer": "MM Buyer",
  "MM_logistics": "MM Logistics",
  "SQA": "SQA",
  "WH": "WH",
  "MC": "MC",
  "SMT": "SMT",
  "MS_SMT": "MS-SMT",
  "MS_IE": "MS-IE",
  "MS_TEST": "MS-TEST",
  "MS_PT": "MS-PT",
  "MS_PE": "MS-PE",
  "MS_IT": "MS-IT",
  "OPS": "OPS",
};

const formatDate = (d) => (!d ? "" : new Date(d).toISOString().split("T")[0]);
const cnStiDisplay = (status) => {
  if (!status) return { label: "NA", color: "default" };
  const s = String(status).toLowerCase();
  if (s === "open") return { label: "Open", color: "warning" };
  if (s === "ontime") return { label: "On Time", color: "success" };
  if (s === "delay") return { label: "Delay", color: "error" };
  return { label: status, color: "default" };
};

const UpdatePackageOwner1 = () => {
  const { cpId } = useParams();
  const theme = useTheme();

  // Role gate
  const role = sessionStorage.getItem("role");
  const isUser = role === "User";

  // NEW: Team-based access control (same as dashboard)
  const userTeam = sessionStorage.getItem("team");

  // NEW: Get enabled team based on user's team
  const getEnabledTeam = () => {
    if (!userTeam || userTeam === "Default Team") {
      return null; // No team enabled for default team
    }
    return TEAM_TO_FIELD_MAPPING[userTeam] || null;
  };

  // NEW: Check if a team is enabled for the current user
  const isTeamEnabled = (team) => {
    const enabledTeam = getEnabledTeam();
    return enabledTeam === team;
  };

  const [trackerData, setTrackerData] = useState({
    category: "", packageId: "", ecnStiNumber: "", productFamily: "", productName: "",
    productCategory: "", productSaleCode: "", receivedDate: "", stiFromDate: "", stiToDate: "",
    tentativeTrialDate: "", closureTargetDate: "", actualClosureDate: "", cnStiStatus: "",
    pdmActionOwner: "", shortNotes: "", cnStiSignoffStatus: "",
  });

  const teams = useMemo(() => [
    "PDM", "MM Buyer", "MM Logistics", "SQA", "WH", "MC", "SMT",
    "MS-SMT", "MS-IE", "MS-TEST", "MS-PT", "MS-PE", "MS-IT", "OPS"
  ], []);

  const pdmOwnerOptions = useMemo(() => ["Hassan", "Suresh"], []);

  const [actionStatuses, setActionStatuses] = useState({
    "Pre-Implementation": Object.fromEntries(teams.map(t => [t, "NA"])),
    "Post Implementation": Object.fromEntries(teams.map(t => [t, "NA"])),
  });

  const [ptoComment, setPtoComment] = useState("");
  const [ptoCommands, setPtoCommands] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busyAction, setBusyAction] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showSuccessSnackbar, setShowSuccessSnackbar] = useState(false);

  const [statusDialog, setStatusDialog] = useState({ open: false, phase: null, team: null, newStatus: "NA" });
  const [editPtoDialogOpen, setEditPtoDialogOpen] = useState(false);
  const [currentPtoComment, setCurrentPtoComment] = useState({ id: null, comment: "" });
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState({ open: false, commentId: null, commentText: "" });
  const [editField, setEditField] = useState(null);
  const [editValue, setEditValue] = useState("");

  // Utilities
  const showSuccess = useCallback((msg) => {
    setSuccessMessage(msg);
    setShowSuccessSnackbar(true);
  }, []);

  const mapStatuses = useCallback((obj) =>
    !obj ? Object.fromEntries(teams.map(t => [t, "NA"])) : {
      PDM: STATUS_LABEL[obj.PDM] || "NA", "MM Buyer": STATUS_LABEL[obj.MM_Buyer] || "NA",
      "MM Logistics": STATUS_LABEL[obj.MM_logistics] || "NA", SQA: STATUS_LABEL[obj.SQA] || "NA",
      WH: STATUS_LABEL[obj.WH] || "NA", MC: STATUS_LABEL[obj.MC] || "NA", SMT: STATUS_LABEL[obj.SMT] || "NA",
      "MS-SMT": STATUS_LABEL[obj.MS_SMT] || "NA", "MS-IE": STATUS_LABEL[obj.MS_IE] || "NA",
      "MS-TEST": STATUS_LABEL[obj.MS_TEST] || "NA", "MS-PT": STATUS_LABEL[obj.MS_PT] || "NA",
      "MS-PE": STATUS_LABEL[obj.MS_PE] || "NA", "MS-IT": STATUS_LABEL[obj.MS_IT] || "NA",
      OPS: STATUS_LABEL[obj.OPS] || "NA",
    }, [teams]);

  // Fetch
  const fetchTrackerData = useCallback(async () => {
    if (!cpId) return setError("No Package ID provided");
    try {
      setLoading(true);
      setError("");
      const { data } = await axios.post(`${Data.url}/getallstatusbypackageid`, { cp_id: cpId });
      const e = data.ecn_sti || {};
      setTrackerData({
        category: e.Change_Note_Cateogry || "", packageId: e.CP_ID || cpId,
        ecnStiNumber: e.ECN_STI_Number || "", productFamily: e.Product_Family || "",
        productName: e.Product_Name || "", productCategory: e.Category || "",
        productSaleCode: e.Product_Sale_code || "", receivedDate: formatDate(e.Receieved_Date),
        stiFromDate: formatDate(e.STI_From_Date), stiToDate: formatDate(e.STI_To_Date),
        tentativeTrialDate: formatDate(e.Trail_Tentative_Plan_Date),
        closureTargetDate: formatDate(e.Closure_Target_Date),
        actualClosureDate: formatDate(e.Actual_Closure_Date), cnStiStatus: e["CN/STI Status"] || "",
        pdmActionOwner: e.PDM_Action_Owner || "", shortNotes: e.Brief_Details || "", cnStiSignoffStatus: "",
      });
      setActionStatuses({
        "Pre-Implementation": mapStatuses(data.pre_implementation_status),
        "Post Implementation": mapStatuses(data.post_implementation_status),
      });
    } catch (err) {
      setError(`Failed to fetch data: ${err.response?.data?.error || err.message}`);
    } finally {
      setLoading(false);
    }
  }, [cpId, mapStatuses]);

  const fetchPtoCommands = useCallback(async () => {
    if (!cpId) return;
    try {
      const { data } = await axios.post(`${Data.url}/getPTOComments`, { CP_ID: cpId });
      setPtoCommands((data || []).map(c => ({
        id: c.Id, comment: c.comment, action: c.action,
        date: new Date(c.date).toLocaleDateString(), edited: c.edited,
      })));
    } catch (err) {
      setError(err.response?.data?.error || "Failed to fetch PTO comments");
    }
  }, [cpId]);

  useEffect(() => {
    Promise.all([fetchTrackerData(), fetchPtoCommands()]);
  }, [fetchTrackerData, fetchPtoCommands]);

  // Edit handlers
  const beginEdit = useCallback((field) => {
    setEditField(field);
    setEditValue(trackerData[field] || "");
  }, [trackerData]);

  const cancelEdit = useCallback(() => {
    setEditField(null);
    setEditValue("");
  }, []);

  const saveEdit = async () => {
    if (!editField) return;
    try {
      setBusyAction(true);
      const payload = { CP_ID: trackerData.packageId };
      if (editField === "actualClosureDate") payload.Actual_Closure_Date = editValue;
      else if (editField === "tentativeTrialDate") payload.Trail_Tentative_Plan_Date = editValue;
      else if (editField === "pdmActionOwner") payload.PDM_Action_Owner = editValue;
      else if (editField === "shortNotes") payload.ECN_STI_Notes = editValue;
      await axios.post(`${Data.url}/updateEcnStiRecord`, payload);
      setTrackerData(prev => ({ ...prev, [editField]: editValue }));
      showSuccess("Updated successfully");
    } catch (err) {
      setError(err.response?.data?.error || "Failed to update field");
    } finally {
      setBusyAction(false);
      cancelEdit();
    }
  };

  // UPDATED: Status dialog click handler with team access control
  const handleStatusClick = (phase, team, currentStatus) => {
    if (!isTeamEnabled(team)) {
      const currentTeam = userTeam || "your team";
      showSuccess(`🔒 Access Denied: You can only update ${currentTeam} status`);
      return;
    }
    setStatusDialog({ open: true, phase, team, newStatus: currentStatus });
  };

  // Status dialog submit
  const updateStatus = async () => {
    const { phase, team, newStatus } = statusDialog;
    if (!phase || !team) return;

    // Double check permissions
    if (!isTeamEnabled(team)) {
      const currentTeam = userTeam || "your team";
      setError(`🔒 Access Denied: You can only update ${currentTeam} status`);
      return;
    }

    try {
      setBusyAction(true);
      await axios.post(`${Data.url}/${ENDPOINT_BY_PHASE[phase]}`, {
        field: FIELD_MAP[team], Status: STATUS_VALUE[newStatus], CP_ID: trackerData.packageId,
      });
      setActionStatuses(prev => ({ ...prev, [phase]: { ...prev[phase], [team]: newStatus } }));
      showSuccess(`Status updated for ${team}`);
    } catch (err) {
      setError(err.response?.data?.error || "Failed to update status");
    } finally {
      setBusyAction(false);
      setStatusDialog(s => ({ ...s, open: false }));
    }
  };

  // PTO dialogs handlers
  const openEditPto = useCallback((c) => {
    setCurrentPtoComment({ id: c.id, comment: c.comment });
    setEditPtoDialogOpen(true);
  }, []);

  const saveEditPto = async () => {
    const txt = currentPtoComment.comment?.trim();
    if (!txt) return setError("Comment cannot be empty");
    try {
      setBusyAction(true);
      const { data } = await axios.post(`${Data.url}/addOrUpdateOrDeletePTOComment`, {
        CP_ID: trackerData.packageId || cpId, ID: currentPtoComment.id, PTO_Comment: txt, Action: "edit",
      });
      showSuccess(data.message || "Updated");
      setEditPtoDialogOpen(false);
      fetchPtoCommands();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to edit PTO comment");
    } finally {
      setBusyAction(false);
    }
  };

  const askDeletePto = useCallback((c) =>
    setDeleteConfirmDialog({ open: true, commentId: c.id, commentText: c.comment }), []);

  const confirmDeletePto = async () => {
    try {
      setBusyAction(true);
      const { data } = await axios.post(`${Data.url}/addOrUpdateOrDeletePTOComment`, {
        CP_ID: trackerData.packageId || cpId, ID: deleteConfirmDialog.commentId, Action: "delete", PTO_Comment: "",
      });
      showSuccess(data.message || "Deleted");
      setDeleteConfirmDialog({ open: false, commentId: null, commentText: "" });
      fetchPtoCommands();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to delete PTO comment");
    } finally {
      setBusyAction(false);
    }
  };

  // Render helpers: for Users, always read-only display
  const renderEditableCell = (field, type, selectOptions = []) => {
    const val = trackerData[field] || "-";
    if (isUser) {
      return <Typography variant="body2" sx={{ fontSize: "0.7rem", fontWeight: 500 }}>{val}</Typography>;
    }
    const isEditing = editField === field;
    if (!isEditing) {
      return (
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, minHeight: "20px" }}>
          <Typography variant="body2" sx={{ flex: 1, fontSize: "0.7rem", fontWeight: 500 }}>{val}</Typography>
          <IconButton
            size="small"
            onClick={() => beginEdit(field)}
            sx={{
              p: 0.5,
              borderRadius: 2,
              transition: 'all 0.3s ease',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.1),
                transform: 'scale(1.1)',
              }
            }}
          >
            <Edit sx={{ fontSize: "0.75rem", color: theme.palette.primary.main }} />
          </IconButton>
        </Box>
      );
    }
    return (
      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, py: 0.5 }}>
        {type === "select" ? (
          <FormControl size="small" sx={{ minWidth: 80 }}>
            <Select value={editValue} onChange={(e) => setEditValue(e.target.value)} displayEmpty
              sx={{ fontSize: "0.7rem", height: 28, borderRadius: 2 }}>
              <MenuItem value=""><em>Select</em></MenuItem>
              {selectOptions.map(o => <MenuItem key={o} value={o}>{o}</MenuItem>)}
            </Select>
          </FormControl>
        ) : type === "text" ? (
          <EnhancedTextField fullWidth multiline rows={2} size="small" value={editValue}
            onChange={(e) => setEditValue(e.target.value)} sx={{ "& .MuiInputBase-input": { fontSize: "0.7rem" } }} />
        ) : (
          <EnhancedTextField type="date" size="small" value={editValue}
            onChange={(e) => setEditValue(e.target.value)} sx={{ "& .MuiInputBase-input": { fontSize: "0.7rem" }, width: 120 }} />
        )}
        <IconButton size="small" onClick={saveEdit} disabled={busyAction}
          sx={{
            p: 0.5,
            borderRadius: 2,
            backgroundColor: alpha(theme.palette.success.main, 0.1),
            '&:hover': { backgroundColor: alpha(theme.palette.success.main, 0.2) }
          }}>
          <Save sx={{ fontSize: "0.75rem", color: theme.palette.success.main }} />
        </IconButton>
        <IconButton size="small" onClick={cancelEdit}
          sx={{
            p: 0.5,
            borderRadius: 2,
            backgroundColor: alpha(theme.palette.error.main, 0.1),
            '&:hover': { backgroundColor: alpha(theme.palette.error.main, 0.2) }
          }}>
          <Cancel sx={{ fontSize: "0.75rem", color: theme.palette.error.main }} />
        </IconButton>
      </Box>
    );
  };

  const basicData = useMemo(() => [
    { label: "Category", value: trackerData.category },
    { label: "Package\nID", value: trackerData.packageId },
    { label: "ECN/STI\nNumber", value: trackerData.ecnStiNumber },
    { label: "Product\nFamily", value: trackerData.productFamily },
    { label: "Product\nName", value: trackerData.productName },
    { label: "Product\nCategory", value: trackerData.productCategory },
    { label: "Received\nDate", value: trackerData.receivedDate },
  ], [trackerData]);

  const isStiValid = Boolean(trackerData.stiFromDate && trackerData.stiToDate);
  const cnSti = cnStiDisplay(trackerData.cnStiStatus);

  return (
    <Box sx={{ backgroundColor: "#f8fafc", minHeight: "100vh" }}>
      <Header />

      <Container maxWidth="xl" sx={{ py: 0.5 }}>
        {/* Loading Overlay */}
        {(loading || busyAction) && (
          <div>
            <LoadingOverlay>
              <div>
                <LoadingCard>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                    <CircularProgress size={32} sx={{ mr: 2 }} />
                    <AutoAwesome style={{ fontSize: 24, color: theme.palette.primary.main }} />
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 700, color: 'primary.main' }}>Processing...</Typography>
                  <Typography variant="body2" sx={{ color: 'text.secondary', mt: 1 }}>Please wait while we update your data</Typography>
                </LoadingCard>
              </div>
            </LoadingOverlay>
          </div>
        )}

        {/* Error Alert */}
        {error && (
          <div>
            <Alert
              severity="error"
              sx={{
                mb: 2,
                borderRadius: 2,
                fontSize: "0.8rem",
                border: '1px solid #f44336',
                boxShadow: '0 4px 12px rgba(244, 67, 54, 0.15)',
              }}
            >
              <strong>❌ Error:</strong> {error}
            </Alert>
          </div>
        )}

        {/* Success Snackbar */}
        <Snackbar
          open={showSuccessSnackbar}
          autoHideDuration={4000}
          onClose={() => setShowSuccessSnackbar(false)}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            onClose={() => setShowSuccessSnackbar(false)}
            severity="success"
            sx={{
              borderRadius: 2,
              fontWeight: 600,
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            }}
          >
            {successMessage}
          </Alert>
        </Snackbar>

        {/* Enhanced Title */}
        <Box sx={{ mb: 3, mt: 10, display: 'flex', alignItems: 'center' }}>
          <Assessment sx={{ mr: 2, color: 'primary.main', fontSize: '2rem' }} />
          <Typography
            variant="h4"
            component="h1"
            sx={{
              fontWeight: 800,
              color: 'primary.main',
              fontSize: '1.5rem',
              textShadow: '0 2px 4px rgba(0,0,0,0.1)',
            }}
          >
            Package Details & Status Management
          </Typography>
        </Box>

        {/* Basic Information */}
        <ShellCard sx={{ mb: 2 }}>
          <CompactContent>
            <SectionTitle>
              <Assessment sx={{ fontSize: "1.2rem" }} />
              Basic Information
            </SectionTitle>
            <TightTableContainer component={Paper}>
              <Table size="small">
                <TableHead>
                  <TableRow>{basicData.map((item, index) => <HeaderCell key={index}>{item.label}</HeaderCell>)}</TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>{basicData.map((item, i) => <DataCell key={i}>{item.value || "-"}</DataCell>)}</TableRow>
                </TableBody>
              </Table>
            </TightTableContainer>
          </CompactContent>
        </ShellCard>

        {/* STI & Timeline Information */}
        <ShellCard sx={{ mb: 2 }}>
          <CompactContent>
            <SectionTitle>
              <Timeline sx={{ fontSize: "1.2rem" }} />
              STI & Timeline Information
            </SectionTitle>
            <TightTableContainer component={Paper}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <HeaderCell>STI Valid</HeaderCell>
                    <HeaderCell>FROM</HeaderCell>
                    <HeaderCell>TO</HeaderCell>
                    <HeaderCell>Tentative Trial</HeaderCell>
                    <HeaderCell>Closure Target</HeaderCell>
                    <HeaderCell>Actual Closure</HeaderCell>
                    <HeaderCell>CN/STI Status</HeaderCell>
                    <HeaderCell>PDM Owner</HeaderCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <DataCell>
                      <StatusChip label={isStiValid ? "Valid" : "NA"} status={isStiValid ? "closed" : "open"} />
                    </DataCell>
                    <DataCell>{trackerData.stiFromDate || "-"}</DataCell>
                    <DataCell>{trackerData.stiToDate || "-"}</DataCell>
                    <DataCell>{renderEditableCell("tentativeTrialDate", "date")}</DataCell>
                    <DataCell>{trackerData.closureTargetDate || "-"}</DataCell>
                    <DataCell>{renderEditableCell("actualClosureDate", "date")}</DataCell>
                    <DataCell><StatusChip label={cnSti.label} status={cnSti.label.toLowerCase()} /></DataCell>
                    <DataCell>{renderEditableCell("pdmActionOwner", "select", pdmOwnerOptions)}</DataCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TightTableContainer>
          </CompactContent>
        </ShellCard>

        {/* Short Notes */}
        <ShellCard sx={{ mb: 2 }}>
          <CompactContent>
            <SectionTitle>
              <Comment sx={{ fontSize: "1.2rem" }} />
              Short Notes
            </SectionTitle>
            <Box sx={{
              backgroundColor: alpha(theme.palette.primary.main, 0.04),
              borderRadius: 2,
              p: 2.5,
              minHeight: 80,
              border: `2px solid ${alpha(theme.palette.primary.main, 0.1)}`,
              transition: 'all 0.3s ease',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.06),
                transform: 'translateY(-1px)',
              }
            }}>
              {isUser ? (
                <Typography variant="body2" sx={{ fontSize: "0.8rem", lineHeight: 1.6 }}>
                  {trackerData.shortNotes || "No notes available"}
                </Typography>
              ) : (
                <>
                  {editField === "shortNotes" ? (
                    renderEditableCell("shortNotes", "text")
                  ) : (
                    <Box sx={{ display: "flex", alignItems: "flex-start", gap: 1 }}>
                      <Typography variant="body2" sx={{ flex: 1, fontSize: "0.8rem", lineHeight: 1.6 }}>
                        {trackerData.shortNotes || "No notes available"}
                      </Typography>
                      <IconButton
                        size="small"
                        onClick={() => beginEdit("shortNotes")}
                        sx={{
                          p: 0.5,
                          borderRadius: 2,
                          backgroundColor: alpha(theme.palette.primary.main, 0.1),
                          '&:hover': {
                            backgroundColor: alpha(theme.palette.primary.main, 0.2),
                            transform: 'scale(1.1)',
                          }
                        }}
                      >
                        <Edit sx={{ fontSize: "0.8rem", color: theme.palette.primary.main }} />
                      </IconButton>
                    </Box>
                  )}
                </>
              )}
            </Box>
          </CompactContent>
        </ShellCard>

        {/* Actions Status Update with Team-based Access Control */}
        <ShellCard sx={{ mb: 2 }}>
          <CompactContent>
            <SectionTitle>
              <Assessment sx={{ fontSize: "1.2rem" }} />
              Actions Status Update
            </SectionTitle>

            {/* Status Legend with team access info */}
            <Box sx={{
              mb: 2,
              p: 2,
              backgroundColor: alpha(theme.palette.primary.main, 0.04),
              borderRadius: 2,
              border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
            }}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 700, color: 'primary.main' }}>
                🎨 Status Legend:
              </Typography>
              <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', alignItems: 'center', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    animation: `${redGlow} 2s infinite`,
                    border: '2px solid #f44336',
                  }} />
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Open
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    animation: `${greenGlow} 2s infinite`,
                    border: '2px solid #4caf50',
                  }} />
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Closed
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    animation: `${yellowGlow} 2s infinite`,
                    border: '2px solid #ff9800',
                  }} />
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    In Progress
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    animation: `${silverGlow} 2s infinite`,
                    border: `2px solid ${alpha('#C0C0C0', 0.7)}`,
                    position: 'relative',
                    '&::after': {
                      content: '"🔒"',
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      fontSize: '8px',
                      color: '#333',
                      fontWeight: 'bold',
                      textShadow: '0 0 2px #fff',
                    }
                  }} />
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    🔒 Locked/NA
                  </Typography>
                </Box>
              </Box>
              {/* Team Access Info */}
              <Typography variant="body2" sx={{
                fontSize: '0.85rem',
                fontWeight: 600,
                color: 'info.main',
                backgroundColor: alpha(theme.palette.info.main, 0.08),
                padding: 1,
                borderRadius: 1,
                border: `1px solid ${alpha(theme.palette.info.main, 0.2)}`
              }}>
                🛡️ <strong>Access Control:</strong> You can only edit status for your team: <strong>{userTeam || 'No Team Assigned'}</strong>
              </Typography>
            </Box>

            <TightTableContainer component={Paper}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <ActionHeaderCell sx={{ width: "80px", position: "sticky", left: 0, zIndex: 2 }}>
                      Phase
                    </ActionHeaderCell>
                    {teams.map(team => (
                      <ActionHeaderCell key={team} sx={{ width: `${(100 - 5.33) / teams.length}%`, minWidth: 60 }}>
                        {team === "MM Logistics" ? "MM\nLogistics" :
                          team === "MS-SMT" ? "MS\nSMT" :
                            team === "MS-IE" ? "MS\nIE" :
                              team === "MS-TEST" ? "MS\nTEST" :
                                team === "MS-PT" ? "MS\nPT" :
                                  team === "MS-PE" ? "MS\nPE" :
                                    team === "MS-IT" ? "MS\nIT" :
                                      team === "MM Buyer" ? "MM\nBuyer" : team}
                      </ActionHeaderCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.keys(actionStatuses).map((phase, idx) => (
                    <TableRow key={phase} sx={{ animation: `${slideInLeft} 0.5s ease-out ${idx * 0.1}s` }}>
                      <ActionDataCell sx={{
                        fontWeight: 700,
                        backgroundColor: alpha(theme.palette.primary.main, 0.08),
                        position: "sticky",
                        left: 0,
                        zIndex: 1,
                        borderRight: `3px solid ${theme.palette.primary.main}`,
                        fontSize: "0.65rem",
                        width: "80px",
                        color: theme.palette.primary.main,
                      }}>
                        {phase === "Pre-Implementation" ? "Pre\nImplementation" : "Post\nImplementation"}
                      </ActionDataCell>
                      {teams.map(team => {
                        const isEnabled = isTeamEnabled(team);
                        const currentStatus = actionStatuses[phase][team];
                        return (
                          <ClickableCell
                            key={`${phase}-${team}`}
                            status={currentStatus}
                            disabled={!isEnabled}
                            onClick={isEnabled ? () => handleStatusClick(phase, team, currentStatus) : undefined}
                            sx={{
                              width: `${(100 - 5.33) / teams.length}%`,
                              minWidth: 60,
                              py: 2,
                            }}
                            title={isEnabled ? currentStatus : `🔒 Access Denied: Only ${userTeam || 'your team'} can update this field`}
                          >
                            <Box sx={{ position: 'relative' }}>
                              <StatusIndicator status={currentStatus} disabled={!isEnabled} />
                              {!isEnabled && (
                                <Tooltip title={`🔒 Access Denied: Only ${userTeam || 'your team'} can update this field`}>
                                  <Box sx={{ position: 'absolute', inset: 0 }} />
                                </Tooltip>
                              )}
                            </Box>
                          </ClickableCell>
                        );
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TightTableContainer>
          </CompactContent>
        </ShellCard>

        {/* PDM Owner Comments - HIDDEN for Users */}
        {!isUser && (
          <ShellCard sx={{ mb: 2 }}>
            <CompactContent>
              <SectionTitle>
                <Comment sx={{ fontSize: "1.2rem" }} />
                PDM Owner Comments
              </SectionTitle>
              <Box sx={{ display: "flex", gap: 2, alignItems: "flex-start", mb: 3 }}>
                <EnhancedTextField
                  fullWidth
                  multiline
                  rows={3}
                  value={ptoComment}
                  onChange={(e) => setPtoComment(e.target.value)}
                  placeholder="Enter your comment here..."
                  variant="outlined"
                  size="small"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 2,
                      fontSize: "0.85rem",
                      backgroundColor: '#ffffff',
                    }
                  }}
                />
                <CompactButton
                  onClick={async () => {
                    if (!ptoComment.trim()) return setError("PTO comment cannot be empty");
                    try {
                      setBusyAction(true);
                      const nextId = String((ptoCommands.length ? Math.max(...ptoCommands.map(c => parseInt(c.id, 10) || 0)) : 0) + 1);
                      const { data } = await axios.post(`${Data.url}/addOrUpdateOrDeletePTOComment`, {
                        ID: nextId, CP_ID: trackerData.packageId || cpId, PTO_Comment: ptoComment.trim(), Action: "add",
                      });
                      setPtoComment("");
                      showSuccess(data.message || "Comment added successfully!");
                      const res = await axios.post(`${Data.url}/getPTOComments`, { CP_ID: cpId });
                      setPtoCommands((res.data || []).map(x => ({
                        id: x.Id, comment: x.comment, action: x.action,
                        date: new Date(x.date).toLocaleDateString(), edited: x.edited,
                      })));
                    } catch (err) {
                      setError(err.response?.data?.error || "Failed to add PTO comment");
                    } finally {
                      setBusyAction(false);
                    }
                  }}
                  disabled={busyAction || !ptoComment.trim()}
                  sx={{ height: "fit-content", minWidth: 120 }}
                >
                  {busyAction ? <CircularProgress size={18} color="inherit" /> : "💬 Submit"}
                </CompactButton>
              </Box>

              <Typography variant="h6" sx={{ mb: 2, fontWeight: 700, fontSize: "1rem", color: 'primary.main' }}>
                📋 Comments History
              </Typography>
              <TightTableContainer component={Paper}>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <CommentHeaderCell>ID</CommentHeaderCell>
                      <CommentHeaderCell>Date</CommentHeaderCell>
                      <CommentHeaderCell>Comment</CommentHeaderCell>
                      <CommentHeaderCell>Action</CommentHeaderCell>
                      <CommentHeaderCell>Edited</CommentHeaderCell>
                      <CommentHeaderCell>Actions</CommentHeaderCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ptoCommands.length ? ptoCommands.slice(0, 3).map((c, i) => (
                      <TableRow key={c.id} sx={{
                        backgroundColor: i % 2 === 0 ? alpha(theme.palette.primary.main, 0.02) : "#ffffff",
                        "&:hover": {
                          backgroundColor: alpha(theme.palette.primary.main, 0.08),
                          transform: 'translateX(4px)',
                          boxShadow: `inset 4px 0 0 ${theme.palette.primary.main}`,
                        },
                        transition: 'all 0.3s ease',
                      }}>
                        <CommentDataCell sx={{ fontWeight: 700, color: theme.palette.primary.main }}>{c.id}</CommentDataCell>
                        <CommentDataCell sx={{ fontWeight: 600 }}>{c.date}</CommentDataCell>
                        <CommentDataCell sx={{
                          wordBreak: "break-word", fontSize: "0.7rem", textAlign: "center", px: 2, lineHeight: 1.4
                        }}>
                          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "32px" }}>
                            {c.comment.length > 50 ? `${c.comment.substring(0, 50)}...` : c.comment}
                          </Box>
                        </CommentDataCell>
                        <CommentDataCell><StatusChip label={c.action} status={c.action?.toLowerCase()} /></CommentDataCell>
                        <CommentDataCell><StatusChip label={c.edited ? "Yes" : "No"} status={c.edited ? "open" : "closed"} /></CommentDataCell>
                        <CommentDataCell>
                          <Box sx={{ display: "flex", gap: 1, justifyContent: "center" }}>
                            <IconButton
                              size="small"
                              onClick={() => openEditPto(c)}
                              sx={{
                                p: 0.5,
                                borderRadius: 2,
                                backgroundColor: alpha(theme.palette.primary.main, 0.1),
                                '&:hover': {
                                  backgroundColor: alpha(theme.palette.primary.main, 0.2),
                                  transform: 'scale(1.1)',
                                }
                              }}
                            >
                              <Edit sx={{ fontSize: "0.7rem", color: theme.palette.primary.main }} />
                            </IconButton>
                            <IconButton
                              size="small"
                              onClick={() => askDeletePto(c)}
                              sx={{
                                p: 0.5,
                                borderRadius: 2,
                                backgroundColor: alpha(theme.palette.error.main, 0.1),
                                '&:hover': {
                                  backgroundColor: alpha(theme.palette.error.main, 0.2),
                                  transform: 'scale(1.1)',
                                }
                              }}
                            >
                              <Delete sx={{ fontSize: "0.7rem", color: theme.palette.error.main }} />
                            </IconButton>
                          </Box>
                        </CommentDataCell>
                      </TableRow>
                    )) : (
                      <TableRow>
                        <CommentDataCell colSpan={6} sx={{ textAlign: "center", py: 3 }}>
                          <Typography color="text.secondary" sx={{ fontSize: "0.8rem" }}>
                            📝 No comments found
                          </Typography>
                        </CommentDataCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TightTableContainer>
            </CompactContent>
          </ShellCard>
        )}

        {/* Manage Owners (UpdatePackageOwner2) */}
        <UpdatePackageOwner2
          cpId={cpId}
          teams={teams}
          setError={setError}
          showSuccessMessage={showSuccess}
          trackerData={trackerData}
        />

        {/* Enhanced Dialogs */}
        <Dialog
          open={statusDialog.open}
          onClose={() => setStatusDialog(s => ({ ...s, open: false }))}
          fullWidth
          maxWidth="xs"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
          TransitionComponent={Grow}
        >
          <DialogTitle sx={{
            pb: 1,
            fontWeight: 700,
            fontSize: "1.1rem",
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            textAlign: 'center',
          }}>
            ⚙️ Update Status for {statusDialog.team}
          </DialogTitle>
          <DialogContent sx={{ pt: 3, pb: 2 }}>
            <FormControl fullWidth sx={{ mt: 1 }}>
              <InputLabel sx={{ fontWeight: 600, fontSize: 14 }}>Status</InputLabel>
              <Select
                value={statusDialog.newStatus}
                label="Status"
                onChange={(e) => setStatusDialog(s => ({ ...s, newStatus: e.target.value }))}
                size="small"
                sx={{
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: 15,
                }}
              >
                <MenuItem value="Open" sx={{ fontWeight: 600, fontSize: 14, py: 1.5 }}>🔴 Open</MenuItem>
                <MenuItem value="Closed" sx={{ fontWeight: 600, fontSize: 14, py: 1.5 }}>🟢 Closed</MenuItem>
                <MenuItem value="In Progress" sx={{ fontWeight: 600, fontSize: 14, py: 1.5 }}>🟡 In Progress</MenuItem>
                <MenuItem value="NA" sx={{ fontWeight: 600, fontSize: 14, py: 1.5 }}>⚪ NA</MenuItem>
              </Select>
            </FormControl>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1 }}>
            <Button
              onClick={() => setStatusDialog(s => ({ ...s, open: false }))}
              size="small"
              sx={{ borderRadius: 2, fontWeight: 600 }}
            >
              Cancel
            </Button>
            <CompactButton
              onClick={updateStatus}
              disabled={busyAction}
              size="small"
              sx={{ minWidth: 100 }}
            >
              {busyAction ? <CircularProgress size={16} color="inherit" /> : "✨ Update"}
            </CompactButton>
          </DialogActions>
        </Dialog>

        <Dialog
          open={editPtoDialogOpen}
          onClose={() => setEditPtoDialogOpen(false)}
          fullWidth
          maxWidth="sm"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
          TransitionComponent={Grow}
        >
          <DialogTitle sx={{
            pb: 1,
            fontWeight: 700,
            fontSize: "1.1rem",
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            textAlign: 'center',
          }}>
            ✏️ Edit Comment
          </DialogTitle>
          <DialogContent sx={{ pt: 2 }}>
            <EnhancedTextField
              autoFocus
              margin="dense"
              label="Comment"
              fullWidth
              multiline
              rows={4}
              value={currentPtoComment.comment}
              onChange={(e) => setCurrentPtoComment(c => ({ ...c, comment: e.target.value }))}
              variant="outlined"
              size="small"
            />
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1 }}>
            <Button
              onClick={() => setEditPtoDialogOpen(false)}
              size="small"
              sx={{ borderRadius: 2, fontWeight: 600 }}
            >
              Cancel
            </Button>
            <CompactButton
              onClick={saveEditPto}
              disabled={busyAction}
              size="small"
              sx={{ minWidth: 100 }}
            >
              {busyAction ? <CircularProgress size={16} color="inherit" /> : "💾 Save"}
            </CompactButton>
          </DialogActions>
        </Dialog>

        <Dialog
          open={deleteConfirmDialog.open}
          onClose={() => setDeleteConfirmDialog({ open: false, commentId: null, commentText: "" })}
          fullWidth
          maxWidth="sm"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              border: '2px solid #f44336',
            }
          }}
          TransitionComponent={Grow}
        >
          <DialogTitle sx={{
            fontSize: 16,
            background: 'linear-gradient(135deg, #f44336, #d32f2f)',
            color: '#fff',
            textAlign: 'center',
            fontWeight: 700,
          }}>
            🗑️ Confirm Delete
          </DialogTitle>
          <DialogContent sx={{ pt: 2 }}>
            <Typography variant="body2" sx={{ mb: 2, fontSize: "0.9rem", fontWeight: 600 }}>
              Are you sure you want to delete this comment?
            </Typography>
            <Typography variant="body2" sx={{
              backgroundColor: alpha('#f44336', 0.1),
              p: 2,
              borderRadius: 2,
              fontStyle: "italic",
              fontSize: "0.8rem",
              border: '1px solid #f44336',
            }}>
              "{deleteConfirmDialog.commentText}"
            </Typography>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1, justifyContent: 'center' }}>
            <Button
              onClick={() => setDeleteConfirmDialog({ open: false, commentId: null, commentText: "" })}
              size="small"
              sx={{ borderRadius: 2, fontWeight: 600 }}
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDeletePto}
              variant="contained"
              color="error"
              disabled={busyAction}
              size="small"
              sx={{
                borderRadius: 2,
                fontWeight: 700,
                background: 'linear-gradient(135deg, #f44336, #d32f2f)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #d32f2f, #b71c1c)',
                }
              }}
            >
              {busyAction ? <CircularProgress size={16} color="inherit" /> : "🗑️ Delete"}
            </Button>
          </DialogActions>
        </Dialog>
      </Container>

      <Footer />
    </Box>
  );
};

export default UpdatePackageOwner1;
