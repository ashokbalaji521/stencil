import React, { useState, useEffect } from "react";
import {
  Box, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Button, Select, MenuItem, FormControl, InputLabel, Grid, Card, CardContent,
  Autocomplete, Checkbox, TextField, Dialog, DialogTitle, DialogContent, DialogActions,
  List, ListItem, ListItemText, Divider, IconButton, CircularProgress, useTheme
} from "@mui/material";
import {
  Email as EmailIcon, Close as CloseIcon, GroupAdd as GroupAddIcon, PersonAdd as PersonAddIcon,
} from "@mui/icons-material";
import { styled, alpha, keyframes } from "@mui/material/styles";
import axios from "axios";
import { Data } from "../custom";

// Enhanced Animations
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0%, 100% { transform: scale(1); opacity: 0.9; }
  50% { transform: scale(1.05); opacity: 1; }
`;

const slideInLeft = keyframes`
  from { transform: translateX(-20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 5px rgba(33, 150, 243, 0.5); }
  50% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.8), 0 0 30px rgba(33, 150, 243, 0.6); }
`;

// TeamMaster data
const teamMaster = [
  { TeamId: 1, TeamName: "PDM" },
  { TeamId: 2, TeamName: "MM_Buyer" },
  { TeamId: 3, TeamName: "MM_logistics" },
  { TeamId: 4, TeamName: "SQA" },
  { TeamId: 5, TeamName: "WH" },
  { TeamId: 6, TeamName: "MC" },
  { TeamId: 7, TeamName: "SMT" },
  { TeamId: 8, TeamName: "MS_SMT" },
  { TeamId: 9, TeamName: "MS_IE" },
  { TeamId: 10, TeamName: "MS_TEST" },
  { TeamId: 11, TeamName: "MS_PT" },
  { TeamId: 12, TeamName: "MS_PE" },
  { TeamId: 13, TeamName: "MS_IT" },
  { TeamId: 14, TeamName: "OPS" },
];

// Enhanced Styled Components
const ShellCard = styled(Card)(({ theme }) => ({
  borderRadius: 12,
  background: '#ffffff',
  boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.1)',
  border: `1px solid ${alpha(theme.palette.divider, 0.12)}`,
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  animation: `${fadeIn} 0.6s ease-out`,
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 25px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.08)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '3px',
    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
  }
}));

const CompactContent = styled(CardContent)(({ theme }) => ({
  padding: 16,
  "&:last-child": { paddingBottom: 16 },
  animation: `${slideInLeft} 0.5s ease-out`,
}));

const TightTableContainer = styled(TableContainer)(({ theme }) => ({
  borderRadius: 8,
  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  overflow: 'hidden',
  background: '#ffffff',
  boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
  '&:hover': {
    boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
  }
}));

// Enhanced StiHeaderCell with gradient styling
const StiHeaderCell = styled(TableCell)(({ theme, isEmail, isApproveStatus }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  fontWeight: 800,
  fontSize: "0.7rem",
  padding: "8px 4px",
  borderBottom: "none",
  textAlign: "center",
  whiteSpace: "pre-line",
  lineHeight: 1.2,
  width: isEmail ? "22%" : isApproveStatus ? "12%" : "9.5%",
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
  }
}));

// Enhanced StiDataCell with hover effects
const StiDataCell = styled(TableCell)(({ theme, isEmail, isApproveStatus }) => ({
  borderBottom: "1px solid rgba(0,0,0,0.06)",
  padding: "6px 4px",
  fontSize: "0.7rem",
  fontWeight: 500,
  textAlign: "center",
  width: isEmail ? "22%" : isApproveStatus ? "12%" : "9.5%",
  wordBreak: isEmail ? "break-all" : "break-word",
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

// Enhanced SignoffHeaderCell with gradient styling - FIXED ALIGNMENT
const SignoffHeaderCell = styled(TableCell)(({ theme, isEmail, isAction }) => ({
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: theme.palette.primary.contrastText,
  fontWeight: 800,
  fontSize: "0.7rem",
  padding: "8px 4px",
  borderBottom: "none",
  textAlign: "center",
  whiteSpace: "pre-line",
  lineHeight: 1.2,
  width: isEmail ? "25%" : isAction ? "15%" : "15%", // Fixed width distribution
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
  '&::after': {
    content: '""',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '2px',
    background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
  }
}));

// Enhanced SignoffDataCell with hover effects - FIXED ALIGNMENT
const SignoffDataCell = styled(TableCell)(({ theme, isEmail, isAction }) => ({
  borderBottom: "1px solid rgba(0,0,0,0.06)",
  padding: "6px 4px",
  fontSize: "0.7rem",
  fontWeight: 500,
  textAlign: "center",
  width: isEmail ? "25%" : isAction ? "15%" : "15%", // Fixed width distribution
  wordBreak: isEmail ? "break-all" : "break-word",
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 800,
  fontSize: "1.1rem",
  color: theme.palette.primary.main,
  marginBottom: 12,
  display: "flex",
  alignItems: "center",
  gap: 8,
  textShadow: '0 1px 2px rgba(0,0,0,0.1)',
}));

const StatusChip = styled(Box)(({ status, theme }) => {
  const colors = {
    approved: { bg: alpha('#4caf50', 0.1), color: '#2e7d32', border: '#4caf50' },
    acknowledged: { bg: alpha('#4caf50', 0.1), color: '#2e7d32', border: '#4caf50' },
    pending: { bg: alpha('#ff9800', 0.1), color: '#e65100', border: '#ff9800' },
    "not approved": { bg: alpha('#f44336', 0.1), color: '#c62828', border: '#f44336' },
    "not acknowledged": { bg: alpha('#f44336', 0.1), color: '#c62828', border: '#f44336' },
    default: { bg: alpha('#9e9e9e', 0.1), color: '#616161', border: '#9e9e9e' }
  };
  const color = colors[status?.toLowerCase()] || colors.default;
  return {
    backgroundColor: color.bg,
    color: color.color,
    border: `1px solid ${color.border}`,
    px: 1,
    py: 0.5,
    borderRadius: 2,
    fontSize: "0.6rem",
    fontWeight: 700,
    textAlign: "center",
    minWidth: "60px",
    display: "inline-block",
    transition: 'all 0.3s ease',
    '&:hover': {
      transform: 'scale(1.05)',
      boxShadow: `0 2px 8px ${alpha(color.border, 0.3)}`,
    },
  };
});

const CompactButton = styled(Button)(({ theme }) => ({
  borderRadius: 8,
  padding: '6px 16px',
  fontWeight: 700,
  textTransform: 'none',
  fontSize: '0.8rem',
  minHeight: 32,
  boxShadow: '0 3px 12px rgba(0, 0, 0, 0.15)',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.2)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
    transition: 'left 0.5s',
  },
  '&:hover::before': {
    left: '100%',
  }
}));

const EnhancedTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: 8,
    transition: 'all 0.3s ease',
    background: '#ffffff',
    '&:hover': {
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
    },
    '&.Mui-focused': {
      animation: `${glow} 2s infinite`,
      transform: 'translateY(-1px)',
    }
  }
}));

const UpdatePackageOwner2 = ({
  cpId,
  teams = teamMaster.map(team => team.TeamName),
  setError,
  showSuccessMessage,
  trackerData,
  isUser = false, // Add prop instead of session
  currentCpId = cpId || "CP1002" // Add prop instead of session
}) => {
  const theme = useTheme();
  const [ownerComments, setOwnerComments] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState("");
  const [selectedOwners, setSelectedOwners] = useState([]);
  const [availableOwners, setAvailableOwners] = useState([]);
  const [selectedSignOffTeam, setSelectedSignOffTeam] = useState("");
  const [selectedSignOffOwners, setSelectedSignOffOwners] = useState([]);
  const [availableSignOffOwners, setAvailableSignOffOwners] = useState([]);
  const [signOffRequests, setSignOffRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isStiCnPopupOpen, setIsStiCnPopupOpen] = useState(false);
  const [isSignOffPopupOpen, setIsSignOffPopupOpen] = useState(false);

  // Updated fetchOwners to use getowners endpoint
  const fetchOwners = async (teamName, type) => {
    try {
      setLoading(true);
      // Find TeamId from teamMaster based on teamName
      const team = teamMaster.find(t => t.TeamName === teamName);
      if (!team) {
        setError(`Team ${teamName} not found`);
        return;
      }
      const { data } = await axios.post(`${Data.url}/getowners`, { TeamId: team.TeamId });
      if (data.error) {
        setError(data.error);
        return;
      }
      if (type === "owner") {
        setAvailableOwners(data.users || []);
        setSelectedOwners([]); // Clear selected owners when team changes
      } else if (type === "signoff") {
        setAvailableSignOffOwners(data.users || []);
        setSelectedSignOffOwners([]); // Clear selected sign-off owners when team changes
      }
    } catch (err) {
      setError(`Failed to fetch ${type} owners`);
    } finally {
      setLoading(false);
    }
  };

  const fetchOwnerComments = async () => {
    try {
      setLoading(true);
      const { data } = await axios.post(`${Data.url}/getStatusRecordsByCpId`, { CP_ID: currentCpId });
      const mappedComments = (data.assignRecords || []).map(record => ({
        copId: trackerData?.packageId || record.CP_ID,
        team: record.Team,
        email: record.Emailid,
        preImplementation: record.preImplementation || "",
        postImplementation: record.postImplementation || "",
        approveStatus: record.ApprovedStatus === true || record.ApprovedStatus === 1 ? "Acknowledged" : "Not Acknowledged",
        id: record.ID,
        CP_ID: record.CP_ID,
      }));
      setOwnerComments(mappedComments);
    } catch (err) {
      setError("Failed to fetch owner comments");
    } finally {
      setLoading(false);
    }
  };

  const fetchSignOffRequests = async () => {
    try {
      setLoading(true);
      const { data } = await axios.post(`${Data.url}/getStatusRecordsByCpId`, { CP_ID: currentCpId });
      const mappedRequests = (data.signOffRecords || []).map(record => ({
        copId: trackerData?.packageId || record.CP_ID,
        team: record.Team,
        email: record.Emailid,
        comment: record.comment || "",
        signOffStatus: record.SignoffApproved === true || record.SignoffApproved === 1 ? "Approved" : "Pending",
        id: record.ID,
        CP_ID: record.CP_ID,
      }));
      setSignOffRequests(mappedRequests);
    } catch (err) {
      setError("Failed to fetch sign-off requests");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteOwnerComment = async (idToDelete) => {
    try {
      await axios.delete(`${Data.url}/deleteAssignRecord/${idToDelete}`, {
        data: { CP_ID: currentCpId },
      });
      setOwnerComments(ownerComments.filter(comment => comment.id !== idToDelete));
      showSuccessMessage("Owner comment deleted successfully!");
    } catch (err) {
      //setError("Failed to delete owner comment");
    }
  };

  const handleDeleteSignOffRequest = async (idToDelete) => {
    try {
      await axios.delete(`${Data.url}/deleteSignOffRecord/${idToDelete}`, {
        data: { CP_ID: currentCpId },
      });
      setSignOffRequests(signOffRequests.filter(request => request.id !== idToDelete));
      showSuccessMessage("Sign-off request deleted successfully!");
    } catch (err) {
      setError("Failed to delete sign-off request");
    }
  };

  useEffect(() => {
    fetchOwnerComments();
    fetchSignOffRequests();
  }, [currentCpId]);

  useEffect(() => {
    if (selectedTeam) {
      fetchOwners(selectedTeam, "owner");
    } else {
      setAvailableOwners([]);
      setSelectedOwners([]);
    }
  }, [selectedTeam]);

  useEffect(() => {
    if (selectedSignOffTeam) {
      fetchOwners(selectedSignOffTeam, "signoff");
    } else {
      setAvailableSignOffOwners([]);
      setSelectedSignOffOwners([]);
    }
  }, [selectedSignOffTeam]);

  const handleAssignOwner = async () => {
    if (selectedTeam && selectedOwners.length > 0) {
      try {
        setLoading(true);
        const usernameString = selectedOwners.map(owner => owner.Username).join(",");
        const { data } = await axios.post(`${Data.url}/AssignUsersToSTICN`, {
          username: usernameString,
          CP_ID: currentCpId,
        });
        const newComments = data.users.map(user => ({
          copId: trackerData?.packageId,
          team: user.Team,
          email: user.Email,
          preImplementation: "",
          postImplementation: "",
          approveStatus: "Not Approved",
          id: user.ID,
          CP_ID: currentCpId,
        }));
        setOwnerComments(prev => [...prev, ...newComments]);
        handleClearStiCnSelections();
        showSuccessMessage("STI/CN Owners assigned successfully!");
      } catch (err) {
        setError("Failed to assign STI/CN owners");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAssignSignOffOwner = async () => {
    if (selectedSignOffTeam && selectedSignOffOwners.length > 0) {
      try {
        setLoading(true);
        const usernameString = selectedSignOffOwners.map(owner => owner.Username).join(",");
        const { data } = await axios.post(`${Data.url}/SignOffUsersFromSTICN`, {
          username: usernameString,
          CP_ID: currentCpId,
        });
        const newRequests = data.users.map(user => ({
          copId: trackerData?.packageId,
          team: user.Team,
          email: user.Email,
          comment: "",
          signOffStatus: "Pending",
          id: user.ID,
          CP_ID: currentCpId,
        }));
        setSignOffRequests(prev => [...prev, ...newRequests]);
        handleClearSignOffSelections();
        showSuccessMessage("Sign-off Owners assigned successfully!");
      } catch (err) {
        setError("Failed to assign sign-off owners");
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSendEmailNotification = async (type) => {
    try {
      setLoading(true);
      const endpoint = type === "signoff" ? "SendSignOffEmailsAndUpdateStatus" : "SendEmailsAndUpdateStatus";
      await axios.post(`${Data.url}/${endpoint}`, {
        type,
        packageId: trackerData?.packageId,
        CP_ID: currentCpId,
      });
      const messageMap = {
        owner: "STI/CN Owner email notifications sent successfully!",
        signoff: "Sign-off Owner email notifications sent successfully!",
      };
      showSuccessMessage(messageMap[type] || "Email notifications sent successfully!");

      if (type === "owner") {
        setIsStiCnPopupOpen(false);
        handleClearStiCnSelections();
      } else if (type === "signoff") {
        setIsSignOffPopupOpen(false);
        handleClearSignOffSelections();
      }
    } catch (err) {
      setError("Failed to send email notification");
    } finally {
      setLoading(false);
    }
  };

  const handleClearStiCnSelections = () => {
    setSelectedTeam("");
    setSelectedOwners([]);
    setAvailableOwners([]);
  };

  const handleClearSignOffSelections = () => {
    setSelectedSignOffTeam("");
    setSelectedSignOffOwners([]);
    setAvailableSignOffOwners([]);
  };

  return (
    <>
      <ShellCard>
        <CompactContent>
          {!isUser && (
            <>
              <SectionTitle sx={{ mb: 2 }}>
                <GroupAddIcon sx={{ fontSize: "1.2rem" }} />
                Manage Owners (CP_ID: {currentCpId})
              </SectionTitle>

              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6}>
                  <CompactButton
                    variant="contained"
                    onClick={() => setIsStiCnPopupOpen(true)}
                    startIcon={<GroupAddIcon />}
                    fullWidth
                    sx={{
                      background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
                      color: theme.palette.primary.contrastText,
                      py: 1.2,
                      fontSize: "0.85rem"
                    }}
                  >
                    🔧 Assign STI/CN Owners
                  </CompactButton>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <CompactButton
                    variant="contained"
                    onClick={() => setIsSignOffPopupOpen(true)}
                    startIcon={<PersonAddIcon />}
                    fullWidth
                    sx={{
                      background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
                      color: theme.palette.primary.contrastText,
                      py: 1.2,
                      fontSize: "0.85rem"
                    }}
                  >
                    ✅ Assign Sign-off Owners
                  </CompactButton>
                </Grid>
              </Grid>

              <Divider sx={{ my: 3, borderColor: alpha(theme.palette.primary.main, 0.1) }} />

              <SectionTitle sx={{ mb: 2 }}>📋 Current Assign STI/CN Owners</SectionTitle>
              <TightTableContainer component={Paper}>
                <Table size="small" sx={{ tableLayout: "fixed", width: "100%" }}>
                  <TableHead>
                    <TableRow>
                      <StiHeaderCell>Team</StiHeaderCell>
                      <StiHeaderCell isEmail>Email</StiHeaderCell>
                      <StiHeaderCell>Pre-Implementation</StiHeaderCell>
                      <StiHeaderCell>Post-Implementation</StiHeaderCell>
                      <StiHeaderCell isApproveStatus>Acknowledgement Status</StiHeaderCell>
                      <StiHeaderCell>CP-ID</StiHeaderCell>
                      <StiHeaderCell>Action</StiHeaderCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ownerComments.length === 0 ? (
                      <TableRow>
                        <StiDataCell colSpan={7} sx={{ textAlign: "center", py: 3 }}>
                          <Typography color="text.secondary" sx={{ fontSize: "0.8rem" }}>
                            📝 No STI/CN Owners assigned yet.
                          </Typography>
                        </StiDataCell>
                      </TableRow>
                    ) : (
                      ownerComments.map((comment, index) => (
                        <TableRow
                          key={comment.id}
                          sx={{
                            "&:hover": {
                              backgroundColor: alpha(theme.palette.primary.main, 0.04),
                              transform: 'translateX(4px)',
                              boxShadow: `inset 4px 0 0 ${theme.palette.primary.main}`,
                            },
                            transition: 'all 0.3s ease',
                            animation: `${slideInLeft} 0.5s ease-out ${index * 0.1}s`
                          }}
                        >
                          <StiDataCell title={comment.team} sx={{ fontWeight: 600 }}>{comment.team}</StiDataCell>
                          <StiDataCell isEmail title={comment.email} sx={{ fontSize: "0.65rem" }}>
                            {comment.email}
                          </StiDataCell>
                          <StiDataCell title={comment.preImplementation}>
                            {comment.preImplementation || "-"}
                          </StiDataCell>
                          <StiDataCell title={comment.postImplementation}>
                            {comment.postImplementation || "-"}
                          </StiDataCell>
                          <StiDataCell isApproveStatus>
                            <StatusChip status={comment.approveStatus}>
                              {comment.approveStatus}
                            </StatusChip>
                          </StiDataCell>
                          <StiDataCell title={comment.CP_ID} sx={{ fontWeight: 600, color: 'primary.main' }}>{comment.CP_ID}</StiDataCell>
                          <StiDataCell>
                            <Button
                              variant="contained"
                              color="error"
                              size="small"
                              onClick={() => handleDeleteOwnerComment(comment.id)}
                              sx={{
                                textTransform: "none",
                                fontSize: "0.65rem",
                                px: 1,
                                py: 0.5,
                                borderRadius: 2,
                                background: 'linear-gradient(135deg, #f44336, #d32f2f)',
                                '&:hover': {
                                  background: 'linear-gradient(135deg, #d32f2f, #b71c1c)',
                                  transform: 'scale(1.05)',
                                }
                              }}
                            >
                              🗑️ Delete
                            </Button>
                          </StiDataCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TightTableContainer>

              <Divider sx={{ my: 3, borderColor: alpha(theme.palette.primary.main, 0.1) }} />
            </>
          )}

          <SectionTitle sx={{ mb: 2 }}>📋 Current Sign-off Requested Owner Details</SectionTitle>
          <TightTableContainer component={Paper}>
            <Table size="small" sx={{ tableLayout: "fixed", width: "100%" }}>
              <TableHead>
                <TableRow>
                  <SignoffHeaderCell>Team</SignoffHeaderCell>
                  <SignoffHeaderCell isEmail>Email</SignoffHeaderCell>
                  <SignoffHeaderCell>Comment</SignoffHeaderCell>
                  <SignoffHeaderCell>Sign-off Status</SignoffHeaderCell>
                  <SignoffHeaderCell>CP-ID</SignoffHeaderCell>
                  {!isUser && <SignoffHeaderCell isAction>Action</SignoffHeaderCell>}
                </TableRow>
              </TableHead>
              <TableBody>
                {signOffRequests.length === 0 ? (
                  <TableRow>
                    <SignoffDataCell colSpan={isUser ? 5 : 6} sx={{ textAlign: "center", py: 3 }}>
                      <Typography color="text.secondary" sx={{ fontSize: "0.8rem" }}>
                        📝 No Sign-off Owners assigned yet.
                      </Typography>
                    </SignoffDataCell>
                  </TableRow>
                ) : (
                  signOffRequests.map((request, index) => (
                    <TableRow
                      key={request.id}
                      sx={{
                        "&:hover": {
                          backgroundColor: alpha(theme.palette.primary.main, 0.04),
                          transform: 'translateX(4px)',
                          boxShadow: `inset 4px 0 0 ${theme.palette.primary.main}`,
                        },
                        transition: 'all 0.3s ease',
                        animation: `${slideInLeft} 0.5s ease-out ${index * 0.1}s`
                      }}
                    >
                      <SignoffDataCell title={request.team} sx={{ fontWeight: 600 }}>{request.team}</SignoffDataCell>
                      <SignoffDataCell isEmail title={request.email} sx={{ fontSize: "0.65rem" }}>
                        {request.email}
                      </SignoffDataCell>
                      <SignoffDataCell title={request.comment}>
                        {request.comment || "-"}
                      </SignoffDataCell>
                      <SignoffDataCell>
                        <StatusChip status={request.signOffStatus}>
                          {request.signOffStatus}
                        </StatusChip>
                      </SignoffDataCell>
                      <SignoffDataCell title={request.CP_ID} sx={{ fontWeight: 600, color: 'primary.main' }}>{request.CP_ID}</SignoffDataCell>
                      {!isUser && (
                        <SignoffDataCell isAction>
                          <Button
                            variant="contained"
                            color="error"
                            size="small"
                            onClick={() => handleDeleteSignOffRequest(request.id)}
                            sx={{
                              textTransform: "none",
                              fontSize: "0.65rem",
                              px: 1,
                              py: 0.5,
                              borderRadius: 2,
                              background: 'linear-gradient(135deg, #f44336, #d32f2f)',
                              '&:hover': {
                                background: 'linear-gradient(135deg, #d32f2f, #b71c1c)',
                                transform: 'scale(1.05)',
                              }
                            }}
                          >
                            🗑️ Delete
                          </Button>
                        </SignoffDataCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TightTableContainer>
        </CompactContent>
      </ShellCard>

      {/* Enhanced STI/CN Owners Dialog */}
      {!isUser && (
        <Dialog
          open={isStiCnPopupOpen}
          onClose={() => { setIsStiCnPopupOpen(false); handleClearStiCnSelections(); }}
          maxWidth="lg"
          fullWidth
          PaperProps={{
            sx: {
              minHeight: "400px",
              maxHeight: "80vh",
              width: "90%",
              maxWidth: "950px",
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
        >
          <DialogTitle sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            p: 2,
            borderRadius: '16px 16px 0 0',
          }}>
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <GroupAddIcon sx={{ mr: 1, fontSize: "1.3rem" }} />
              <Typography variant="h6" sx={{ fontSize: "1.1rem", fontWeight: 700 }}>
                🔧 Assign STI/CN Owners for CP_ID: {currentCpId}
              </Typography>
            </Box>
            <IconButton
              onClick={() => { setIsStiCnPopupOpen(false); handleClearStiCnSelections(); }}
              size="small"
              sx={{
                color: '#fff',
                '&:hover': {
                  backgroundColor: alpha('#fff', 0.1),
                  transform: 'scale(1.1)',
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </DialogTitle>

          <DialogContent sx={{ padding: 3, pt: 3 }}>
            <Box sx={{
              px: 3,
              py: 2.5,
              border: `2px solid ${alpha(theme.palette.primary.main, 0.2)}`,
              borderRadius: 3,
              backgroundColor: alpha(theme.palette.primary.main, 0.02),
              transition: 'all 0.3s ease',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.04),
                transform: 'translateY(-1px)',
              }
            }}>
              <Grid container spacing={4} alignItems="flex-start">
                <Grid item xs={12} sm={5}>
                  <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 700, color: 'primary.main' }}>
                    Select Team
                  </Typography>
                  <FormControl fullWidth size="medium">
                    <InputLabel sx={{
                      fontWeight: 700,
                      fontSize: '0.95rem',
                      color: 'primary.main',
                      '&.Mui-focused': {
                        color: 'primary.main',
                      }
                    }}>
                      Choose Team
                    </InputLabel>
                    <Select
                      value={selectedTeam}
                      onChange={(e) => setSelectedTeam(e.target.value)}
                      label="Choose Team"
                      sx={{
                        minHeight: 52,
                        fontSize: "0.95rem",
                        fontWeight: 600,
                        borderRadius: 3,
                        width: '100%',
                        minWidth: 300,
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: alpha(theme.palette.primary.main, 0.3),
                          borderWidth: 2,
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: theme.palette.primary.main,
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: theme.palette.primary.main,
                        }
                      }}
                      MenuProps={{
                        PaperProps: {
                          sx: {
                            maxHeight: 300,
                            minWidth: 380,
                            borderRadius: 2,
                            boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                            border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                          }
                        }
                      }}
                    >
                      {teamMaster.map(team => (
                        <MenuItem
                          key={team.TeamId}
                          value={team.TeamName}
                          sx={{
                            fontWeight: 600,
                            fontSize: '0.95rem',
                            py: 1.5,
                            px: 3,
                            minHeight: 45,
                            minWidth: 380,
                            '&:hover': {
                              backgroundColor: alpha(theme.palette.primary.main, 0.1),
                            },
                            '&.Mui-selected': {
                              backgroundColor: alpha(theme.palette.primary.main, 0.15),
                              '&:hover': {
                                backgroundColor: alpha(theme.palette.primary.main, 0.2),
                              }
                            }
                          }}
                        >
                          {team.TeamName}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={7}>
                  <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 700, color: 'primary.main' }}>
                    Select STI/CN Owners
                  </Typography>
                  <Autocomplete
                    multiple
                    options={availableOwners}
                    getOptionLabel={option => option.Username}
                    value={selectedOwners}
                    onChange={(event, newValue) => setSelectedOwners(newValue)}
                    renderInput={params => (
                      <EnhancedTextField
                        {...params}
                        label="Choose Multiple Owners"
                        placeholder="Select owners..."
                        size="medium"
                        sx={{
                          width: '100%',
                          minWidth: 400,
                          '& .MuiInputBase-root': {
                            minHeight: 52,
                            fontSize: '0.95rem',
                          },
                          '& .MuiInputLabel-root': {
                            fontWeight: 700,
                            fontSize: '0.95rem',
                          }
                        }}
                      />
                    )}
                    renderOption={(props, option, { selected }) => (
                      <li {...props} style={{
                        padding: '14px 18px',
                        minHeight: '65px',
                        minWidth: '500px'
                      }}>
                        <Checkbox
                          checked={selected}
                          style={{ marginRight: 14 }}
                          size="medium"
                        />
                        <Box sx={{ flex: 1 }}>
                          <Typography sx={{
                            fontSize: "1rem",
                            fontWeight: 600,
                            color: 'primary.main',
                            whiteSpace: 'nowrap',
                            overflow: 'visible'
                          }}>
                            👤 {option.Username}
                          </Typography>
                          <Typography sx={{
                            fontSize: "0.85rem",
                            color: 'text.secondary',
                            mt: 0.3,
                            whiteSpace: 'nowrap',
                            overflow: 'visible'
                          }}>
                            📧 {option.Email}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    ListboxProps={{
                      style: {
                        maxHeight: 320,
                        minWidth: 550,
                        width: 'auto',
                      }
                    }}
                    componentsProps={{
                      popper: {
                        style: {
                          minWidth: 550,
                        }
                      }
                    }}
                    disabled={!selectedTeam || loading}
                  />
                </Grid>
              </Grid>
              {selectedOwners.length > 0 && (
                <Box sx={{
                  mt: 3,
                  mx: -1,
                  p: 2.5,
                  border: `2px dashed ${alpha(theme.palette.primary.main, 0.3)}`,
                  borderRadius: 3,
                  backgroundColor: alpha(theme.palette.primary.main, 0.02),
                }}>
                  <Typography variant="h6" color="primary.main" sx={{ mb: 2, fontSize: "1rem", fontWeight: 700 }}>
                    ✅ Selected STI/CN Owners ({selectedOwners.length}):
                  </Typography>
                  <Grid container spacing={2}>
                    {selectedOwners.map((owner, index) => (
                      <Grid item xs={12} sm={6} md={4} key={index}>
                        <Box sx={{
                          p: 2.5,
                          borderRadius: 2,
                          backgroundColor: alpha(theme.palette.primary.main, 0.05),
                          border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                          minHeight: 75,
                        }}>
                          <Typography sx={{
                            fontSize: "0.9rem",
                            fontWeight: 700,
                            color: 'primary.main',
                            mb: 0.5,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            👤 {owner.Username}
                          </Typography>
                          <Typography sx={{
                            fontSize: "0.8rem",
                            color: 'text.secondary',
                            wordBreak: 'break-all',
                            lineHeight: 1.3
                          }}>
                            📧 {owner.Email}
                          </Typography>
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              )}
            </Box>
          </DialogContent>

          <DialogActions sx={{
            padding: 2.5,
            backgroundColor: alpha(theme.palette.primary.main, 0.02),
            borderTop: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
            gap: 2
          }}>
            <Button
              onClick={handleClearStiCnSelections}
              color="error"
              variant="outlined"
              size="small"
              disabled={selectedOwners.length === 0}
              sx={{
                borderRadius: 3,
                fontWeight: 700,
                px: 2.5,
                py: 1,
                fontSize: '0.85rem'
              }}
            >
              🗑️ Clear All
            </Button>
            <Box sx={{ display: "flex", gap: 2 }}>
              <Button
                onClick={() => { setIsStiCnPopupOpen(false); handleClearStiCnSelections(); }}
                size="small"
                sx={{
                  borderRadius: 3,
                  fontWeight: 700,
                  px: 2.5,
                  py: 1,
                  fontSize: '0.85rem'
                }}
              >
                ❌ Cancel
              </Button>
              <CompactButton
                onClick={handleAssignOwner}
                size="small"
                disabled={selectedOwners.length === 0 || loading}
                sx={{
                  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
                  color: theme.palette.primary.contrastText,
                  minWidth: 110,
                  px: 2.5,
                  py: 1.2,
                  fontSize: '0.85rem'
                }}
              >
                {loading ? <CircularProgress size={20} color="inherit" /> : "🔧 Assign"}
              </CompactButton>
              <CompactButton
                onClick={() => handleSendEmailNotification("owner")}
                startIcon={<EmailIcon sx={{ fontSize: '1rem' }} />}
                disabled={loading}
                size="small"
                sx={{
                  background: 'linear-gradient(135deg, #2e7d32, #1b5e20)',
                  color: '#fff',
                  minWidth: 150,
                  px: 2.5,
                  py: 1.2,
                  fontSize: '0.85rem'
                }}
              >
                📧 Send Notifications
              </CompactButton>
            </Box>
          </DialogActions>
        </Dialog>
      )}

      {/* Enhanced Sign-off Owners Dialog */}
      {!isUser && (
        <Dialog
          open={isSignOffPopupOpen}
          onClose={() => { setIsSignOffPopupOpen(false); handleClearSignOffSelections(); }}
          maxWidth="lg"
          fullWidth
          PaperProps={{
            sx: {
              minHeight: "400px",
              maxHeight: "80vh",
              width: "90%",
              maxWidth: "950px",
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
        >
          <DialogTitle sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            p: 2,
            borderRadius: '16px 16px 0 0',
          }}>
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <PersonAddIcon sx={{ mr: 1, fontSize: "1.3rem" }} />
              <Typography variant="h6" sx={{ fontSize: "1.1rem", fontWeight: 700 }}>
                ✅ Assign Sign-off Owners for CP_ID: {currentCpId}
              </Typography>
            </Box>
            <IconButton
              onClick={() => { setIsSignOffPopupOpen(false); handleClearSignOffSelections(); }}
              size="small"
              sx={{
                color: '#fff',
                '&:hover': {
                  backgroundColor: alpha('#fff', 0.1),
                  transform: 'scale(1.1)',
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </DialogTitle>

          <DialogContent sx={{ padding: 3, pt: 3 }}>
            <Box sx={{
              px: 3,
              py: 2.5,
              border: `2px solid ${alpha(theme.palette.primary.main, 0.2)}`,
              borderRadius: 3,
              backgroundColor: alpha(theme.palette.primary.main, 0.02),
              transition: 'all 0.3s ease',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.04),
                transform: 'translateY(-1px)',
              }
            }}>
              <Grid container spacing={4} alignItems="flex-start">
                <Grid item xs={12} sm={5}>
                  <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 700, color: 'primary.main' }}>
                    Select Team
                  </Typography>
                  <FormControl fullWidth size="medium">
                    <InputLabel sx={{
                      fontWeight: 700,
                      fontSize: '0.95rem',
                      color: 'primary.main',
                      '&.Mui-focused': {
                        color: 'primary.main',
                      }
                    }}>
                      Choose Team
                    </InputLabel>
                    <Select
                      value={selectedSignOffTeam}
                      onChange={(e) => setSelectedSignOffTeam(e.target.value)}
                      label="Choose Team"
                      sx={{
                        minHeight: 52,
                        fontSize: "0.95rem",
                        fontWeight: 600,
                        borderRadius: 3,
                        width: '100%',
                        minWidth: 300,
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: alpha(theme.palette.primary.main, 0.3),
                          borderWidth: 2,
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: theme.palette.primary.main,
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: theme.palette.primary.main,
                        }
                      }}
                      MenuProps={{
                        PaperProps: {
                          sx: {
                            maxHeight: 300,
                            minWidth: 380,
                            borderRadius: 2,
                            boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                            border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                          }
                        }
                      }}
                    >
                      {teamMaster.map(team => (
                        <MenuItem
                          key={team.TeamId}
                          value={team.TeamName}
                          sx={{
                            fontWeight: 600,
                            fontSize: '0.95rem',
                            py: 1.5,
                            px: 3,
                            minHeight: 45,
                            minWidth: 380,
                            '&:hover': {
                              backgroundColor: alpha(theme.palette.primary.main, 0.1),
                            },
                            '&.Mui-selected': {
                              backgroundColor: alpha(theme.palette.primary.main, 0.15),
                              '&:hover': {
                                backgroundColor: alpha(theme.palette.primary.main, 0.2),
                              }
                            }
                          }}
                        >
                          {team.TeamName}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={7}>
                  <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 700, color: 'primary.main' }}>
                    Select Sign-off Owners
                  </Typography>
                  <Autocomplete
                    multiple
                    options={availableSignOffOwners}
                    getOptionLabel={option => option.Username}
                    value={selectedSignOffOwners}
                    onChange={(event, newValue) => setSelectedSignOffOwners(newValue)}
                    renderInput={params => (
                      <EnhancedTextField
                        {...params}
                        label="Choose Multiple Owners"
                        placeholder="Select owners..."
                        size="medium"
                        sx={{
                          width: '100%',
                          minWidth: 400,
                          '& .MuiInputBase-root': {
                            minHeight: 52,
                            fontSize: '0.95rem',
                          },
                          '& .MuiInputLabel-root': {
                            fontWeight: 700,
                            fontSize: '0.95rem',
                          }
                        }}
                      />
                    )}
                    renderOption={(props, option, { selected }) => (
                      <li {...props} style={{
                        padding: '14px 18px',
                        minHeight: '65px',
                        minWidth: '500px'
                      }}>
                        <Checkbox
                          checked={selected}
                          style={{ marginRight: 14 }}
                          size="medium"
                        />
                        <Box sx={{ flex: 1 }}>
                          <Typography sx={{
                            fontSize: "1rem",
                            fontWeight: 600,
                            color: 'primary.main',
                            whiteSpace: 'nowrap',
                            overflow: 'visible'
                          }}>
                            👤 {option.Username}
                          </Typography>
                          <Typography sx={{
                            fontSize: "0.85rem",
                            color: 'text.secondary',
                            mt: 0.3,
                            whiteSpace: 'nowrap',
                            overflow: 'visible'
                          }}>
                            📧 {option.Email}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    ListboxProps={{
                      style: {
                        maxHeight: 320,
                        minWidth: 550,
                        width: 'auto',
                      }
                    }}
                    componentsProps={{
                      popper: {
                        style: {
                          minWidth: 550,
                        }
                      }
                    }}
                    disabled={!selectedSignOffTeam || loading}
                  />
                </Grid>
              </Grid>
              {selectedSignOffOwners.length > 0 && (
                <Box sx={{
                  mt: 3,
                  mx: -1,
                  p: 2.5,
                  border: `2px dashed ${alpha(theme.palette.primary.main, 0.3)}`,
                  borderRadius: 3,
                  backgroundColor: alpha(theme.palette.primary.main, 0.02),
                }}>
                  <Typography variant="h6" sx={{ mb: 2, fontSize: "1rem", fontWeight: 700, color: 'primary.main' }}>
                    ✅ Selected Sign-off Owners ({selectedSignOffOwners.length}):
                  </Typography>
                  <Grid container spacing={2}>
                    {selectedSignOffOwners.map((owner, index) => (
                      <Grid item xs={12} sm={6} md={4} key={index}>
                        <Box sx={{
                          p: 2.5,
                          borderRadius: 2,
                          backgroundColor: alpha(theme.palette.primary.main, 0.05),
                          border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                          minHeight: 75,
                        }}>
                          <Typography sx={{
                            fontSize: "0.9rem",
                            fontWeight: 700,
                            color: 'primary.main',
                            mb: 0.5,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            👤 {owner.Username}
                          </Typography>
                          <Typography sx={{
                            fontSize: "0.8rem",
                            color: 'text.secondary',
                            wordBreak: 'break-all',
                            lineHeight: 1.3
                          }}>
                            📧 {owner.Email}
                          </Typography>
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              )}
            </Box>
          </DialogContent>

          <DialogActions sx={{
            padding: 2.5,
            backgroundColor: alpha(theme.palette.primary.main, 0.02),
            borderTop: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
            gap: 2
          }}>
            <Button
              onClick={handleClearSignOffSelections}
              color="error"
              variant="outlined"
              size="small"
              disabled={selectedSignOffOwners.length === 0}
              sx={{
                borderRadius: 3,
                fontWeight: 700,
                px: 2.5,
                py: 1,
                fontSize: '0.85rem'
              }}
            >
              🗑️ Clear All
            </Button>
            <Box sx={{ display: "flex", gap: 2 }}>
              <Button
                onClick={() => { setIsSignOffPopupOpen(false); handleClearSignOffSelections(); }}
                size="small"
                sx={{
                  borderRadius: 3,
                  fontWeight: 700,
                  px: 2.5,
                  py: 1,
                  fontSize: '0.85rem'
                }}
              >
                ❌ Cancel
              </Button>
              <CompactButton
                onClick={handleAssignSignOffOwner}
                size="small"
                disabled={selectedSignOffOwners.length === 0 || loading}
                sx={{
                  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
                  color: theme.palette.primary.contrastText,
                  minWidth: 110,
                  px: 2.5,
                  py: 1.2,
                  fontSize: '0.85rem'
                }}
              >
                {loading ? <CircularProgress size={20} color="inherit" /> : "✅ Assign"}
              </CompactButton>
              <CompactButton
                onClick={() => handleSendEmailNotification("signoff")}
                startIcon={<EmailIcon sx={{ fontSize: '1rem' }} />}
                disabled={loading}
                size="small"
                sx={{
                  background: 'linear-gradient(135deg, #f57c00, #ef6c00)',
                  color: '#fff',
                  minWidth: 150,
                  px: 2.5,
                  py: 1.2,
                  fontSize: '0.85rem'
                }}
              >
                📧 Send Notifications
              </CompactButton>
            </Box>
          </DialogActions>
        </Dialog>
      )}
    </>
  );
};

export default UpdatePackageOwner2;
