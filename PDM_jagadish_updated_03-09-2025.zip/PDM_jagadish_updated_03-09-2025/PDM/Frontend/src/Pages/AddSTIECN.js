import React, { useState } from "react";
import axios from "axios";
import {
  Box,
  Container,
  TextField,
  Button,
  Grid,
  Typography,
  Paper,
  Snackbar,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import { Data } from "../custom";


const AddSTIECN = ({ open, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    changeNoteCategory: "",
    cpId: "",
    ecnStiType: "",
    ecnNumber: "",
    stiNumber: "",
    receivedDate: dayjs(),
    stiFromDate: dayjs(),
    stiToDate: dayjs(),
    productFamily: "",
    productName: "",
    details: "",
  });
  const [errors, setErrors] = useState({});
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [loading, setLoading] = useState(false);


  const theme = {
    primaryColor: "#2563eb",
    secondaryColor: "#4f46e5",
    errorColor: "#dc2626",
    successColor: "#10b981",
    borderRadius: "8px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.05)",
    inputBg: "#ffffff",
    paperBg: "rgba(255, 255, 255, 0.9)",
  };


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" });
    }
  };


  const handleDateChange = (name) => (newValue) => {
    setFormData({ ...formData, [name]: newValue });
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" });
    }
  };


  const validateForm = () => {
    const newErrors = {};
    const requiredFields = [
      "changeNoteCategory",
      "cpId",
      "ecnStiType",
      formData.ecnStiType === "ECN" ? "ecnNumber" : "stiNumber",
      formData.ecnStiType === "ECN" ? "receivedDate" : "stiFromDate",
      formData.ecnStiType === "STI" && "stiToDate",
      "productFamily",
      "productName",
    ].filter(Boolean);


    requiredFields.forEach((field) => {
      if (!formData[field] || (formData[field] instanceof dayjs && !formData[field].isValid())) {
        newErrors[field] = "This field is required";
      }
    });


    return newErrors;
  };


  const resetForm = () => {
    setFormData({
      changeNoteCategory: "",
      cpId: "",
      ecnStiType: "",
      ecnNumber: "",
      stiNumber: "",
      receivedDate: dayjs(),
      stiFromDate: dayjs(),
      stiToDate: dayjs(),
      productFamily: "",
      productName: "",
      details: "",
    });
    setErrors({});
  };


  const handleSubmit = async () => {
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }


    setLoading(true);
    try {
      const payload = {
        Change_Note_Cateogry: formData.changeNoteCategory,
        CP_ID: formData.cpId,
        ECN_STI_Type: formData.ecnStiType,
        ECN_Number: formData.ecnStiType === "ECN" ? formData.ecnNumber : null,
        STI_Number: formData.ecnStiType === "STI" ? formData.stiNumber : null,
        Receieved_Date: formData.ecnStiType === "ECN" && formData.receivedDate.isValid() ? formData.receivedDate.format("YYYY-MM-DD") : null,
        STI_From_Date: formData.ecnStiType === "STI" && formData.stiFromDate.isValid() ? formData.stiFromDate.format("YYYY-MM-DD") : null,
        STI_To_Date: formData.ecnStiType === "STI" && formData.stiToDate.isValid() ? formData.stiToDate.format("YYYY-MM-DD") : null,
        Product_Family: formData.productFamily,
        Product_Name: formData.productName,
        Brief_Details: formData.details,
      };


      const response = await axios.post(`${Data.url}/addECN`, payload);


      if (response.status === 200) {
        setSnackbar({
          open: true,
          message: "STI/ECN added successfully",
          severity: "success",
        });
        setTimeout(() => {
          resetForm();
          onClose();
          if (onSuccess) {
            onSuccess();
          }
        }, 1500);
      }
    } catch (error) {
      console.error("API Error:", error);
      setSnackbar({
        open: true,
        message: error.response?.data?.error || "Failed to add STI/ECN",
        severity: "error",
      });
    } finally {
      setLoading(false);
    }
  };


  const handleCancel = () => {
    resetForm();
    onClose();
  };


  const handleSnackbarClose = () => {
    setSnackbar({ ...snackbar, open: false });
  };


  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: theme.borderRadius,
          padding: 2,
          backgroundColor: theme.paperBg,
          boxShadow: theme.boxShadow,
          margin: { xs: 2, sm: 4 },
          transition: "all 0.3s ease-in-out",
        },
      }}
    >
      <DialogTitle sx={{ textAlign: "left", py: 2 }}>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            background: `linear-gradient(to right, ${theme.primaryColor}, ${theme.secondaryColor})`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Add New STI/ECN
        </Typography>
      </DialogTitle>


      <DialogContent sx={{ px: { xs: 2, sm: 4 }, py: 2 }}>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <Container maxWidth="lg" disableGutters>
            <Paper
              elevation={0}
              sx={{
                p: { xs: 2, sm: 4 },
                backgroundColor: theme.paperBg,
                borderRadius: theme.borderRadius,
                backdropFilter: "blur(4px)",
                transition: "all 0.3s ease-in-out",
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <FormControl
                    fullWidth
                    size="small"
                    required
                    error={!!errors.changeNoteCategory}
                    sx={{
                      backgroundColor: theme.inputBg,
                      borderRadius: theme.borderRadius,
                      "& .MuiOutlinedInput-root": {
                        borderRadius: theme.borderRadius,
                        transition: "all 0.3s ease-in-out",
                      },
                      "& .MuiInputLabel-root": {
                        color: "text.secondary",
                        fontSize: "0.9rem",
                      },
                      "&:hover": {
                        "& .MuiOutlinedInput-notchedOutline": {
                          borderColor: theme.primaryColor,
                        },
                      },
                    }}
                  >
                    <InputLabel id="change-note-category-label">Change Note Category</InputLabel>
                    <Select
                      labelId="change-note-category-label"
                      name="changeNoteCategory"
                      value={formData.changeNoteCategory}
                      onChange={handleInputChange}
                      label="Change Note Category"
                      sx={{ width: '230px' }}
                    >
                      <MenuItem value="">
                        <em>Select Category</em>
                      </MenuItem>
                      <MenuItem value="Materials">Materials</MenuItem>
                      <MenuItem value="Tools & Jigs">Tools & Jigs</MenuItem>
                      <MenuItem value="Documents">Documents</MenuItem>
                    </Select>
                    {errors.changeNoteCategory && (
                      <Typography color="error" variant="caption">
                        {errors.changeNoteCategory}
                      </Typography>
                    )}
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="CP ID"
                    name="cpId"
                    value={formData.cpId}
                    onChange={handleInputChange}
                    size="small"
                    fullWidth
                    required
                    error={!!errors.cpId}
                    helperText={errors.cpId}
                    sx={{
                      backgroundColor: theme.inputBg,
                      borderRadius: theme.borderRadius,
                      "& .MuiOutlinedInput-root": {
                        borderRadius: theme.borderRadius,
                        transition: "all 0.3s ease-in-out",
                      },
                      "& .MuiInputLabel-root": {
                        color: "text.secondary",
                        fontSize: "0.9rem",
                      },
                      "&:hover": {
                        "& .MuiOutlinedInput-root": {
                          borderColor: theme.primaryColor,
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl
                    fullWidth
                    size="small"
                    required
                    error={!!errors.ecnStiType}
                    sx={{
                      backgroundColor: theme.inputBg,
                      borderRadius: theme.borderRadius,
                      "& .MuiOutlinedInput-root": {
                        borderRadius: theme.borderRadius,
                        transition: "all 0.3s ease-in-out",
                      },
                      "& .MuiInputLabel-root": {
                        color: "text.secondary",
                        fontSize: "0.9rem",
                      },
                      "&:hover": {
                        "& .MuiOutlinedInput-notchedOutline": {
                          borderColor: theme.primaryColor,
                        },
                      },
                    }}
                  >
                    <InputLabel id="ecn-sti-type-label">Change Note Type</InputLabel>
                    <Select
                      labelId="ecn-sti-type-label"
                      name="ecnStiType"
                      value={formData.ecnStiType}
                      onChange={handleInputChange}
                      label="ECN/STI Type"
                      sx={{ width: '230px' }}
                    >
                      <MenuItem value="">
                        <em>None</em>
                      </MenuItem>
                      <MenuItem value="ECN">ECN</MenuItem>
                      <MenuItem value="STI">STI</MenuItem>
                    </Select>
                    {errors.ecnStiType && (
                      <Typography color="error" variant="caption">
                        {errors.ecnStiType}
                      </Typography>
                    )}
                  </FormControl>
                </Grid>
                {formData.ecnStiType === "ECN" && (
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="ECN Number"
                      name="ecnNumber"
                      value={formData.ecnNumber}
                      onChange={handleInputChange}
                      size="small"
                      fullWidth
                      required
                      error={!!errors.ecnNumber}
                      helperText={errors.ecnNumber}
                      sx={{
                        backgroundColor: theme.inputBg,
                        borderRadius: theme.borderRadius,
                        "& .MuiOutlinedInput-root": {
                          borderRadius: theme.borderRadius,
                          transition: "all 0.3s ease-in-out",
                        },
                        "& .MuiInputLabel-root": {
                          color: "text.secondary",
                          fontSize: "0.9rem",
                        },
                        "&:hover": {
                          "& .MuiOutlinedInput-root": {
                            borderColor: theme.primaryColor,
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                {formData.ecnStiType === "STI" && (
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="STI Number"
                      name="stiNumber"
                      value={formData.stiNumber}
                      onChange={handleInputChange}
                      size="small"
                      fullWidth
                      required
                      error={!!errors.stiNumber}
                      helperText={errors.stiNumber}
                      sx={{
                        backgroundColor: theme.inputBg,
                        borderRadius: theme.borderRadius,
                        "& .MuiOutlinedInput-root": {
                          borderRadius: theme.borderRadius,
                          transition: "all 0.3s ease-in-out",
                        },
                        "& .MuiInputLabel-root": {
                          color: "text.secondary",
                          fontSize: "0.9rem",
                        },
                        "&:hover": {
                          "& .MuiOutlinedInput-root": {
                            borderColor: theme.primaryColor,
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                {formData.ecnStiType === "ECN" && (
                  <Grid item xs={12} sm={6}>
                    <DatePicker
                      label="Received Date"
                      value={formData.receivedDate}
                      sx={{ width: '230px' }}
                      onChange={handleDateChange("receivedDate")}
                      slotProps={{
                        textField: {
                          size: "small",
                          fullWidth: true,
                          required: true,
                          error: !!errors.receivedDate,
                          helperText: errors.receivedDate,
                          sx: {
                            backgroundColor: theme.inputBg,
                            borderRadius: theme.borderRadius,
                            "& .MuiOutlinedInput-root": {
                              borderRadius: theme.borderRadius,
                              transition: "all 0.3s ease-in-out",
                            },
                            "& .MuiInputLabel-root": {
                              color: "text.secondary",
                              fontSize: "0.9rem",
                            },
                            "&:hover": {
                              "& .MuiOutlinedInput-root": {
                                borderColor: theme.primaryColor,
                              },
                            },
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                {formData.ecnStiType === "STI" && (
                  <>
                    <Grid item xs={12} sm={6}>
                      <DatePicker
                        label="STI From Date"
                        value={formData.stiFromDate}
                        sx={{ width: '230px' }}
                        onChange={handleDateChange("stiFromDate")}
                        slotProps={{
                          textField: {
                            size: "small",
                            fullWidth: true,
                            required: true,
                            error: !!errors.stiFromDate,
                            helperText: errors.stiFromDate,
                            sx: {
                              backgroundColor: theme.inputBg,
                              borderRadius: theme.borderRadius,
                              "& .MuiOutlinedInput-root": {
                                borderRadius: theme.borderRadius,
                                transition: "all 0.3s ease-in-out",
                              },
                              "& .MuiInputLabel-root": {
                                color: "text.secondary",
                                fontSize: "0.9rem",
                              },
                              "&:hover": {
                                "& .MuiOutlinedInput-root": {
                                  borderColor: theme.primaryColor,
                                },
                              },
                            },
                          },
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <DatePicker
                        label="STI To Date"
                        value={formData.stiToDate}
                        sx={{ width: '230px' }}
                        onChange={handleDateChange("stiToDate")}
                        slotProps={{
                          textField: {
                            size: "small",
                            fullWidth: true,
                            required: true,
                            error: !!errors.stiToDate,
                            helperText: errors.stiToDate,
                            sx: {
                              backgroundColor: theme.inputBg,
                              borderRadius: theme.borderRadius,
                              "& .MuiOutlinedInput-root": {
                                borderRadius: theme.borderRadius,
                                transition: "all 0.3s ease-in-out",
                              },
                              "& .MuiInputLabel-root": {
                                color: "text.secondary",
                                fontSize: "0.9rem",
                              },
                              "&:hover": {
                                "& .MuiOutlinedInput-root": {
                                  borderColor: theme.primaryColor,
                                },
                              },
                            },
                          },
                        }}
                      />
                    </Grid>
                  </>
                )}
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="Product Family"
                    name="productFamily"
                    value={formData.productFamily}
                    onChange={handleInputChange}
                    size="small"
                    fullWidth
                    required
                    error={!!errors.productFamily}
                    helperText={errors.productFamily}
                    sx={{
                      backgroundColor: theme.inputBg,
                      borderRadius: theme.borderRadius,
                      "& .MuiOutlinedInput-root": {
                        borderRadius: theme.borderRadius,
                        transition: "all 0.3s ease-in-out",
                      },
                      "& .MuiInputLabel-root": {
                        color: "text.secondary",
                        fontSize: "0.9rem",
                      },
                      "&:hover": {
                        "& .MuiOutlinedInput-root": {
                          borderColor: theme.primaryColor,
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="Product Name"
                    name="productName"
                    value={formData.productName}
                    onChange={handleInputChange}
                    size="small"
                    fullWidth
                    required
                    error={!!errors.productName}
                    helperText={errors.productName}
                    sx={{
                      backgroundColor: theme.inputBg,
                      borderRadius: theme.borderRadius,
                      "& .MuiOutlinedInput-root": {
                        borderRadius: theme.borderRadius,
                        transition: "all 0.3s ease-in-out",
                      },
                      "& .MuiInputLabel-root": {
                        color: "text.secondary",
                        fontSize: "0.9rem",
                      },
                      "&:hover": {
                        "& .MuiOutlinedInput-root": {
                          borderColor: theme.primaryColor,
                        },
                      },
                    }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Comments Section */}
            <Paper
              elevation={0}
              sx={{
                p: { xs: 2, sm: 4 },
                backgroundColor: theme.paperBg,
                borderRadius: theme.borderRadius,
                backdropFilter: "blur(4px)",
                transition: "all 0.3s ease-in-out",
                mt: 3,
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 600,
                  color: theme.primaryColor,
                  mb: 2,
                }}
              >
                Comments
              </Typography>
              <TextField
                label="Brief Details of CN/STI"
                name="details"
                value={formData.details}
                onChange={handleInputChange}
                size="small"
                fullWidth
                multiline
                rows={4}
                sx={{
                  backgroundColor: theme.inputBg,
                  borderRadius: theme.borderRadius,
                  "& .MuiOutlinedInput-root": {
                    borderRadius: theme.borderRadius,
                    transition: "all 0.3s ease-in-out",
                  },
                  "& .MuiInputLabel-root": {
                    color: "text.secondary",
                    fontSize: "0.9rem",
                  },
                  "&:hover": {
                    "& .MuiOutlinedInput-root": {
                      borderColor: theme.primaryColor,
                    },
                  },
                }}
              />
            </Paper>
          </Container>
        </LocalizationProvider>
      </DialogContent>


      <DialogActions sx={{ p: 3, justifyContent: "center", gap: 2 }}>
        <Button
          variant="outlined"
          onClick={handleCancel}
          sx={{
            textTransform: "none",
            borderRadius: theme.borderRadius,
            px: 4,
            py: 1,
            color: theme.primaryColor,
            borderColor: theme.primaryColor,
            "&:hover": {
              backgroundColor: `${theme.primaryColor}10`,
              borderColor: theme.secondaryColor,
            },
            transition: "all 0.3s ease-in-out",
          }}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={loading}
          sx={{
            textTransform: "none",
            borderRadius: theme.borderRadius,
            px: 4,
            py: 1,
            background: `linear-gradient(to right, ${theme.primaryColor}, ${theme.secondaryColor})`,
            "&:hover": {
              background: `linear-gradient(to right, ${theme.secondaryColor}, ${theme.primaryColor})`,
            },
            "&.Mui-disabled": {
              background: "grey.300",
            },
            transition: "all 0.3s ease-in-out",
          }}
          startIcon={loading && <CircularProgress size={20} color="inherit" />}
        >
          {loading ? "Submitting..." : "Submit"}
        </Button>
      </DialogActions>


      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        sx={{ zIndex: 9999 }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbar.severity}
          sx={{
            width: "100%",
            borderRadius: theme.borderRadius,
            p: 2,
            backgroundColor: snackbar.severity === "success" ? theme.successColor : theme.errorColor,
            color: "white",
            "& .MuiAlert-icon": {
              color: "white",
            },
            boxShadow: theme.boxShadow,
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Dialog>
  );
};


export default AddSTIECN;
