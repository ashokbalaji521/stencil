import { FormControl, InputLabel, Select, MenuItem, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

const SelectSection = () => {
  const navigate = useNavigate();
  
  // List of routes from App.js
  const routes = [
    { path: "/Dashboard", label: "Dashboard" },
    { path: "/UserDashboard", label: "User Dashboard" },
    { path: "/AddSTIECN", label: "Add STI/ECN" },
    { path: "/update-package-owner/:cpId", label: "Update Package Owner" },
    { path: "/login", label: "Login" },
  ];

  const handleRouteChange = (event) => {
    const selectedPath = event.target.value;
    // For UpdatePackageOwner, replace :cpId with a placeholder or handle dynamically if needed
    if (selectedPath.includes(":cpId")) {
      navigate(selectedPath.replace(":cpId", "placeholder")); // Replace with actual cpId if available
    } else {
      navigate(selectedPath);
    }
  };

  return (
    <Box
      sx={{
        position: "absolute",
        top: 70, // Position below the Header (Header height is 60px)
        left: 20,
        zIndex: 1000,
      }}
    >
      <FormControl sx={{ minWidth: 200 }}>
        <InputLabel id="route-select-label">Select Page</InputLabel>
        <Select
          labelId="route-select-label"
          label="Select Page"
          defaultValue=""
          onChange={handleRouteChange}
        >
          <MenuItem value="" disabled>
            Select a page
          </MenuItem>
          {routes.map((route) => (
            <MenuItem key={route.path} value={route.path}>
              {route.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
};

export default SelectSection;