// import React, { useState, useEffect } from 'react';
// import {
//   Box, List, ListItem, ListItemIcon, ListItemText, ListItemButton,
//   Tooltip, Zoom, Typography, Divider
// } from '@mui/material';
// import {
//   Dashboard as DashboardIcon,
//   Assessment as AssessmentIcon,
//   Settings as SettingsIcon,
//   Home as HomeIcon,
//   Person as PersonIcon,
//   Menu as MenuIcon,
//   Close as CloseIcon
// } from '@mui/icons-material';
// import { useNavigate, useLocation } from 'react-router-dom';
// import { HEADER_HEIGHT, HEADER_GAP } from './Header'; // adjust path if needed

// const Sidebar = ({ collapsed, setCollapsed }) => {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const [userRole, setUserRole] = useState('');

//   // Get user role from sessionStorage on component mount
//   useEffect(() => {
//     const role = sessionStorage.getItem('role') || sessionStorage.getItem('userRole') || 'User';
//     setUserRole(role);
//   }, []);

//   // All navigation items
//   const allNavItems = [
//     {
//       label: 'Home',
//       icon: <HomeIcon />,
//       path: '/login',
//       color: '#1976d2',
//       gradient: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
//       roles: ['Admin'] // Only show for Admin
//     },
//     {
//       label: 'Dashboard',
//       icon: <DashboardIcon />,
//       path: '/Dashboard',
//       color: '#2196f3',
//       gradient: 'linear-gradient(135deg, #2196f3 0%, #64b5f6 100%)',
//       roles: ['Admin'] // Only show for Admin
//     },
//     {
//       label: 'User Access',
//       icon: <AssessmentIcon />,
//       path: '/useraccess',
//       color: '#ff9800',
//       gradient: 'linear-gradient(135deg, #ff9800 0%, #ffb74d 100%)',
//       roles: ['Admin'] // Only show for Admin
//     },
//     {
//       label: 'Summary',
//       icon: <SettingsIcon />,
//       path: '/summary',
//       color: '#4caf50',
//       gradient: 'linear-gradient(135deg, #4caf50 0%, #81c784 100%)',
//       roles: ['Admin'] // Only show for Admin
//     },
//     {
//       label: 'UserDashboard',
//       icon: <PersonIcon />,
//       path: '/UserDashboard',
//       color: '#9c27b0',
//       gradient: 'linear-gradient(135deg, #9c27b0 0%, #ba68c8 100%)',
//       roles: ['User'] // Only show for User
//     }
//   ];

//   // Filter navigation items based on user role
//   const navItems = allNavItems.filter(item =>
//     item.roles.includes(userRole) ||
//     (userRole === 'Admin' && item.label !== 'UserDashboard') ||
//     (userRole === 'User' && item.label === 'UserDashboard')
//   );

//   const isActive = (path) => location.pathname === path;
//   const handleNavigation = (path) => navigate(path);

//   // Extra-compact widths
//   const sidebarWidth = collapsed ? 52 : 200;

//   return (
//     <Box
//       sx={{
//         position: 'fixed',
//         left: 0,
//         top: HEADER_HEIGHT + HEADER_GAP,
//         height: `calc(100vh - ${HEADER_HEIGHT + HEADER_GAP}px)`,
//         width: sidebarWidth,
//         background: 'linear-gradient(180deg, #f8fbff 0%, #ffffff 100%)',
//         borderRight: '1px solid rgba(0, 0, 0, 0.08)',
//         boxShadow: '3px 0 14px rgba(0, 0, 0, 0.06)',
//         transition: 'width 0.2s ease',
//         zIndex: 1200,
//         overflow: 'hidden',
//         display: 'flex',
//         flexDirection: 'column'
//       }}
//     >
//       {/* Sidebar header */}
//       <Box
//         sx={{
//           p: collapsed ? 0.75 : 1,
//           borderBottom: '1px solid rgba(224, 231, 255, 0.6)',
//           minHeight: 46,
//           display: 'flex',
//           alignItems: 'center',
//           justifyContent: collapsed ? 'center' : 'space-between'
//         }}
//       >
//         {!collapsed && (
//           <Box>
//             <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#134380' }}>
//               Navigation
//             </Typography>
//             <Typography variant="caption" sx={{ fontSize: '0.7rem', color: '#666' }}>
//               {userRole === 'Admin' ? 'Admin Panel' : 'User Panel'}
//             </Typography>
//           </Box>
//         )}
//         <Box
//           onClick={() => setCollapsed(!collapsed)}
//           sx={{
//             width: 28,
//             height: 28,
//             borderRadius: '8px',
//             background: '#1976d2',
//             display: 'flex',
//             alignItems: 'center',
//             justifyContent: 'center',
//             cursor: 'pointer',
//             '&:hover': {
//               background: '#1565c0'
//             }
//           }}
//         >
//           {collapsed
//             ? <MenuIcon sx={{ color: '#fff', fontSize: 17 }} />
//             : <CloseIcon sx={{ color: '#fff', fontSize: 17 }} />}
//         </Box>
//       </Box>

//       {/* Nav list */}
//       <List sx={{ p: 0.5, flex: 1 }}>
//         {navItems.length > 0 ? (
//           navItems.map((item) => (
//             <Tooltip
//               key={item.label}
//               title={collapsed ? item.label : ''}
//               placement="right"
//               arrow
//               TransitionComponent={Zoom}
//             >
//               <ListItem disablePadding sx={{ mb: 0.4 }}>
//                 <ListItemButton
//                   onClick={() => handleNavigation(item.path)}
//                   sx={{
//                     minHeight: 40,
//                     px: 0.75,
//                     borderRadius: 1.5,
//                     background: isActive(item.path) ? `${item.color}12` : 'transparent',
//                     border: isActive(item.path) ? `1px solid ${item.color}33` : '1px solid transparent',
//                     transition: 'all 0.2s ease',
//                     '&:hover': {
//                       background: isActive(item.path)
//                         ? `${item.color}20`
//                         : 'rgba(0, 0, 0, 0.04)'
//                     }
//                   }}
//                 >
//                   <ListItemIcon
//                     sx={{
//                       minWidth: collapsed ? 'auto' : 32,
//                       mr: collapsed ? 0 : 0.75
//                     }}
//                   >
//                     <Box
//                       sx={{
//                         width: 26,
//                         height: 26,
//                         borderRadius: 1,
//                         background: isActive(item.path) ? item.gradient : '#f2f5f9',
//                         display: 'flex',
//                         alignItems: 'center',
//                         justifyContent: 'center',
//                         '& svg': {
//                           fontSize: '1rem',
//                           color: isActive(item.path) ? '#fff' : item.color
//                         }
//                       }}
//                     >
//                       {item.icon}
//                     </Box>
//                   </ListItemIcon>
//                   {!collapsed && (
//                     <ListItemText
//                       primary={item.label}
//                       primaryTypographyProps={{
//                         fontSize: '0.84rem',
//                         fontWeight: isActive(item.path) ? 700 : 500,
//                         color: isActive(item.path) ? item.color : '#333'
//                       }}
//                     />
//                   )}
//                 </ListItemButton>
//               </ListItem>
//             </Tooltip>
//           ))
//         ) : (
//           <ListItem>
//             <ListItemText
//               primary="No navigation items available"
//               primaryTypographyProps={{ fontSize: '0.8rem', color: '#666' }}
//             />
//           </ListItem>
//         )}
//       </List>

//       {/* Footer */}
//       <Box sx={{ px: 1, pb: 1 }}>
//         {!collapsed && (
//           <>
//             <Divider sx={{ my: 0.75 }} />
//             <Typography variant="caption" sx={{ color: '#666', fontSize: '0.7rem' }}>
//               © 2025 Nokia Corporation
//             </Typography>
//             <Typography variant="caption" sx={{ color: '#999', fontSize: '0.65rem', display: 'block', mt: 0.5 }}>
//               Role: {userRole}
//             </Typography>
//           </>
//         )}
//       </Box>
//     </Box>
//   );
// };

// export default Sidebar;
