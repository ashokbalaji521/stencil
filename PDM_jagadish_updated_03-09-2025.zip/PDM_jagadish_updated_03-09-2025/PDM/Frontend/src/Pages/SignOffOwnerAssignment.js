import React, { useState, useEffect } from "react";
import {
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Autocomplete,
  TextField,
  Checkbox,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
   Box,
  Paper,
} from "@mui/material";
import { Email as EmailIcon } from "@mui/icons-material";
import axios from "axios";
import { Data } from "../custom";

const SignOffOwnerAssignment = ({
  teams,
  packageId,
  setError,
  showSuccessMessage,
  signOffRequests,
  setSignOffRequests,
}) => {
  const [selectedSignOffTeam, setSelectedSignOffTeam] = useState("");
  const [selectedSignOffOwners, setSelectedSignOffOwners] = useState([]);
  const [availableSignOffOwners, setAvailableSignOffOwners] = useState([]);

  const fetchSignOffOwners = async (team) => {
    try {
      const response = await axios.post(`${Data.url}/AssignUser`, { team });
      setAvailableSignOffOwners(response.data.users || []);
    } catch (err) {
      console.error("Error fetching sign-off owners:", err);
      setError("Failed to fetch sign-off owners");
    }
  };

  useEffect(() => {
    if (selectedSignOffTeam) {
      fetchSignOffOwners(selectedSignOffTeam);
    } else {
      setAvailableSignOffOwners([]);
      setSelectedSignOffOwners([]);
    }
  }, [selectedSignOffTeam]);

  const handleSignOffOwnerAssignment = async () => {
    if (selectedSignOffTeam && selectedSignOffOwners.length > 0) {
      try {
        const usernameString = selectedSignOffOwners.map((owner) => owner.Username).join(",");
        const response = await axios.post(`${Data.url}/SignOffUsersFromSTICN`, {
          username: usernameString,
          cp_id: packageId,
        });

        const newRequests = response.data.users.map((user) => ({
          copId: packageId,
          team: user.Team,
          email: user.Email,
          comment: "",
          signOffStatus: "Pending",
          id: user.ID,
        }));

        setSignOffRequests([...signOffRequests, ...newRequests]);
        setSelectedSignOffTeam("");
        setSelectedSignOffOwners([]);
        setAvailableSignOffOwners([]);
        setError("");
        showSuccessMessage("Sign-off owners assigned successfully!");
      } catch (err) {
        console.error("Error assigning sign-off owners:", err);
        setError("Failed to assign sign-off owners");
      }
    }
  };

  const handleDeleteSignOffRequest = async (index, requestId) => {
    try {
      await axios.delete(`${Data.url}/signoff-requests/${requestId}`);
      setSignOffRequests(signOffRequests.filter((_, i) => i !== index));
      showSuccessMessage("Sign-off request deleted successfully!");
    } catch (err) {
      console.error("Error deleting sign-off request:", err);
      setError("Failed to delete sign-off request");
    }
  };

  const handleSendSignOffEmailNotification = async () => {
    try {
      await axios.post(`${Data.url}/SendSignOffEmailsAndUpdateStatus`, {
        packageId: packageId,
      });
      setError("");
      showSuccessMessage("Sign-off email notifications sent successfully!");
    } catch (err) {
      console.error("Error sending sign-off email notification:", err);
      setError("Failed to send sign-off email notification");
    }
  };

  return (
    <div>
      <Typography variant="h6" sx={{ mb: 3 }}>
        Assign Sign off Owner*
      </Typography>
      <Box sx={{ mb: 4 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth size="small">
              <InputLabel>Select Team</InputLabel>
              <Select
                value={selectedSignOffTeam}
                onChange={(e) => setSelectedSignOffTeam(e.target.value)}
                label="Select Team"
              >
                {teams.map((team) => (
                  <MenuItem key={team} value={team}>
                    {team}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <Autocomplete
              multiple
              options={availableSignOffOwners}
              getOptionLabel={(option) => option.Username}
              value={selectedSignOffOwners}
              onChange={(event, newValue) => setSelectedSignOffOwners(newValue)}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Sign-off Owners"
                  placeholder="Select multiple owners"
                  size="small"
                />
              )}
              renderOption={(props, option, { selected }) => (
                <li {...props}>
                  <Checkbox checked={selected} style={{ marginRight: 8 }} />
                  {option.Username} ({option.Email})
                </li>
              )}
              disabled={!selectedSignOffTeam}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <Button
              variant="contained"
              onClick={handleSignOffOwnerAssignment}
              disabled={selectedSignOffOwners.length === 0}
              fullWidth
              size="small"
              sx={{
                backgroundColor: '#1976d2',
                '&:hover': { backgroundColor: '#115293' },
                textTransform: 'none',
              }}
            >
              Assign Sign-off Owners
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Button
              variant="contained"
              onClick={handleSendSignOffEmailNotification}
              startIcon={<EmailIcon />}
              fullWidth
              size="small"
              sx={{
                backgroundColor: '#2e7d32',
                '&:hover': { backgroundColor: '#1b5e20' },
                textTransform: 'none',
              }}
            >
              Send Email Notifications
            </Button>
          </Grid>
        </Grid>
      </Box>

      <Typography variant="h6" sx={{ mb: 2 }}>
        Sign Off Requested Owner Details
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>COP ID</TableCell>
              <TableCell>Team</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Comment</TableCell>
              <TableCell>Sign off Status</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {signOffRequests.map((request, index) => (
              <TableRow key={index}>
                <TableCell>{request.copId}</TableCell>
                <TableCell>{request.team}</TableCell>
                <TableCell>{request.email}</TableCell>
                <TableCell>{request.comment}</TableCell>
                <TableCell>{request.signOffStatus}</TableCell>
                <TableCell>
                  <Button
                    variant="contained"
                    color="error"
                    size="small"
                    onClick={() => handleDeleteSignOffRequest(index, request.id)}
                    sx={{ textTransform: 'none' }}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default SignOffOwnerAssignment;