import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import * as XLSX from "xlsx";
import {
  Dialog, DialogTitle, DialogContent, DialogActions, MenuItem, Select, FormControl, InputLabel,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  Box, Container, TextField, Button, Typography, CircularProgress, Alert, Snackbar,
  Card, CardContent, Chip, Tooltip, IconButton, useTheme, Fade, Zoom, Slide
} from "@mui/material";
import { Delete as DeleteIcon, Assessment, TrendingUp, Lock as LockIcon } from "@mui/icons-material";
import { styled, alpha, keyframes } from "@mui/material/styles";

// Import Data first
import { Data } from "../custom";

// Ultra-compact table controls
const TABLE_FONT = 10;
const ROW_HEIGHT = 36;
const HEADER_FONT = 10;

// Enhanced Animations
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0%, 100% { transform: scale(1); opacity: 0.9; }
  50% { transform: scale(1.05); opacity: 1; }
`;

const slideInLeft = keyframes`
  from { transform: translateX(-20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 5px rgba(33, 150, 243, 0.5); }
  50% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.8), 0 0 30px rgba(33, 150, 243, 0.6); }
`;

const redGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #f44336, 0 0 10px #f44336, 0 0 15px #f44336;
    background: radial-gradient(circle, #ff6b6b, #f44336);
  }
  50% { 
    box-shadow: 0 0 10px #f44336, 0 0 20px #f44336, 0 0 30px #f44336;
    background: radial-gradient(circle, #ff8a80, #ff5722);
  }
`;

const yellowGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #ff9800, 0 0 10px #ff9800, 0 0 15px #ff9800;
    background: radial-gradient(circle, #ffb74d, #ff9800);
  }
  50% { 
    box-shadow: 0 0 10px #ff9800, 0 0 20px #ff9800, 0 0 30px #ff9800;
    background: radial-gradient(circle, #ffc947, #f57c00);
  }
`;

const greenGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #4caf50, 0 0 10px #4caf50, 0 0 15px #4caf50;
    background: radial-gradient(circle, #81c784, #4caf50);
  }
  50% { 
    box-shadow: 0 0 10px #4caf50, 0 0 20px #4caf50, 0 0 30px #4caf50;
    background: radial-gradient(circle, #a5d6a7, #2e7d32);
  }
`;

const silverGlow = keyframes`
  0%, 100% { 
    box-shadow: 0 0 5px #C0C0C0, 0 0 10px #C0C0C0, 0 0 15px #C0C0C0;
    background: radial-gradient(circle, #D3D3D3, #C0C0C0);
  }
  50% { 
    box-shadow: 0 0 10px #C0C0C0, 0 0 20px #C0C0C0, 0 0 30px #C0C0C0;
    background: radial-gradient(circle, #E5E5E5, #A9A9A9);
  }
`;

// Fallback components
const FallbackHeader = ({ username }) => (
  <Box sx={{ height: '64px', backgroundColor: '#1976d2', color: 'white', display: 'flex', alignItems: 'center', px: 2 }}>
    <Typography variant="h6">PDM Dashboard - {username}</Typography>
  </Box>
);

const FallbackFooter = () => (
  <Box sx={{ height: '40px', backgroundColor: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="caption">© 2025 PDM System</Typography>
  </Box>
);

const FallbackAddSTIECN = ({ open, onClose, onSuccess }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
    <DialogTitle>Add STI/ECN (Fallback)</DialogTitle>
    <DialogContent>
      <Typography>This is a fallback component. The original AddSTIECN component failed to load.</Typography>
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Close</Button>
    </DialogActions>
  </Dialog>
);

// Import components with fallbacks
let Header, Footer, AddSTIECN;

try {
  const HeaderModule = require("../Pages/Header");
  Header = HeaderModule.default || HeaderModule.Header || FallbackHeader;
} catch (e) {
  console.error("Failed to import Header:", e);
  Header = FallbackHeader;
}

try {
  const FooterModule = require("../Pages/Footer");
  Footer = FooterModule.default || FooterModule.Footer || FallbackFooter;
} catch (e) {
  console.error("Failed to import Footer:", e);
  Footer = FallbackFooter;
}

try {
  const AddSTIECNModule = require("./AddSTIECN");
  AddSTIECN = AddSTIECNModule.default || AddSTIECNModule.AddSTIECN || FallbackAddSTIECN;
} catch (e) {
  console.error("Failed to import AddSTIECN:", e);
  AddSTIECN = FallbackAddSTIECN;
}

// Styled Components
const ShellCard = styled(Card)(({ theme }) => ({
  borderRadius: 12,
  background: '#ffffff',
  boxShadow: '0 4px 20px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.1)',
  border: `1px solid ${alpha(theme.palette.divider, 0.12)}`,
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  position: 'relative',
  overflow: 'hidden',
  animation: `${fadeIn} 0.6s ease-out`,
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 8px 25px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.08)',
  },
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '3px',
    background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
  }
}));

const InstructionCard = styled(ShellCard)(({ theme }) => ({
  animation: `${fadeIn} 0.6s ease-out`,
  background: '#ffffff',
  border: `2px solid ${alpha(theme.palette.info.main, 0.2)}`,
  transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
  '&:hover': {
    transform: 'translateY(-3px) scale(1.02)',
    boxShadow: `0 12px 24px ${alpha(theme.palette.info.main, 0.15)}`,
    '&::before': {
      background: `linear-gradient(90deg, ${theme.palette.info.main}, ${theme.palette.info.dark})`,
      height: '4px',
    }
  }
}));

const MainWrapper = styled(Box)(() => ({
  display: 'flex',
  flexDirection: 'column',
  minHeight: '100vh',
  marginLeft: 0,
  width: '100%',
  paddingTop: "70px",
  backgroundColor: "#f8fafc",
}));

const ContentContainer = styled(Container)(() => ({
  flex: 1,
  padding: "10px 20px 20px !important",
  maxWidth: "100% !important",
  display: 'flex',
  flexDirection: 'column',
  gap: '20px',
}));

const TightTableContainer = styled(TableContainer)(({ theme }) => ({
  borderRadius: 8,
  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  overflow: 'hidden',
  background: '#ffffff',
  boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
  '&:hover': {
    boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
  }
}));

const FixedTable = styled(Table)({
  tableLayout: 'fixed',
  width: '100%'
});

const TightHead = styled(TableHead)(({ theme }) => ({
  '& .MuiTableCell-head': {
    background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
    color: theme.palette.primary.contrastText,
    fontWeight: 800,
    fontSize: `${HEADER_FONT}px`,
    padding: '8px 4px',
    lineHeight: 1.05,
    whiteSpace: 'pre-line',
    textAlign: 'center',
    position: 'relative',
    textShadow: '0 1px 2px rgba(0,0,0,0.1)',
    '&::after': {
      content: '""',
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      height: '2px',
      background: `linear-gradient(90deg, transparent, ${alpha('#fff', 0.3)}, transparent)`,
    }
  }
}));

const HeadCell = styled(TableCell)({
  fontSize: `${HEADER_FONT}px`,
  padding: '8px 4px',
  lineHeight: 1.05,
  whiteSpace: 'pre-line',
  textAlign: 'center',
  overflow: 'hidden',
  textOverflow: 'ellipsis'
});

const BodyCell = styled(TableCell)(({ theme }) => ({
  fontSize: `${TABLE_FONT}px`,
  padding: '8px 4px',
  height: ROW_HEIGHT,
  textAlign: 'center',
  verticalAlign: 'middle',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  transition: 'all 0.2s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.04),
  }
}));

const StyledButton = styled(Button)(({ theme, variant }) => ({
  textTransform: "none",
  fontSize: "0.8rem",
  fontWeight: 600,
  padding: "8px 16px",
  borderRadius: 8,
  minHeight: "36px",
  boxShadow: variant === 'contained' ? "0 2px 8px rgba(25, 118, 210, 0.3)" : "none",
  transition: "all 0.2s ease",
  "&:hover": {
    transform: "translateY(-1px)",
    boxShadow: variant === 'contained'
      ? "0 4px 12px rgba(25, 118, 210, 0.4)"
      : "0 2px 8px rgba(0,0,0,0.1)",
  },
}));

const StyledTextField = styled(TextField)(({ theme }) => ({
  "& .MuiOutlinedInput-root": {
    borderRadius: 10,
    backgroundColor: "#ffffff",
    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
    transition: 'all 0.3s ease',
    "& fieldset": {
      border: "1px solid rgba(0,0,0,0.08)",
    },
    "&:hover": {
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
      "& fieldset": {
        border: "1px solid #1976d2",
      }
    },
    "&.Mui-focused": {
      animation: `${glow} 2s infinite`,
      transform: 'translateY(-1px)',
      "& fieldset": {
        border: "2px solid #1976d2",
      }
    },
  },
}));

const GlowingBulb = styled(Box)(({ status, disabled }) => {
  let animation = '';
  if (status === '0' || status === 0) {
    animation = redGlow;
  } else if (status === '1' || status === 1) {
    animation = greenGlow;
  } else if (status === '2' || status === 2) {
    animation = yellowGlow;
  } else {
    animation = silverGlow;
  }

  return {
    width: 16,
    height: 16,
    borderRadius: '50%',
    animation: `${animation} 2s ease-in-out infinite`,
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.3s ease',
    display: 'inline-block',
    position: 'relative',
    '&:hover': {
      transform: disabled ? 'none' : 'scale(1.2)',
    },
    '&::after': disabled ? {
      content: '"🔒"',
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      fontSize: '8px',
      color: '#333',
      fontWeight: 'bold',
      textShadow: '0 0 2px #fff',
      zIndex: 2,
    } : {}
  };
});

const StatusRow = styled(TableRow)(({ theme }) => ({
  animation: `${slideInLeft} 0.5s ease-out`,
  transition: 'all 0.3s ease',
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.02),
    transform: 'translateX(4px)',
    boxShadow: `inset 4px 0 0 ${theme.palette.primary.main}`,
  }
}));

const clickableCellStyle = (isEnabled) => ({
  cursor: isEnabled ? 'pointer' : 'not-allowed',
  padding: '8px',
  textAlign: 'center',
  transition: 'all 0.3s ease',
  '&:hover': isEnabled ? {
    transform: 'scale(1.05)',
    boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
  } : {}
});

const LoadingOverlay = styled(Box)({
  position: 'fixed',
  inset: 0,
  background: 'linear-gradient(135deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.5) 100%)',
  backdropFilter: 'blur(8px)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 9999,
});

const LoadingCard = styled(ShellCard)(({ theme }) => ({
  padding: theme.spacing(3),
  textAlign: 'center',
  minWidth: 240,
  background: '#ffffff',
  animation: `${pulse} 2s infinite`,
}));

const UserDashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [username, setUsername] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [excelData, setExcelData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPhase, setCurrentPhase] = useState("preimp");
  const [updateLoading, setUpdateLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });
  const [summaryData, setSummaryData] = useState([]);
  const [detailData, setDetailData] = useState([]);
  const [openPopup, setOpenPopup] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCpId, setSelectedCpId] = useState(null);
  const [statusDialog, setStatusDialog] = useState({ open: false, cpId: null, fieldKey: null, currentStatus: null, newStatus: "" });
  const [teamAssignmentsCount, setTeamAssignmentsCount] = useState(0);
  const [yourAssignmentsCount, setYourAssignmentsCount] = useState(0);

  const navigate = useNavigate();
  const theme = useTheme();

  useEffect(() => {
    const storedUsername = sessionStorage.getItem('username') || localStorage.getItem('username') || 'User';
    setUsername(storedUsername);
    const storedEmail = sessionStorage.getItem('email') || '';
    
    if (storedEmail) {
      fetchAssignments(storedEmail);
    } else {
      setSnackbar({ open: true, message: "No email found in session storage", severity: "warning" });
    }

    fetchStatusData(currentPhase);
    sessionStorage.removeItem('currentCpId');
  }, [searchTerm, currentPhase]);

  const fetchAssignments = async (email) => {
    try {
      setLoading(true);
      const response = await axios.post(`${Data.url}/getuserteammemberswithmail`, { email });
      setTeamAssignmentsCount(response.data.teamAssignments.count);
      setYourAssignmentsCount(response.data.YourAssignments.count);
    } catch (err) {
      setError(`Failed to fetch assignments: ${err.message || 'An error occurred'}`);
    } finally {
      setLoading(false);
    }
  };

  const fieldMapping = {
    pdm: "PDM", mmBuyer: "MM_Buyer", mmLogistics: "MM_logistics", sqa: "SQA", wh: "WH",
    mc: "MC", smt: "SMT", msSmt: "MS_SMT", msJe: "MS_IE", msTest: "MS_TEST",
    msPt: "MS_PT", msPe: "MS_PE", msIt: "MS_IT", ops: "OPS",
  };

  const teamToFieldMapping = {
    "PDM": "pdm",
    "MM_Buyer": "mmBuyer",
    "MM_logistics": "mmLogistics",
    "SQA": "sqa",
    "WH": "wh",
    "MC": "mc",
    "SMT": "smt",
    "MS_SMT": "msSmt",
    "MS_IE": "msJe",
    "MS_TEST": "msTest",
    "MS_PT": "msPt",
    "MS_PE": "msPe",
    "MS_IT": "msIt",
    "OPS": "ops",
  };

  const getEnabledFieldKey = () => {
    const teamName = sessionStorage.getItem("team");
    if (!teamName || teamName === "Default Team") {
      return null;
    }
    return teamToFieldMapping[teamName] || null;
  };

  const isFieldEnabled = (fieldKey) => {
    const enabledField = getEnabledFieldKey();
    return enabledField === fieldKey;
  };

  const getUpdateEndpoint = (phase) => ({
    preimp: 'updatestatuspreimp', TrailStatus: 'updatestatustrailstatus', postimp: 'updatestatuspostimp'
  }[phase] || 'updatestatuspreimp');

  const getPhaseTitle = (phase) => ({
    preimp: 'Preparation Phase (Pre-Implementation) Action Status',
    postimp: 'Post Implementation Action Status'
  }[phase] || 'Action Status');

  const getStatusText = (status) => ({ 0: 'Open', 1: 'Closed', 2: 'In Progress' }[status] || 'NA');

  const getStatusBulb = (status, fieldKey) => {
    const isEnabled = isFieldEnabled(fieldKey);
    return <GlowingBulb status={status} disabled={!isEnabled} />;
  };

  const handleStatusClick = (cpId, fieldKey, currentStatus) => {
    if (!isFieldEnabled(fieldKey)) {
      const teamName = sessionStorage.getItem("team") || "your team";
      setSnackbar({
        open: true,
        message: `🔒 Access Denied: You can only update ${teamName} status`,
        severity: "error"
      });
      return;
    }

    setStatusDialog({ open: true, cpId, fieldKey, currentStatus, newStatus: currentStatus?.toString() || "0" });
  };

  const handleStatusUpdate = async () => {
    try {
      setUpdateLoading(true);
      if (!["0", "1", "2"].includes(statusDialog.newStatus)) throw new Error("Invalid status value");

      const updateData = {
        field: fieldMapping[statusDialog.fieldKey], Status: statusDialog.newStatus, CP_ID: statusDialog.cpId,
      };

      const { status } = await axios.post(`${Data.url}/${getUpdateEndpoint(currentPhase)}`, updateData);
      if (status === 200) {
        setSnackbar({ open: true, message: `✨ Status updated successfully for ${fieldMapping[statusDialog.fieldKey]}`, severity: "success" });
        setTimeout(() => fetchStatusData(currentPhase), 500);
      }
    } catch (error) {
      setSnackbar({ open: true, message: `❌ Failed to update status: ${error.response?.data?.message || error.message}`, severity: "error" });
    } finally {
      setStatusDialog({ ...statusDialog, open: false });
      setUpdateLoading(false);
    }
  };

  const fetchStatusData = async (endpoint) => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await axios.post(`${Data.url}/${endpoint}`, { search: searchTerm.trim() });
      processApiData(data);
      setCurrentPhase(endpoint);
    } catch (err) {
      setError(`Failed to fetch data: ${err.message || 'An error occurred'}`);
    } finally {
      setLoading(false);
    }
  };

  const processApiData = (response) => {
    if (response?.data && response?.statusCount) {
      const data = response.data;
      const statusCount = response.statusCount;

      const processedData = data.map(item => ({
        category: item.Category || 'N/A', packageId: item.CP_ID || 'N/A', ecnStiNumber: item.ECN_STI_Number || 'N/A',
        productFamily: item.Product_Family || 'N/A', productName: item.Product_Name || 'N/A',
        pdm: item.PDM ?? 'NA', mmBuyer: item.MM_Buyer ?? 'NA', mmLogistics: item.MM_logistics ?? 'NA',
        sqa: item.SQA ?? 'NA', wh: item.WH ?? 'NA', mc: item.MC ?? 'NA', smt: item.SMT ?? 'NA',
        msSmt: item.MS_SMT ?? 'NA', msJe: item.MS_IE ?? 'NA', msTest: item.MS_TEST ?? 'NA',
        msPt: item.MS_PT ?? 'NA',
        msPe: item.MS_PE ?? 'NA', msIt: item.MS_IT ?? 'NA', ops: item.OPS ?? 'NA',
      }));
      setDetailData(processedData);

      const summaryRows = [
        {
          team: "Open",
          pdm: statusCount.open.PDM || 0, mmBuyer: statusCount.open.MM_Buyer || 0, mmLogistics: statusCount.open.MM_logistics || 0,
          sqa: statusCount.open.SQA || 0, wh: statusCount.open.WH || 0, mc: statusCount.open.MC || 0, smt: statusCount.open.SMT || 0,
          msSmt: statusCount.open.MS_SMT || 0, msJe: statusCount.open.MS_IE || 0, msTest: statusCount.open.MS_TEST || 0,
          msPt: statusCount.open.MS_PT || 0, msPe: statusCount.open.MS_PE || 0, msIt: statusCount.open.MS_IT || 0, ops: statusCount.open.OPS || 0,
        },
        {
          team: "In Progress",
          pdm: statusCount.inprogress.PDM || 0, mmBuyer: statusCount.inprogress.MM_Buyer || 0, mmLogistics: statusCount.inprogress.MM_logistics || 0,
          sqa: statusCount.inprogress.SQA || 0, wh: statusCount.inprogress.WH || 0, mc: statusCount.inprogress.MC || 0, smt: statusCount.inprogress.SMT || 0,
          msSmt: statusCount.inprogress.MS_SMT || 0, msJe: statusCount.inprogress.MS_IE || 0, msTest: statusCount.inprogress.MS_TEST || 0,
          msPt: statusCount.inprogress.MS_PT || 0, msPe: statusCount.inprogress.MS_PE || 0, msIt: statusCount.inprogress.MS_IT || 0, ops: statusCount.inprogress.OPS || 0,
        },
      ];
      setSummaryData(summaryRows);
    } else {
      setDetailData([]);
      setSummaryData([]);
      setError("Invalid API response format or no data.");
    }
  };

  const handlePackageIdClick = (cpId) => {
    sessionStorage.setItem('currentCpId', cpId);
    navigate(`/UpdatePackageOwner1/${cpId}`);
  };

  const handleConfirmDelete = async () => {
    try {
      setUpdateLoading(true);
      const { status } = await axios.delete(`${Data.url}/deletePackage/${selectedCpId}`);
      if (status === 200) {
        setSnackbar({ open: true, message: `🗑️ Package ${selectedCpId} deleted successfully.`, severity: 'success' });
        fetchStatusData(currentPhase);
      }
    } catch (err) {
      setSnackbar({ open: true, message: `❌ Failed to delete ${selectedCpId}: ${err.response?.data?.error || err.message}`, severity: 'error' });
    } finally {
      setUpdateLoading(false);
      setDeleteDialogOpen(false);
      setSelectedCpId(null);
    }
  };

  const filteredDetailData = detailData.filter(item =>
    item.packageId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.ecnStiNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const statusFields = ['pdm', 'mmBuyer', 'mmLogistics', 'sqa', 'wh', 'mc', 'smt', 'msSmt', 'msJe', 'msTest', 'msPt', 'msPe', 'msIt', 'ops'];
  const headers = ['Category', 'Package\nID', 'ECN/STI\nNumber', 'Product\nFamily', 'Product\nName', 'PDM', 'MM\nBuyer', 'MM\nLogistics', 'SQA', 'WH', 'MC', 'SMT', 'MS\nSMT', 'MS\nIE', 'MS\nTEST', 'MS\nPT', 'MS\nPE', 'MS\nIT', 'OPS', 'Action'];

  return (
    <>
      <Header username={username} />

      <MainWrapper>
        {(updateLoading || loading) && (
          <Fade in={updateLoading || loading}>
            <LoadingOverlay>
              <Zoom in={updateLoading || loading}>
                <LoadingCard>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                    <CircularProgress size={32} sx={{ mr: 2 }} />
                    <Assessment style={{ fontSize: 24, color: theme.palette.primary.main }} />
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 700, color: 'primary.main' }}>Processing...</Typography>
                  <Typography variant="body2" sx={{ color: 'text.secondary', mt: 1 }}>
                    Please wait while we update your data
                  </Typography>
                </LoadingCard>
              </Zoom>
            </LoadingOverlay>
          </Fade>
        )}

        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          TransitionComponent={Slide}
        >
          <Alert
            onClose={() => setSnackbar({ ...snackbar, open: false })}
            severity={snackbar.severity}
            sx={{
              width: '100%',
              borderRadius: 2,
              fontWeight: 600,
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>

        <ContentContainer>
          {error && (
            <Slide direction="down" in={!!error}>
              <Alert
                severity="error"
                sx={{
                  borderRadius: 2,
                  boxShadow: "0 2px 8px rgba(244, 67, 54, 0.1)",
                  border: '1px solid #f44336',
                }}
              >
                <strong>❌ Error:</strong> {error}
              </Alert>
            </Slide>
          )}

          <Fade in timeout={800}>
            <ShellCard>
              <CardContent sx={{ p: 2 }}>
                <Box sx={{ display: "flex", gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
                  <StyledButton
                    variant="contained"
                    onClick={() => fetchStatusData('preimp')}
                    disabled={loading}
                    startIcon={loading && currentPhase === 'preimp' ? <CircularProgress size={20} /> : <TrendingUp />}
                    sx={{
                      background: currentPhase === 'preimp'
                        ? 'linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)'
                        : 'linear-gradient(135deg, #42a5f5 0%, #1e88e5 100%)',
                      color: '#fff',
                      boxShadow: currentPhase === 'preimp' ? '0 4px 12px rgba(25, 118, 210, 0.4)' : '0 2px 8px rgba(66, 165, 245, 0.3)',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 16px rgba(25, 118, 210, 0.5)',
                      }
                    }}
                  >
                    🔄 Pre-Implementation Status
                  </StyledButton>
                  <StyledButton
                    variant="contained"
                    onClick={() => fetchStatusData('postimp')}
                    disabled={loading}
                    startIcon={loading && currentPhase === 'postimp' ? <CircularProgress size={20} /> : <Assessment />}
                    sx={{
                      background: currentPhase === 'postimp'
                        ? 'linear-gradient(135deg, #f57c00 0%, #e65100 100%)'
                        : 'linear-gradient(135deg, #ffa726 0%, #ff9800 100%)',
                      color: '#fff',
                      boxShadow: currentPhase === 'postimp' ? '0 4px 12px rgba(245, 124, 0, 0.4)' : '0 2px 8px rgba(255, 167, 38, 0.3)',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 16px rgba(245, 124, 0, 0.5)',
                      }
                    }}
                  >
                    ⚡ Post Implementation Status
                  </StyledButton>
                  <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', marginLeft: 'auto' }}>
                    <Chip
                      label={`Your Assignments: ${yourAssignmentsCount}`}
                      color="primary"
                      size="small"
                      sx={{ fontWeight: 700 }}
                    />
                    <Chip
                      label={`Team Assignments: ${teamAssignmentsCount}`}
                      color="secondary"
                      size="small"
                      sx={{ fontWeight: 700 }}
                    />
                  </Box>
                </Box>

                <InstructionCard sx={{ mt: 2 }}>
                  <CardContent sx={{ p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Box sx={{
                        p: 1,
                        borderRadius: '50%',
                        background: `linear-gradient(135deg, ${theme.palette.info.main}, ${theme.palette.info.dark})`,
                        mr: 1.5,
                        animation: `${pulse} 2s infinite`,
                      }}>
                        <Assessment sx={{ fontSize: 16, color: '#fff' }} />
                      </Box>
                      <Typography variant="body2" sx={{ fontSize: '0.9rem', color: 'info.dark', fontWeight: 700 }}>
                        💡 <strong>Instructions:</strong> Click on glowing status bulbs to update • Click{' '}
                        <Box component="span" sx={{
                          px: 1,
                          py: 0.3,
                          borderRadius: 1,
                          background: 'linear-gradient(45deg, #1976d2, #42a5f5)',
                          color: '#fff',
                          fontWeight: 800,
                          display: 'inline-block',
                        }}>
                          Package ID
                        </Box>{' '}
                        for detailed view
                      </Typography>
                    </Box>
                  </CardContent>
                </InstructionCard>
              </CardContent>
            </ShellCard>
          </Fade>

          {!loading && summaryData.length > 0 && (
            <Fade in timeout={1000}>
              <ShellCard>
                <CardContent sx={{ p: 1.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <TrendingUp sx={{ mr: 1, color: 'primary.main' }} />
                    <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 800, fontSize: '1.2rem' }}>
                      {getPhaseTitle(currentPhase)} - Summary Overview
                    </Typography>
                  </Box>

                  <TightTableContainer component={Paper}>
                    <FixedTable size="small">
                      <TightHead>
                        <TableRow>
                          <HeadCell sx={{ width: '12%' }}>Status</HeadCell>
                          {['PDM', 'MM\nBuyer', 'MM\nLogistics', 'SQA', 'WH', 'MC', 'SMT', 'MS\nSMT', 'MS\nIE', 'MS\nTEST', 'MS\nPT', 'MS\nPE', 'MS\nIT', 'OPS'].map((label, idx) => (
                            <HeadCell key={idx} sx={{ width: '6%' }}>{label}</HeadCell>
                          ))}
                        </TableRow>
                      </TightHead>
                      <TableBody>
                        {summaryData.map((row, index) => (
                          <StatusRow key={index} style={{ animationDelay: `${index * 200}ms` }}>
                            <BodyCell sx={{ textAlign: 'center', fontWeight: 800, color: 'primary.main' }}>
                              {row.team}
                            </BodyCell>
                            {statusFields.map(field => (
                              <BodyCell key={field} sx={{ fontWeight: 600, color: row[field] > 0 ? 'primary.main' : 'text.secondary' }}>
                                {row[field]}
                              </BodyCell>
                            ))}
                          </StatusRow>
                        ))}
                      </TableBody>
                    </FixedTable>
                  </TightTableContainer>
                </CardContent>
              </ShellCard>
            </Fade>
          )}

          {!loading && detailData.length > 0 && (
            <Fade in timeout={1200}>
              <ShellCard>
                <CardContent sx={{ p: 1.5 }}>
                  <Box sx={{ mb: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Assessment sx={{ mr: 1, color: 'primary.main' }} />
                      <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 800, fontSize: '1.2rem' }}>
                        Actions Status Update
                      </Typography>
                    </Box>
                    <Chip
                      label={`${filteredDetailData.length} Records`}
                      color="primary"
                      size="small"
                      sx={{ fontWeight: 700 }}
                    />
                  </Box>

                  <Box sx={{
                    mb: 2,
                    p: 1.5,
                    backgroundColor: alpha(theme.palette.primary.main, 0.02),
                    border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
                    borderRadius: 2,
                  }}>
                    <Typography variant="body2" sx={{
                      fontSize: '0.85rem',
                      fontWeight: 700,
                      color: 'primary.main',
                      mb: 1
                    }}>
                      📊 Status Indicators:
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', alignItems: 'center' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{
                          width: 16,
                          height: 16,
                          borderRadius: '50%',
                          animation: `${redGlow} 2s infinite`,
                          border: '2px solid #f44336',
                        }} />
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                          Open
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{
                          width: 16,
                          height: 16,
                          borderRadius: '50%',
                          animation: `${greenGlow} 2s infinite`,
                          border: '2px solid #4caf50',
                        }} />
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                          Closed
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{
                          width: 16,
                          height: 16,
                          borderRadius: '50%',
                          animation: `${yellowGlow} 2s infinite`,
                          border: '2px solid #ff9800',
                        }} />
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                          In Progress
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{
                          width: 16,
                          height: 16,
                          borderRadius: '50%',
                          animation: `${silverGlow} 2s infinite`,
                          border: `2px solid ${alpha('#C0C0C0', 0.7)}`,
                          position: 'relative',
                          '&::after': {
                            content: '"🔒"',
                            position: 'absolute',
                            top: '50%',
                            left: '50%',
                            transform: 'translate(-50%, -50%)',
                            fontSize: '8px',
                            color: '#333',
                            fontWeight: 'bold',
                            textShadow: '0 0 2px #fff',
                          }
                        }} />
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                          🔒 Locked/NA
                        </Typography>
                      </Box>
                    </Box>
                  </Box>

                  <StyledTextField
                    placeholder="🔍 Search by Package ID, Product Name, or ECN/STI Number..."
                    variant="outlined"
                    size="small"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    fullWidth
                    sx={{ mb: 2 }}
                  />

                  <TightTableContainer component={Paper}>
                    <FixedTable size="small">
                      <TightHead>
                        <TableRow>
                          {headers.map(header => (
                            <HeadCell key={header} sx={{ width: '5%' }}>{header}</HeadCell>
                          ))}
                        </TableRow>
                      </TightHead>
                      <TableBody>
                        {filteredDetailData.length > 0 ? (
                          filteredDetailData.map((row, index) => (
                            <StatusRow key={index} style={{ animationDelay: `${index * 100}ms` }}>
                              <BodyCell sx={{ fontWeight: 600, textAlign: 'center' }}>{row.category}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>
                                <Button
                                  onClick={() => handlePackageIdClick(row.packageId)}
                                  sx={{
                                    textTransform: 'none',
                                    fontWeight: 800,
                                    color: 'primary.main',
                                    fontSize: `${TABLE_FONT}px`,
                                    p: 0,
                                    minWidth: 0,
                                    transition: 'all 0.3s ease',
                                    '&:hover': {
                                      color: 'primary.dark',
                                      transform: 'scale(1.1)',
                                    }
                                  }}
                                >
                                  🔗 {row.packageId}
                                </Button>
                              </BodyCell>
                              <BodyCell sx={{ fontWeight: 600, textAlign: 'center' }}>{row.ecnStiNumber}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>{row.productFamily}</BodyCell>
                              <BodyCell sx={{ textAlign: 'center' }}>{row.productName}</BodyCell>

                              {statusFields.map((field) => {
                                const isEnabled = isFieldEnabled(field);
                                return (
                                  <BodyCell
                                    key={field}
                                    align="center"
                                    sx={clickableCellStyle(isEnabled)}
                                    onClick={isEnabled ? () => handleStatusClick(row.packageId, field, row[field]) : undefined}
                                  >
                                    <Box sx={{
                                      display: 'flex',
                                      justifyContent: 'center',
                                      alignItems: 'center',
                                      position: 'relative'
                                    }}>
                                      {getStatusBulb(row[field], field)}
                                      {!isEnabled && (
                                        <Tooltip title={`🔒 Access Denied: Only ${sessionStorage.getItem("team") || 'your team'} can update this field`}>
                                          <Box sx={{ position: 'absolute', inset: 0 }} />
                                        </Tooltip>
                                      )}
                                    </Box>
                                  </BodyCell>
                                );
                              })}

                              <BodyCell align="center">
                                <Tooltip title="Delete Package" placement="top">
                                  <IconButton
                                    size="small"
                                    color="error"
                                    onClick={() => { setSelectedCpId(row.packageId); setDeleteDialogOpen(true); }}
                                    sx={{
                                      p: '3px',
                                      borderRadius: 2,
                                      transition: 'all 0.3s ease',
                                      '&:hover': {
                                        transform: 'scale(1.2)',
                                        backgroundColor: alpha('#f44336', 0.1),
                                      }
                                    }}
                                  >
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                              </BodyCell>
                            </StatusRow>
                          ))
                        ) : (
                          <TableRow>
                            <BodyCell colSpan={20} sx={{ textAlign: "center", py: 4 }}>
                              <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: 'italic' }}>
                                📝 No data available for the current search/filter.
                              </Typography>
                            </BodyCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </FixedTable>
                  </TightTableContainer>
                </CardContent>
              </ShellCard>
            </Fade>
          )}
        </ContentContainer>

        <Footer />

        <AddSTIECN open={openPopup} onClose={() => setOpenPopup(false)} onSuccess={() => fetchStatusData(currentPhase)} />

        <Dialog
          open={statusDialog.open}
          onClose={() => setStatusDialog({ ...statusDialog, open: false })}
          fullWidth
          maxWidth="xs"
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
            }
          }}
          TransitionComponent={Zoom}
        >
          <DialogTitle sx={{
            pb: 1,
            fontSize: 17,
            fontWeight: 900,
            background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
            color: '#fff',
            textAlign: 'center',
          }}>
            ⚙️ Update Status
          </DialogTitle>
          <DialogContent sx={{ pt: 3, pb: 3, px: 3 }}>
            <FormControl fullWidth size="small" sx={{ mt: 2 }}>
              <InputLabel sx={{ fontWeight: 700, fontSize: 14, color: 'primary.main' }}>
                Select Status
              </InputLabel>
              <Select
                value={statusDialog.newStatus}
                onChange={(e) => setStatusDialog({ ...statusDialog, newStatus: e.target.value })}
                label="Select Status"
                sx={{
                  borderRadius: 2,
                  fontWeight: 700,
                  fontSize: 15,
                }}
              >
                <MenuItem value="0" sx={{ fontWeight: 700, fontSize: 14, py: 1.5 }}>
                  🔴 Open
                </MenuItem>
                <MenuItem value="1" sx={{ fontWeight: 700, fontSize: 14, py: 1.5 }}>
                  🟢 Closed
                </MenuItem>
                <MenuItem value="2" sx={{ fontWeight: 700, fontSize: 14, py: 1.5 }}>
                  🟡 In Progress
                </MenuItem>
              </Select>
            </FormControl>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1 }}>
            <Button
              onClick={() => setStatusDialog({ ...statusDialog, open: false })}
              color="inherit"
              size="small"
              sx={{ borderRadius: 2, fontWeight: 800, fontSize: 13 }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleStatusUpdate}
              disabled={updateLoading}
              variant="contained"
              size="small"
              sx={{
                borderRadius: 2,
                fontWeight: 700,
                background: 'linear-gradient(135deg, #1976d2, #0d47a1)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #0d47a1, #1976d2)',
                }
              }}
              startIcon={updateLoading ? <CircularProgress size={12} /> : null}
            >
              ✨ Update
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={deleteDialogOpen}
          onClose={() => setDeleteDialogOpen(false)}
          PaperProps={{
            sx: {
              borderRadius: 4,
              background: '#ffffff',
              border: '2px solid #f44336',
            }
          }}
          TransitionComponent={Zoom}
        >
          <DialogTitle sx={{
            fontSize: 16,
            background: 'linear-gradient(135deg, #f44336, #d32f2f)',
            color: '#fff',
            textAlign: 'center',
          }}>
            <Typography variant="inherit" fontWeight={800}>🗑️ Confirm Delete</Typography>
          </DialogTitle>
          <DialogContent sx={{ pt: 2 }}>
            <Typography sx={{ fontSize: 13, textAlign: 'center', fontWeight: 600 }}>
              Are you sure you want to delete package{' '}
              <Box component="span" sx={{
                color: 'error.main',
                fontWeight: 800,
                background: alpha('#f44336', 0.1),
                px: 1,
                py: 0.3,
                borderRadius: 1,
              }}>
                {selectedCpId}
              </Box>
              ? This action cannot be undone.
            </Typography>
          </DialogContent>
          <DialogActions sx={{ px: 2, pb: 2, gap: 1, justifyContent: 'center' }}>
            <Button
              onClick={() => setDeleteDialogOpen(false)}
              color="inherit"
              size="small"
              sx={{ borderRadius: 2 }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmDelete}
              color="error"
              variant="contained"
              size="small"
              sx={{
                borderRadius: 2,
                fontWeight: 700,
                background: 'linear-gradient(135deg, #f44336, #d32f2f)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #d32f2f, #b71c1c)',
                }
              }}
              startIcon={<DeleteIcon />}
            >
              🗑️ Delete
            </Button>
          </DialogActions>
        </Dialog>
      </MainWrapper>
    </>
  );
};

export default UserDashboard; 