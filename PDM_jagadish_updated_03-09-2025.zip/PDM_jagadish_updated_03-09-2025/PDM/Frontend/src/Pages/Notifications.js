import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Alert,
  IconButton,
  Badge,
  Tooltip,
  Divider,
  Button,
} from "@mui/material";
import {
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Pending as PendingIcon,
  Refresh as RefreshIcon,
  Email as EmailIcon,
  Person as PersonIcon,
} from "@mui/icons-material";
import axios from "axios";
import { Data } from "../custom";

const NotificationsPage = () => {
  const [assignData, setAssignData] = useState({
    ACKNOWLEDGED: [],
    NOTACKNOWLEDGED: [],
    signedOff_Approved: [],
    notSignedOff_not_Approved: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [username, setUsername] = useState("");

  // Fetch user info from sessionStorage on mount
  useEffect(() => {
    const storedEmail = sessionStorage.getItem("email");
    const storedUsername = sessionStorage.getItem("username");

    if (storedEmail && storedUsername) {
      setUserEmail(storedEmail);
      setUsername(storedUsername);
      fetchAssignStatus(storedEmail);
    } else {
      setError("User information not found in session. Please log in.");
      setLoading(false);
    }
  }, []);

  // Fetch assignment status
  const fetchAssignStatus = async (email) => {
    try {
      setLoading(true);
      setError("");
      const response = await axios.post(`${Data.url}/getAssignStatus`, { email });
      const data = response.data;

      // Validate response structure
      if (
        !data.ACKNOWLEDGED ||
        !data.NOTACKNOWLEDGED ||
        !data.signedOff_Approved ||
        !data.notSignedOff_not_Approved
      ) {
        throw new Error("Invalid response format from server");
      }

      setAssignData({
        ACKNOWLEDGED: data.ACKNOWLEDGED || [],
        NOTACKNOWLEDGED: data.NOTACKNOWLEDGED || [],
        signedOff_Approved: data.signedOff_Approved || [],
        notSignedOff_not_Approved: data.notSignedOff_not_Approved || [],
      });
    } catch (err) {
      console.error("Error fetching assign status:", err);
      setError(
        err.response?.data?.error ||
          "Failed to fetch notifications. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  // Handle approval for assignments or sign-offs
  const handleApprove = async (id, type) => {
    if (!userEmail) {
      setError("User email is required to perform this action.");
      return;
    }

    try {
      setLoading(true);
      setError("");
      const endpoint =
        type === "assignment"
          ? `${Data.url}/AssignmentConfirmationnotification/${id}`
          : `${Data.url}/SignOffConfirmationnotification/${id}`;
      const response = await axios.post(endpoint, { email: userEmail });
      setError(
        response.data.message ||
          `${type === "assignment" ? "Assignment" : "Sign-off"} confirmed successfully!`
      );
      fetchAssignStatus(userEmail);
    } catch (err) {
      console.error(`Error confirming ${type}:`, err);
      setError(
        err.response?.data?.error ||
          `Failed to confirm ${type}. Please try again.`
      );
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    if (userEmail) {
      fetchAssignStatus(userEmail);
    } else {
      setError("User email is required to refresh notifications.");
    }
  };

  // Status chip rendering
  const getStatusChip = (status, type) => {
    const configs = {
      acknowledged: {
        label: "Acknowledged",
        color: "success",
        icon: <CheckCircleIcon fontSize="small" />,
      },
      notAcknowledged: {
        label: "Not Acknowledged",
        color: "warning",
        icon: <PendingIcon fontSize="small" />,
      },
      signedOff: {
        label: "Signed Off",
        color: "success",
        icon: <CheckCircleIcon fontSize="small" />,
      },
      notSignedOff: {
        label: "Not Signed Off",
        color: "error",
        icon: <CancelIcon fontSize="small" />,
      },
    };

    const config = configs[type] || {
      label: status,
      color: "default",
      icon: null,
    };

    return (
      <Chip
        label={config.label}
        color={config.color}
        size="small"
        icon={config.icon}
        sx={{ fontWeight: 500, borderRadius: "8px" }}
      />
    );
  };

  // Render table row
  const renderRecordRow = (record, index, statusType, bgColor) => (
    <TableRow
      key={record.ID || index}
      sx={{
        bgcolor: bgColor,
        "&:hover": {
          bgcolor: `${bgColor}cc`,
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        },
        transition: "all 0.3s ease",
      }}
    >
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        <AssignmentIcon
          sx={{ color: "#1976d2", fontSize: 24, verticalAlign: "middle", mr: 1 }}
        />
        {record.Username || "Unknown User"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        <EmailIcon
          sx={{ fontSize: 16, color: "#666", verticalAlign: "middle", mr: 1 }}
        />
        {record.Emailid || "N/A"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        {record.Team || "N/A"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        <PersonIcon
          sx={{ fontSize: 16, color: "#666", verticalAlign: "middle", mr: 1 }}
        />
        {record.Role || "N/A"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        {record.ApprovedStatus ? "Approved" : "Not Approved"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        {record.SignoffApproved !== null ? (record.SignoffApproved ? "Yes" : "No") : "N/A"}
      </TableCell>
      <TableCell sx={{ borderBottom: "1px solid #e0e0e0", py: 1.5 }}>
        {(statusType === "notAcknowledged" || statusType === "notSignedOff") && (
          <Button
            variant="contained"
            color={statusType === "notAcknowledged" ? "warning" : "error"}
            size="small"
            onClick={() =>
              handleApprove(
                record.ID,
                statusType === "notAcknowledged" ? "assignment" : "signOff"
              )
            }
            disabled={loading}
          >
            Approve
          </Button>
        )}
      </TableCell>
    </TableRow>
  );

  // Render records list
  const renderRecordsList = (records, title, statusType, bgColor) => (
    <Card
      sx={{
        mb: 3,
        borderRadius: "12px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
      }}
    >
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
          <Typography
            variant="h6"
            sx={{ fontWeight: 600, color: "#134380", flexGrow: 1 }}
          >
            {title}
          </Typography>
          <Badge
            badgeContent={records.length}
            color="primary"
            sx={{
              "& .MuiBadge-badge": { fontSize: "0.8rem", minWidth: "24px", height: "24px" },
            }}
          />
        </Box>
        <Divider sx={{ mb: 2 }} />
        {records.length === 0 ? (
          <Typography
            variant="body2"
            sx={{ color: "#666", fontStyle: "italic", py: 2, textAlign: "center" }}
          >
            No {title.toLowerCase()} found
          </Typography>
        ) : (
          <TableContainer component={Paper} sx={{ maxHeight: "400px", overflowY: "auto" }}>
            <Table stickyHeader sx={{ minWidth: 800 }}>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Username
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Email
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Team
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Role
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Approved Status
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Signoff Approved
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, bgcolor: "#f5f5f5" }}>
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {records.map((record, index) =>
                  renderRecordRow(record, index, statusType, bgColor)
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </CardContent>
    </Card>
  );

  // Display loading state if fetching data
  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
          bgcolor: "#f5f7fa",
        }}
      >
        <CircularProgress size={60} thickness={4} />
        <Typography variant="h6" sx={{ mt: 3, color: "#555" }}>
          Loading Notifications...
        </Typography>
      </Box>
    );
  }

  // Display notifications dashboard
  return (
    <Box
      sx={{
        p: { xs: 2, md: 4 },
        maxWidth: 1400,
        mx: "auto",
        bgcolor: "#f5f7fa",
        minHeight: "100vh",
      }}
    >
      {/* Header */}
      <Paper
        elevation={3}
        sx={{
          p: 3,
          mb: 4,
          background: "linear-gradient(135deg, #134380 0%, #1e88e5 100%)",
          color: "white",
          borderRadius: "12px",
        }}
      >
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Box>
            <Typography
              variant="h4"
              sx={{ fontWeight: 700, mb: 1, letterSpacing: "0.5px" }}
            >
              Notifications Dashboard
            </Typography>
            <Typography variant="subtitle1" sx={{ opacity: 0.9, fontSize: "1.1rem" }}>
              Assignment and Sign-off Status for: {username || "Unknown User"}
            </Typography>
          </Box>
          <Tooltip title="Refresh Notifications">
            <IconButton
              onClick={handleRefresh}
              sx={{ color: "white", "&:hover": { bgcolor: "rgba(255,255,255,0.1)" } }}
              disabled={loading}
            >
              <RefreshIcon fontSize="large" />
            </IconButton>
          </Tooltip>
        </Box>
      </Paper>

      {/* Error/Success Alert */}
      {error && (
        <Alert
          severity={error.includes("successfully") ? "success" : "error"}
          sx={{ mb: 4, borderRadius: "8px", fontSize: "1rem" }}
          onClose={() => setError("")}
        >
          {error}
        </Alert>
      )}

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 5 }}>
        {[
          {
            count: assignData.ACKNOWLEDGED.length,
            label: "Acknowledged",
            bgColor: "#e8f5e8",
            borderColor: "#4caf50",
            textColor: "#2e7d32",
          },
          {
            count: assignData.NOTACKNOWLEDGED.length,
            label: "Not Acknowledged",
            bgColor: "#fff3e0",
            borderColor: "#ff9800",
            textColor: "#f57c00",
          },
          {
            count: assignData.signedOff_Approved.length,
            label: "Signed Off",
            bgColor: "#e3f2fd",
            borderColor: "#2196f3",
            textColor: "#1976d2",
          },
          {
            count: assignData.notSignedOff_not_Approved.length,
            label: "Not Signed Off",
            bgColor: "#ffebee",
            borderColor: "#f44336",
            textColor: "#d32f2f",
          },
        ].map((item, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card
              sx={{
                bgcolor: item.bgColor,
                borderLeft: `5px solid ${item.borderColor}`,
                borderRadius: "8px",
                transition: "transform 0.3s ease",
                "&:hover": {
                  transform: "translateY(-5px)",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.1)",
                },
              }}
            >
              <CardContent sx={{ textAlign: "center", py: 3 }}>
                <Typography
                  variant="h3"
                  sx={{ color: item.borderColor, fontWeight: 700, mb: 1 }}
                >
                  {item.count}
                </Typography>
                <Typography
                  variant="subtitle2"
                  sx={{ color: item.textColor, fontWeight: 500 }}
                >
                  {item.label}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Detailed Tables */}
      <Grid container spacing={3}>
        <Grid item xs={12} lg={6}>
          {renderRecordsList(
            assignData.ACKNOWLEDGED,
            "Acknowledged Assignments",
            "acknowledged",
            "#f1f8e9"
          )}
          {renderRecordsList(
            assignData.signedOff_Approved,
            "Signed Off & Approved",
            "signedOff",
            "#e3f2fd"
          )}
        </Grid>
        <Grid item xs={12} lg={6}>
          {renderRecordsList(
            assignData.NOTACKNOWLEDGED,
            "Pending Acknowledgments",
            "notAcknowledged",
            "#fff8e1"
          )}
          {renderRecordsList(
            assignData.notSignedOff_not_Approved,
            "Pending Sign-offs",
            "notSignedOff",
            "#ffebee"
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default NotificationsPage;