import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
    Alert,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Snackbar,
    Box,
    Button,
    FormControl,
    MenuItem,
    InputLabel,
    TextField,
    Select,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Card,
    CardContent,
    Grid,
    Chip,
    IconButton,
    Fade,
    Skeleton,
    Container,
    Divider,
    Stack,
    Avatar,
    Badge,
    Tooltip,
} from "@mui/material";
import {
    Delete as DeleteIcon,
    PersonAdd as PersonAddIcon,
    Search as SearchIcon,
    Refresh as RefreshIcon,
    Group as GroupIcon,
    Email as EmailIcon,
    Person as PersonIcon,
    AdminPanelSettings as AdminIcon,
    SupervisorAccount as ManagerIcon,
    AccountCircle as UserIcon,
    FilterList as FilterIcon,
} from "@mui/icons-material";
import { styled, alpha, keyframes } from "@mui/material/styles";
import axios from "axios";
import Header from "./Header";
import { Data } from "../custom";

// Advanced animations
const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 5px rgba(25, 118, 210, 0.4); }
  50% { box-shadow: 0 0 20px rgba(25, 118, 210, 0.8), 0 0 30px rgba(25, 118, 210, 0.6); }
`;

const float = keyframes`
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-4px); }
`;

// Enhanced styled components
const CompactCard = styled(Card)(({ theme }) => ({
    background: `linear-gradient(135deg, 
    ${alpha(theme.palette.primary.main, 0.06)} 0%,
    ${alpha(theme.palette.secondary.main, 0.04)} 50%,
    ${alpha(theme.palette.primary.light, 0.06)} 100%)`,
    backdropFilter: 'blur(15px) saturate(180%)',
    border: `1px solid ${alpha(theme.palette.primary.main, 0.15)}`,
    borderRadius: 12,
    position: 'relative',
    overflow: 'hidden',
    boxShadow: `0 4px 20px ${alpha(theme.palette.common.black, 0.08)}`,
    transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)',
    '&:hover': {
        transform: 'translateY(-4px)',
        boxShadow: `0 8px 25px ${alpha(theme.palette.common.black, 0.12)}`,
    },
}));

const CompactTable = styled(TableContainer)(({ theme }) => ({
    background: `linear-gradient(135deg, 
    ${alpha(theme.palette.background.paper, 0.95)} 0%,
    ${alpha(theme.palette.background.paper, 0.9)} 100%)`,
    backdropFilter: 'blur(15px) saturate(180%)',
    borderRadius: 12,
    border: `1px solid ${alpha(theme.palette.primary.main, 0.12)}`,
    overflow: 'hidden',
    boxShadow: `0 6px 25px ${alpha(theme.palette.common.black, 0.08)}`,
}));

const SmallTableHead = styled(TableHead)(({ theme }) => ({
    background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.dark})`,
    '& .MuiTableCell-head': {
        color: theme.palette.primary.contrastText,
        fontWeight: 600,
        fontSize: '0.8rem',
        padding: '8px 12px',
        borderBottom: 'none',
    },
}));

const SmallTableRow = styled(TableRow)(({ theme }) => ({
    transition: 'all 0.2s ease-in-out',
    '&:nth-of-type(odd)': {
        backgroundColor: alpha(theme.palette.primary.main, 0.02),
    },
    '&:hover': {
        backgroundColor: alpha(theme.palette.primary.main, 0.06),
        transform: 'translateX(4px)',
    },
    '& .MuiTableCell-root': {
        padding: '6px 12px',
        fontSize: '0.8rem',
    }
}));

const SmallButton = styled(Button)(({ theme }) => ({
    background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
    borderRadius: 8,
    padding: '6px 16px',
    textTransform: 'none',
    fontWeight: 600,
    fontSize: '0.8rem',
    color: 'white',
    boxShadow: `0 3px 12px ${alpha(theme.palette.primary.main, 0.3)}`,
    transition: 'all 0.3s ease',
    '&:hover': {
        transform: 'translateY(-2px)',
        boxShadow: `0 6px 20px ${alpha(theme.palette.primary.main, 0.4)}`,
    },
}));

const SmallDeleteButton = styled(IconButton)(({ theme }) => ({
    color: theme.palette.error.main,
    border: `1px solid ${alpha(theme.palette.error.main, 0.3)}`,
    borderRadius: 6,
    padding: '4px',
    transition: 'all 0.2s ease',
    '&:hover': {
        backgroundColor: alpha(theme.palette.error.main, 0.1),
        borderColor: theme.palette.error.main,
        transform: 'scale(1.05)',
    },
}));

const CompactSearchBox = styled(Box)(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    background: `linear-gradient(135deg, 
    ${alpha(theme.palette.background.paper, 0.9)} 0%,
    ${alpha(theme.palette.primary.main, 0.04)} 100%)`,
    backdropFilter: 'blur(8px)',
    borderRadius: 12,
    padding: '6px 12px',
    border: `1px solid ${alpha(theme.palette.primary.main, 0.15)}`,
    transition: 'all 0.3s ease',
    '&:focus-within': {
        borderColor: theme.palette.primary.main,
        boxShadow: `0 0 0 2px ${alpha(theme.palette.primary.main, 0.1)}`,
    },
}));

const RoleIcon = ({ role }) => {
    const icons = {
        admin: <AdminIcon sx={{ fontSize: 14 }} />,
        manager: <ManagerIcon sx={{ fontSize: 14 }} />,
        user: <UserIcon sx={{ fontSize: 14 }} />
    };
    return icons[role?.toLowerCase()] || <UserIcon sx={{ fontSize: 14 }} />;
};

// Custom hooks (same as before)
const useUserManagement = () => {
    const [userList, setUserList] = useState([]);
    const [teams, setTeams] = useState([]);
    const [loading, setLoading] = useState(false);
    const [sessionRole, setSessionRole] = useState("");
    const [searchTerm, setSearchTerm] = useState("");

    const fetchUsers = useCallback(async () => {
        setLoading(true);
        try {
            const response = await axios.post(`${Data.url}/userdetails`);
            const userdetails = response.data.map((item) => ({
                email: item.Email,
                role: item.Role,
                team: item.Team,
                username: item.Username,
            }));
            setUserList(userdetails);
        } catch (error) {
            console.error("Error fetching users:", error);
        } finally {
            setLoading(false);
        }
    }, []);

    const fetchTeams = useCallback(async () => {
        try {
            const response = await axios.post(`${Data.url}/getTeams`);
            setTeams(response.data);
        } catch (error) {
            console.error("Error fetching teams:", error);
        }
    }, []);

    useEffect(() => {
        fetchUsers();
        fetchTeams();
        const roleFromSession = sessionStorage.getItem('userRole') || localStorage.getItem('userRole');
        setSessionRole(roleFromSession || "User");
    }, [fetchUsers, fetchTeams]);

    const filteredUsers = useMemo(() => {
        return userList.filter(user =>
            user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.team.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [userList, searchTerm]);

    return {
        userList: filteredUsers,
        teams,
        loading,
        sessionRole,
        searchTerm,
        setSearchTerm,
        fetchUsers,
    };
};

const useFormValidation = () => {
    const [errors, setErrors] = useState({});

    const validateForm = (formData) => {
        const newErrors = {};
        if (!formData.email) {
            newErrors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = "Email is invalid";
        }
        if (!formData.username) {
            newErrors.username = "Username is required";
        } else if (formData.username.length < 3) {
            newErrors.username = "Username must be at least 3 characters";
        }
        if (!formData.teamId) {
            newErrors.teamId = "Team selection is required";
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    return { errors, validateForm, setErrors };
};

const UserAccess = () => {
    const username = "user";
    const { userList, teams, loading, sessionRole, searchTerm, setSearchTerm, fetchUsers } = useUserManagement();
    const { errors, validateForm, setErrors } = useFormValidation();

    const [openDialog, setOpenDialog] = useState(false);
    const [userToDelete, setUserToDelete] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
    const [formData, setFormData] = useState({ email: "", username: "", teamId: "", teamName: "" });

    const handleChange = useCallback((e) => {
        const { name, value } = e.target;
        if (name === 'teamId') {
            const selectedTeam = teams.find(team => team.TeamId === value);
            setFormData((prev) => ({
                ...prev,
                teamId: value,
                teamName: selectedTeam ? selectedTeam.TeamName : ''
            }));
        } else {
            setFormData((prev) => ({ ...prev, [name]: value }));
        }
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    }, [teams, errors, setErrors]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm(formData)) {
            setSnackbar({ open: true, message: "Please fix the form errors", severity: "error" });
            return;
        }
        setSubmitting(true);
        const data = { email: formData.email, username: formData.username, role: sessionRole, teamId: formData.teamId, teamName: formData.teamName };
        try {
            const response = await axios.post(`${Data.url}/adduser`, data, { headers: { "Content-Type": "application/json" } });
            if (response.status >= 200 && response.status < 300) {
                setSnackbar({ open: true, message: "User added successfully!", severity: "success" });
                setFormData({ email: "", username: "", teamId: "", teamName: "" });
                fetchUsers();
            }
        } catch (error) {
            setSnackbar({ open: true, message: "Failed to add user!", severity: "error" });
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = async (usernametodel) => {
        if (!usernametodel) return;
        try {
            const response = await axios.post(`${Data.url}/deleteuser`, { username: usernametodel }, { headers: { "Content-Type": "application/json" } });
            if (response.status >= 200 && response.status < 300) {
                setSnackbar({ open: true, message: "User deleted successfully!", severity: "success" });
                fetchUsers();
            }
        } catch (error) {
            setSnackbar({ open: true, message: "Failed to delete user!", severity: "error" });
        } finally {
            setOpenDialog(false);
            setUserToDelete(null);
        }
    };

    const openDeleteDialog = (username) => {
        setUserToDelete(username);
        setOpenDialog(true);
    };

    const getRoleColor = (role) => {
        switch (role?.toLowerCase()) {
            case 'admin': return 'error';
            case 'manager': return 'warning';
            case 'user': return 'info';
            default: return 'default';
        }
    };

    return (
        <>
            <Header username={username} />
            {/* Changed mt: 6 to mt: 3 to reduce gap */}
            <Box sx={{ mt: 8, mx: 2, maxWidth: '100%' }}>

                <Fade in timeout={400}>
                    <Box>
                        {/* Compact Header - Left Aligned */}
                        <Box mb={1.5} textAlign="left">
                            <Typography
                                variant="h5"
                                component="h1"
                                sx={{
                                    fontWeight: 700,
                                    fontSize: '1.4rem',
                                    background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
                                    backgroundClip: 'text',
                                    WebkitBackgroundClip: 'text',
                                    WebkitTextFillColor: 'transparent',
                                    mb: 0,
                                }}
                            >
                                User Access Management
                            </Typography>
                        </Box>

                        {/* Compact Add User Form */}
                        <CompactCard sx={{ mb: 2 }}>
                            <CardContent sx={{ p: 2 }}>
                                <Box display="flex" alignItems="center" mb={1.5}>
                                    <PersonAddIcon sx={{ mr: 1, color: 'primary.main', fontSize: 20 }} />
                                    <Typography variant="subtitle1" fontWeight={600} sx={{ fontSize: '1rem' }}>
                                        Add New User
                                    </Typography>
                                </Box>

                                <Grid container spacing={1.5}>
                                    <Grid item xs={12} sm={6} md={2.4}>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            label="Email"
                                            name="email"
                                            type="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            error={!!errors.email}
                                            helperText={errors.email}
                                            InputProps={{
                                                startAdornment: <EmailIcon sx={{ mr: 0.5, color: 'action.disabled', fontSize: 16 }} />,
                                            }}
                                            sx={{
                                                '& .MuiOutlinedInput-root': { borderRadius: 2 },
                                                '& .MuiInputBase-input': { fontSize: '0.85rem' }
                                            }}
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={2.4}>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            label="Username"
                                            name="username"
                                            value={formData.username}
                                            onChange={handleChange}
                                            error={!!errors.username}
                                            helperText={errors.username}
                                            InputProps={{
                                                startAdornment: <PersonIcon sx={{ mr: 0.5, color: 'action.disabled', fontSize: 16 }} />,
                                            }}
                                            sx={{
                                                '& .MuiOutlinedInput-root': { borderRadius: 2 },
                                                '& .MuiInputBase-input': { fontSize: '0.85rem' }
                                            }}
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={2.4}>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            label="Role"
                                            value={sessionRole}
                                            disabled
                                            sx={{
                                                '& .MuiOutlinedInput-root': { borderRadius: 2 },
                                                '& .MuiInputBase-input': { fontSize: '0.85rem' }
                                            }}
                                        />
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={2.4}>
                                        <FormControl fullWidth size="small" error={!!errors.teamId}>
                                            <InputLabel sx={{ fontSize: '0.85rem' }}>Team</InputLabel>
                                            <Select
                                                value={formData.teamId}
                                                name="teamId"
                                                label="Team"
                                                onChange={handleChange}
                                                sx={{
                                                    borderRadius: 2,
                                                    '& .MuiSelect-select': { fontSize: '0.85rem' }
                                                }}
                                            >
                                                {teams.map((team) => (
                                                    <MenuItem key={team.TeamId} value={team.TeamId} sx={{ fontSize: '0.85rem' }}>
                                                        <GroupIcon sx={{ mr: 0.5, fontSize: 14 }} />
                                                        {team.TeamName}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                            {errors.teamId && (
                                                <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 1, fontSize: '0.7rem' }}>
                                                    {errors.teamId}
                                                </Typography>
                                            )}
                                        </FormControl>
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={2.4}>
                                        <SmallButton
                                            fullWidth
                                            onClick={handleSubmit}
                                            disabled={submitting}
                                            sx={{ height: 36 }}
                                        >
                                            {submitting ? 'Adding...' : 'Add User'}
                                        </SmallButton>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </CompactCard>

                        {/* Compact Search and Actions */}
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                            <CompactSearchBox sx={{ width: 250 }}>
                                <SearchIcon sx={{ color: 'action.disabled', mr: 1, fontSize: 18 }} />
                                <TextField
                                    placeholder="Search users..."
                                    variant="standard"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    InputProps={{ disableUnderline: true }}
                                    sx={{ flexGrow: 1, '& input': { fontSize: '0.8rem' } }}
                                />
                            </CompactSearchBox>

                            <Stack direction="row" spacing={1} alignItems="center">
                                <Button
                                    startIcon={<RefreshIcon sx={{ fontSize: 16 }} />}
                                    onClick={fetchUsers}
                                    disabled={loading}
                                    size="small"
                                    sx={{
                                        borderRadius: 2,
                                        textTransform: 'none',
                                        fontSize: '0.8rem'
                                    }}
                                >
                                    Refresh
                                </Button>
                                <Chip
                                    label={`${userList.length} Users`}
                                    color="primary"
                                    size="small"
                                    sx={{ fontSize: '0.75rem' }}
                                />
                            </Stack>
                        </Box>

                        {/* Compact Users Table */}
                        <CompactTable component={Paper}>
                            <Table size="small">
                                <SmallTableHead>
                                    <TableRow>
                                        <TableCell>Email</TableCell>
                                        <TableCell>Username</TableCell>
                                        <TableCell>Role</TableCell>
                                        <TableCell>Team</TableCell>
                                        <TableCell align="center">Actions</TableCell>
                                    </TableRow>
                                </SmallTableHead>
                                <TableBody>
                                    {loading ? (
                                        [...Array(3)].map((_, index) => (
                                            <TableRow key={index}>
                                                <TableCell><Skeleton animation="wave" height={24} /></TableCell>
                                                <TableCell><Skeleton animation="wave" height={24} /></TableCell>
                                                <TableCell><Skeleton animation="wave" width={50} height={24} /></TableCell>
                                                <TableCell><Skeleton animation="wave" height={24} /></TableCell>
                                                <TableCell><Skeleton animation="wave" width={30} height={24} /></TableCell>
                                            </TableRow>
                                        ))
                                    ) : userList.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={5} align="center" sx={{ py: 2 }}>
                                                <Typography variant="body2" color="text.secondary">
                                                    No users found
                                                </Typography>
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        userList.map((user, index) => (
                                            <SmallTableRow key={index}>
                                                <TableCell>
                                                    <Box display="flex" alignItems="center">
                                                        <Avatar sx={{ width: 20, height: 20, mr: 1, fontSize: '0.6rem' }}>
                                                            {user.email.charAt(0).toUpperCase()}
                                                        </Avatar>
                                                        <Typography sx={{ fontSize: '0.8rem' }}>
                                                            {user.email}
                                                        </Typography>
                                                    </Box>
                                                </TableCell>
                                                <TableCell>
                                                    <Typography sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                                                        {user.username}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        icon={<RoleIcon role={user.role} />}
                                                        label={user.role}
                                                        color={getRoleColor(user.role)}
                                                        size="small"
                                                        sx={{
                                                            fontSize: '0.7rem',
                                                            height: 22
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Typography sx={{ fontSize: '0.8rem' }}>
                                                        {user.team}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell align="center">
                                                    <SmallDeleteButton
                                                        onClick={() => openDeleteDialog(user.username)}
                                                        size="small"
                                                    >
                                                        <DeleteIcon sx={{ fontSize: 14 }} />
                                                    </SmallDeleteButton>
                                                </TableCell>
                                            </SmallTableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </CompactTable>
                    </Box>
                </Fade>

                {/* Compact Delete Dialog */}
                <Dialog
                    open={openDialog}
                    onClose={() => setOpenDialog(false)}
                    PaperProps={{
                        sx: { borderRadius: 3, minWidth: 300 }
                    }}
                >
                    <DialogTitle sx={{ pb: 1 }}>
                        <Box display="flex" alignItems="center">
                            <DeleteIcon sx={{ mr: 1, color: 'error.main', fontSize: 20 }} />
                            <Typography variant="h6" sx={{ fontSize: '1rem' }}>
                                Confirm Deletion
                            </Typography>
                        </Box>
                    </DialogTitle>
                    <Divider />
                    <DialogContent sx={{ pt: 2 }}>
                        <Typography sx={{ fontSize: '0.9rem' }}>
                            Delete user{' '}
                            <Chip
                                label={userToDelete}
                                color="error"
                                variant="outlined"
                                size="small"
                                sx={{ fontSize: '0.75rem' }}
                            />?
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1, fontSize: '0.8rem' }}>
                            This action cannot be undone.
                        </Typography>
                    </DialogContent>
                    <DialogActions sx={{ p: 2 }}>
                        <Button
                            onClick={() => setOpenDialog(false)}
                            size="small"
                            sx={{ borderRadius: 2, textTransform: 'none', fontSize: '0.8rem' }}
                        >
                            Cancel
                        </Button>
                        <Button
                            color="error"
                            variant="contained"
                            onClick={() => handleDelete(userToDelete)}
                            size="small"
                            sx={{ borderRadius: 2, textTransform: 'none', fontSize: '0.8rem' }}
                        >
                            Delete
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* Compact Snackbar */}
                <Snackbar
                    open={snackbar.open}
                    autoHideDuration={3000}
                    onClose={() => setSnackbar({ ...snackbar, open: false })}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <Alert
                        onClose={() => setSnackbar({ ...snackbar, open: false })}
                        severity={snackbar.severity}
                        sx={{
                            borderRadius: 2,
                            fontSize: '0.8rem'
                        }}
                    >
                        {snackbar.message}
                    </Alert>
                </Snackbar>
            </Box>
        </>
    );
};

export default UserAccess;
