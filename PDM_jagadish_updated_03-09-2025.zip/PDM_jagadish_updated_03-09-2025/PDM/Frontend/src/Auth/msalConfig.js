// Auth/msalConfig.js
import { PublicClientApplication } from "@azure/msal-browser";

const msalConfig = {
    auth: {
        clientId: "5c1b49a7-0665-4e31-b197-fd79cfc149a8",
        authority: "https://login.microsoftonline.com/5d471751-9675-428d-917b-70f44f9630b0/v2.0",
        redirectUri: "http://localhost:3000/pdm/Dashboard",
    },
    cache: {
        cacheLocation: "sessionStorage",
        storeAuthStateInCookie: false,
    }
};

export const msalInstance = new PublicClientApplication(msalConfig);
