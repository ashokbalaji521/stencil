import React, { useState, useEffect } from "react";
import {
    AppBar,
    Toolbar,
    Typography,
    Button,
    Paper,
    Container,
    Box,
    Alert,
    CircularProgress,
    Fade,
    Slide,
    Divider,
    Chip,
    IconButton,
    LinearProgress,
    Stack,
    Zoom
} from "@mui/material";
import { useMsal } from "@azure/msal-react";
import {
    Login as LoginIcon,
    Security as SecurityIcon,
    Verified as VerifiedIcon,
    Close as CloseIcon,
    Shield as ShieldIcon,
    Lock as LockIcon,
    Security as SecurityIcon2,
    Visibility as VisibilityIcon
} from "@mui/icons-material";
import logo from "../Assets/Images/nokia.png";
import pdmLogo from "../Assets/Images/PDM.png";
import { jwtDecode } from "jwt-decode";
import { Data } from "../custom";
import axios from "axios";

const LoginPage = () => {
    const { instance } = useMsal();
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState("");
    const [showWelcome, setShowWelcome] = useState(true);
    const [loginProgress, setLoginProgress] = useState(0);
    const [cardHovered, setCardHovered] = useState(false);
    const [buttonHovered, setButtonHovered] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => setShowWelcome(false), 1500);
        return () => clearTimeout(timer);
    }, []);

    const simulateProgress = () => {
        const timer = setInterval(() => {
            setLoginProgress((prev) => {
                if (prev >= 100) {
                    clearInterval(timer);
                    return 100;
                }
                return prev + 12.5;
            });
        }, 160);
    };

    const resolveRole = (decodedToken) => {
        // Primary source (AAD "roles" claim for app roles)
        const roles = decodedToken?.roles || [];

        // Optional fallbacks if your tenant emits other claims:
        const appRoles = decodedToken?.appRoles || [];
        const groups = decodedToken?.groups || [];

        // Normalize into a single list of strings
        const all = [
            ...roles,
            ...(Array.isArray(appRoles) ? appRoles : []),
            ...(Array.isArray(groups) ? groups : [])
        ].map(String);

        // Prioritize Admin, then User
        if (all.some(r => /admin/i.test(r))) return "Admin";
        if (all.some(r => /^user$/i.test(r) || /user/i.test(r))) return "User";

        // If nothing matches, return null to trigger error flow
        return null;
    };

    const resolveUsername = (decodedToken) => {
        // Common AAD claims for name-like fields
        return (
            decodedToken?.name ||
            decodedToken?.preferred_username ||
            decodedToken?.upn ||
            decodedToken?.email ||
            "Guest User"
        );
    };

    // FIXED: Proper axios call without incorrect fetch API mixing
    const fetchUserTeamInfo = async (email) => {
        try {
            console.log('Fetching team info for email:', email);

            // CORRECT axios.post syntax
            const response = await axios.post(`${Data.url}/login`, {
                email: email  // Just send email in the body
            });

            console.log('Team API Response:', response.data);
            return response.data;  // axios automatically parses JSON

        } catch (error) {
            console.error('Error fetching team info:', error);
            console.error('Error response:', error.response?.data);
            throw error;
        }
    };

    const handleLogin = async () => {
        setIsLoading(true);
        setError("");
        setLoginProgress(0);
        simulateProgress();

        try {
            const loginResponse = await instance.loginPopup({
                scopes: ["openid", "profile", "email"],
                prompt: "select_account"
            });

            const idToken = loginResponse.idToken;
            if (!idToken) {
                throw new Error("Authentication failed - No ID token received");
            }

            const decodedToken = jwtDecode(idToken);

            // Determine role from claims
            const role = resolveRole(decodedToken);
            if (!role) {
                throw new Error("Access denied - Insufficient permissions");
            }

            // Get username and email
            const username = resolveUsername(decodedToken);
            const email = decodedToken?.email || decodedToken?.preferred_username || "";

            console.log('Extracted email from token:', email);

            // Store basic info in sessionStorage
            sessionStorage.setItem("username", username);
            sessionStorage.setItem("role", role);
            sessionStorage.setItem("idToken", idToken);
            sessionStorage.setItem("email", email); // Store email immediately

            // UPDATED: Fetch team information for both User and Admin roles
            try {
                const teamInfo = await fetchUserTeamInfo(email);
                if (teamInfo && teamInfo.team && teamInfo.teamId) {
                    sessionStorage.setItem("team", teamInfo.team);
                    sessionStorage.setItem("teamId", teamInfo.teamId.toString());
                    console.log("Team data stored successfully:", teamInfo);
                } else {
                    console.warn("No team data received, using defaults");
                    // Set default values instead of failing
                    sessionStorage.setItem("team", "Default Team");
                    sessionStorage.setItem("teamId", "1");
                }
            } catch (teamError) {
                console.error("Failed to fetch team info:", teamError);
                // Set default team data instead of failing login
                sessionStorage.setItem("team", "Default Team");
                sessionStorage.setItem("teamId", "1");
                console.log("Using default team data due to API error");
            }

            // Simulate brief delay for UX continuity
            await new Promise((resolve) => setTimeout(resolve, 700));

            // Navigate based on role
            if (role === "Admin") {
                window.location.href = "/pdm/Dashboard";
            } else if (role === "User") {
                window.location.href = "/pdm/UserDashboard";
            } else {
                throw new Error("Access denied - Insufficient permissions");
            }

        } catch (err) {
            console.error("Login failed:", err);
            // Clean up any partial session data on failure
            sessionStorage.removeItem("username");
            sessionStorage.removeItem("role");
            sessionStorage.removeItem("idToken");
            sessionStorage.removeItem("team");
            sessionStorage.removeItem("teamId");
            sessionStorage.removeItem("email");
            setError(err.message || "Authentication failed. Please try again.");
            setLoginProgress(0);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Box
            sx={{
                minHeight: "100vh",
                background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)",
                position: "relative",
                overflow: "hidden"
            }}
        >
            {/* Animated Background Elements (kept subtle) */}
            <Box
                sx={{
                    position: "absolute",
                    inset: 0,
                    backgroundImage: `
            radial-gradient(circle at 25% 25%, rgba(25, 118, 210, 0.06) 0%, transparent 50%),
            radial-gradient(circle at 75% 75%, rgba(25, 118, 210, 0.06) 0%, transparent 50%)
          `,
                    animation: "backgroundFloat 20s ease-in-out infinite",
                    "@keyframes backgroundFloat": {
                        "0%, 100%": { transform: "translate(0, 0)" },
                        "50%": { transform: "translate(-14px, -14px)" }
                    },
                    zIndex: 1
                }}
            />

            {/* Floating dots reduced size */}
            {[...Array(6)].map((_, i) => (
                <Box
                    key={i}
                    sx={{
                        position: "absolute",
                        width: 3 + Math.random() * 6,
                        height: 3 + Math.random() * 6,
                        backgroundColor: "rgba(25, 118, 210, 0.25)",
                        borderRadius: "50%",
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                        animation: `float${i} ${14 + Math.random() * 8}s linear infinite`,
                        "@keyframes float0": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-80px) rotate(360deg)", opacity: 0 }
                        },
                        "@keyframes float1": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-64px) rotate(-360deg)", opacity: 0 }
                        },
                        "@keyframes float2": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-96px) rotate(360deg)", opacity: 0 }
                        },
                        "@keyframes float3": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-72px) rotate(-360deg)", opacity: 0 }
                        },
                        "@keyframes float4": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-88px) rotate(360deg)", opacity: 0 }
                        },
                        "@keyframes float5": {
                            "0%": { transform: "translateY(0px) rotate(0deg)", opacity: 0.28 },
                            "50%": { opacity: 0.9 },
                            "100%": { transform: "translateY(-76px) rotate(-360deg)", opacity: 0 }
                        }
                    }}
                />
            ))}

            {/* Compact Header with larger/bold logo text as requested */}
            <AppBar
                position="static"
                elevation={2}
                sx={{
                    backgroundColor: "#1976d2",
                    zIndex: 10
                }}
            >
                <Toolbar sx={{ minHeight: 48, px: { xs: 1.5, md: 2.5 } }}>
                    {/* Left - Logo */}
                    <Box sx={{ display: "flex", alignItems: "center", minWidth: "140px" }}>
                        <Box
                            component="img"
                            src={logo}
                            alt="Nokia Logo"
                            sx={{
                                height: 28,
                                width: "auto",
                                objectFit: "contain",
                                filter: "brightness(0) invert(1)",
                                mr: 1.25
                            }}
                            onError={(e) => {
                                e.target.style.display = "none";
                                if (e.target.nextSibling) e.target.nextSibling.style.display = "block";
                            }}
                        />
                    </Box>

                    {/* Center - Title */}
                    <Box
                        sx={{
                            flexGrow: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center"
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                fontWeight: 700,
                                color: "#ffffff",
                                fontSize: { xs: "1rem", md: "1.15rem" },
                                textAlign: "center",
                                lineHeight: 1.05,
                                letterSpacing: 0.2
                            }}
                        >
                            Nokia Enterprise Portal
                        </Typography>
                    </Box>

                    {/* Right - Security chip */}
                    <Box sx={{ minWidth: "140px", display: "flex", justifyContent: "flex-end" }}>
                        <Chip
                            icon={<SecurityIcon sx={{ fontSize: 16 }} />}
                            label="Secure SSO"
                            size="small"
                            sx={{
                                backgroundColor: "rgba(255, 255, 255, 0.15)",
                                color: "#ffffff",
                                fontWeight: 600,
                                border: "1px solid rgba(255, 255, 255, 0.2)",
                                height: 26
                            }}
                        />
                    </Box>
                </Toolbar>
            </AppBar>

            {/* Progress Bar (slim) */}
            {isLoading && (
                <Box sx={{ position: "relative" }}>
                    <LinearProgress
                        variant="determinate"
                        value={loginProgress}
                        sx={{
                            height: 4,
                            backgroundColor: "rgba(25, 118, 210, 0.1)",
                            "& .MuiLinearProgress-bar": {
                                backgroundColor: "#1976d2",
                                boxShadow: "0 0 6px rgba(25, 118, 210, 0.4)"
                            }
                        }}
                    />
                    <Box
                        sx={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            right: 0,
                            height: "4px",
                            background:
                                "linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.5), transparent)",
                            animation: "progressSweep 2s ease-in-out infinite",
                            "@keyframes progressSweep": {
                                "0%": { transform: "translateX(-100%)" },
                                "100%": { transform: "translateX(100%)" }
                            }
                        }}
                    />
                </Box>
            )}

            {/* Welcome Screen (smaller) */}
            <Fade in={showWelcome} timeout={600}>
                <Box
                    sx={{
                        position: "absolute",
                        inset: 0,
                        display: showWelcome ? "flex" : "none",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 100,
                        backgroundColor: "rgba(255, 255, 255, 0.94)",
                        backdropFilter: "blur(8px)"
                    }}
                >
                    <Zoom in={showWelcome} timeout={500}>
                        <Paper
                            elevation={10}
                            sx={{
                                p: 3,
                                textAlign: "center",
                                backgroundColor: "#ffffff",
                                borderRadius: 3,
                                maxWidth: 360,
                                border: "1px solid rgba(25, 118, 210, 0.1)",
                                boxShadow: "0 8px 32px rgba(25, 118, 210, 0.18)"
                            }}
                        >
                            <Box
                                component="img"
                                src={logo}
                                alt="Nokia"
                                sx={{
                                    height: 46,
                                    width: "auto",
                                    mb: 1.5,
                                    objectFit: "contain",
                                    animation: "logoSpin 3s ease-in-out infinite",
                                    "@keyframes logoSpin": {
                                        "0%, 100%": { transform: "rotate(0deg) scale(1)" },
                                        "50%": { transform: "rotate(4deg) scale(1.04)" }
                                    }
                                }}
                            />
                            <Typography variant="h6" color="#1976d2" gutterBottom sx={{ fontWeight: 600 }}>
                                Welcome to Nokia PDM Portal
                            </Typography>
                            <Typography variant="body2" color="textSecondary" sx={{ mb: 2 }}>
                                Initializing secure environment...
                            </Typography>
                            <CircularProgress
                                size={28}
                                sx={{ color: "#1976d2", filter: "drop-shadow(0 0 4px rgba(25, 118, 210, 0.25))" }}
                            />
                        </Paper>
                    </Zoom>
                </Box>
            </Fade>

            {/* Main Content */}
            <Container
                maxWidth="xl"
                sx={{
                    position: "relative",
                    zIndex: 2,
                    height: "calc(100vh - 96px)",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    px: 3,
                    gap: 3
                }}
            >
                {/* Left - Info */}
                <Slide direction="right" in={!showWelcome} timeout={800}>
                    <Box sx={{ maxWidth: "50%" }}>
                        <Typography
                            variant="h1"
                            sx={{
                                fontWeight: 800,
                                color: "#1976d2",
                                mb: 1.25,
                                fontSize: { xs: "2.2rem", md: "3rem", lg: "3.6rem" },
                                lineHeight: 1.05,
                                animation: "textGlow 4s ease-in-out infinite alternate",
                                "@keyframes textGlow": {
                                    "0%": { textShadow: "0 0 14px rgba(25, 118, 210, 0.22)" },
                                    "100%": { textShadow: "0 0 26px rgba(25, 118, 210, 0.45)" }
                                }
                            }}
                        >
                            PDM Smart View
                        </Typography>

                        <Typography
                            variant="h3"
                            sx={{
                                fontWeight: 300,
                                color: "#666",
                                mb: 4,
                                fontSize: { xs: "1.3rem", md: "1.7rem", lg: "2rem" },
                                animation: "subtitleFloat 6s ease-in-out infinite",
                                "@keyframes subtitleFloat": {
                                    "0%, 100%": { transform: "translateY(0px)" },
                                    "50%": { transform: "translateY(-3px)" }
                                }
                            }}
                        >
                            @360° Enterprise Solution
                        </Typography>

                        {/* Feature list (compact) */}
                        <Stack spacing={2} sx={{ mb: 4 }}>
                            {[
                                "Real-time dashboard and advanced analytics",
                                "Intelligent asset management system",
                                "Enterprise security and compliance",
                                "360-degree product lifecycle visibility"
                            ].map((feature, index) => (
                                <Fade key={index} in={!showWelcome} timeout={1000 + index * 150}>
                                    <Box
                                        sx={{
                                            display: "flex",
                                            alignItems: "center",
                                            animation: `featureSlide ${2.6 + index * 0.4}s ease-in-out infinite`,
                                            "@keyframes featureSlide": {
                                                "0%, 100%": { transform: "translateX(0px)" },
                                                "50%": { transform: "translateX(3px)" }
                                            }
                                        }}
                                    >
                                        <VerifiedIcon
                                            sx={{
                                                color: "#4caf50",
                                                mr: 1.25,
                                                fontSize: 22,
                                                filter: "drop-shadow(0 0 2px rgba(76, 175, 80, 0.35))"
                                            }}
                                        />
                                        <Typography variant="body1" sx={{ color: "#555", fontSize: "0.98rem" }}>
                                            {feature}
                                        </Typography>
                                    </Box>
                                </Fade>
                            ))}
                        </Stack>

                        {/* Security badges (compact) */}
                        <Stack
                            direction="row"
                            spacing={1.5}
                            sx={{
                                flexWrap: "wrap",
                                gap: 1.5,
                                "& > *": {
                                    animation: "badgePulse 3s ease-in-out infinite alternate"
                                },
                                "@keyframes badgePulse": {
                                    "0%": { transform: "scale(1)" },
                                    "100%": { transform: "scale(1.02)" }
                                }
                            }}
                        >
                            <Chip
                                icon={<SecurityIcon sx={{ fontSize: 16 }} />}
                                label="SOC 2 Compliant"
                                variant="outlined"
                                size="small"
                                sx={{
                                    borderColor: "#1976d2",
                                    color: "#1976d2",
                                    fontWeight: 600,
                                    fontSize: "0.78rem",
                                    height: 26
                                }}
                            />
                            <Chip
                                icon={<ShieldIcon sx={{ fontSize: 16 }} />}
                                label="ISO 27001"
                                variant="outlined"
                                size="small"
                                sx={{
                                    borderColor: "#1976d2",
                                    color: "#1976d2",
                                    fontWeight: 600,
                                    fontSize: "0.78rem",
                                    height: 26
                                }}
                            />
                            <Chip
                                icon={<LockIcon sx={{ fontSize: 16 }} />}
                                label="Enterprise Security"
                                variant="outlined"
                                size="small"
                                sx={{
                                    borderColor: "#1976d2",
                                    color: "#1976d2",
                                    fontWeight: 600,
                                    fontSize: "0.78rem",
                                    height: 26
                                }}
                            />
                        </Stack>
                    </Box>
                </Slide>

                {/* Right - Login Card (compact) */}
                <Slide direction="left" in={!showWelcome} timeout={900}>
                    <Paper
                        elevation={16}
                        onMouseEnter={() => setCardHovered(true)}
                        onMouseLeave={() => setCardHovered(false)}
                        sx={{
                            p: { xs: 2.25, md: 3 },
                            pt: 3,
                            pb: 3,
                            backgroundColor: "#ffffff",
                            borderRadius: 4,
                            width: { xs: "100%", md: "380px" },
                            maxWidth: "420px",
                            minHeight: "440px",
                            height: "auto",
                            position: "relative",
                            overflow: "visible",
                            border: "1px solid rgba(25, 118, 210, 0.1)",
                            transition: "all 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
                            transform: cardHovered ? "translateY(-6px) scale(1.015)" : "translateY(0) scale(1)",
                            boxShadow: cardHovered
                                ? "0 16px 48px rgba(25, 118, 210, 0.26)"
                                : "0 8px 30px rgba(25, 118, 210, 0.14)",
                            "&::after": {
                                content: '""',
                                position: "absolute",
                                top: "50%",
                                left: "50%",
                                width: cardHovered ? "100%" : "0%",
                                height: cardHovered ? "100%" : "0%",
                                background:
                                    "radial-gradient(circle, rgba(25, 118, 210, 0.05) 0%, transparent 70%)",
                                transform: "translate(-50%, -50%)",
                                transition: "all 0.4s ease",
                                borderRadius: "50%"
                            }
                        }}
                    >
                        {/* PDM Logo smaller */}
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: "center",
                                mb: 2,
                                animation: "pdmPulse 2s ease-in-out infinite",
                                "@keyframes pdmPulse": {
                                    "0%": { transform: "scale(1)" },
                                    "50%": { transform: "scale(1.04)" },
                                    "100%": { transform: "scale(1)" }
                                }
                            }}
                        >
                            <img
                                src={pdmLogo}
                                alt="PDM Logo"
                                style={{
                                    width: "100%",
                                    maxWidth: "260px",
                                    height: "auto",
                                    objectFit: "contain"
                                }}
                            />
                        </Box>

                        <Divider sx={{ mb: 2.25, position: "relative", zIndex: 2 }}>
                            <Chip
                                icon={<LockIcon sx={{ fontSize: 16 }} />}
                                label="Secure Authentication"
                                size="small"
                                sx={{
                                    backgroundColor: "#e3f2fd",
                                    color: "#1976d2",
                                    fontWeight: 700,
                                    border: "1px solid rgba(25, 118, 210, 0.2)",
                                    fontSize: "0.75rem",
                                    height: 24,
                                    "@keyframes chipGlow": {
                                        "0%": { boxShadow: "0 0 4px rgba(25, 118, 210, 0.28)" },
                                        "100%": { boxShadow: "0 0 10px rgba(25, 118, 210, 0.45)" }
                                    }
                                }}
                            />
                        </Divider>

                        {/* Error Alert (compact) */}
                        {error && (
                            <Zoom in={!!error}>
                                <Alert
                                    severity="error"
                                    sx={{
                                        mb: 2,
                                        borderRadius: 2,
                                        position: "relative",
                                        zIndex: 2,
                                        animation: "errorShake 0.45s ease-in-out"
                                    }}
                                    action={
                                        <IconButton size="small" onClick={() => setError("")}>
                                            <CloseIcon fontSize="small" />
                                        </IconButton>
                                    }
                                >
                                    {error}
                                </Alert>
                            </Zoom>
                        )}

                        {/* Description (compact) */}
                        <Box sx={{ mb: 2, textAlign: "center", position: "relative", zIndex: 2 }}>
                            <Typography
                                variant="body2"
                                sx={{
                                    mb: 1.5,
                                    color: "#555",
                                    lineHeight: 1.5,
                                    fontSize: "0.9rem"
                                }}
                            >
                                Use your Nokia enterprise credentials to securely access the PDM Smart View
                                platform with complete data protection.
                            </Typography>

                            {/* Mini features */}
                            <Stack direction="row" spacing={1.25} sx={{ mb: 1.5, justifyContent: "center" }}>
                                {[
                                    {
                                        icon: <SecurityIcon2 sx={{ fontSize: 18 }} />,
                                        label: "Multi-Factor",
                                        color: "#ff9800"
                                    },
                                    {
                                        icon: <VisibilityIcon sx={{ fontSize: 18 }} />,
                                        label: "Real-time Monitor",
                                        color: "#2196f3"
                                    }
                                ].map((feature, index) => (
                                    <Box
                                        key={index}
                                        sx={{
                                            p: 1.1,
                                            borderRadius: 2,
                                            background: `linear-gradient(135deg, ${feature.color}10, ${feature.color}05)`,
                                            border: `1px solid ${feature.color}30`,
                                            textAlign: "center",
                                            transition: "all 0.25s ease",
                                            animation: `featureAnimation${index} 3s ease-in-out infinite`,
                                            "&:hover": {
                                                transform: "translateY(-1px)",
                                                boxShadow: `0 4px 12px ${feature.color}30`
                                            },
                                            [`@keyframes featureAnimation${index}`]: {
                                                "0%, 100%": { transform: "scale(1)" },
                                                "50%": { transform: "scale(1.03)" }
                                            }
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                color: feature.color,
                                                mb: 0.4,
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center",
                                                filter: `drop-shadow(0 0 1px ${feature.color})`
                                            }}
                                        >
                                            {feature.icon}
                                        </Box>
                                        <Typography
                                            variant="caption"
                                            sx={{
                                                color: feature.color,
                                                fontWeight: 600,
                                                fontSize: "0.72rem"
                                            }}
                                        >
                                            {feature.label}
                                        </Typography>
                                    </Box>
                                ))}
                            </Stack>
                        </Box>

                        {/* Login Button (compact) */}
                        <Box sx={{ position: "relative", mb: 2.5, zIndex: 2 }}>
                            <Button
                                onClick={handleLogin}
                                disabled={isLoading}
                                variant="contained"
                                fullWidth
                                size="medium"
                                onMouseEnter={() => setButtonHovered(true)}
                                onMouseLeave={() => setButtonHovered(false)}
                                sx={{
                                    backgroundColor: isLoading ? "#bdbdbd" : "#1976d2",
                                    py: 1.2,
                                    fontSize: "0.98rem",
                                    fontWeight: 700,
                                    borderRadius: 3,
                                    textTransform: "none",
                                    position: "relative",
                                    overflow: "hidden",
                                    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                                    transform:
                                        buttonHovered && !isLoading ? "translateY(-1px) scale(1.01)" : "translateY(0) scale(1)",
                                    boxShadow:
                                        buttonHovered && !isLoading
                                            ? "0 10px 28px rgba(25, 118, 210, 0.34)"
                                            : "0 6px 18px rgba(25, 118, 210, 0.18)",
                                    "&::before": {
                                        content: '""',
                                        position: "absolute",
                                        top: "50%",
                                        left: isLoading ? "50%" : buttonHovered ? "50%" : "-50%",
                                        width: isLoading ? "100%" : buttonHovered ? "100%" : "0%",
                                        height: isLoading ? "100%" : buttonHovered ? "100%" : "0%",
                                        background: isLoading
                                            ? "none"
                                            : "radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%)",
                                        borderRadius: "50%",
                                        transform: "translate(-50%, -50%)",
                                        transition: "all 0.45s ease"
                                    },
                                    "&:hover": {
                                        backgroundColor: isLoading ? "#bdbdbd" : "#1565c0"
                                    }
                                }}
                                startIcon={
                                    isLoading ? (
                                        <CircularProgress
                                            size={20}
                                            sx={{
                                                color: "#fff",
                                                filter: "drop-shadow(0 0 4px rgba(255, 255, 255, 0.4))"
                                            }}
                                        />
                                    ) : (
                                        <LoginIcon
                                            sx={{
                                                fontSize: 22,
                                                transition: "all 0.25s ease"
                                            }}
                                        />
                                    )
                                }
                            >
                                {isLoading ? "Authenticating..." : "Sign In with Nokia SSO"}
                            </Button>

                            {/* Button glow */}
                            {!isLoading && buttonHovered && (
                                <Box
                                    sx={{
                                        position: "absolute",
                                        top: "50%",
                                        left: "50%",
                                        width: "110%",
                                        height: "110%",
                                        background: "radial-gradient(circle, rgba(25, 118, 210, 0.09) 0%, transparent 70%)",
                                        transform: "translate(-50%, -50%)",
                                        borderRadius: 3,
                                        zIndex: -1,
                                        animation: "buttonGlow 1s ease-in-out infinite alternate",
                                        "@keyframes buttonGlow": {
                                            "0%": { opacity: 0.5, transform: "translate(-50%, -50%) scale(1)" },
                                            "100%": { opacity: 1, transform: "translate(-50%, -50%) scale(1.06)" }
                                        }
                                    }}
                                />
                            )}
                        </Box>
                    </Paper>
                </Slide>
            </Container>

            {/* Footer (slimmer) */}
            <Box
                sx={{
                    backgroundColor: "#f8f9fa",
                    borderTop: "1px solid #e0e0e0",
                    py: 1.25,
                    textAlign: "center",
                    position: "relative",
                    zIndex: 10
                }}
            >
                <Container>
                    <Typography
                        variant="body2"
                        sx={{ color: "#666", fontWeight: 500, mb: 0.25, fontSize: "0.85rem" }}
                    >
                        © 2025 Nokia Corporation. All rights reserved.
                    </Typography>
                    <Typography variant="caption" sx={{ color: "#888", fontSize: "0.72rem" }}>
                        Enterprise PDM Solution v2.0 | Privacy Policy | Terms of Service
                    </Typography>
                </Container>
            </Box>
        </Box>
    );
};

export default LoginPage;
