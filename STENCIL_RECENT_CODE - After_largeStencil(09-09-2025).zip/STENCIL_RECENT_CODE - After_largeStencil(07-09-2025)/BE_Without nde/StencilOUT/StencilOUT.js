import { conConfig } from "../db.js";
import sql from "mssql";


export const getPartCodeData = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    const getPartCode = await pool
      .request()
      .query(`SELECT DISTINCT 
                st.[PartNumber], 
                st.[Product], 
                st.[Side], 
                st.[StencilThickness], 
                st.[StencilTension], 
                st.[Remarks], 
                DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                st.StencilID, 
                st.BarcodeID, 
                COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
              FROM StencilTable st
              LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
              LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
              LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
              LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]
              WHERE st.Status = 1`);
    return res.status(200).json(getPartCode.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch part codes" });
  }
};


export const getBarcodeIDData = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    console.log("Inhere");
    const getbarCode = await pool
      .request()
      .query(`Select distinct [BarcodeID] from StencilTable`);
    const barCodes = getbarCode.recordset;
    console.log(barCodes);
    return res.status(200).json(barCodes);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch part codes" });
  }
};
export const getProductNameData = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    const getProductName = await pool
      .request()
      .query(`SELECT DISTINCT 
                st.[Product], 
                st.[Side], 
                st.[PartNumber], 
                st.[StencilThickness], 
                st.[StencilTension], 
                st.[Remarks], 
                DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                st.StencilID, 
                st.BarcodeID, 
                COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
              FROM StencilTable st
              LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
              LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
              LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
              LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]
              WHERE st.Status = 1`);
    return res.status(200).json(getProductName.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch product names" });
  }
};
export const getallStencilIDData = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    const getStencilID = await pool
      .request()
      .query(`SELECT DISTINCT 
                st.[StencilID], 
                st.[Product], 
                st.[Side], 
                st.[PartNumber], 
                st.[StencilThickness], 
                st.[StencilTension], 
                st.[Remarks], 
                DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                st.BarcodeID, 
                COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
              FROM StencilTable st
              LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
              LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
              LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
              LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]
              WHERE st.Status = 1`);
    return res.status(200).json(getStencilID.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch stencil IDs" });
  }
};

export const getSelectedPartCodeData = async (req, res) => {
  // Destructure and trim input values
  let partCode = req.body.partCode?.trim();
  let stencilId = req.body.stencilId?.trim();
  let Product = req.body.Product?.trim();

  console.log(partCode, stencilId, Product);

  try {
    const pool = await sql.connect(conConfig);
    let query = `
      SELECT Product, Side, PartNumber, StencilID, BarcodeID, Rackno
      FROM StencilTable
      WHERE (Blocked IS NULL OR Blocked = 0)
        AND (Scrap IS NULL OR Scrap = 0)
        AND Status = 1
    `;

    const conditions = [];
    const params = {};

    if (partCode) {
      conditions.push(`PartNumber = @partCode`);
      params.partCode = partCode;
    }
    if (stencilId) {
      conditions.push(`StencilID = @stencilId`);
      params.stencilId = stencilId;
    }
    if (Product) {
      conditions.push(`Product = @Product`);
      params.Product = Product;
    }

    // Append dynamic filters
    if (conditions.length > 0) {
      query += ` AND (${conditions.join(' AND ')})`;
    }

    const request = pool.request();
    Object.keys(params).forEach(key => {
      request.input(key, params[key]);
    });

    const getData = await request.query(query);
    return res.status(200).json(getData.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch part code data" });
  }
};


export const getSelectedPartCodeDataBlock = async (req, res) => {
  let partCode = req.body.partCode?.trim(); // Trim leading and trailing spaces

  console.log("Part Code Received:", partCode);

  try {
    const pool = await sql.connect(conConfig);
    const getData = await pool
      .request()
      .input('partCode', sql.VarChar, partCode)
      .query(`
        SELECT 
          st.Product, 
          st.Side, 
          st.PartNumber, 
          st.BarcodeID, 
          st.Blocked, 
          st.StencilID, 
          st.Scrap, 
          st.Rackno,
          COALESCE(rs1.PhysicalLocation, rs2.PhysicalLocation, rs3.PhysicalLocation, rs4.PhysicalLocation) AS PhysicalLocation
        FROM StencilTable st
        LEFT JOIN stencilRackStatus rs1 ON rs1.Rack_id = st.RackID
        LEFT JOIN stencilRackStatus1_copy rs2 ON rs2.Rack_id = st.RackID2
        LEFT JOIN stencilRackStatus2_copy rs3 ON rs3.Rack_id = st.RackID3
        LEFT JOIN stencilRackStatus3_copy rs4 ON rs4.Rack_id = st.RackID4
        WHERE st.PartNumber = @partCode
      `);

    if (getData.recordset.length === 0) {
      return res.status(404).json({ error: "No data found for the specified part code" });
    }

    return res.status(200).json(getData.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch part code data" });
  }
};




// export const LightUpStencil = async (req, res) => {
//   const barcode = req.body.barcode;
//   console.log("barcode", barcode);

//   try {
//     const pool = await sql.connect(conConfig);
//     const updateAuthorized = await pool
//       .request()
//       .query(
//         `Update StencilTable set AuthorizedOut = 1 where BarcodeID = '${barcode}'`
//       );
//     const getLedId = await pool
//       .request()
//       .query(
//         `SELECT LedID,RackID from StencilTable where BarcodeID = '${barcode}'`
//       );
//     const ledId = String(getLedId.recordset[0].LedID);
//     const RackID = String(getLedId.recordset[0].RackID);
//     console.log("ledId", ledId);
//     const lightup = await pool
//       .request()
//       .input("LedId", sql.VarChar, ledId)
//       .query(
//         `Update [StencilLEDStatus] set [LEDRackStatus] =3 where [LEDRack_id] = @LedId`
//       );

//     const lightuptower = await pool
//       .request()
//       .input("LedId", sql.VarChar, ledId)
//       .query(
//         `Update [StencilLEDStatus] set [LEDRackStatus] =1 where [LEDRack_id] = 2`
//       );
//     const getRackStatus = await pool
//       .request()
//       .query(`Select data from [tblRackSensorInput]`);
//     const rackBit = getRackStatus.recordset[0].data;

//     const getPhysicalLoc = await pool
//       .request()
//       .query(
//         `Select [PhysicalLocation] from [stencilRackStatus] where [Rack_id] = '${RackID}'`
//       );

//     const physicalloc = getPhysicalLoc.recordset[0].PhysicalLocation;

//     return res.status(200).json({
//       ledId: ledId,
//       RackID: RackID,
//       rackBit: rackBit,
//       barcode: barcode,
//       physicalLocation: physicalloc,
//     });
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({ error: "Failed to LightUp" });
//   }
// };

// getRackStatus remains unchanged as it already handles all racks


export const getRackStatusindi = async (req, res) => {
  console.log(req.body);
  try {
    const barcode = req.body.barcode;
    const pool = await sql.connect(conConfig);

    // Get Rackno, RackID, and RackIDB from StencilTable
    const getRackno = await pool
      .request()
      .query(
        `SELECT Rackno,
                CASE Rackno 
                  WHEN 'Rack-1' THEN RackID 
                  WHEN 'Rack-2' THEN RackID2 
                  WHEN 'Rack-3' THEN RackID3 
                  WHEN 'Rack-4' THEN RackID4 
                END AS RackID,
                CASE Rackno 
                  WHEN 'Rack-3' THEN RackID3B 
                  WHEN 'Rack-4' THEN RackID4B 
                  ELSE NULL 
                END AS RackIDB
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackno.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, RackID, RackIDB } = getRackno.recordset[0];

    if (!Rackno) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Determine the correct stencilRackStatus table based on Rackno
    const rackStatusTableMap = {
      "Rack-1": "stencilRackStatus",
      "Rack-2": "stencilRackStatus1_copy",
      "Rack-3": "stencilRackStatus2_copy",
      "Rack-4": "stencilRackStatus3_copy",
    };
    const rackStatusTable = rackStatusTableMap[Rackno];

    if (!rackStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Get RackStatus for primary and paired (if applicable) Rack_id
    const rackIdsToCheck = [RackID];
    if (RackIDB) {
      rackIdsToCheck.push(RackIDB);
    }

    const getRackStatus = await pool
      .request()
      .input("RackId1", sql.VarChar, rackIdsToCheck[0])
      .input("RackId2", sql.VarChar, rackIdsToCheck[1] || null)
      .query(
        `SELECT RackStatus FROM [${rackStatusTable}] 
         WHERE [Rack_id] IN (@RackId1${rackIdsToCheck[1] ? ', @RackId2' : ''})`
      );

    // If paired, check both positions; status is "1" only if both are "1"
    const statuses = getRackStatus.recordset.map(row => row.RackStatus);
    const currentStatus = rackIdsToCheck.length > 1 ? (statuses.every(s => s === "1") ? "1" : "0") : statuses[0] || "";
    return res.status(200).json({ currentStatus: currentStatus });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to get RackStatus" });
  }
};

export const getRackNo = async (req, res) => {
  try {
    const barcode = req.body.barcode;
    const pool = await sql.connect(conConfig);
    const result = await pool
      .request()
      .query(`SELECT Rackno FROM [StencilTable] WHERE BarcodeID = '${barcode}'`);
    
    if (result.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    return res.status(200).json({ Rackno: result.recordset[0].Rackno });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to fetch Rackno" });
  }
};



export const updateOperatorId = async (req, res) => {

  const { stencilId, partNumber, barcodeId, operatorId } = req.body;

 

  console.log("Received request body:", req.body);  // Log the entire request body

  console.log("stencilId:", stencilId);  // Log stencilId

  console.log("partNumber:", partNumber);  // Log partNumber

  console.log("barcodeId:", barcodeId);  // Log barcodeId

  console.log("operatorId:", operatorId);  // Log operatorId

 

  if ((!stencilId && !partNumber && !barcodeId) || !operatorId) {

    console.log("At least one ID (Stencil ID, Part Number, or Barcode ID) and Operator ID are required.");

    return res.status(400).json({ message: "ID and Operator ID are required." });

  }

 

  try {

    const pool = await sql.connect(conConfig);

    let result;

 

    if (stencilId) {

      result = await pool.request()

        .input("StencilID", sql.NVarChar, stencilId)

        .input("OperatorID", sql.NVarChar, operatorId)

        .query(`

          UPDATE [StencilTable]

          SET Operator_id = @OperatorID

          WHERE StencilID = @StencilID

        `);

    } else if (partNumber) {

      result = await pool.request()

        .input("PartNumber", sql.NVarChar, partNumber)

        .input("OperatorID", sql.NVarChar, operatorId)

        .query(`

          UPDATE [StencilTable]

          SET Operator_id = @OperatorID

          WHERE PartNumber = @PartNumber

        `);

    } else if (barcodeId) {

      result = await pool.request()

        .input("BarcodeID", sql.NVarChar, barcodeId)

        .input("OperatorID", sql.NVarChar, operatorId)

        .query(`

          UPDATE [StencilTable]

          SET Operator_id = @OperatorID

          WHERE BarcodeID = @BarcodeID

        `);

    }

 

    // Check if the update affected any rows

    if (result.rowsAffected[0] > 0) {

      console.log("Operator ID updated successfully.");

      res.json({ message: "Operator ID updated successfully." });

    } else {

      console.log("Record not found.");

      res.status(404).json({ message: "Record not found." });

    }

  } catch (error) {

    console.error("Error updating Operator ID:", error);

    res.status(500).json({ message: "Server error." });

  }

};
export const LightUpStencil = async (req, res) => {
  const barcode = req.body.barcode;
  console.log("barcode", barcode);

  try {
    const pool = await sql.connect(conConfig);

    // Get Rackno, LedID, RackID, and paired columns from StencilTable
    const getRackInfo = await pool
      .request()
      .query(
        `SELECT Rackno, 
                CASE Rackno 
                  WHEN 'Rack-1' THEN LedID 
                  WHEN 'Rack-2' THEN LedID2 
                  WHEN 'Rack-3' THEN LedID3 
                  WHEN 'Rack-4' THEN LedID4 
                END AS LedID,
                CASE Rackno 
                  WHEN 'Rack-1' THEN RackID 
                  WHEN 'Rack-2' THEN RackID2 
                  WHEN 'Rack-3' THEN RackID3 
                  WHEN 'Rack-4' THEN RackID4 
                END AS RackID,
                CASE Rackno 
                  WHEN 'Rack-3' THEN RackID3B 
                  WHEN 'Rack-4' THEN RackID4B 
                  ELSE NULL 
                END AS RackIDB,
                CASE Rackno 
                  WHEN 'Rack-3' THEN LedID3B 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedIDB
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackInfo.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID, RackID, RackIDB, LedIDB } = getRackInfo.recordset[0];
    console.log("Rackno:", Rackno, "LedID:", LedID, "RackID:", RackID, "RackIDB:", RackIDB, "LedIDB:", LedIDB);

    if (!Rackno || !LedID || !RackID) {
      return res.status(400).json({ error: "Invalid rack or LED data" });
    }

    // Update AuthorizedOut, Status, and Authorized in StencilTable
    await pool
      .request()
      .query(
        `UPDATE [StencilTable] 
         SET AuthorizedOut = 1, 
             [Status] = 0, 
             [Authorized] = 0,
             LastOutDate = GETDATE() 
         WHERE BarcodeID = '${barcode}'`
      );

    // Determine the correct StencilLEDStatus table based on Rackno
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Update LEDRackStatus in the appropriate StencilLEDStatus table
    await pool
      .request()
      .input("LedId", sql.VarChar, LedID)
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 3 
         WHERE [LEDRack_id] = @LedId`
      );

    // Update LEDRackStatus for paired LED if applicable (Rack-3 or Rack-4)
    if (( Rackno === 'Rack-4') && LedIDB) {
      await pool
        .request()
        .input("LedIdB", sql.VarChar, LedIDB)
        .query(
          `UPDATE [${ledStatusTable}] 
           SET [LEDRackStatus] = 3 
           WHERE [LEDRack_id] = @LedIdB`
        );
    }

    // MODIFIED: Update LEDRackStatus = 1 only where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 1 
         WHERE [PhysicalLocation] = 'Y'`
      );

    // Get rack status from tblRackSensorInput
    const getRackStatus = await pool
      .request()
      .query(
        `SELECT data FROM [tblRackSensorInput] 
         WHERE rackid = '${Rackno}'`
      );
    const rackBit = getRackStatus.recordset[0]?.data || "";

    // Determine the correct stencilRackStatus table based on Rackno
    const rackStatusTableMap = {
      "Rack-1": "stencilRackStatus",
      "Rack-2": "stencilRackStatus1_copy",
      "Rack-3": "stencilRackStatus2_copy",
      "Rack-4": "stencilRackStatus3_copy",
    };
    const rackStatusTable = rackStatusTableMap[Rackno];

    // Get PhysicalLocation from the appropriate stencilRackStatus table
    const getPhysicalLoc = await pool
      .request()
      .query(
        `SELECT [PhysicalLocation] 
         FROM [${rackStatusTable}] 
         WHERE [Rack_id] = '${RackID}'`
      );
    const physicalloc = getPhysicalLoc.recordset[0]?.PhysicalLocation || "";

    // Get PairedPhysicalLocation for Rack-3 or Rack-4
    let pairedPhysicalLoc = null;
    if (( Rackno === 'Rack-4') && RackIDB) {
      const getPairedPhysicalLoc = await pool
        .request()
        .query(
          `SELECT [PhysicalLocation] 
           FROM [${rackStatusTable}] 
           WHERE [Rack_id] = '${RackIDB}'`
        );
      pairedPhysicalLoc = getPairedPhysicalLoc.recordset[0]?.PhysicalLocation || null;
    }

    // Update PhysicalLocation and PairedPhysicalLocation in OperationHistoryN
    await pool
      .request()
      .input("PhysicalLocation", sql.VarChar, physicalloc)
      .input("PairedPhysicalLocation", sql.VarChar, pairedPhysicalLoc)
      .input("BarcodeID", sql.VarChar, barcode)
      .query(
        `UPDATE [OperationHistoryN]
         SET PhysicalLocation = @PhysicalLocation,
             PairedPhysicalLocation = @PairedPhysicalLocation
         WHERE ID = (
           SELECT TOP 1 ID
           FROM [OperationHistoryN]
           WHERE StencilBarcodeID = @BarcodeID
           ORDER BY UpdatedDateTime DESC
         )`
      );

    // Respond with updated information
    return res.status(200).json({
      ledId: LedID,
      RackID: RackID,
      rackBit: rackBit,
      barcode: barcode,
      physicalLocation: physicalloc,
      pairedPhysicalLocation: pairedPhysicalLoc,
      Rackno: Rackno,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to LightUp" });
  }
};


export const updateEmptyStencilData = async (req, res) => {
  try {
    const barcode = req.body.barcode;
    const pool = await sql.connect(conConfig);

    // Get Rackno, LedID, and LedIDB from StencilTable
    const getRackno = await pool
      .request()
      .query(
        `SELECT Rackno,
                CASE Rackno 
                  WHEN 'Rack-1' THEN LedID 
                  WHEN 'Rack-2' THEN LedID2 
                  WHEN 'Rack-3' THEN LedID3 
                  WHEN 'Rack-4' THEN LedID4 
                END AS LedID,
                CASE Rackno 
                  WHEN 'Rack-3' THEN LedID3B 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedIDB
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackno.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID, LedIDB } = getRackno.recordset[0];

    if (!Rackno) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Determine the correct StencilLEDStatus table based on Rackno
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // MODIFIED: Update LEDRackStatus to 0 where PhysicalLocation = 'Y' and for primary/paired LEDs
    const ledIdsToUpdate = [LedID];
    if (LedIDB) {
      ledIdsToUpdate.push(LedIDB);
    }

    // Turn off LEDs for primary and paired LEDs
    await pool
      .request()
      .input("LedId1", sql.VarChar, ledIdsToUpdate[0])
      .input("LedId2", sql.VarChar, ledIdsToUpdate[1] || null)
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] IN (@LedId1${ledIdsToUpdate[1] ? ', @LedId2' : ''})`
      );

    // Turn off LED where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [PhysicalLocation] = 'Y'`
      );

    return res.status(200).json({ success: "success" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to Empty" });
  }
};


export const removeWrongStencil = async (req, res) => {
  const pool = await sql.connect(conConfig);
  const barcode = req.body.barcode;
  console.log("barcode", barcode);

  try {
    // Get Rackno, LedID, and LedIDB from StencilTable
    const getRackInfo = await pool
      .request()
      .query(
        `SELECT Rackno, 
                CASE Rackno 
                  WHEN 'Rack-1' THEN LedID 
                  WHEN 'Rack-2' THEN LedID2 
                  WHEN 'Rack-3' THEN LedID3 
                  WHEN 'Rack-4' THEN LedID4 
                END AS LedID,
                CASE Rackno 
                  WHEN 'Rack-3' THEN LedID3B 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedIDB
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackInfo.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID, LedIDB } = getRackInfo.recordset[0];
    console.log("Rackno:", Rackno, "LedID:", LedID, "LedIDB:", LedIDB);

    if (!Rackno || !LedID) {
      return res.status(400).json({ error: "Invalid Rackno or LedID" });
    }

    // Determine the correct StencilLEDStatus table based on Rackno
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Switch off the LED for the stencil, paired LED (if applicable), and where PhysicalLocation = 'Y'
    const ledIdsToUpdate = [LedID];
    if (LedIDB) {
      ledIdsToUpdate.push(LedIDB);
    }

    // Turn off primary and paired LEDs
    await pool
      .request()
      .input("LedId1", sql.VarChar, ledIdsToUpdate[0])
      .input("LedId2", sql.VarChar, ledIdsToUpdate[1] || null)
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] IN (@LedId1${ledIdsToUpdate[1] ? ', @LedId2' : ''})`
      );

    // MODIFIED: Turn off LED where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [PhysicalLocation] = 'Y'`
      );

    // Find Rack_id where RackStatus = 1 and stencil exists
    const rackStatusTableMap = {
      "Rack-1": "stencilRackStatus",
      "Rack-2": "stencilRackStatus1_copy",
      "Rack-3": "stencilRackStatus2_copy",
      "Rack-4": "stencilRackStatus3_copy",
    };
    const rackStatusTable = rackStatusTableMap[Rackno];

    const getRackId = await pool
      .request()
      .query(
        `SELECT Rack_id 
         FROM [${rackStatusTable}] 
         WHERE RackStatus = 1 
         AND EXISTS (
           SELECT 1 
           FROM [StencilTable] B 
           WHERE B.Rackno = '${Rackno}' 
           AND (
             (B.RackID =  [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-1') OR 
             (B.RackID2 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-2') OR 
             (B.RackID3 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-3') OR 
             (B.RackID4 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-4')
           )
         )`
      );

    if (getRackId.recordset.length === 0) {
      return res.status(404).json({ error: "No active rack found" });
    }

    // MODIFIED: Turn on light and sound (LEDRack_id 1 and 4) and where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 1 
         WHERE [LEDRack_id] IN (1, 4)`
      );

    // Turn on LED where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 1 
         WHERE [PhysicalLocation] = 'Y'`
      );

    await new Promise((resolve) => setTimeout(resolve, 2000));
    console.log("Light up");

    // MODIFIED: Turn off light and sound (LEDRack_id 4) and where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] = 4`
      );

    // Turn off LED where PhysicalLocation = 'Y'
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [PhysicalLocation] = 'Y'`
      );
    
    console.log("Light off");

    return res.status(200).json({ success: "success" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to remove data" });
  }
};