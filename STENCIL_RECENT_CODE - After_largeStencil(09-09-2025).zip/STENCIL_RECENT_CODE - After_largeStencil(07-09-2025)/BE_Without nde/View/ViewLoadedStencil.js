import { conConfig } from "../db.js";
import sql from "mssql";

export const getStencils = async (req, res) => {
  const { fromMaintenance_updated_datetime, toMaintenance_updated_datetime } = req.body;
  try {
    const pool = await sql.connect(conConfig);
    let query = `
      SELECT 
        st.[Product],
        st.[Side],
        st.[PartNumber],
        st.[StencilThickness],
        st.[StencilTension],
        st.[Remarks],
        DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime,
        DATEADD(minute, -330, st.[LastINDate]) AS LastINDate,
        st.StencilID,
        st.BarcodeID,
        st.Rackno,

        -- Physical location from multiple rack status tables
        COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation,

        -- PairedPhysicalLocation only from rs4.PhysicalLocation mapping
        led.[PairedPhysicalLocation],

        -- Logic for AvailableStatus
        CASE 
          WHEN st.Scrap = 1 THEN 'Scrap'
          WHEN st.Blocked = 1 THEN 'Blocked'
          ELSE 'Available'
        END AS AvailableStatus

      FROM StencilTable st
      LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
      LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
      LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
      LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]

      -- Join StencilLEDStatus3 ONLY using rs4.PhysicalLocation
      LEFT JOIN [StencilLEDStatus3] led 
        ON led.[PhysicalLocation] = rs4.[PhysicalLocation]

      WHERE st.Status = 1
    `;

    const filters = [];
    if (fromMaintenance_updated_datetime) {
      filters.push(`st.[Maintenance_updated_datetime] >= DATEADD(minute, 330, @fromMaintenance_updated_datetime)`);
    }
    if (toMaintenance_updated_datetime) {
      filters.push(`st.[Maintenance_updated_datetime] <= DATEADD(minute, 330, @toMaintenance_updated_datetime)`);
    }

    if (filters.length > 0) {
      query += ' AND ' + filters.join(' AND ');
    }

    // Order by LastINDate in descending order
    query += ` ORDER BY st.[LastINDate] DESC`;

    const request = pool.request();
    if (fromMaintenance_updated_datetime) {
      request.input('fromMaintenance_updated_datetime', sql.DateTime, new Date(fromMaintenance_updated_datetime));
    }
    if (toMaintenance_updated_datetime) {
      request.input('toMaintenance_updated_datetime', sql.DateTime, new Date(toMaintenance_updated_datetime));
    }

    const getData = await request.query(query);
    console.log("Fetched data:", getData.recordset);
    res.json(getData.recordset);
  } catch (err) {
    console.error("Error fetching data from database:", err);
    res.status(500).send("Server error");
  }
};



 
 
 
 
export const GetExportdatas = async (req, res) => {
  const { fromMaintenance_updated_datetime, toMaintenance_updated_datetime } = req.body;
 
  try {
    const pool = await sql.connect(conConfig);
 
    // Start building the base SQL query
    let query = `
      SELECT
        st.[Product],
        st.[Side],
        st.[PartNumber],
        st.[DateofManufacturing],
        st.[SupplierPartNumber],
        st.[StencilThickness],
        st.[Remarks],
        st.[ModuleCode],
        st.[LastINDate],
        st.[LastOutDate],
        st.[ModifiedUserID],
        st.[StencilTension],
        st.[LastModifiedDate],
        DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, -- Adjust by -5:30 hours
        st.StencilID,
        st.BarcodeID,
        CASE
          WHEN st.[Blocked] = 1 THEN 'Blocked'
          WHEN st.[Scrap] = 1 THEN 'Scraped'
          ELSE 'Available'
        END AS StatusOfStencil
      FROM
        StencilTable st
    `;
 
    // Create an array for filters
    const filters = [];
 
    // Check if filters are provided and add to the filters array
    if (fromMaintenance_updated_datetime) {
      filters.push("[Maintenance_updated_datetime] >= @fromMaintenance_updated_datetime");
    }
    if (toMaintenance_updated_datetime) {
      filters.push("[Maintenance_updated_datetime] <= @toMaintenance_updated_datetime");
    }
 
    // Append filters to query if any exist
    if (filters.length > 0) {
      query += ' WHERE ' + filters.join(' AND ');
    }
 
    // Add custom ordering to prioritize non-null LastModifiedDate
    query += `
      ORDER BY
        CASE
          WHEN [LastModifiedDate] IS NOT NULL THEN 1
          ELSE 2
        END ASC, -- Prioritize non-NULL values first
        [LastModifiedDate] DESC, -- Sort by LastModifiedDate in descending order
        [Maintenance_updated_datetime] DESC -- Then by Maintenance_updated_datetime in descending order
    `;
 
    const request = pool.request();
 
    // Add inputs to request based on filters
    if (fromMaintenance_updated_datetime) {
      request.input('fromMaintenance_updated_datetime', sql.DateTime, new Date(fromMaintenance_updated_datetime));
    }
    if (toMaintenance_updated_datetime) {
      request.input('toMaintenance_updated_datetime', sql.DateTime, new Date(toMaintenance_updated_datetime));
    }
 
    // Execute the query
    const getData = await request.query(query);
    console.log("Fetched data:", getData.recordset);
    res.json(getData.recordset); // Return the result as JSON
  } catch (err) {
    console.error("Error fetching data from database:", err);
    res.status(500).send("Server error"); // Respond with a 500 error
  }
};
 
 export const getrackdataformaintainance = async (req, res) => {
  const { fromMaintenance_updated_datetime, toMaintenance_updated_datetime, rackno } = req.body;

  try {
    const pool = await sql.connect(conConfig);

    // Base query with correctly aliased joins
    let query = `
      SELECT 
        st.[Product],
        st.[Side],
        st.[PartNumber],
        st.[StencilThickness],
        st.[StencilTension],
        st.[Remarks],
        DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime,
        st.StencilID,
        st.BarcodeID,
        st.Rackno,
        COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
      FROM StencilTable st
      LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
      LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
      LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
      LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]
      WHERE st.Status = 1
    `;

    const filters = [];

    // Add date filters with timezone adjustment
    if (fromMaintenance_updated_datetime) {
      filters.push(`st.[Maintenance_updated_datetime] >= DATEADD(minute, 330, @fromMaintenance_updated_datetime)`);
    }
    if (toMaintenance_updated_datetime) {
      filters.push(`st.[Maintenance_updated_datetime] <= DATEADD(minute, 330, @toMaintenance_updated_datetime)`);
    }

    // Add rack number filter
    if (rackno) {
      filters.push(`st.[Rackno] = @rackno`);
    }

    if (filters.length > 0) {
      query += ' AND ' + filters.join(' AND ');
    }

    query += ` ORDER BY st.[Maintenance_updated_datetime] DESC`;

    const request = pool.request();

    if (fromMaintenance_updated_datetime) {
      request.input('fromMaintenance_updated_datetime', sql.DateTime, new Date(fromMaintenance_updated_datetime));
    }
    if (toMaintenance_updated_datetime) {
      request.input('toMaintenance_updated_datetime', sql.DateTime, new Date(toMaintenance_updated_datetime));
    }
    if (rackno) {
      request.input('rackno', sql.VarChar, rackno);
    }

    const getData = await request.query(query);
    console.log("Fetched data:", getData.recordset);
    res.json(getData.recordset);
  } catch (err) {
    console.error("Error fetching data from database:", err);
    res.status(500).send("Server error");
  }
};