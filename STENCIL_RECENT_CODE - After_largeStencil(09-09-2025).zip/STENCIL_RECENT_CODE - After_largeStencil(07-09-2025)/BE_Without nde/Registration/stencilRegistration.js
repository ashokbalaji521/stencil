import { conConfig } from "../db.js";
import sql from "mssql";
 
export const insertStencilData = async (req, res) => {
  const {
    productName,
    pcbPartNumber,
    stencilID,
    barcodeID,
    topBottom,
    date,
    stencilTensions,
    remarks,
    supplierPartNumber,
    stencilThickness,
    moduleCode,
    ModifiedUserID,
  } = req.body;

  console.log(ModifiedUserID);

  try {
    const pool = await sql.connect(conConfig);

    // Check if the barcodeID already exists
    const existingBarcode = await pool
      .request()
      .input("barcodeID", sql.NVarChar, barcodeID)
      .query("SELECT COUNT(*) AS count FROM [dbo].[StencilTable] WHERE [BarcodeID] = @barcodeID");

    if (existingBarcode.recordset[0].count > 0) {
      return res.status(400).json({ message: "This barcodeID is already present." });
    }

    // Convert array to string if necessary
    const tensionsString = Array.isArray(stencilTensions)
      ? stencilTensions.join(", ")
      : "";

    // Execute insert query
    await pool
      .request()
      .input("productName", sql.NVarChar, productName)
      .input("pcbPartNumber", sql.NVarChar, pcbPartNumber)
      .input("stencilID", sql.NVarChar, stencilID)
      .input("barcodeID", sql.NVarChar, barcodeID)
      .input("topBottom", sql.NVarChar, topBottom)
      .input("date", sql.DateTime, new Date(date))
      .input("stencilTensions", sql.NVarChar, tensionsString)
      .input("remarks", sql.NVarChar, remarks)
      .input("supplierPartNumber", sql.NVarChar, supplierPartNumber)
      .input("stencilThickness", sql.NVarChar, stencilThickness)
      .input("moduleCode", sql.NVarChar, moduleCode)
      .input("ModifiedUserID", sql.NVarChar, ModifiedUserID)
      .query(`
        INSERT INTO [dbo].[StencilTable] (
          [Product], [Side], [PartNumber], [StencilID], [BarcodeID], [DateofManufacturing],
          [StencilTension], [Remarks], [SupplierPartNumber], [StencilThickness],
          [ModuleCode], [ModifiedUserID], [RegisterationStatus], [RegisterationDatetime]
        )
        VALUES (
          @productName, @topBottom, @pcbPartNumber, @stencilID, @barcodeID, @date,
          @stencilTensions, @remarks, @supplierPartNumber, @stencilThickness,
          @moduleCode, @ModifiedUserID, 1, GETDATE()
        )
      `);

    res.status(200).json({ message: "Stencil registration added successfully" });
  } catch (error) {
    console.error("Error inserting data:", error);
    res.status(500).json({ message: "Error inserting data", error: error.message });
  }
};


export const getUserRoleModuleData = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    console.log("Inhere");
 
    // Query for modules where each role is TRUE (1)
    const getRole1Modules = await pool
      .request()
      .query(`SELECT DISTINCT [ModuleName] FROM UserRoleModule WHERE Role1 = 1`);
   
    const getRole2Modules = await pool
      .request()
      .query(`SELECT DISTINCT [ModuleName] FROM UserRoleModule WHERE Role2 = 1`);
   
    const getRole3Modules = await pool
      .request()
      .query(`SELECT DISTINCT [ModuleName] FROM UserRoleModule WHERE Role3 = 1`);
   
    const getRole4Modules = await pool
      .request()
      .query(`SELECT DISTINCT [ModuleName] FROM UserRoleModule WHERE Role4 = 1`);
   
    const getRole5Modules = await pool
      .request()
      .query(`SELECT DISTINCT [ModuleName] FROM UserRoleModule WHERE Role5 = 1`);
 
    // Extracting the module names from the query result
    const role1Modules = getRole1Modules.recordset.map(item => item.ModuleName);
    const role2Modules = getRole2Modules.recordset.map(item => item.ModuleName);
    const role3Modules = getRole3Modules.recordset.map(item => item.ModuleName);
    const role4Modules = getRole4Modules.recordset.map(item => item.ModuleName);
    const role5Modules = getRole5Modules.recordset.map(item => item.ModuleName);
 
    // Structuring the response by categorizing modules for each role
    const response = {
      TECH: role1Modules,
      ENGG: role2Modules,
      ADMIN: role3Modules,
      role4Modules: role4Modules,
      OPERATOR: role5Modules
    };
 
    return res.status(200).json(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch role-specific module data" });
  }
};
 
 
 
 
 
 
 