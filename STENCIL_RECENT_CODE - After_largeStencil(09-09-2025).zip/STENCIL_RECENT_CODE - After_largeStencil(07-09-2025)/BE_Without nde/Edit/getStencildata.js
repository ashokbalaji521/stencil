import { conConfig } from "../db.js";
import sql from "mssql";
 
export const getStencilDataByBarcodeID = async (req, res) => {
  const barcodeID = req.query.BarcodeId; // Get BarcodeID from query parameters
  console.log(barcodeID);
  try {
    const pool = await sql.connect(conConfig);
    const getData = await pool
      .request()
      .input("barcodeID", sql.VarChar, barcodeID) // Use parameterized query
      .query(
        `SELECT
            [SNO],
            [Product],
            [Side],
            [PartNumber],
            [SupplierPartNumber],
            [DateofManufacturing],
            [StencilThickness],
            [StencilID],
            [BarcodeID],
            [ModuleCode],
            [StencilTension],
            [LastINDate],
            [LastOutDate],
            [LastModifiedDate],
            [ModifiedUserID],
            [Remarks],
            [Status],
            [RackID],
            [LedID],
            [Authorized],
            [AuthorizedOut],
            [Blocked]
          FROM
            [StencilApplication].[dbo].[StencilTable]
          WHERE
            BarcodeID = @barcodeID`
      );
 
    return res.status(200).json(getData.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch stencil data" });
  }
};

export const getStencilDataByBarcodeIDformaintain = async (req, res) => {
  const barcodeID = req.query.BarcodeId; // Get BarcodeID from query parameters
  console.log(barcodeID);
  try {
    const pool = await sql.connect(conConfig);
    const getData = await pool
      .request()
      .input("barcodeID", sql.VarChar, barcodeID) // Use parameterized query
      .query(
        `SELECT
            [SNO],
            [Product],
            [Side],
            [PartNumber],
            [SupplierPartNumber],
            [DateofManufacturing],
            [StencilThickness],
            [StencilID],
            [BarcodeID],
            [ModuleCode],
            [StencilTension],
            [LastINDate],
            [LastOutDate],
            [LastModifiedDate],
            [ModifiedUserID],
            [Remarks],
            [Status],
            [RackID],
            [LedID],
            [Authorized],
            [AuthorizedOut],
            [Blocked]
          FROM
            [StencilApplication].[dbo].[StencilTable]
          WHERE
            BarcodeID = @barcodeID`
      );
 
    return res.status(200).json(getData.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch stencil data" });
  }
};

export const updateStencilDataByBarcodeID = async (req, res) => {
  const barcodeID = req.body.BarcodeID;
  const {
    Product,
    Side,
    PartNumber,
    SupplierPartNumber,
    DateofManufacturing,
    StencilThickness,
    StencilID,
    ModuleCode,
    StencilTension,
    LastINDate,
    LastOutDate,
    ModifiedUserID,
    Remarks,
    Status,
    RackID,
    LedID,
    Authorized,
    AuthorizedOut,
    Blocked,
  } = req.body;

  try {
    const pool = await sql.connect(conConfig);

    const stencilTensionString = Array.isArray(StencilTension) ? StencilTension.join(",") : StencilTension;

    const checkRecord = await pool
      .request()
      .input('barcodeID', sql.VarChar, barcodeID)
      .query(`SELECT * FROM [StencilApplication].[dbo].[StencilTable] WHERE BarcodeID = @barcodeID`);

    if (checkRecord.recordset.length > 0) {
      // Record exists, update it
      const updates = [];
      const parameters = { barcodeID };

      if (Product !== undefined) {
        updates.push("Product = @Product");
        parameters.Product = Product;
      }
      if (Side !== undefined) {
        updates.push("Side = @Side");
        parameters.Side = Side;
      }
      if (PartNumber !== undefined) {
        updates.push("PartNumber = @PartNumber");
        parameters.PartNumber = PartNumber;
      }
      if (SupplierPartNumber !== undefined) {
        updates.push("SupplierPartNumber = @SupplierPartNumber");
        parameters.SupplierPartNumber = SupplierPartNumber;
      }
      if (DateofManufacturing !== undefined) {
        updates.push("DateofManufacturing = @DateofManufacturing");
        parameters.DateofManufacturing = DateofManufacturing;
      }
      if (StencilThickness !== undefined) {
        updates.push("StencilThickness = @StencilThickness");
        parameters.StencilThickness = StencilThickness;
      }
      if (StencilID !== undefined) {
        updates.push("StencilID = @StencilID");
        parameters.StencilID = StencilID;
      }
      if (ModuleCode !== undefined) {
        updates.push("ModuleCode = @ModuleCode");
        parameters.ModuleCode = ModuleCode;
      }
      if (stencilTensionString !== undefined) {
        updates.push("StencilTension = @StencilTension");
        parameters.StencilTension = stencilTensionString;
      }
      if (LastINDate !== undefined) {
        updates.push("LastINDate = @LastINDate");
        parameters.LastINDate = LastINDate;
      }
      if (LastOutDate !== undefined) {
        updates.push("LastOutDate = @LastOutDate");
        parameters.LastOutDate = LastOutDate;
      }
      if (ModifiedUserID !== undefined) {
        updates.push("ModifiedUserID = @ModifiedUserID");
        parameters.ModifiedUserID = ModifiedUserID;
      }
      if (Remarks !== undefined) {
        updates.push("Remarks = @Remarks");
        parameters.Remarks = Remarks;
      }
      if (Status !== undefined) {
        updates.push("Status = @Status");
        parameters.Status = Status;
      }
      if (RackID !== undefined) {
        updates.push("RackID = @RackID");
        parameters.RackID = RackID;
      }
      if (LedID !== undefined) {
        updates.push("LedID = @LedID");
        parameters.LedID = LedID;
      }
      if (Authorized !== undefined) {
        updates.push("Authorized = @Authorized");
        parameters.Authorized = Authorized;
      }
      if (AuthorizedOut !== undefined) {
        updates.push("AuthorizedOut = @AuthorizedOut");
        parameters.AuthorizedOut = AuthorizedOut;
      }
      if (Blocked !== undefined) {
        updates.push("Blocked = @Blocked");
        parameters.Blocked = Blocked;
      }

      // Always update UpdatedStatus to 1
      updates.push("UpdatedStatus = 1");

      const updateQuery = `
        UPDATE [StencilApplication].[dbo].[StencilTable]
        SET
          ${updates.join(", ")},
          LastModifiedDate = GETDATE()
        WHERE
          BarcodeID = @barcodeID;
      `;

      const request = pool.request();
      Object.entries(parameters).forEach(([key, value]) => {
        if (["Status", "Authorized", "AuthorizedOut", "Blocked"].includes(key)) {
          request.input(key, sql.Bit, value);
        } else if (["DateofManufacturing", "LastINDate", "LastOutDate"].includes(key)) {
          request.input(key, sql.DateTime, value);
        } else if (key === "ModifiedUserID") {
          request.input(key, sql.NVarChar(255), value);
        } else {
          request.input(key, sql.NVarChar(sql.MAX), value);
        }
      });

      await request.query(updateQuery);

      const updatedRecord = await pool
        .request()
        .input('barcodeID', sql.VarChar, barcodeID)
        .query(`SELECT * FROM [StencilApplication].[dbo].[StencilTable] WHERE BarcodeID = @barcodeID`);

      return res.status(200).json({
        message: "Stencil data updated successfully",
        updatedData: updatedRecord.recordset[0],
      });

    } else {
      // Record does not exist - insert
      const insertQuery = `
        INSERT INTO [StencilApplication].[dbo].[StencilTable]
          (BarcodeID, Product, Side, PartNumber, SupplierPartNumber, DateofManufacturing, StencilThickness,
          StencilID, ModuleCode, StencilTension, LastINDate, LastOutDate, ModifiedUserID, Remarks, Status,
          RackID, LedID, Authorized, AuthorizedOut, Blocked, LastModifiedDate)
        VALUES
          (@barcodeID, @Product, @Side, @PartNumber, @SupplierPartNumber, @DateofManufacturing, @StencilThickness,
          @StencilID, @ModuleCode, @StencilTension, @LastINDate, @LastOutDate, @ModifiedUserID, @Remarks, @Status,
          @RackID, @LedID, @Authorized, @AuthorizedOut, @Blocked, GETDATE());
      `;

      await pool
        .request()
        .input('barcodeID', sql.VarChar, barcodeID)
        .input('Product', sql.NVarChar(sql.MAX), Product)
        .input('Side', sql.NVarChar(50), Side)
        .input('PartNumber', sql.NVarChar(sql.MAX), PartNumber)
        .input('SupplierPartNumber', sql.NVarChar(sql.MAX), SupplierPartNumber)
        .input('DateofManufacturing', sql.DateTime, DateofManufacturing)
        .input('StencilThickness', sql.NVarChar(sql.MAX), StencilThickness)
        .input('StencilID', sql.NVarChar(sql.MAX), StencilID)
        .input('ModuleCode', sql.NVarChar(sql.MAX), ModuleCode)
        .input('StencilTension', sql.NVarChar(sql.MAX), stencilTensionString)
        .input('LastINDate', sql.DateTime, LastINDate)
        .input('LastOutDate', sql.DateTime, LastOutDate)
        .input('ModifiedUserID', sql.Int, ModifiedUserID)
        .input('Remarks', sql.NVarChar(sql.MAX), Remarks)
        .input('Status', sql.Bit, Status)
        .input('RackID', sql.NVarChar(sql.MAX), RackID)
        .input('LedID', sql.VarChar(sql.MAX), LedID)
        .input('Authorized', sql.Bit, Authorized)
        .input('AuthorizedOut', sql.Bit, AuthorizedOut)
        .input('Blocked', sql.Bit, Blocked)
        .query(insertQuery);

      return res.status(201).json({ message: "New stencil data added successfully" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to update or insert stencil data" });
  }
};


 

// Backend Implementation

export const storeEditableStencilRecord = async (req, res) => {
  console.log("=== storeEditableStencilRecord CALLED ===");
  console.log("Request body:", req.body);

  try {
    const {
      Product,
      StencilId,
      Side,
      PartNumber,
      PhysicalLocation,
      BarcodeID,
      StencilThickness,
      SupplierPartNumber,
      Remarks,
      ModuleCode,
      StencilTension,
      Rackno,
      Maintenance_updated_datetime,
      operatorid
    } = req.body;

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    const query = `
      INSERT INTO [StencilApplication].[dbo].[EditableStencilrecord] 
      (
        Product,
        Side,
        PartNumber,
        SupplierPartNumber,
        StencilThickness,
        StencilID,
        BarcodeID,
        ModuleCode,
        StencilTension,
        Remarks,
        Rackno,
        PhysicalLocation,
        operatorid,
        Maintenance_updated_datetime
      ) 
      VALUES 
      (
        @Product,
        @Side,
        @PartNumber,
        @SupplierPartNumber,
        @StencilThickness,
        @StencilId,
        @BarcodeID,
        @ModuleCode,
        @StencilTension,
        @Remarks,
        @Rackno,
        @PhysicalLocation,
        @operatorid,
        @Maintenance_updated_datetime
      )
    `;

    request.input("Product", sql.NVarChar(sql.MAX), Product || null);
    request.input("Side", sql.NVarChar(50), Side || null);
    request.input("PartNumber", sql.NVarChar(sql.MAX), PartNumber || null);
    request.input("SupplierPartNumber", sql.NVarChar(sql.MAX), SupplierPartNumber || null);
    request.input("StencilThickness", sql.NVarChar(sql.MAX), StencilThickness || null);
    request.input("StencilId", sql.NVarChar(sql.MAX), StencilId || null);
    request.input("BarcodeID", sql.NVarChar(sql.MAX), BarcodeID || null);
    request.input("ModuleCode", sql.NVarChar(sql.MAX), ModuleCode || null);
    request.input("StencilTension", sql.NVarChar(sql.MAX), StencilTension || null);
    request.input("Remarks", sql.NVarChar(sql.MAX), Remarks || null);
    request.input("Rackno", sql.VarChar(50), Rackno || null);
    request.input("PhysicalLocation", sql.NVarChar(100), PhysicalLocation || null);
    request.input("operatorid", sql.VarChar(50), operatorid || null);
    request.input("Maintenance_updated_datetime", sql.DateTime, new Date(Maintenance_updated_datetime));

    console.log("Executing query:", query);
    const result = await request.query(query);

    return res.status(200).json({
      status: "success",
      code: 200,
      message: "Editable stencil record stored successfully",
      rowsAffected: result.rowsAffected[0]
    });

  } catch (err) {
    console.error("=== ERROR in storeEditableStencilRecord ===");
    console.error("Error message:", err.message);
    console.error("Error stack:", err.stack);

    return res.status(500).json({
      status: "error",
      code: 500,
      message: "Failed to store editable stencil record",
      error: err.message,
      details: process.env.NODE_ENV === "development" ? err.stack : undefined,
    });
  }
};

export const updateStencilTension = async (req, res) => {
  console.log("=== updateStencilTension CALLED ===");
  console.log("Request body:", req.body);

  try {
    const {
      barcodeID,
      stencilTensions,
      remarks,
      moduleCode,
      operatorid
    } = req.body;

    // Validate required fields
    if (!barcodeID) {
      return res.status(400).json({
        status: "error",
        code: 400,
        message: "BarcodeID is required"
      });
    }

    if (!operatorid || operatorid.length !== 8) {
      return res.status(400).json({
        status: "error",
        code: 400,
        message: "Operator ID must be exactly 8 digits"
      });
    }

    const pool = await sql.connect(conConfig);
    const request = pool.request();

    // Convert stencil tensions array to string format
    const stencilTensionString = stencilTensions && stencilTensions.length > 0 
      ? stencilTensions.join(",") 
      : null;

    const query = `
      UPDATE [StencilApplication].[dbo].[StencilTable] 
      SET 
        StencilTension = @StencilTension,
        Remarks = @Remarks,
        ModuleCode = @ModuleCode,
        ModifiedUserID = @operatorid,
        LastModifiedDate = @LastModifiedDate,
        Maintenance_updated_datetime = @Maintenance_updated_datetime
      WHERE BarcodeID = @BarcodeID
    `;

    request.input("StencilTension", sql.NVarChar(sql.MAX), stencilTensionString || null);
    request.input("Remarks", sql.NVarChar(sql.MAX), remarks || null);
    request.input("ModuleCode", sql.NVarChar(sql.MAX), moduleCode || null);
    request.input("operatorid", sql.NVarChar(255), operatorid);
    request.input("BarcodeID", sql.NVarChar(sql.MAX), barcodeID);
    request.input("LastModifiedDate", sql.DateTime, new Date());
    request.input("Maintenance_updated_datetime", sql.DateTime, new Date());

    console.log("Executing update query:", query);
    console.log("Parameters:", {
      StencilTension: stencilTensionString,
      Remarks: remarks,
      ModuleCode: moduleCode,
      operatorid: operatorid,
      BarcodeID: barcodeID
    });

    const result = await request.query(query);

    if (result.rowsAffected[0] === 0) {
      return res.status(404).json({
        status: "error",
        code: 404,
        message: "No stencil found with the provided BarcodeID"
      });
    }

    return res.status(200).json({
      status: "success",
      code: 200,
      message: "Stencil data updated successfully",
      rowsAffected: result.rowsAffected[0]
    });

  } catch (err) {
    console.error("=== ERROR in updateStencilTension ===");
    console.error("Error message:", err.message);
    console.error("Error stack:", err.stack);

    return res.status(500).json({
      status: "error",
      code: 500,
      message: "Failed to update stencil tension",
      error: err.message,
      details: process.env.NODE_ENV === "development" ? err.stack : undefined,
    });
  }
};

export const getEditableStencilRecords = async (req, res) => {
  console.log("=== getEditableStencilRecords CALLED ===");
  console.log("Query parameters:", req.query);

  let { fromDate, toDate } = req.query;

  try {
    const pool = await sql.connect(conConfig);
    const request = pool.request();

    // Step 1: Handle null/empty fromDate & toDate
    if (!fromDate || fromDate.trim() === "" || !toDate || toDate.trim() === "") {
      console.log("Fetching min/max datetime because fromDate or toDate missing...");

      const rangeResult = await pool.request().query(`
        SELECT 
          MIN(Maintenance_updated_datetime) AS MinDate,
          MAX(Maintenance_updated_datetime) AS MaxDate
        FROM [StencilApplication].[dbo].[EditableStencilrecord]
      `);

      const minDate = rangeResult.recordset[0].MinDate;
      const maxDate = rangeResult.recordset[0].MaxDate;

      // Handle empty table case
      if (!minDate || !maxDate) {
        console.log("Table is empty, returning empty result...");
        return res.status(200).json({
          status: "success",
          code: 200,
          message: "No records found in the table",
          data: [],
          count: 0,
          appliedFilter: { fromDate: null, toDate: null }
        });
      }

      if (!fromDate || fromDate.trim() === "") {
        fromDate = minDate.toISOString();
      }

      if (!toDate || toDate.trim() === "") {
        toDate = maxDate.toISOString();
      }
    }

    // Step 2: Build query with datetime filtering
    let query = `
      SELECT 
        [Product],
        [Side],
        [PartNumber],
        [SupplierPartNumber],
        [DateofManufacturing],
        [StencilThickness],
        [StencilID],
        [BarcodeID],
        [ModuleCode],
        [StencilTension],
        [LastINDate],
        [LastOutDate],
        [LastModifiedDate],
        [ModifiedUserID],
        [Remarks],
        [Status],
        [Authorized],
        [AuthorizedOut],
        [Blocked],
        [Scrap],
        [Operator_id],
        [Maintenance_updated_datetime],
        [Unauthorized_stencilout],
        [UserName],
        [Rackno],
        [PhysicalLocation],
        [operatorid]
      FROM [StencilApplication].[dbo].[EditableStencilrecord]
      WHERE Maintenance_updated_datetime BETWEEN @FromDate AND @ToDate
      ORDER BY Maintenance_updated_datetime DESC
    `;

    request.input("FromDate", sql.DateTime, new Date(fromDate));
    request.input("ToDate", sql.DateTime, new Date(toDate));

    console.log("Final Query:", query);
    console.log("FromDate:", fromDate, "ToDate:", toDate);

    const result = await request.query(query);

    return res.status(200).json({
      status: "success",
      code: 200,
      message: "Editable records fetched successfully",
      data: result.recordset,
      count: result.recordset.length,
      appliedFilter: { fromDate, toDate }
    });
  } catch (err) {
    console.error("=== ERROR in getEditableStencilRecords ===");
    console.error("Error message:", err.message);

    return res.status(500).json({
      status: "error",
      code: 500,
      message: "Failed to fetch editable records",
      error: err.message,
      details: process.env.NODE_ENV === "development" ? err.stack : undefined,
    });
  }
};


 
export const getStencilDataByBarcodeIDforslot = async (req, res) => {
  const barcodeID = req.query.BarcodeId; // Get BarcodeID from query parameters
  console.log(barcodeID);
 
  if (!barcodeID) {
    return res.status(400).json({ error: "BarcodeId is required" });
  }
 
  try {
    const pool = await sql.connect(conConfig);
 
    // Update the Unauthorized_stencilout based on conditions
    await pool
      .request()
      .input("barcodeID", sql.VarChar, barcodeID)
      .query(`
        UPDATE [StencilApplication].[dbo].[StencilTable]
        SET [Unauthorized_stencilout] =
            CASE
                WHEN [Operator_id] IS NOT NULL AND [Operator_id] <> '' AND [Status] = 0 THEN NULL
                WHEN [Operator_id] IS NULL OR [Operator_id] = '' AND [Status] = 0 THEN 1
                ELSE [Unauthorized_stencilout] -- Retain existing value if none of the conditions match
            END
        WHERE BarcodeID = @barcodeID
      `);
 
    // Retrieve updated data from StencilTable
    const stencilData = await pool
      .request()
      .input("barcodeID", sql.VarChar, barcodeID)
      .query(`
        SELECT
            [SNO],
            [Product],
            [Side],
            [PartNumber],
            [SupplierPartNumber],
            [DateofManufacturing],
            [StencilThickness],
            [StencilID],
            [BarcodeID],
            [ModuleCode],
            [StencilTension],
            [LastINDate],
            [LastOutDate],
            [LastModifiedDate],
            [ModifiedUserID],
            [Blocked],
            [Scrap],
            [Operator_id],
            [Maintenance_updated_datetime],
            [Unauthorized_stencilout]
        FROM
            [StencilApplication].[dbo].[StencilTable]
        WHERE
            BarcodeID = @barcodeID
      `);
 
    // Retrieve data from StencilTable_Copy
    const stencilCopyData = await pool
      .request()
      .input("barcodeID", sql.VarChar, barcodeID)
      .query(`
        SELECT
          [SNO],
          [Product],
          [Side],
          [PartNumber],
          [SupplierPartNumber],
          [DateofManufacturing],
          [StencilThickness],
          [StencilID],
          [BarcodeID],
          [ModuleCode],
          [StencilTension],
          [LastINDate],
          [LastOutDate],
          [LastModifiedDate],
          [ModifiedUserID],
          [Remarks],
          [Status],
          [RackID],
          [LedID]
        FROM
          [StencilApplication].[dbo].[StencilTable_Copy]
        WHERE
          BarcodeID = @barcodeID
      `);
 
    const stencilCopyTableData = stencilCopyData.recordset;
 
    // Retrieve data from stencilRackStatus based on RackID
    const rackIds = stencilCopyTableData.map((row) => row.RackID).filter((id) => id); // Get valid RackIDs
 
    let rackStatusData = [];
    if (rackIds.length > 0) {
      const rackStatusQuery = `
        SELECT
          [Rack_id],
          [RackStatus],
          [PhysicalLocation]
        FROM
          [StencilApplication].[dbo].[stencilRackStatus]
        WHERE
          Rack_id IN (${rackIds.map((_, idx) => `@rackId${idx}`).join(",")})
      `;
 
      const rackStatusRequest = pool.request();
      rackIds.forEach((id, idx) => {
        rackStatusRequest.input(`rackId${idx}`, sql.VarChar, id);
      });
 
      const rackStatusResult = await rackStatusRequest.query(rackStatusQuery);
      rackStatusData = rackStatusResult.recordset;
    }
 
    // Combine results
    const stencilTableData = stencilData.recordset;
 
    return res.status(200).json({
      stencilTableData,
      stencilCopyTableData,
      rackStatusData, // Add rack status data to the response
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to update and fetch stencil data" });
  }
};
 
 export const getPartCodeDatabyall = async (req, res) => {
   try {
     const pool = await sql.connect(conConfig);
     const getPartCode = await pool
       .request()
       .query(`SELECT DISTINCT 
                 st.[PartNumber], 
                 st.[Product], 
                 st.[Side], 
                 st.[StencilThickness], 
                 st.[StencilTension], 
                 st.[Remarks], 
                 DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                 st.StencilID, 
                 st.BarcodeID, 
                 COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
               FROM StencilTable st
               LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
               LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
               LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
               LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]`);
     return res.status(200).json(getPartCode.recordset);
   } catch (err) {
     console.log(err);
     return res.status(500).json({ error: "Failed to fetch part codes" });
   }
 };
 
 export const getProductNameDatabyall = async (req, res) => {
   try {
     const pool = await sql.connect(conConfig);
     const getProductName = await pool
       .request()
       .query(`SELECT DISTINCT 
                 st.[Product], 
                 st.[Side], 
                 st.[PartNumber], 
                 st.[StencilThickness], 
                 st.[StencilTension], 
                 st.[Remarks], 
                 DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                 st.StencilID, 
                 st.BarcodeID, 
                 COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
               FROM StencilTable st
               LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
               LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
               LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
               LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]`);
     return res.status(200).json(getProductName.recordset);
   } catch (err) {
     console.log(err);
     return res.status(500).json({ error: "Failed to fetch product names" });
   }
 };
 export const getallStencilIDDatabyall = async (req, res) => {
   try {
     const pool = await sql.connect(conConfig);
     const getStencilID = await pool
       .request()
       .query(`SELECT DISTINCT 
                 st.[StencilID], 
                 st.[Product], 
                 st.[Side], 
                 st.[PartNumber], 
                 st.[StencilThickness], 
                 st.[StencilTension], 
                 st.[Remarks], 
                 DATEADD(minute, -330, st.[Maintenance_updated_datetime]) AS Maintenance_updated_datetime, 
                 st.BarcodeID, 
                 COALESCE(rs1.[PhysicalLocation], rs2.[PhysicalLocation], rs3.[PhysicalLocation], rs4.[PhysicalLocation]) AS PhysicalLocation
               FROM StencilTable st
               LEFT JOIN [stencilRackStatus] rs1 ON rs1.[Rack_id] = st.[RackID]
               LEFT JOIN [stencilRackStatus1_copy] rs2 ON rs2.[Rack_id] = st.[RackID2]
               LEFT JOIN [stencilRackStatus2_copy] rs3 ON rs3.[Rack_id] = st.[RackID3]
               LEFT JOIN [stencilRackStatus3_copy] rs4 ON rs4.[Rack_id] = st.[RackID4]`);
     return res.status(200).json(getStencilID.recordset);
   } catch (err) {
     console.log(err);
     return res.status(500).json({ error: "Failed to fetch stencil IDs" });
   }
 };
 
export const getSelectedPartCodeDataforedit = async (req, res) => {
  let { partCode, stencilId, Product } = req.body;

  // Trim the input values
  partCode = partCode?.trim();
  stencilId = stencilId?.trim();
  Product = Product?.trim();

  console.log(partCode, stencilId, Product);

  try {
    const pool = await sql.connect(conConfig);
    let query = `SELECT Product, Side, PartNumber, StencilID, BarcodeID, Rackno
                 FROM StencilTable
                 WHERE (Blocked IS NULL OR Blocked = 0)
                 AND (Scrap IS NULL OR Scrap = 0)`;

    const conditions = [];
    const params = {};

    if (partCode) {
      conditions.push(`PartNumber = @partCode`);
      params.partCode = partCode;
    }
    if (stencilId) {
      conditions.push(`StencilID = @stencilId`);
      params.stencilId = stencilId;
    }
    if (Product) {
      conditions.push(`Product = @Product`);
      params.Product = Product;
    }

    if (conditions.length > 0) {
      query += ` AND (${conditions.join(' AND ')})`;
    }

    const request = pool.request();
    Object.keys(params).forEach(key => {
      request.input(key, params[key]);
    });

    const getData = await request.query(query);
    return res.status(200).json(getData.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to fetch part code data" });
  }
};
