import { conConfig } from "../db.js";
import sql from "mssql";
import moment from 'moment-timezone';

export const getNoncompliant = async (req, res) => {
  const pool = await sql.connect(conConfig);
  try {
    const getIds = await pool.request()
      .query(`  select * from [NonAuthorizedOut]  
`);

    return res.status(200).json(getIds.recordset);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to Light up" });
  }
};

export const switchLightOff = async (req, res) => {
  const pool = await sql.connect(conConfig);

  const ledRackIds = req.body.led;
  console.log(ledRackIds);
  try {
    const updateQuery = `
    UPDATE StencilLEDStatus 
    SET [LEDRackStatus] = 0 
    WHERE LEDRack_id IN (${ledRackIds.join(",")})
  `;

    // Step 4: Execute the UPDATE query
    await pool.request().query(updateQuery);
    return res.status(200).json({ Success: "Success" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to Switch Off" });
  }
};

// export const getNoncompliantdatetimefilter = async (req, res) => {
//   const pool = await sql.connect(conConfig);
 
//   const { fromDate, toDate } = req.body;
 
//   try {
//     let query = `SELECT * FROM [NonAuthorizedOut] WHERE 1=1`;
   
//     if (fromDate) {
//       query += ` AND [TimeColumn] >= @fromDate`;
//     }
 
//     if (toDate) {
//       query += ` AND [TimeColumn] <= @toDate`;
//     }

//     query += ` ORDER BY [TimeColumn] DESC`;

 
//     const request = pool.request();
 
//     // Parse fromDate and toDate, adjusting for timezone and precision
//     if (fromDate) {
//       const utcFromDate = moment(fromDate).tz("UTC").toDate();
//       request.input('fromDate', sql.DateTime2, utcFromDate);
//     }
 
//     if (toDate) {
//       const utcToDate = moment(toDate).tz("UTC").endOf("minute").toDate();
//       request.input('toDate', sql.DateTime2, utcToDate);
//     }
 
//     const getIds = await request.query(query);
 
//     return res.status(200).json(getIds.recordset);
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({ error: "Failed to fetch records" });
//   }
// };


export const getNoncompliantdatetimefilter = async (req, res) => {
  const pool = await sql.connect(conConfig);
  const { fromDate, toDate } = req.body;

  try {
    let query = `
      SELECT [ID], [TimeColumn], [Physical Location], [RackNo]
      FROM [StencilApplication].[dbo].[check_NonAuthorizedIn_Alter]
      WHERE 1=1
    `;

    if (fromDate) {
      query += ` AND [TimeColumn] >= @fromDate`;
    }

    if (toDate) {
      query += ` AND [TimeColumn] <= @toDate`;
    }

    query += ` ORDER BY [TimeColumn] DESC`;

    const request = pool.request();

    // Parse dates properly
    if (fromDate) {
      const utcFromDate = moment(fromDate).tz("UTC").toDate();
      request.input("fromDate", sql.DateTime2, utcFromDate);
    }

    if (toDate) {
      const utcToDate = moment(toDate).tz("UTC").endOf("minute").toDate();
      request.input("toDate", sql.DateTime2, utcToDate);
    }

    const result = await request.query(query);

    return res.status(200).json(result.recordset);
  } catch (err) {
    console.error("Error fetching records:", err);
    return res.status(500).json({ error: "Failed to fetch records" });
  }
};
