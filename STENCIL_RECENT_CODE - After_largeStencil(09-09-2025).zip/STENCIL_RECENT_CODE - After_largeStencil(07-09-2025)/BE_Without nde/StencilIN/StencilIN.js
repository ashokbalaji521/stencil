import { conConfig } from "../db.js";
import sql from "mssql";
 
export const getStencilData = async (req, res) => {
  console.log("checkingnew");
  const barcode = req.body.barcode;
 
  try {
    console.log("inside try");
 
    const pool = await sql.connect(conConfig);
 
    const result = await pool
      .request()
      .input("barcode", sql.NVarChar, barcode)
      .query("SELECT BarcodeID from StencilTable where BarcodeID = @barcode");
    console.log("result", result.recordset.length);
 
    if (result.recordset.length != []) {
      console.log("Record Exists");
    } else {
      return res.status(300).send("Stencil does not exist");
    }
  } catch (err) {}
 
  const data = { data: "Success" };
  return res.status(200).send(data);
};


// export const getRackStatus = async (req, res) => {
//   const pool = await sql.connect(conConfig);
//   if (Object.keys(req.body).length > 0) {
//     const stencilId = req.body.stencilId;
//     console.log("The object is not empty.");
//     const checkStencil = await pool
//       .request()
//       .query(
//         `Select Product from [StencilTable] where BarcodeID ='${stencilId}' `
//       );
//     console.log(checkStencil.recordset.length);
//     if (checkStencil.recordset.length == 0) {
//       return res.status(204).send("Not registered");
//     }
//   }
 
//   const getrackst = await pool
//     .request()
//     .query("Select data from [tblRackSensorInput]");
 
//   const currentStatus = String(getrackst.recordset[0].data);
//   console.log("currentStatus", { currentStatus: currentStatus });
 
//   return res.status(200).send({ currentStatus: currentStatus });
// };
 
// export const updateStencilStatus = async (req, res) => {
//   try {
//     const pool = await sql.connect(conConfig);
//     const onLightUpSound = await pool
//       .request()
//       .query(
//         `Update [StencilLEDStatus] set [LEDRackStatus] = 1 where [LEDRack_id] in (1,4)`
//       );
//     const stencilId = req.body.key1;
//     console.log("stencilId", stencilId);
//     const updateStencil = await pool
//     .request()
//     .query(
//       `UPDATE [StencilTable] 
//        SET Status = 1, 
//            LastINDate = GETDATE() 
//        WHERE BarcodeID = '${stencilId}'`
//     );
 
//     console.log("Status Updated");
 
//     // const lightUpSoundInitial = await pool
//     //   .request()
//     //   .query(`Select data from [tblRackLedOutput] `);
//     // // Original binary string
//     // let binaryString = lightUpSoundInitial.recordset[0].data;
 
//     // // Convert binary string to a BigInt (for large binary strings)
//     // let binaryNumber = BigInt("0b" + binaryString);
 
//     // // Set the 2nd and 3rd bits to 1 (counting from the left, 0-based index)
//     // binaryNumber |= 1n << BigInt(binaryString.length - 1);
//     // binaryNumber |= 1n << BigInt(binaryString.length - 4);
 
//     // // Convert the modified number back to a binary string
//     // let modifiedBinaryString = binaryNumber
//     //   .toString(2)
//     //   .padStart(binaryString.length, "0");
 
//     // console.log(modifiedBinaryString);
//     // console.log(binaryString);
 
//     await new Promise((resolve) => setTimeout(resolve, 1000));
//     console.log("Light up");
//     const offLightUpSound = await pool
//       .request()
//       .query(
//         `Update [StencilLEDStatus] set [LEDRackStatus] = 0 where [LEDRack_id] in (2,4)`
//       );
//     console.log("Light off");
//     return res.status(200).send("Success");
//   } catch (err) {
//     console.log(err);
//     return res.status(500).send("Failed");
//   }
// };
 
export const abortUpdate = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    const operatorId = req.body.operator;
 
    const insert = await pool.request()
      .query(`Insert into [StencilInOperatorAbort] ([OperationId]
      ,[DateTime]) VALUES ('${operatorId}',GETDATE())`);
    return res.status(200).send("Success");
  } catch (err) {
    console.log(err);
    return res.status(500).send("Failed");
  }
};
 
// export const updatedRackIDStencilTable = async (req, res) => {
//   try {
//     const pool = await sql.connect(conConfig);
//     console.log("newcode", req.body);
//     const newbit = req.body.new;
//     const oldbit = req.body.old;
//     const barcode = req.body.barcode;
//     const bits1 = newbit.split("");
//     const bits2 = oldbit.split("");

//     // Initialize an array to store the positions of different bits
//     const differingPositions = [];

//     // Compare each bit
//     for (let i = 0; i < bits1.length; i++) {
//       if (bits1[i] !== bits2[i]) {
//         // Store the position (1-indexed)
//         differingPositions.push(i + 1);
//       }
//     }
//     let position = differingPositions[0];

//     // Update RackID in StencilTable
//     await pool
//       .request()
//       .query(
//         `UPDATE StencilTable SET RackID = '${position}', Authorized = 1, AuthorizedOut = NULL WHERE BarcodeID = '${barcode}'`
//       );

//     // Get PhysicalLocation from stencilRackStatus
//     const getPhysicalPos = await pool
//       .request()
//       .query(
//         `SELECT PhysicalLocation FROM stencilRackStatus WHERE Rack_id = '${position}'`
//       );

//     const PhysicalLoc = String(getPhysicalPos.recordset[0].PhysicalLocation);
//     console.log("PhysicalLoc", PhysicalLoc);

//     // Get LEDRack_id from StencilLEDStatus
//     const LEDIdquery = await pool
//       .request()
//       .input("PhysicalLoc", sql.VarChar, PhysicalLoc)
//       .query(
//         `SELECT LEDRack_id FROM StencilLEDStatus WHERE PhysicalLocation = @PhysicalLoc`
//       );
//     const LEDId = String(LEDIdquery.recordset[0].LEDRack_id);
//     console.log("LEDId", LEDId);

//     // Update LedID in StencilTable
//     await pool
//       .request()
//       .query(
//         `UPDATE StencilTable SET LedID = '${LEDId}' WHERE BarcodeID = '${barcode}'`
//       );

//     // Update LEDRackStatus to 3 in StencilLEDStatus
//     await pool
//       .request()
//       .input("LEDid", sql.VarChar, LEDId)
//       .query(
//         `UPDATE StencilLEDStatus SET LEDRackStatus = 3 WHERE LEDRack_id = @LEDid`
//       );

//     setTimeout(async () => {
//       // Reset LEDRackStatus to 0 after 2 seconds
//       await pool
//         .request()
//         .input("LEDid", sql.VarChar, LEDId)
//         .query(
//           `UPDATE StencilLEDStatus SET LEDRackStatus = 0 WHERE LEDRack_id = @LEDid`
//         );
//     }, 2000);

//     // Update PhysicalLocation in the latest record of OperationHistoryN for the given BarcodeID
//     await pool
//       .request()
//       .input("BarcodeID", sql.VarChar, barcode)
//       .input("PhysicalLocation", sql.VarChar, PhysicalLoc)
//       .query(
//         `UPDATE OperationHistoryN 
//          SET PhysicalLocation = @PhysicalLocation 
//          WHERE ID = (
//            SELECT TOP 1 ID 
//            FROM OperationHistoryN 
//            WHERE StencilBarcodeID = @BarcodeID 
//            ORDER BY UpdatedDateTime DESC
//          )`
//       );

//     return res.status(200).send(differingPositions);
//   } catch (err) {
//     console.error(err);
//     return res.status(500).send("An error occurred.");
//   }
// };
 
export const getRackStatus = async (req, res) => {
  const pool = await sql.connect(conConfig);
  
  if (Object.keys(req.body).length > 0) {
    const stencilId = req.body.stencilId.trim();  // trim input first

    console.log("The object is not empty.");

    const checkStencil = await pool
      .request()
      .query(
        `SELECT Product FROM [StencilTable] WHERE LTRIM(RTRIM(BarcodeID)) = '${stencilId}'`
      );

    console.log(checkStencil.recordset.length);
    
    if (checkStencil.recordset.length == 0) {
      return res.status(204).send("Not registered");
    }
  }

  const racksData = await pool
    .request()
    .query("SELECT rackid, data FROM [tblRackSensorInput]");
  
  const allRackStatus = {};
  racksData.recordset.forEach(rack => {
    allRackStatus[rack.rackid] = rack.data;
  });

  console.log("All rack statuses:", allRackStatus);
 
  return res.status(200).send(allRackStatus);
};


export const updateStencilStatus = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    const stencilId = req.body.key1;
    const rackNo = req.body.rackNo; // This will be determined in the frontend
    
    console.log("stencilId", stencilId);
    console.log("rackNo", rackNo);
    
  
    let ledRackIdsToUpdate = [];
    if (rackNo === 'Rack-1') {
      ledRackIdsToUpdate = [1, 4]; // LEDs for Rack-1
    } else if (rackNo === 'Rack-2') {
      ledRackIdsToUpdate = [2, 5]; // LEDs for Rack-2
    } else if (rackNo === 'Rack-3') {
      ledRackIdsToUpdate = [3, 6]; // LEDs for Rack-3
    } else if (rackNo === 'Rack-4') {
      ledRackIdsToUpdate = [7, 8]; // LEDs for Rack-4
    }
    
    
    if (rackNo === 'Rack-1') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus] SET [LEDRackStatus] = 1 , [NAstencilIn] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-2') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus1] SET [LEDRackStatus] = 1 , [NAstencilIn] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-3') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus2] SET [LEDRackStatus] = 1 , [NAstencilIn] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-4') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus3] SET [LEDRackStatus] = 1 , [NAstencilIn] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    }
    
    
    const updateStencil = await pool
      .request()
      .query(
        `UPDATE [StencilTable] 
         SET Status = 1, 
             LastINDate = GETDATE(),
             Rackno = '${rackNo}'
         WHERE BarcodeID = '${stencilId}'`
      );
    
    console.log("Status Updated");
    
    
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    console.log("Light up");
    
    
    if (rackNo === 'Rack-1') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus] SET [LEDRackStatus] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-2') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus1] SET [LEDRackStatus] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-3') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus2] SET [LEDRackStatus] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    } else if (rackNo === 'Rack-4') {
      await pool.request().query(
        `UPDATE [StencilLEDStatus3] SET [LEDRackStatus] = 0 WHERE [LEDRack_id] IN (${ledRackIdsToUpdate.join(',')})`
      );
    }
    
    console.log("Light off");
    return res.status(200).send("Success");
  } catch (err) {
    console.log(err);
    return res.status(500).send("Failed");
  }
};


// export const updatedRackIDStencilTable = async (req, res) => {
//   try {
//     const pool = await sql.connect(conConfig);
//     console.log("newcode", req.body);
    
//     const changedRacks = req.body.changedRacks; 
//     const barcode = req.body.barcode;
    
  
//     const rackNo = changedRacks.rackId; 
//     const newbit = changedRacks.new;
//     const oldbit = changedRacks.old;
    
//     const bits1 = newbit.split("");
//     const bits2 = oldbit.split("");

    
//     const differingPositions = [];

    
//     for (let i = 0; i < bits1.length; i++) {
//       if (bits1[i] !== bits2[i]) {
  
//         differingPositions.push(i + 1);
//       }
//     }
    
//     if (differingPositions.length === 0) {
//       return res.status(400).send("No changes detected in rack status");
//     }
    
//     let position = differingPositions[0];
//     let rackIdColumn, ledIdColumn;
//     let rackStatusTable, ledStatusTable;
    
  
//     if (rackNo === 'Rack-1') {
//       rackIdColumn = 'RackID';
//       ledIdColumn = 'LedID';
//       rackStatusTable = 'stencilRackStatus';
//       ledStatusTable = 'StencilLEDStatus';
//     } else if (rackNo === 'Rack-2') {
//       rackIdColumn = 'RackID2';
//       ledIdColumn = 'LedID2';
//       rackStatusTable = 'stencilRackStatus1_copy';
//       ledStatusTable = 'StencilLEDStatus1';
//     } else if (rackNo === 'Rack-3') {
//       rackIdColumn = 'RackID3';
//       ledIdColumn = 'LedID3';
//       rackStatusTable = 'stencilRackStatus2_copy';
//       ledStatusTable = 'StencilLEDStatus2';
//     } else if (rackNo === 'Rack-4') {
//       rackIdColumn = 'RackID4';
//       ledIdColumn = 'LedID4';
//       rackStatusTable = 'stencilRackStatus3_copy';
//       ledStatusTable = 'StencilLEDStatus3';
//     }
    
    
//     let updateQuery = `
//       UPDATE StencilTable 
//       SET RackID = NULL, LedID = NULL, 
//           RackID2 = NULL, LedID2 = NULL, 
//           RackID3 = NULL, LedID3 = NULL, 
//           RackID4 = NULL, LedID4 = NULL,
//           Rackno = '${rackNo}',
//           Authorized = 1, 
//           AuthorizedOut = NULL 
//       WHERE BarcodeID = '${barcode}'
//     `;
    
//     await pool.request().query(updateQuery);
    

//     updateQuery = `
//       UPDATE StencilTable 
//       SET ${rackIdColumn} = '${position}'
//       WHERE BarcodeID = '${barcode}'
//     `;
    
//     await pool.request().query(updateQuery);

  
//     const getPhysicalPos = await pool
//       .request()
//       .query(
//         `SELECT PhysicalLocation FROM ${rackStatusTable} WHERE Rack_id = '${position}'`
//       );

//     if (getPhysicalPos.recordset.length === 0) {
//       return res.status(404).send(`No physical location found for Rack_id ${position} in ${rackStatusTable}`);
//     }

//     const PhysicalLoc = String(getPhysicalPos.recordset[0].PhysicalLocation);
//     console.log("PhysicalLoc", PhysicalLoc);

  
//     const LEDIdquery = await pool
//       .request()
//       .input("PhysicalLoc", sql.VarChar, PhysicalLoc)
//       .query(
//         `SELECT LEDRack_id FROM ${ledStatusTable} WHERE PhysicalLocation = @PhysicalLoc`
//       );
    
//     if (LEDIdquery.recordset.length === 0) {
//       return res.status(404).send(`No LED rack found for PhysicalLocation ${PhysicalLoc} in ${ledStatusTable}`);
//     }

//     const LEDId = String(LEDIdquery.recordset[0].LEDRack_id);
//     console.log("LEDId", LEDId);

//     await pool
//       .request()
//       .query(
//         `UPDATE StencilTable SET ${ledIdColumn} = '${LEDId}' WHERE BarcodeID = '${barcode}'`
//       );

    
//     await pool
//       .request()
//       .input("LEDid", sql.VarChar, LEDId)
//       .query(
//         `UPDATE ${ledStatusTable} SET LEDRackStatus = 3 WHERE LEDRack_id = @LEDid`
//       );

//     setTimeout(async () => {
      
//       await pool
//         .request()
//         .input("LEDid", sql.VarChar, LEDId)
//         .query(
//           `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = @LEDid`
//         );
//     }, 2000);

//     // Additional LED status update for LEDRack_id = 4
//     await pool
//       .request()
//       .input("LEDid", sql.VarChar, LEDId)
//       .query(
//         `UPDATE ${ledStatusTable} SET LEDRackStatus = 1 WHERE LEDRack_id = 4`
//       );

//     setTimeout(async () => {
      
//       await pool
//         .request()
//         .input("LEDid", sql.VarChar, LEDId)
//         .query(
//           `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = 4`
//         );
//     }, 2000);

//     await pool
//       .request()
//       .input("BarcodeID", sql.VarChar, barcode)
//       .input("PhysicalLocation", sql.VarChar, PhysicalLoc)
//       .query(
//         `UPDATE OperationHistoryN 
//          SET PhysicalLocation = @PhysicalLocation 
//          WHERE ID = (
//            SELECT TOP 1 ID 
//            FROM OperationHistoryN 
//            WHERE StencilBarcodeID = @BarcodeID 
//            ORDER BY UpdatedDateTime DESC
//          )`
//       );

//     return res.status(200).send({
//       differingPositions,
//       rackNo,
//       physicalLocation: PhysicalLoc,
//       ledId: LEDId
//     });
//   } catch (err) {
//     console.error(err);
//     return res.status(500).send("An error occurred.");
//   }
// };

export const updatedRackIDStencilTable = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    console.log("newcode", req.body);

    const changedRacks = req.body.changedRacks;
    const barcode = req.body.barcode;

    const rackNo = changedRacks.rackId;
    const newbit = changedRacks.new;
    const oldbit = changedRacks.old;

    const bits1 = newbit.split("");
    const bits2 = oldbit.split("");

    const differingPositions = [];

    for (let i = 0; i < bits1.length; i++) {
      if (bits1[i] !== bits2[i]) {
        differingPositions.push(i + 1);
      }
    }

    if (differingPositions.length === 0) {
      return res.status(400).send("No changes detected in rack status");
    }

    let position = differingPositions[0];
    let rackIdColumn, ledIdColumn, rackIdColumnB, ledIdColumnB;
    let rackStatusTable, ledStatusTable;

    if (rackNo === 'Rack-1') {
      rackIdColumn = 'RackID';
      ledIdColumn = 'LedID';
      rackStatusTable = 'stencilRackStatus';
      ledStatusTable = 'StencilLEDStatus';
    } else if (rackNo === 'Rack-2') {
      rackIdColumn = 'RackID2';
      ledIdColumn = 'LedID2';
      rackStatusTable = 'stencilRackStatus1_copy';
      ledStatusTable = 'StencilLEDStatus1';
    } else if (rackNo === 'Rack-3') {
      rackIdColumn = 'RackID3';
      ledIdColumn = 'LedID3';
      rackStatusTable = 'stencilRackStatus2_copy';
      ledStatusTable = 'StencilLEDStatus2';
    } else if (rackNo === 'Rack-4') {
      rackIdColumn = 'RackID4';
      ledIdColumn = 'LedID4';
      rackIdColumnB = 'RackID4B';
      ledIdColumnB = 'LedID4B';
      rackStatusTable = 'stencilRackStatus3_copy';
      ledStatusTable = 'StencilLEDStatus3';
    }

    // Determine paired physical location for Rack-4
    let pairedPosition = null;
    if (rackNo === 'Rack-4') {
      const physicalLocNum = parseInt(position);
      if (physicalLocNum % 2 === 1) {
        pairedPosition = physicalLocNum + 1; // Odd to even (e.g., 1 -> 2)
      } else {
        pairedPosition = physicalLocNum - 1; // Even to odd (e.g., 2 -> 1)
      }
    }

    // Reset all rack and LED columns
    let updateQuery = `
      UPDATE StencilTable 
      SET RackID = NULL, LedID = NULL, 
          RackID2 = NULL, LedID2 = NULL, 
          RackID3 = NULL, LedID3 = NULL, 
          RackID4 = NULL, LedID4 = NULL,
          RackID4B = NULL, LedID4B = NULL,
          Rackno = '${rackNo}',
          Authorized = 1, 
          AuthorizedOut = NULL 
      WHERE BarcodeID = '${barcode}'
    `;
    await pool.request().query(updateQuery);

    // Update primary position
    updateQuery = `
      UPDATE StencilTable 
      SET ${rackIdColumn} = '${position}'
      WHERE BarcodeID = '${barcode}'
    `;
    await pool.request().query(updateQuery);

    // Get physical location for primary position
    const getPhysicalPos = await pool
      .request()
      .query(
        `SELECT PhysicalLocation FROM ${rackStatusTable} WHERE Rack_id = '${position}'`
      );

    if (getPhysicalPos.recordset.length === 0) {
      return res.status(404).send(`No physical location found for Rack_id ${position} in ${rackStatusTable}`);
    }

    const physicalLoc = String(getPhysicalPos.recordset[0].PhysicalLocation);
    console.log("PhysicalLoc", physicalLoc);

    // Get LED ID for primary physical location
    const LEDIdquery = await pool
      .request()
      .input("PhysicalLoc", sql.VarChar, physicalLoc)
      .query(
        `SELECT LEDRack_id FROM ${ledStatusTable} WHERE PhysicalLocation = @PhysicalLoc`
      );

    if (LEDIdquery.recordset.length === 0) {
      return res.status(404).send(`No LED rack found for PhysicalLocation ${physicalLoc} in ${ledStatusTable}`);
    }

    const LEDId = String(LEDIdquery.recordset[0].LEDRack_id);
    console.log("LEDId", LEDId);

    // Update LED ID for primary position
    await pool
      .request()
      .query(
        `UPDATE StencilTable SET ${ledIdColumn} = '${LEDId}' WHERE BarcodeID = '${barcode}'`
      );

    // Handle paired position for Rack-4
    let pairedPhysicalLoc = null;
    let pairedLEDId = null;
    if (pairedPosition && rackNo === 'Rack-4') {
      // Update paired position in StencilTable
      updateQuery = `
        UPDATE StencilTable 
        SET ${rackIdColumnB} = '${pairedPosition}'
        WHERE BarcodeID = '${barcode}'
      `;
      await pool.request().query(updateQuery);

      // Get physical location for paired position
      const getPairedPhysicalPos = await pool
        .request()
        .query(
          `SELECT PhysicalLocation FROM ${rackStatusTable} WHERE Rack_id = '${pairedPosition}'`
        );

      if (getPairedPhysicalPos.recordset.length > 0) {
        pairedPhysicalLoc = String(getPairedPhysicalPos.recordset[0].PhysicalLocation);
        console.log("PairedPhysicalLoc", pairedPhysicalLoc);

        // Get LED ID for paired physical location
        const pairedLEDIdQuery = await pool
          .request()
          .input("PairedPhysicalLoc", sql.VarChar, pairedPhysicalLoc)
          .query(
            `SELECT LEDRack_id FROM ${ledStatusTable} WHERE PhysicalLocation = @PairedPhysicalLoc`
          );

        if (pairedLEDIdQuery.recordset.length > 0) {
          pairedLEDId = String(pairedLEDIdQuery.recordset[0].LEDRack_id);
          console.log("PairedLEDId", pairedLEDId);

          // Update LED ID for paired position
          await pool
            .request()
            .query(
              `UPDATE StencilTable SET ${ledIdColumnB} = '${pairedLEDId}' WHERE BarcodeID = '${barcode}'`
            );

          // Update LED status for paired LED
          await pool
            .request()
            .input("PairedLEDid", sql.VarChar, pairedLEDId)
            .query(
              `UPDATE ${ledStatusTable} SET LEDRackStatus = 3 WHERE LEDRack_id = @PairedLEDid`
            );

          // Reset paired LED status after 2 seconds
          setTimeout(async () => {
            await pool
              .request()
              .input("PairedLEDid", sql.VarChar, pairedLEDId)
              .query(
                `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = @PairedLEDid`
              );
          }, 2000);
        }
      }
    }

    // Update LED status for primary LED
    await pool
      .request()
      .input("LEDid", sql.VarChar, LEDId)
      .query(
        `UPDATE ${ledStatusTable} SET LEDRackStatus = 3 WHERE LEDRack_id = @LEDid`
      );

    // Reset primary LED status after 2 seconds
    setTimeout(async () => {
      await pool
        .request()
        .input("LEDid", sql.VarChar, LEDId)
        .query(
          `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = @LEDid`
        );
    }, 2000);

    // Additional LED status update for LEDRack_id = 4
    await pool
      .request()
      .input("LEDid", sql.VarChar, LEDId)
      .query(
        `UPDATE ${ledStatusTable} SET LEDRackStatus = 1 WHERE LEDRack_id = 4`
      );

    // Reset LEDRack_id = 4 after 2 seconds
    setTimeout(async () => {
      await pool
        .request()
        .input("LEDid", sql.VarChar, LEDId)
        .query(
          `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = 4`
        );
    }, 2000);

    // Update OperationHistoryN with physical location
    await pool
      .request()
      .input("BarcodeID", sql.VarChar, barcode)
      .input("PhysicalLocation", sql.VarChar, physicalLoc)
      .query(
        `UPDATE OperationHistoryN 
         SET PhysicalLocation = @PhysicalLocation 
         WHERE ID = (
           SELECT TOP 1 ID 
           FROM OperationHistoryN 
           WHERE StencilBarcodeID = @BarcodeID 
           ORDER BY UpdatedDateTime DESC
         )`
      );

    // Update OperationHistoryN with paired physical location if applicable
    if (pairedPhysicalLoc) {
      await pool
        .request()
        .input("BarcodeID", sql.VarChar, barcode)
        .input("PairedPhysicalLocation", sql.VarChar, pairedPhysicalLoc)
        .query(
          `UPDATE OperationHistoryN 
           SET PairedPhysicalLocation = @PairedPhysicalLocation 
           WHERE ID = (
             SELECT TOP 1 ID 
             FROM OperationHistoryN 
             WHERE StencilBarcodeID = @BarcodeID 
             ORDER BY UpdatedDateTime DESC
           )`
        );
    }

    return res.status(200).send({
      differingPositions,
      rackNo,
      physicalLocation: physicalLoc,
      ledId: LEDId,
      pairedPhysicalLocation: pairedPhysicalLoc,
      pairedLedId: pairedLEDId
    });
  } catch (err) {
    console.error(err);
    return res.status(500).send("An error occurred.");
  }
};