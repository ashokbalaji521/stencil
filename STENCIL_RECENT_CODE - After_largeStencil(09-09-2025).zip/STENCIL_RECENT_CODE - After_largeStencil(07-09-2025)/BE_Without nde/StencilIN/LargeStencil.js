import { conConfig } from "../db.js";
import sql from "mssql";


export const updatedRackIDStencilTableforlargestencil = async (req, res) => {
  try {
    const pool = await sql.connect(conConfig);
    console.log("newcode", req.body);

    const changedRacks = req.body.changedRacks;
    const barcode = req.body.barcode;

    const rackNo = changedRacks.rackId;
    const newbit = changedRacks.new;
    const oldbit = changedRacks.old;

    const bits1 = newbit.split("");
    const bits2 = oldbit.split("");

    const differingPositions = [];

    for (let i = 0; i < bits1.length; i++) {
      if (bits1[i] !== bits2[i]) {
        differingPositions.push(i + 1);
      }
    }

    if (differingPositions.length === 0) {
      return res.status(400).send("No changes detected in rack status");
    }

    let position = differingPositions[0];
    let rackIdColumn, ledIdColumn, rackIdColumnB, ledIdColumnB;
    let rackStatusTable, ledStatusTable;

    if (rackNo === 'Rack-1') {
      rackIdColumn = 'RackID';
      ledIdColumn = 'LedID';
      rackStatusTable = 'stencilRackStatus';
      ledStatusTable = 'StencilLEDStatus';
    } else if (rackNo === 'Rack-2') {
      rackIdColumn = 'RackID2';
      ledIdColumn = 'LedID2';
      rackStatusTable = 'stencilRackStatus1_copy';
      ledStatusTable = 'StencilLEDStatus1';
    } else if (rackNo === 'Rack-3') {
      rackIdColumn = 'RackID3';
      ledIdColumn = 'LedID3';
      rackStatusTable = 'stencilRackStatus2_copy';
      ledStatusTable = 'StencilLEDStatus2';
    } else if (rackNo === 'Rack-4') {
      rackIdColumn = 'RackID4';
      ledIdColumn = 'LedID4';
      rackIdColumnB = 'RackID4B';
      ledIdColumnB = 'LedID4B';
      rackStatusTable = 'stencilRackStatus3_copy';
      ledStatusTable = 'StencilLEDStatus3';
    }

    // Determine paired physical location for Rack-4
    let pairedPosition = null;
    if (rackNo === 'Rack-4') {
      const physicalLocNum = parseInt(position);
      if (physicalLocNum % 2 === 1) {
        pairedPosition = physicalLocNum + 1; // Odd to even (e.g., 1 -> 2)
      } else {
        pairedPosition = physicalLocNum - 1; // Even to odd (e.g., 2 -> 1)
      }
    }

    // Reset all rack and LED columns
    let updateQuery = `
      UPDATE StencilTable 
      SET RackID = NULL, LedID = NULL, 
          RackID2 = NULL, LedID2 = NULL, 
          RackID3 = NULL, LedID3 = NULL, 
          RackID4 = NULL, LedID4 = NULL,
          RackID4B = NULL, LedID4B = NULL,
          Rackno = '${rackNo}',
          Authorized = 1, 
          AuthorizedOut = NULL 
      WHERE BarcodeID = '${barcode}'
    `;
    await pool.request().query(updateQuery);

    // Update primary position
    updateQuery = `
      UPDATE StencilTable 
      SET ${rackIdColumn} = '${position}'
      WHERE BarcodeID = '${barcode}'
    `;
    await pool.request().query(updateQuery);

    // Get physical location for primary position
    const getPhysicalPos = await pool
      .request()
      .query(
        `SELECT PhysicalLocation FROM ${rackStatusTable} WHERE Rack_id = '${position}'`
      );

    if (getPhysicalPos.recordset.length === 0) {
      return res.status(404).send(`No physical location found for Rack_id ${position} in ${rackStatusTable}`);
    }

    const physicalLoc = String(getPhysicalPos.recordset[0].PhysicalLocation);
    console.log("PhysicalLoc", physicalLoc);

    // Get LED ID for primary physical location
    const LEDIdquery = await pool
      .request()
      .input("PhysicalLoc", sql.VarChar, physicalLoc)
      .query(
        `SELECT LEDRack_id FROM ${ledStatusTable} WHERE PhysicalLocation = @PhysicalLoc`
      );

    if (LEDIdquery.recordset.length === 0) {
      return res.status(404).send(`No LED rack found for PhysicalLocation ${physicalLoc} in ${ledStatusTable}`);
    }

    const LEDId = String(LEDIdquery.recordset[0].LEDRack_id);
    console.log("LEDId", LEDId);

    // Update LED ID for primary position
    await pool
      .request()
      .query(
        `UPDATE StencilTable SET ${ledIdColumn} = '${LEDId}' WHERE BarcodeID = '${barcode}'`
      );

    // Handle paired position for Rack-4
    let pairedPhysicalLoc = null;
    let pairedLEDId = null;
    if (pairedPosition && rackNo === 'Rack-4') {
      // Update paired position in StencilTable
      updateQuery = `
        UPDATE StencilTable 
        SET ${rackIdColumnB} = '${pairedPosition}'
        WHERE BarcodeID = '${barcode}'
      `;
      await pool.request().query(updateQuery);

      // Get physical location for paired position
      const getPairedPhysicalPos = await pool
        .request()
        .query(
          `SELECT PhysicalLocation FROM ${rackStatusTable} WHERE Rack_id = '${pairedPosition}'`
        );

      if (getPairedPhysicalPos.recordset.length > 0) {
        pairedPhysicalLoc = String(getPairedPhysicalPos.recordset[0].PhysicalLocation);
        console.log("PairedPhysicalLoc", pairedPhysicalLoc);

        // Get LED ID for paired physical location
        const pairedLEDIdQuery = await pool
          .request()
          .input("PairedPhysicalLoc", sql.VarChar, pairedPhysicalLoc)
          .query(
            `SELECT LEDRack_id FROM ${ledStatusTable} WHERE PhysicalLocation = @PairedPhysicalLoc`
          );

        if (pairedLEDIdQuery.recordset.length > 0) {
          pairedLEDId = String(pairedLEDIdQuery.recordset[0].LEDRack_id);
          console.log("PairedLEDId", pairedLEDId);

          // Update LED ID for paired position
          await pool
            .request()
            .query(
              `UPDATE StencilTable SET ${ledIdColumnB} = '${pairedLEDId}' WHERE BarcodeID = '${barcode}'`
            );

          // Update LED status for paired LED
          await pool
            .request()
            .input("PairedLEDid", sql.VarChar, pairedLEDId)
            .query(
              `UPDATE ${ledStatusTable} SET LEDRackStatus = 3 WHERE LEDRack_id = @PairedLEDid`
            );

          // Reset paired LED status after 2 seconds
          setTimeout(async () => {
            await pool
              .request()
              .input("PairedLEDid", sql.VarChar, pairedLEDId)
              .query(
                `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = @PairedLEDid`
              );
          }, 2000);
        }
      }
    }

    // Update LED status for primary LED
    await pool
      .request()
      .input("LEDid", sql.VarChar, LEDId)
      .query(
        `UPDATE ${ledStatusTable} SET LEDRackStatus = 3 WHERE LEDRack_id = @LEDid`
      );

    // Reset primary LED status after 2 seconds
    setTimeout(async () => {
      await pool
        .request()
        .input("LEDid", sql.VarChar, LEDId)
        .query(
          `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = @LEDid`
        );
    }, 2000);

    // Additional LED status update for LEDRack_id = 4
    await pool
      .request()
      .input("LEDid", sql.VarChar, LEDId)
      .query(
        `UPDATE ${ledStatusTable} SET LEDRackStatus = 1 WHERE LEDRack_id = 4`
      );

    // Reset LEDRack_id = 4 after 2 seconds
    setTimeout(async () => {
      await pool
        .request()
        .input("LEDid", sql.VarChar, LEDId)
        .query(
          `UPDATE ${ledStatusTable} SET LEDRackStatus = 0 WHERE LEDRack_id = 4`
        );
    }, 2000);

    // Update OperationHistoryN with physical location
    await pool
      .request()
      .input("BarcodeID", sql.VarChar, barcode)
      .input("PhysicalLocation", sql.VarChar, physicalLoc)
      .query(
        `UPDATE OperationHistoryN 
         SET PhysicalLocation = @PhysicalLocation 
         WHERE ID = (
           SELECT TOP 1 ID 
           FROM OperationHistoryN 
           WHERE StencilBarcodeID = @BarcodeID 
           ORDER BY UpdatedDateTime DESC
         )`
      );

    // Update OperationHistoryN with paired physical location if applicable
    if (pairedPhysicalLoc) {
      await pool
        .request()
        .input("BarcodeID", sql.VarChar, barcode)
        .input("PairedPhysicalLocation", sql.VarChar, pairedPhysicalLoc)
        .query(
          `UPDATE OperationHistoryN 
           SET PairedPhysicalLocation = @PairedPhysicalLocation 
           WHERE ID = (
             SELECT TOP 1 ID 
             FROM OperationHistoryN 
             WHERE StencilBarcodeID = @BarcodeID 
             ORDER BY UpdatedDateTime DESC
           )`
        );
    }

    return res.status(200).send({
      differingPositions,
      rackNo,
      physicalLocation: physicalLoc,
      ledId: LEDId,
      pairedPhysicalLocation: pairedPhysicalLoc,
      pairedLedId: pairedLEDId
    });
  } catch (err) {
    console.error(err);
    return res.status(500).send("An error occurred.");
  }
};









//----------------------------------------    stencil out   ---------------------------------------------------------------------------//


export const removeWrongStencilforlargestencil = async (req, res) => {
  const pool = await sql.connect(conConfig);
  const barcode = req.body.barcode;
  console.log("barcode", barcode);

  try {
    // Get Rackno, LedID, RackID, and paired RackID4B, LedID4B for Rack-4
    const getRackInfo = await pool
      .request()
      .query(
        `SELECT Rackno, 
                CASE Rackno 
                  WHEN 'Rack-1' THEN LedID 
                  WHEN 'Rack-2' THEN LedID2 
                  WHEN 'Rack-3' THEN LedID3 
                  WHEN 'Rack-4' THEN LedID4 
                END AS LedID,
                CASE Rackno 
                  WHEN 'Rack-1' THEN RackID 
                  WHEN 'Rack-2' THEN RackID2 
                  WHEN 'Rack-3' THEN RackID3 
                  WHEN 'Rack-4' THEN RackID4 
                END AS RackID,
                CASE Rackno 
                  WHEN 'Rack-4' THEN RackID4B 
                  ELSE NULL 
                END AS RackID4B,
                CASE Rackno 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedID4B
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackInfo.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID, RackID, RackID4B, LedID4B } = getRackInfo.recordset[0];
    console.log("Rackno:", Rackno, "LedID:", LedID, "RackID:", RackID, "RackID4B:", RackID4B, "LedID4B:", LedID4B);

    if (!Rackno || !LedID || !RackID) {
      return res.status(400).json({ error: "Invalid Rackno, LedID, or RackID" });
    }

    // Determine the correct StencilLEDStatus table based on Rackno 
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Switch off the LED for the stencil, LEDRack_id = 2, and LedID4B (if Rack-4)
    let ledIds = [LedID, "2"];
    if (Rackno === "Rack-4" && LedID4B) {
      ledIds.push(LedID4B);
    }

    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] IN (${ledIds.map(id => `'${id}'`).join(',')})`
      );

    // Find Rack_id where RackStatus = 1 and stencil exists
    const rackStatusTableMap = {
      "Rack-1": "stencilRackStatus",
      "Rack-2": "stencilRackStatus1_copy",
      "Rack-3": "stencilRackStatus2_copy",
      "Rack-4": "stencilRackStatus3_copy",
    };
    const rackStatusTable = rackStatusTableMap[Rackno];

    const getRackId = await pool
      .request()
      .query(
        `SELECT Rack_id 
         FROM [${rackStatusTable}] 
         WHERE RackStatus = 1 
         AND EXISTS (
           SELECT 1 
           FROM [StencilTable] B 
           WHERE B.Rackno = '${Rackno}' 
           AND (
             (B.RackID = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-1') OR 
             (B.RackID2 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-2') OR 
             (B.RackID3 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-3') OR 
             (B.RackID4 = [${rackStatusTable}].Rack_id AND '${Rackno}' = 'Rack-4')
           )
         )`
      );

    if (getRackId.recordset.length === 0) {
      return res.status(404).json({ error: "No active rack found" });
    }

    // Turn on light and sound (LEDRack_id 1 and 4)
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 1 
         WHERE [LEDRack_id] IN (1, 4)`
      );

    await new Promise((resolve) => setTimeout(resolve, 2000));
    console.log("Light up");

    // Turn off light and sound (LEDRack_id 2 and 4)
    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] IN (2, 4)`
      );
    console.log("Light off");

    // Update StencilTable to reset RackID, LedID, RackID4B, and LedID4B for the appropriate rack
    let updateQuery = `
      UPDATE [StencilTable] 
      SET RackID = CASE WHEN Rackno = 'Rack-1' THEN NULL ELSE RackID END,
          LedID = CASE WHEN Rackno = 'Rack-1' THEN NULL ELSE LedID END,
          RackID2 = CASE WHEN Rackno = 'Rack-2' THEN NULL ELSE RackID2 END,
          LedID2 = CASE WHEN Rackno = 'Rack-2' THEN NULL ELSE LedID2 END,
          RackID3 = CASE WHEN Rackno = 'Rack-3' THEN NULL ELSE RackID3 END,
          LedID3 = CASE WHEN Rackno = 'Rack-3' THEN NULL ELSE LedID3 END,
          RackID4 = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE RackID4 END,
          LedID4 = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE LedID4 END,
          RackID4B = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE RackID4B END,
          LedID4B = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE LedID4B END
      WHERE BarcodeID = '${barcode}'`;

    await pool.request().query(updateQuery);

    // Get PhysicalLocation and PairedPhysicalLocation for Rack-4
    let physicalLoc = "";
    let pairedPhysicalLoc = null;
    if (RackID) {
      const getPhysicalLoc = await pool
        .request()
        .query(
          `SELECT [PhysicalLocation] 
           FROM [${rackStatusTable}] 
           WHERE [Rack_id] = '${RackID}'`
        );
      physicalLoc = getPhysicalLoc.recordset[0]?.PhysicalLocation || "";

      if (Rackno === "Rack-4" && RackID4B) {
        const getPairedPhysicalLoc = await pool
          .request()
          .query(
            `SELECT [PhysicalLocation] 
             FROM [${rackStatusTable}] 
             WHERE [Rack_id] = '${RackID4B}'`
          );
        pairedPhysicalLoc = getPairedPhysicalLoc.recordset[0]?.PhysicalLocation || null;
      }
    }

    // Update PhysicalLocation and PairedPhysicalLocation in OperationHistoryN
    let historyUpdateQuery = `
      UPDATE [OperationHistoryN]
      SET PhysicalLocation = @PhysicalLocation`;
    if (pairedPhysicalLoc && Rackno === "Rack-4") {
      historyUpdateQuery += `, PairedPhysicalLocation = @PairedPhysicalLocation`;
    }
    historyUpdateQuery += `
      WHERE ID = (
        SELECT TOP 1 ID
        FROM [OperationHistoryN]
        WHERE StencilBarcodeID = @BarcodeID
        ORDER BY UpdatedDateTime DESC
      )`;

    const historyRequest = pool
      .request()
      .input("PhysicalLocation", sql.VarChar, physicalLoc)
      .input("BarcodeID", sql.VarChar, barcode);
    if (pairedPhysicalLoc && Rackno === "Rack-4") {
      historyRequest.input("PairedPhysicalLocation", sql.VarChar, pairedPhysicalLoc);
    }
    await historyRequest.query(historyUpdateQuery);

    return res.status(200).json({
      success: "success",
      physicalLocation: physicalLoc,
      pairedPhysicalLocation: pairedPhysicalLoc,
      rackno: Rackno,
      ledId: LedID,
      rackId: RackID,
      ledId4B: LedID4B,
      rackId4B: RackID4B
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to remove data" });
  }
};

export const LightUpStencilforlargestencil = async (req, res) => {
  const barcode = req.body.barcode;
  console.log("barcode", barcode);

  try {
    const pool = await sql.connect(conConfig);

    // Get Rackno, LedID, RackID, and paired RackID4B, LedID4B for Rack-4
    const getRackInfo = await pool
      .request()
      .query(
        `SELECT Rackno, 
                CASE Rackno 
                  WHEN 'Rack-1' THEN LedID 
                  WHEN 'Rack-2' THEN LedID2 
                  WHEN 'Rack-3' THEN LedID3 
                  WHEN 'Rack-4' THEN LedID4 
                END AS LedID,
                CASE Rackno 
                  WHEN 'Rack-1' THEN RackID 
                  WHEN 'Rack-2' THEN RackID2 
                  WHEN 'Rack-3' THEN RackID3 
                  WHEN 'Rack-4' THEN RackID4 
                END AS RackID,
                CASE Rackno 
                  WHEN 'Rack-4' THEN RackID4B 
                  ELSE NULL 
                END AS RackID4B,
                CASE Rackno 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedID4B
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackInfo.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID, RackID, RackID4B, LedID4B } = getRackInfo.recordset[0];
    console.log("Rackno:", Rackno, "LedID:", LedID, "RackID:", RackID, "RackID4B:", RackID4B, "LedID4B:", LedID4B);

    if (!Rackno || !LedID || !RackID) {
      return res.status(400).json({ error: "Invalid rack or LED data" });
    }

    // Update AuthorizedOut, Status, Authorized, and reset RackID/LedID columns in StencilTable
    let updateQuery = `
      UPDATE [StencilTable] 
      SET AuthorizedOut = 1, 
          [Status] = 0, 
          [Authorized] = 0,
          LastOutDate = GETDATE(),
          RackID = CASE WHEN Rackno = 'Rack-1' THEN NULL ELSE RackID END,
          LedID = CASE WHEN Rackno = 'Rack-1' THEN NULL ELSE LedID END,
          RackID2 = CASE WHEN Rackno = 'Rack-2' THEN NULL ELSE RackID2 END,
          LedID2 = CASE WHEN Rackno = 'Rack-2' THEN NULL ELSE LedID2 END,
          RackID3 = CASE WHEN Rackno = 'Rack-3' THEN NULL ELSE RackID3 END,
          LedID3 = CASE WHEN Rackno = 'Rack-3' THEN NULL ELSE LedID3 END,
          RackID4 = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE RackID4 END,
          LedID4 = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE LedID4 END,
          RackID4B = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE RackID4B END,
          LedID4B = CASE WHEN Rackno = 'Rack-4' THEN NULL ELSE LedID4B END
      WHERE BarcodeID = '${barcode}'`;

    await pool.request().query(updateQuery);

    // Determine the correct StencilLEDStatus table based on Rackno
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Update LEDRackStatus for the primary LED
    await pool
      .request()
      .input("LedId", sql.VarChar, LedID)
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 3 
         WHERE [LEDRack_id] = @LedId`
      );

    // Update LEDRackStatus for the paired LED (Rack-4 only)
    if (Rackno === "Rack-4" && LedID4B) {
      await pool
        .request()
        .input("LedId4B", sql.VarChar, LedID4B)
        .query(
          `UPDATE [${ledStatusTable}] 
           SET [LEDRackStatus] = 3 
           WHERE [LEDRack_id] = @LedId4B`
        );

      // Reset paired LED status after 2 seconds
      setTimeout(async () => {
        await pool
          .request()
          .input("LedId4B", sql.VarChar, LedID4B)
          .query(
            `UPDATE [${ledStatusTable}] 
             SET [LEDRackStatus] = 0 
             WHERE [LEDRack_id] = @LedId4B`
          );
      }, 2000);
    }

    // Update LEDRackStatus for LEDRack_id = 2 (sound/light indicator)
    await pool
      .request()
      .input("LedId", sql.VarChar, "2")
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 1 
         WHERE [LEDRack_id] = @LedId`
      );

    // Reset LEDRackStatus for LEDRack_id = 2 after 2 seconds
    setTimeout(async () => {
      await pool
        .request()
        .input("LedId", sql.VarChar, "2")
        .query(
          `UPDATE [${ledStatusTable}] 
           SET [LEDRackStatus] = 0 
           WHERE [LEDRack_id] = @LedId`
        );
    }, 2000);

    // Get rack status from tblRackSensorInput
    const getRackStatus = await pool
      .request()
      .query(
        `SELECT data FROM [tblRackSensorInput] 
         WHERE rackid = '${Rackno}'`
      );
    const rackBit = getRackStatus.recordset[0]?.data || "";

    // Determine the correct stencilRackStatus table based on Rackno
    const rackStatusTableMap = {
      "Rack-1": "stencilRackStatus",
      "Rack-2": "stencilRackStatus1_copy",
      "Rack-3": "stencilRackStatus2_copy",
      "Rack-4": "stencilRackStatus3_copy",
    };
    const rackStatusTable = rackStatusTableMap[Rackno];

    // Get PhysicalLocation and PairedPhysicalLocation for Rack-4
    let physicalLoc = "";
    let pairedPhysicalLoc = null;
    if (RackID) {
      const getPhysicalLoc = await pool
        .request()
        .query(
          `SELECT [PhysicalLocation] 
           FROM [${rackStatusTable}] 
           WHERE [Rack_id] = '${RackID}'`
        );
      physicalLoc = getPhysicalLoc.recordset[0]?.PhysicalLocation || "";

      if (Rackno === "Rack-4" && RackID4B) {
        const getPairedPhysicalLoc = await pool
          .request()
          .query(
            `SELECT [PhysicalLocation] 
             FROM [${rackStatusTable}] 
             WHERE [Rack_id] = '${RackID4B}'`
          );
        pairedPhysicalLoc = getPairedPhysicalLoc.recordset[0]?.PhysicalLocation || null;
      }
    }

    // Update PhysicalLocation and PairedPhysicalLocation in OperationHistoryN
    let historyUpdateQuery = `
      UPDATE [OperationHistoryN]
      SET PhysicalLocation = @PhysicalLocation`;
    if (pairedPhysicalLoc) {
      historyUpdateQuery += `, PairedPhysicalLocation = @PairedPhysicalLocation`;
    }
    historyUpdateQuery += `
      WHERE ID = (
        SELECT TOP 1 ID
        FROM [OperationHistoryN]
        WHERE StencilBarcodeID = @BarcodeID
        ORDER BY UpdatedDateTime DESC
      )`;

    const historyRequest = pool
      .request()
      .input("PhysicalLocation", sql.VarChar, physicalLoc)
      .input("BarcodeID", sql.VarChar, barcode);
    if (pairedPhysicalLoc) {
      historyRequest.input("PairedPhysicalLocation", sql.VarChar, pairedPhysicalLoc);
    }
    await historyRequest.query(historyUpdateQuery);

    // Respond with updated information
    return res.status(200).json({
      ledId: LedID,
      rackId: RackID,
      rackId4B: RackID4B,
      ledId4B: LedID4B,
      rackBit: rackBit,
      barcode: barcode,
      physicalLocation: physicalLoc,
      pairedPhysicalLocation: pairedPhysicalLoc,
      rackno: Rackno,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to LightUp" });
  }
};


export const updateEmptyStencilDataforlargestencil = async (req, res) => {
  try {
    const barcode = req.body.barcode;
    const pool = await sql.connect(conConfig);

    // Get Rackno and LedID4B (for Rack-4) from StencilTable
    const getRackno = await pool
      .request()
      .query(
        `SELECT Rackno, 
                CASE Rackno 
                  WHEN 'Rack-4' THEN LedID4B 
                  ELSE NULL 
                END AS LedID4B
         FROM [StencilTable] 
         WHERE BarcodeID = '${barcode}'`
      );

    if (getRackno.recordset.length === 0) {
      return res.status(404).json({ error: "Stencil not found" });
    }

    const { Rackno, LedID4B } = getRackno.recordset[0];

    if (!Rackno) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Determine the correct StencilLEDStatus table based on Rackno
    const ledStatusTableMap = {
      "Rack-1": "StencilLEDStatus",
      "Rack-2": "StencilLEDStatus1",
      "Rack-3": "StencilLEDStatus2",
      "Rack-4": "StencilLEDStatus3",
    };
    const ledStatusTable = ledStatusTableMap[Rackno];

    if (!ledStatusTable) {
      return res.status(400).json({ error: "Invalid Rackno" });
    }

    // Update LEDRackStatus to 0 for LEDRack_id = 2 and LedID4B (if Rack-4)
    let ledIds = ["2"];
    if (Rackno === "Rack-4" && LedID4B) {
      ledIds.push(LedID4B);
    }

    await pool
      .request()
      .query(
        `UPDATE [${ledStatusTable}] 
         SET [LEDRackStatus] = 0 
         WHERE [LEDRack_id] IN (${ledIds.map(id => `'${id}'`).join(',')})`
      );

    return res.status(200).json({ success: "success" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ error: "Failed to Empty" });
  }
};

















