import React, { useState, useEffect } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { CircularProgress, Box, Button, TextField } from "@mui/material";
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import Header from "./Header";
import axios from "axios";
import { format, addHours, addMinutes, subHours, subMinutes } from 'date-fns';
import { Data } from "../Custom/custom";
import * as XLSX from 'xlsx';

const OperatorHistory = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageSize, setPageSize] = useState(5);
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);

  const fetchData = async (filters = {}) => {
    setLoading(true);
    try {
      // Add 5 hours and 30 minutes to fromTime and toTime for IST
      const fromtime = filters.fromtime
        ? addMinutes(addHours(filters.fromtime, 5), 30).toISOString()
        : "";
      const totime = filters.totime
        ? addMinutes(addHours(filters.totime, 5), 30).toISOString()
        : "";

      const response = await axios.post(`${Data.url}getOperatorHistoryDatetimeFilter`, {
        fromtime,
        totime,
      });

      const TableData = response.data.map((item) => {
        // Handle PhysicalLocation and PairedPhysicalLocation
        let slotValue = "N/A";
        if (item.PhysicalLocation || item["Physical Location"]) {
          const physicalLoc = item.PhysicalLocation || item["Physical Location"];
          if (item.PairedPhysicalLocation) {
            // Combine and sort in ascending order
            const locations = [physicalLoc, item.PairedPhysicalLocation].sort((a, b) => a - b);
            slotValue = `[${locations.join(",")}]`;
          } else {
            slotValue = physicalLoc;
          }
        }

        return {
          ID: item.ID,
          OperatorId: item.OperatorID,
          Time: format(subMinutes(subHours(new Date(item.UpdatedDateTime), 5), 30), 'yyyy-MM-dd HH:mm:ss'),
          Action: item.Operation,
          StencilBarcodeId: item.StencilBarcodeID,
          StencilId: item.StencilID,
          PhysicalLocation: slotValue, // Updated to use formatted slotValue
          Rackno: item.Rackno || "N/A",
        };
      });

      // Set data in the same order as received
      setData(TableData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSearch = () => {
    fetchData({ fromtime: fromTime, totime: toTime });
  };

  const handleFromTimeChange = (newValue) => {
    setFromTime(newValue);
  };

  const handleToTimeChange = (newValue) => {
    setToTime(newValue);
  };

  const handleDownload = () => {
    const orderedData = data.map((item, index) => ({
      "SL No": index + 1,
      OperatorId: item.OperatorId || "",
      StencilId: item.StencilId || "",
      StencilBarcodeId: item.StencilBarcodeId || "",
      Time: item.Time || "",
      Action: item.Action || "",
      Slot: item.PhysicalLocation || "", // Use formatted PhysicalLocation (Slot)
      Rackno: item.Rackno || "",
    }));

    const ws = XLSX.utils.json_to_sheet(orderedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Operator History");
    XLSX.writeFile(wb, "operator_history.xlsx");
  };

  const columns = [
    {
      field: "OperatorId",
      headerName: "OperatorId",
      width: 200,
      headerClassName: "super-app-theme--header-operator",
    },
    {
      field: "StencilId",
      headerName: "StencilId",
      width: 200,
      headerClassName: "super-app-theme--header-stencil",
    },
    {
      field: "StencilBarcodeId",
      headerName: "BarcodeId",
      width: 300,
      headerClassName: "super-app-theme--header-barcode",
    },
    {
      field: "Time",
      headerName: "DateTime",
      width: 350,
      headerClassName: "super-app-theme--header-time",
    },
    {
      field: "Action",
      headerName: "IN/OUT",
      width: 200,
      headerClassName: "super-app-theme--header-action",
    },
    {
      field: "PhysicalLocation",
      headerName: "Slot",
      width: 250,
      headerClassName: "super-app-theme--header-location",
    },
    {
      field: "Rackno",
      headerName: "Rack No",
      width: 150,
      headerClassName: "super-app-theme--header-rackno",
    },
  ];

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Header data={"Operation History"} />

      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <DateTimePicker
          label="From Time"
          value={fromTime}
          onChange={handleFromTimeChange}
          renderInput={(params) => <TextField {...params} />}
        />

        <Box sx={{ mx: 2 }} />

        <DateTimePicker
          label="To Time"
          value={toTime}
          onChange={handleToTimeChange}
          renderInput={(params) => <TextField {...params} />}
        />

        <Box sx={{ mx: 2 }} />

        <Button variant="contained" onClick={handleSearch}>Search</Button>

        <Box sx={{ mx: 2 }} />

        <Button variant="contained" color="secondary" onClick={handleDownload}>
          Download
        </Button>
      </Box>

      <Box sx={{ height: 700, width: '100%' }}>
        {loading ? (
          <CircularProgress />
        ) : (
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={pageSize}
            onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
            components={{ Toolbar: GridToolbar }}
            rowsPerPageOptions={[5, 10, 20]}
            getRowId={(row) => `${row.ID || row.StencilId || row.StencilBarcodeId || row.Time}_${Math.random()}`}
            sx={{
              '& .MuiDataGrid-cell': {
                borderRight: '1px solid #ddd',
              },
              '& .super-app-theme--header-operator': {
                backgroundColor: '#f0f8ff',
                color: '#333',
              },
              '& .super-app-theme--header-stencil': {
                backgroundColor: '#ffe4e1',
                color: '#333',
              },
              '& .super-app-theme--header-barcode': {
                backgroundColor: '#f5f5dc',
                color: '#333',
              },
              '& .super-app-theme--header-time': {
                backgroundColor: '#e0ffff',
                color: '#333',
              },
              '& .super-app-theme--header-action': {
                backgroundColor: '#f0f8ff',
                color: '#333',
              },
              '& .super-app-theme--header-location': {
                backgroundColor: '#f8f8ff',
                color: '#333',
              },
              '& .super-app-theme--header-rackno': {
                backgroundColor: '#e6e6fa',
                color: '#333',
              },
            }}
          />
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default OperatorHistory;