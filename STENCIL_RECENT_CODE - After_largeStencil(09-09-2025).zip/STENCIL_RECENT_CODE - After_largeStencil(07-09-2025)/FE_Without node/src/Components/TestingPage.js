// import React, { useState, useEffect } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
// import axios from "axios";
// import { Data } from "../Custom/custom";
// import logo from "../Utils/logo.png";
// import { useNavigate } from "react-router-dom";
// import { Button } from "@mui/material";

// const ColorBoxes = () => {
//   const colors = [
//     { number: 1, color: "red" },
//     { number: 2, color: "yellow" },
//     { number: 3, color: "green" },
//     { number: 4, color: "blue" },
//     { number: 5, color: "violet" },
//     { number: 6, color: "purple" },
//   ];

//   return (
//     <div
//       style={{
//         display: "flex",
//         gap: "10px",
//         marginBottom: "10px",
//         marginLeft: "500px",
//       }}
//     >
//       {colors.map((box) => (
//         <div
//           key={box.number}
//           style={{
//             width: "40px",
//             height: "40px",
//             backgroundColor: box.color,
//             color: "",
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//             fontWeight: "bold",
//             borderRadius: "5px",
//           }}
//         >
//           {box.number}
//         </div>
//       ))}
//     </div>
//   );
// };

// const RackDataTable = () => {
//   const [rackData, setRackData] = useState([]);
//   const [rackData1, setRackData1] = useState([]);
//   const [editMode, setEditMode] = useState(false);
//   const [editData, setEditData] = useState({ row: null, col: null, value: "" });
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await axios.post(`${Data.url}updateStatus`);
//         if (response.data && Array.isArray(response.data)) {
//           setRackData(response.data);
//         }
//       } catch (error) {
//         console.error("Error fetching data:", error);
//       }
//     };

//     fetchData();
//   }, []);

//   useEffect(() => {
//     const fetchData1 = async () => {
//       try {
//         const response = await axios.post(`${Data.url}getStatus`);
//         if (response.data && Array.isArray(response.data)) {
//           setRackData1(response.data);
//         }
//       } catch (error) {
//         console.error("Error fetching data:", error);
//       }
//     };

//     fetchData1();
//   }, []);

//   const handleEditClick = (rowIndex, colIndex, value) => {
//     setEditData({ row: rowIndex, col: colIndex, value });
//   };

//   const handleChange = (e) => {
//     setEditData({ ...editData, value: e.target.value });
//   };

//   const handleSave = async () => {
//     try {
//       const updatedData = rackData1.map((rack, rowIndex) => {
//         if (rowIndex === editData.row) {
//           const newData = rack.LEDRackStatus.split("");
//           newData[editData.col] = editData.value;
//           return { ...rack, LEDRackStatus: newData.join("") };
//         }
//         return rack;
//       });

//       const updatedRackData = updatedData.map((rack) => ({
//         LEDRack_id: rack.LEDRack_id,
//         LEDRackStatus: rack.LEDRackStatus,
//       }));

//       await axios.post(`${Data.url}updateRackData`, {
//         updatedRackData,
//       });

//       setRackData1(updatedData);
//       setEditData({ row: null, col: null, value: "" });
//       setEditMode(false);
//     } catch (error) {
//       console.error("Error saving data:", error);
//     }
//   };

//   const handleCancel = () => {
//     setEditData({ row: null, col: null, value: "" });
//     setEditMode(false);
//   };

//   const transposeData = (data) => {
//     if (data.length === 0 || !data[0].LEDRackStatus) return [];
//     const numCols = data[0].LEDRackStatus.length;
//     return Array.from({ length: numCols }, (_, colIndex) =>
//       data.map((row) => row.LEDRackStatus[colIndex])
//     );
//   };

//   const getColumnHeaders = (data) => {
//     if (data.length === 0 || !data[0].LEDRackStatus) return [];

//     const predefinedHeaders = ["G", "Y", "R", "B"];
//     const numAdditionalHeaders = 64 - predefinedHeaders.length; // Assuming you always want 60 columns

//     // Instead of mapping 64, 63, ..., map 1, 2, 3, etc.
//     const additionalHeaders = Array.from(
//       { length: numAdditionalHeaders },
//       (_, index) => (60 - index).toString() // Starting from 5
//     );

//     return [...predefinedHeaders, ...additionalHeaders];
//   };

//   const columnHeaders = getColumnHeaders(rackData1);

//   if (rackData1.length === 0) {
//     return <div className="text-center">Loading...</div>;
//   }

//   const transposedRackData = transposeData(rackData1);

//   const getCellStyle = (value) => {
//     return value === "0" ? "bg-success text-white" : "bg-danger text-white";
//   };

//   const handleHomeClick = () => {
//     navigate("/Homepage"); // Navigate to the homepage
//   };
  
//   return (
//     <div className="container mt-5">
//       <div
//         className="NewStencilRegistration text-center mb-4"
//         style={{
//           display: "flex", // Enables flexbox layout
//           alignItems: "center", // Vertically center the items
//           justifyContent: "left", // Align items to the left
//         }}
//       >
//         <img
//           src={logo} // Use the imported image
//           alt="Logo"
//           style={{
//             height: 40, // Adjust the height of the image
//             marginRight: 8, // Add margin for spacing between the image and text
//           }}
//         />
//         <h2 className="child" style={{ margin: 0 }}>
//           Stencil Rack Status
//         </h2>

//         <Button
//           color="inherit"
//           onClick={handleHomeClick} // Use handleHomeClick to navigate
//           sx={{ fontWeight: "bold", color: "#fff" }}
//         >
//           Home
//         </Button>
//       </div>

//       {/* Edit Button Section */}
//       <div className="mb-3 text-center">
//         <button
//           className={`btn ${editMode ? "btn-secondary" : "btn-primary"}`}
//           onClick={() => setEditMode(!editMode)}
//         >
//           {editMode ? "View Mode" : "Edit Mode"}
//         </button>
//       </div>
//       <ColorBoxes />
//       <div>
//         <h3>SENSOR</h3>
//       </div>
//       {/* Upper Table for Sensor Status */}
//       <div className="table-responsive">
//         <table className="table table-bordered table-hover">
//           <thead className="thead-dark">
//             <tr>
//               <th className="text-center">Rack ID</th>
//               {rackData[0]?.data?.length > 0 &&
//                 Array.from({ length: rackData[0].data.length }, (_, index) => (
//                   <th key={index + 1} className="text-center">
//                     {index + 1}
//                   </th>
//                 ))}
//             </tr>
//           </thead>
//           <tbody>
//             {rackData.map((rack, rowIndex) => (
//               <tr key={rowIndex}>
//                 <td className="text-center font-weight-bold">{rack.rackid}</td>
//                 {rack.data?.split("").map((char, colIndex) => (
//                   <td
//                     key={colIndex}
//                     className={`text-center ${getCellStyle(char)}`}
//                   >
//                     {char}
//                   </td>
//                 ))}
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//       <div>
//         <h3>LED</h3>
//       </div>
//       {/* LED Rack Status Table - Keep original structure */}
//       <div className="table-responsive">
//         <table className="table table-bordered table-hover">
//           <thead className="thead-dark">
//             <tr>
//               {columnHeaders.map((header) => (
//                 <th key={header} className="text-center">
//                   {header}
//                 </th>
//               ))}
//             </tr>
//           </thead>
//           <tbody>
//             {transposedRackData.map((column, colIndex) => (
//               <tr key={colIndex}>
//                 {column.map((char, rowIndex) => (
//                   <td
//                     key={rowIndex}
//                     className={`text-center ${getCellStyle(char)}`}
//                   >
//                     {editMode &&
//                     editData.col === colIndex &&
//                     editData.row === rowIndex ? (
//                       <>
//                         <input
//                           type="text"
//                           value={editData.value}
//                           onChange={(e) =>
//                             setEditData({ ...editData, value: e.target.value })
//                           }
//                           autoFocus
//                         />
//                         <button
//                           className="btn btn-success btn-sm ml-2"
//                           onClick={handleSave}
//                         >
//                           Save
//                         </button>
//                         <button
//                           className="btn btn-secondary btn-sm ml-2"
//                           onClick={() =>
//                             setEditData({ row: null, col: null, value: "" })
//                           }
//                         >
//                           Cancel
//                         </button>
//                       </>
//                     ) : (
//                       <>
//                         {char}
//                         {editMode && (
//                           <button
//                             className="btn btn-primary btn-sm ml-2"
//                             onClick={() =>
//                               setEditData({
//                                 row: rowIndex,
//                                 col: colIndex,
//                                 value: char,
//                               })
//                             }
//                           >
//                             Edit
//                           </button>
//                         )}
//                       </>
//                     )}
//                   </td>
//                 ))}
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// };

// export default RackDataTable;

//-------------------------------------------------------------------------------------------------------//
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { Data } from "../Custom/custom"; // Assuming this contains your base URL
import logo from "../Utils/logo.png";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";
 
// --- Helper Components and Functions (Keep these as they were) ---
 
const ColorBoxes = () => {
  const colors = [
    { number: 1, color: "red" },
    { number: 2, color: "yellow" },
    { number: 3, color: "green" },
    { number: 4, color: "blue" },
    { number: 5, color: "violet" },
    { number: 6, color: "purple" },
  ];
 
  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
        marginBottom: "10px",
        marginLeft: "500px",
      }}
    >
      {colors.map((box) => (
        <div
          key={box.number}
          style={{
            width: "40px",
            height: "40px",
            backgroundColor: box.color,
            color: "black",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: "bold",
            borderRadius: "5px",
          }}
        >
          {box.number}
        </div>
      ))}
    </div>
  );
};
 
const getCellStyle = (value) => {
  return value === "0" ? "bg-success text-white" : "bg-danger text-white";
};
 
const transposeData = (data) => {
  if (!data || data.length === 0 || !data[0].LEDRackStatus) return [];
 
  const expectedLength = data[0].LEDRackStatus.length;
 
  const paddedData = data.map(row => {
    let status = row.LEDRackStatus || "";
    if (status.length < expectedLength) {
      status = status.padEnd(expectedLength, '0');
    }
    return { ...row, LEDRackStatus: status };
  });
 
  return Array.from({ length: expectedLength }, (_, colIndex) =>
    paddedData.map((row) => row.LEDRackStatus[colIndex])
  );
};
 
const getColumnHeaders = (data) => {
  const predefinedHeaders = ["G", "Y", "R", "B"];
 
  const dataLength = data && data.length > 0 && data[0].LEDRackStatus ? data[0].LEDRackStatus.length : 64;
  const numNumberedHeaders = dataLength > predefinedHeaders.length ? dataLength - predefinedHeaders.length : 0;
 
 
  const numberedHeaders = Array.from({ length: numNumberedHeaders }, (_, index) => (index + 1).toString());
 
  return [...predefinedHeaders, ...numberedHeaders];
};
 
 
// --- TransposedDataTable Component (Buttons with Text) ---
const TransposedDataTable = ({
  title,
  data, // Array of original records with { LEDRack_id, LEDRackStatus, PhysicalLocation }
  isEditable, // Global edit mode status from parent
  editMode, // This is just the global edit mode from the parent
  editData, // { rackId: null, col: null, value: "", sourceKey: null }
  handleEditClick, // Function to call when a cell is clicked in edit mode
  handleSave, // Function to call when save is triggered from input or button
  handleCancel, // Function to call when cancel is triggered from input or button
  sourceKey, // Identifier for this table instance (e.g., 'rack1')
  setEditData, // Function to update the editData state
}) => {
 
  const transposedData = transposeData(data);
  const columnHeaders = getColumnHeaders(data);
 
  if (!data || data.length === 0) {
    return <div className="text-center">Loading {title}...</div>;
  }
 
  const rackColumnHeaders = data.map(record => record.PhysicalLocation || `ID: ${record.LEDRack_id || 'N/A'}`);
 
 
  return (
    <div className="table-responsive mt-4">
      <h3>{title}</h3>
      <table className="table table-bordered table-hover">
        <thead className="thead-dark">
          <tr>
            <th className="text-center">Status Bit</th>
            {data.map((record, index) => (
              // Use LEDRack_id as a key if available and reliable, otherwise index
              <th key={record.LEDRack_id || index} className="text-center">
                {record.PhysicalLocation || `Rack ${record.LEDRack_id || index + 1}`}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {transposedData.map((columnData, colIndex) => {
            const statusBitHeader = columnHeaders[colIndex];
 
            return (
              <tr key={colIndex}>
                <th className="text-center">{statusBitHeader}</th>
 
                {columnData.map((char, rowIndex) => {
                  const record = data[rowIndex];
 
                  return (
                    <td
                      key={rowIndex}
                      className={`text-center ${getCellStyle(char)}`}
                      onClick={() => {
                        // Check if global edit mode is enabled
                        if (editMode) {
                          // Call handleEditClick with the correct parameters
                          handleEditClick(record?.LEDRack_id, colIndex, char, sourceKey);
                        }
                      }}
                      style={{ cursor: editMode ? 'pointer' : 'default' }} // Simplified cursor check
                    >
                      {/* Conditional rendering for the input field AND BUTTONS */}
                      {editMode && // Global edit mode must be on
                        editData.sourceKey === sourceKey && // Check if the editData belongs to this table instance
                        editData.rackId === record?.LEDRack_id && // Check if the editData is for this specific rack record (row) - Use ?. for safety
                        editData.col === colIndex ? ( // Check if the editData is for this specific status bit position (column)
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}>
                          <input
                            type="text"
                            value={editData.value}
                            // Ensure only '0' or '1' is allowed, or remove if any character is valid
                            onChange={(e) => {
                              const newValue = e.target.value;
                              if (newValue === '0' || newValue === '1' || newValue === '') {
                                setEditData({ ...editData, value: newValue });
                              } else {
                                // Optional: Alert user or show feedback for invalid input
                                // console.warn("Invalid input. Please enter '0' or '1'.");
                              }
                            }}
                            autoFocus // Automatically focus the input when it appears
                            maxLength="1" // Limit input to one character
                            className="form-control form-control-sm d-inline-block" // Use d-inline-block for flex alignment
                            style={{ width: '30px', textAlign: 'center', flexShrink: 0 }} // Compact style
                            // onBlur removed to prevent premature cancel
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                handleSave();
                                e.preventDefault();
                              }
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Escape') {
                                handleCancel();
                                e.preventDefault();
                              }
                            }}
                          />
                          {/* Explicit Save Button with text */}
                          <button
                            className="btn btn-success btn-sm"
                            onClick={handleSave}
                            style={{ flexShrink: 0 }} // Prevent shrinking in flex container
                          >
                            Save
                          </button>
                          {/* Explicit Cancel Button with text */}
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={handleCancel}
                            style={{ flexShrink: 0 }} // Prevent shrinking
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        // Display the character when not editing
                        char
                      )}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
 
 
// --- Main RackDataTable Component (Includes Save/Cancel Handlers) ---
const RackDataTable = () => {
  const [sensorData, setSensorData] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({ rackId: null, col: null, value: "", sourceKey: null });
 
  const [rackData, setRackData] = useState({
    rack1: [],
    rack2: [],
    rack3: [],
    rack4: [],
  });
 
  const navigate = useNavigate();
 
 
  const racksConfig = [
    { key: 'rack1', title: 'Rack 1 Status', apiId: 'Rack-1', endpoint: `${Data.url}getStatus1`, updateEndpoint: `${Data.url}updateRackData` },
    { key: 'rack2', title: 'Rack 2 Status', apiId: 'Rack-2', endpoint: `${Data.url}getStatus2`, updateEndpoint: `${Data.url}updateRackData1` },
    { key: 'rack3', title: 'Rack 3 Status', apiId: 'Rack-3', endpoint: `${Data.url}getStatus3`, updateEndpoint: `${Data.url}updateRackData2` },
    { key: 'rack4', title: 'Rack 4 Status', apiId: 'Rack-4', endpoint: `${Data.url}getStatus4`, updateEndpoint: `${Data.url}updateRackData3` },
  ];
 
 
  useEffect(() => {
    const fetchSensorData = async () => {
      try {
        const response = await axios.post(`${Data.url}updateStatus`);
        if (response.data && Array.isArray(response.data)) {
         
          const rackIdMap = {};
         
       
          response.data.forEach(rack => {
            rackIdMap[rack.rackid] = rack;
          });
       
          const sortedData = racksConfig.map(config =>
            rackIdMap[config.apiId] || { rackid: config.apiId, data: "" }
          );
         
          setSensorData(sortedData);
        } else {
          console.warn("Unexpected sensor data format:", response.data);
          setSensorData([]);
        }
      } catch (error) {
        console.error("Error fetching sensor data:", error);
        setSensorData([]);
      }
    };
    fetchSensorData();
  }, []);
 
  // Fetch all rack data
  useEffect(() => {
    const fetchAllRackData = async () => {
      const newRackData = {};
      for (const rackConfig of racksConfig) {
        try {
          const response = await axios.post(rackConfig.endpoint);
          if (response.data && Array.isArray(response.data)) {
            newRackData[rackConfig.key] = response.data;
          } else {
            console.warn(`Unexpected data format for ${rackConfig.title}:`, response.data);
            newRackData[rackConfig.key] = [];
          }
        } catch (error) {
          console.error(`Error fetching ${rackConfig.title}:`, error);
          newRackData[rackConfig.key] = [];
        }
      }
      setRackData(newRackData);
    };
 
    fetchAllRackData();
  }, []);
 
  // Handler for clicking a cell in edit mode
  const handleEditClick = (rackId, colIndex, value, sourceKey) => {
    if (editMode) {
      // Set the state to indicate this cell is being edited
      setEditData({ rackId, col: colIndex, value, sourceKey });
    }
  };
 
  // Handler for saving an edited cell
  const handleSave = async () => {
    const { rackId, col, value, sourceKey } = editData;
 
    // Check if editData is still valid before proceeding.
    // Use == null to check for both null and undefined.
    // Optional: Add validation here if `value` must be '0' or '1'
    if (rackId == null || col == null || value === "" || sourceKey == null) {
      console.warn("Save called with incomplete or cancelled edit data. Aborting save.", { editData });
      // Reset editData explicitly just in case
      setEditData({ rackId: null, col: null, value: "", sourceKey: null });
      return; // Stop the save operation here
    }
 
    // Validate the value if necessary (e.g., must be '0' or '1')
    if (value !== '0' && value !== '1') {
      console.warn(`Invalid value '${value}' for LED status. Must be '0' or '1'. Aborting save.`);
      // Optionally show an error message to the user
      handleCancel(); // Cancel the edit if the value is invalid
      return;
    }
 
 
    const rackConfig = racksConfig.find(config => config.key === sourceKey);
    if (!rackConfig) {
      console.error("Unknown sourceKey:", sourceKey);
      handleCancel(); // Cancel the edit if the source key is not found
      return;
    }
 
    const currentRackData = rackData[sourceKey];
    const apiUrl = rackConfig.updateEndpoint;
 
    try {
      // Find the specific record (rack) to update within the current data for this table
      const updatedRackDataArray = currentRackData.map((rack) => {
        // Match by the stored rackId (can be null if ID wasn't available)
        if (rack?.LEDRack_id === rackId) { // Use ?. for safety
          const newData = rack.LEDRackStatus.split("");
          // Check if the column index is within the valid bounds of the status string
          if (col >= 0 && col < newData.length) {
            newData[col] = value; // Update the character at the specified column index
          } else {
            // Log a warning if the column index is out of bounds
            console.warn(`Column index ${col} out of bounds for rack ${rack?.LEDRack_id}. String length: ${newData.length}`);
            return rack; // Return original if index is bad
          }
          return { ...rack, LEDRackStatus: newData.join("") };
        }
        // Return all other records unchanged
        return rack;
      });
 
      // Prepare data for the backend update (assuming backend format)
      const dataToSend = updatedRackDataArray.map((rack) => ({
        LEDRack_id: rack.LEDRack_id,
        LEDRackStatus: rack.LEDRackStatus,
      }));
 
      await axios.post(apiUrl, { updatedRackData: dataToSend });
 
      // If the backend update is successful, update the local React state.
      // Use a functional update (prev => ...) to safely update the nested state.
      setRackData(prev => ({
        ...prev, // Copy the previous rackData object
        [sourceKey]: updatedRackDataArray // Update the specific rack's data array with the new one
      }));
 
      // Reset the editData state to null/empty values. This closes the input field.
      setEditData({ rackId: null, col: null, value: "", sourceKey: null });
 
    } catch (error) {
      // Log any errors during the save process
      console.error("Error saving data:", error);
      // Optionally, revert state or show error message on save failure
      handleCancel();
    }
  };
 
  // Handler for canceling an edit operation
  const handleCancel = () => {
    // Reset the editData state to its initial null/empty values.
    // This hides the input field without saving any changes.
    setEditData({ rackId: null, col: null, value: "", sourceKey: null });
  };
 
  const handleHomeClick = () => {
    navigate("/Homepage");
  };
 
  const hasLoadedAnyRackData = Object.values(rackData).some(data => data.length > 0);
  const isLoading = !hasLoadedAnyRackData || !sensorData.length;
  const hasDataAvailable = hasLoadedAnyRackData || sensorData.length > 0;
 
 
  if (isLoading && !hasDataAvailable) {
    return <div className="text-center">Loading...</div>;
  }
 
  return (
    <div className="container mt-5">
      <div className="NewStencilRegistration text-center mb-4" style={{ display: "flex", alignItems: "center", justifyContent: "left" }}>
        <img src={logo} alt="Logo" style={{ height: 40, marginRight: 8 }} />
        <h2 className="child" style={{ margin: 0, flexGrow: 1, textAlign: 'center' }}>Stencil Rack Status</h2>
        <Button color="inherit" onClick={handleHomeClick} sx={{ fontWeight: "bold", color: "#fff" }}>Home</Button>
      </div>
 
      <div className="mb-3 text-center">
        <button className={`btn ${editMode ? "btn-secondary" : "btn-primary"}`} onClick={() => setEditMode(!editMode)}>
          {editMode ? "Exit Edit Mode" : "Enter Edit Mode"}
        </button>
        {editMode && <p className="text-muted mt-2">Click on a cell in the LED table to edit.</p>}
      </div>
 
      <ColorBoxes />
 
      <div>
        <h3>SENSOR</h3>
      </div>
      <div className="table-responsive">
        {sensorData.length > 0 ? (
          <table className="table table-bordered table-hover">
            <thead className="thead-dark">
              <tr>
                <th className="text-center">Rack ID</th>
                {sensorData[0]?.data?.length > 0 &&
                  Array.from({ length: sensorData[0].data.length }, (_, index) => (
                    <th key={index + 1} className="text-center">{index + 1}</th>
                  ))}
              </tr>
            </thead>
            <tbody>
              {sensorData.map((rack, rowIndex) => (
                <tr key={rowIndex}>
                  <th className="text-center">{rack.rackid}</th>
                  {rack.data?.split("").map((char, colIndex) => (
                    <td key={colIndex} className={`text-center ${getCellStyle(char)}`}>
                      {char}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          !isLoading && <div className="text-center">No sensor data available.</div>
        )}
      </div>
 
      <div>
        <h3>LED</h3>
      </div>
 
      {racksConfig.map(rackConfig => (
        <TransposedDataTable
          key={rackConfig.key}
          title={rackConfig.title}
          data={rackData[rackConfig.key]}
          isEditable={editMode}
          editMode={editMode} // Pass editMode down (redundant with isEditable, but harmless)
          editData={editData}
          handleEditClick={handleEditClick}
          handleSave={handleSave}
          handleCancel={handleCancel}
          sourceKey={rackConfig.key}
          setEditData={setEditData}
        />
      ))}
 
      {!hasLoadedAnyRackData && !isLoading && (
        <div className="text-center mt-4">No LED rack data available.</div>
      )}
 
    </div>
  );
};
 
export default RackDataTable;