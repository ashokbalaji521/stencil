import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Autocomplete, TextField } from "@mui/material";
import { Data } from "../Custom/custom";
import logo from "../Utils/logo.png";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  AppBar,
} from "@mui/material";
import {
  Container,
  Button,
  Typography,
  Box,
  Select,
  MenuItem,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Toolbar,
} from "@mui/material";

function BlockUnblock() {
  const [selectedPartCode, setSelectedPartCode] = useState(null);
  const [Partcodedata, setData] = useState([]);
  const uniquePartcodedata = [...new Set(Partcodedata)];
  const [successAlert, setSuccessAlert] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [isWaitingVisible, setIsWaitingPopupVisible] = useState(false);
  const [checkRackStatus, setCheckRackStatus] = useState(false);
  const [changedRackBit, setChangedRackBit] = useState("");
  const [rackdata, setRackData] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [rackId, setRackId] = useState(0);
  const [physicalloc, setPhysicalLoc] = useState(0);
  const [wrongPickup, setWrongPickup] = useState(false);
  const [username, setUsername] = useState(""); // State to store username
  const navigate = useNavigate();
  
  // Get username from session storage when component mounts
  useEffect(() => {
    const storedUsername = sessionStorage.getItem("username");
    if (storedUsername) {
      setUsername(storedUsername);
    } else {
      console.warn("Username not found in session storage");
      // You might want to handle this case, perhaps redirect to login
    }
  }, []);

  const handlePartCodeChange = (event, newValue) => {
    setSelectedPartCode(newValue);
  };
  
  const handleCancelWaiting = () => {
    setIsWaitingPopupVisible(false);
  };

  useEffect(() => {
    let timer;

    if (wrongPickup) {
      timer = setTimeout(() => {
        setWrongPickup(false);
        navigate("/StencilIn");
      }, 5000);
    }

    return () => clearTimeout(timer);
  }, [wrongPickup, navigate]);

  const ScrapButton = ({ row, handleOutClickScrap }) => (
    <TableCell>
      <Button
        variant="contained"
        color={row.Scrap ? "error" : "error"}
        onClick={() => handleOutClickScrap(row.BarcodeID, row.Scrap)}
        disabled={row.Scrap}
      >
        {row.Scrap ? "Scrapped" : "Scrap"}
      </Button>
    </TableCell>
  );
  
  const handleOutClick = (barcodeID) => {
    console.log("OUT button clicked for Barcode ID:", barcodeID);
    console.log("Current username:", username);

    // Include username from session storage in the request
    axios
      .post(`${Data.url}blockunlockstencil`, { 
        barcode: barcodeID,
        username: username // Include username in request
      })
      .then((res) => {
        console.log("Success");
        handleSubmit();
        setSuccessAlert(true); // Show success alert
        
        // Auto-hide success alert after 3 seconds
        setTimeout(() => {
          setSuccessAlert(false);
        }, 3000);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  const handleOutClickScrap = (barcodeID, scrapStatus) => {
    if (scrapStatus) {
      console.log("Item is already scrapped. No action taken.");
      return;
    }

    console.log("SCRAP button clicked for Barcode ID:", barcodeID);
    console.log("Current username:", username);
    
    // Include username from session storage in the request
    axios
      .post(`${Data.url}scrapstencil`, { 
        barcode: barcodeID,
        username: username // Include username in request
      })
      .then((res) => {
        console.log("Scrap successful");

        // Update local state to reflect that the item is now scrapped
        setTableData((prevData) =>
          prevData.map((row) =>
            row.BarcodeID === barcodeID ? { ...row, Scrap: true } : row
          )
        );

        // Save the scrapped item status to local storage for persistence
        localStorage.setItem(barcodeID, JSON.stringify({ Scrap: true }));
        
        setSuccessAlert(true); // Show success alert
        
        // Auto-hide success alert after 3 seconds
        setTimeout(() => {
          setSuccessAlert(false);
        }, 3000);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  useEffect(() => {
    axios.post(`${Data.url}getPartCodeDatabyall`).then((response) => {
      const cleanedPartCodes = response.data.map((part) => part.PartNumber);
      setData(cleanedPartCodes);
    });
  }, []);

  const handleSubmit = () => {
    console.log("Selected Part Code:", selectedPartCode);
    axios
      .post(`${Data.url}getSelectedPartCodeDatablock`, {
        partCode: selectedPartCode,
      })
      .then((response) => {
        console.log("Fetched Data:", response.data);
        setTableData(response.data);
        setShowTable(true);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setShowTable(false);
      });
  };

  const handleCloseAlert = () => {
    setSuccessAlert(false);
  };
  
  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar
          disableGutters
          sx={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              height: 40,
            }}
          />
          <Button
            color="inherit"
            onClick={handleHomeClick}
            sx={{ fontWeight: "bold" }}
          >
            Home
          </Button>
          {username && (
            <Typography variant="subtitle1" sx={{ marginLeft: 'auto', fontWeight: 'medium' }}>
              User: {username}
            </Typography>
          )}
        </Toolbar>
      </AppBar>
      <Box
        sx={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          color: "#fff",
        }}
      >
        <Dialog
          open={isWaitingVisible}
          onClose={handleCancelWaiting}
          aria-labelledby="alert-dialog-title-waiting"
          aria-describedby="alert-dialog-description-waiting"
          PaperProps={{
            style: {
              backgroundColor: "Yellow",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-waiting">
            {"Please Pick from Location "}
            {physicalloc <= 60
              ? `Rack -1 ${physicalloc}`
              : `Rack -2 ${physicalloc}`}
          </DialogTitle>
        </Dialog>
        <Dialog
          open={wrongPickup}
          aria-labelledby="alert-dialog-title-waiting"
          aria-describedby="alert-dialog-description-waiting"
          PaperProps={{
            style: {
              backgroundColor: "Red",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-waiting">
            {"Wrong Stencil Picked!!!"}
          </DialogTitle>
        </Dialog>
        {successAlert && (
          <Alert
            variant="filled"
            severity="success"
            action={
              <Button color="inherit" size="small" onClick={handleCloseAlert}>
                Close
              </Button>
            }
          >
            Operation Successful!
          </Alert>
        )}
        <Container
          sx={{
            backgroundColor: "rgba(255, 255, 255, 0.2)",
            borderRadius: "12px",
            padding: "40px",
            boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
            backdropFilter: "blur(10px)",
            width: "65%",
            maxWidth: "400px",
            marginBottom: "40px",
          }}
        >
          <Typography
            variant="h4"
            component="h1"
            sx={{
              marginBottom: "20px",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            Block/Unblock/Scrap Stencil
          </Typography>
          <Autocomplete
            options={uniquePartcodedata}
            value={selectedPartCode}
            getOptionLabel={(option) => option || ""}
            onChange={(event, newValue) => handlePartCodeChange(event, newValue)}
            filterOptions={(options, { inputValue }) => {
              const searchValue = inputValue.trim().toUpperCase();
              if (searchValue === '') return options;
              
              return options.filter(option => {
                if (!option) return false;
                const optionStr = option.toString().toUpperCase();
                return optionStr.includes(searchValue);
              });
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Part Code"
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": {
                    color: "white",
                    backgroundColor: "transparent",
                  },
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "white",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "white",
                  },
                  "& .MuiInputLabel-root": {
                    color: "white",
                  },
                  "& .MuiAutocomplete-popupIndicator": {
                    color: "white",
                  },
                  "& .MuiAutocomplete-clearIndicator": {
                    color: "white",
                  },
                }}
                onBlur={() => {
                  if (!selectedPartCode) handlePartCodeChange(null);
                }}
              />
            )}
            disableClearable={false} 
          />
          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{
              backgroundColor: "#4CAF50",
              "&:hover": {
                backgroundColor: "#45a049",
              },
              padding: "10px 0",
              fontSize: "16px",
              fontWeight: "bold",
              width: "100%",
            }}
          >
            Submit
          </Button>
        </Container>
        {showTable && (
          <TableContainer
            component={Paper}
            sx={{ width: "80%", marginTop: "20px" }}
          >
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Product
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Side
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Part Number
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                        Stencil ID
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Barcode ID
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Status
                  </TableCell>
                   <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Rack No
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                     Slot
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Action
                  </TableCell>

                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Action
                  </TableCell>

                </TableRow>
              </TableHead>
              <TableBody>
                {tableData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>{row.Product}</TableCell>
                    <TableCell>{row.Side}</TableCell>
                    <TableCell>{row.PartNumber}</TableCell>
                      <TableCell>{row.StencilID}</TableCell>
                    <TableCell>{row.BarcodeID.trim()}</TableCell>
                    <TableCell>
                      {row.Blocked ? "Blocked" : row.Scrap ? "Scrapped" : "Available"}
                    </TableCell>
                     <TableCell>{row.Rackno}</TableCell>
                       <TableCell>{row.PhysicalLocation}</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => handleOutClick(row.BarcodeID)}
                        disabled={row.Scrap}
                      >
                        {row.Blocked ? "Unblock " : "Block"}
                      </Button>
                    </TableCell>
                    <ScrapButton row={row} handleOutClickScrap={handleOutClickScrap} />
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>
    </div>
  );
}

export default BlockUnblock;