import React, { useReducer, useContext, useMemo } from "react";
import { ThememmmContext } from "../App";

function reducer(state, action) {
  switch (action.type) {
    case "INCREMENT":
      return { count: state.count + 1 };
  }
}
function Interview() {
  const [state, dispatch] = useReducer(reducer, { count: 0 });
  const using = useContext(ThememmmContext);

  const doublenum = useMemo(() => {
    return slowFunction(state.count);
  }, [state.count]);
  function Increment() {
    dispatch({ type: "INCREMENT" });
  }

  return (
    <div>
      {state.count}

      <button onClick={Increment}>+</button>
      {doublenum}
    </div>
  );
}

function slowFunction(num) {
  for (let i = 0; i < 10000000; i++) {}
  return num * 2;
}

export default Interview;
