import React, { useState, useEffect } from "react";
import { Box, Container, TextField, Button, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Data } from "../Custom/custom";

const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    const role = sessionStorage.getItem("role");
    const sessionExpiry = sessionStorage.getItem("sessionExpiry");

    if (token && role !== "5") {
      const currentTime = Date.now();

      // Check if the session has expired
      if (sessionExpiry && currentTime > parseInt(sessionExpiry)) {
        sessionStorage.clear();
        navigate("/Login");
      } else {
        // Set a timeout for session expiry
        const timeout = setTimeout(() => {
          sessionStorage.clear();
          navigate("/Login");
        }, 1 * 60 * 1000); // 1 minute

        return () => clearTimeout(timeout);
      }
    }
  }, [navigate]);

  const handleLogin = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post(`${Data.url}login`, { username, password });
      const { token, role } = response.data;

      if (token) {
        sessionStorage.setItem("token", token);
        sessionStorage.setItem("username", username);
        sessionStorage.setItem("role", role);

        if (role !== "5") {
          const sessionExpiry = Date.now() + 1 * 60 * 1000; // 1 minute
          sessionStorage.setItem("sessionExpiry", sessionExpiry.toString());

          // Set a timeout for session expiry
          setTimeout(() => {
            sessionStorage.clear();
            navigate("/Login");
          }, 1 * 60 * 1000); // 1 minute
        }

        navigate("/HomePage");
        setTimeout(() => {
          window.location.reload();
        }, 100);
      } else {
        console.error("Login failed. Please check your credentials.");
      }
    } catch (error) {
      console.error("Incorrect username or password:", error);
    }
  };

  return (
    <Box
      sx={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
        flexDirection: "column",
      }}
    >
      <Typography
        variant="h3"
        align="center"
        sx={{ color: "#fff", fontWeight: "bold", marginBottom: "20px" }}
      >
        STENCIL MANAGEMENT SYSTEM
      </Typography>
      <Container
        maxWidth="xs"
        sx={{
          backgroundColor: "rgba(255, 255, 255, 0.1)",
          borderRadius: "16px",
          padding: "40px",
          boxShadow: "0 12px 24px rgba(0,0,0,0.3)",
          backdropFilter: "blur(10px)",
        }}
      >
        <Typography
          variant="h4"
          align="center"
          gutterBottom
          sx={{ color: "#fff", fontWeight: "bold" }}
        >
          Login
        </Typography>
        <form onSubmit={handleLogin} autoComplete="off">
          <TextField
            fullWidth
            label="Username"
            variant="outlined"
            margin="normal"
            InputProps={{ sx: { color: "#fff" } }}
            InputLabelProps={{ sx: { color: "#ccc" } }}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="new-username" // Disable browser auto-fill
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            variant="outlined"
            margin="normal"
            InputProps={{ sx: { color: "#fff" } }}
            InputLabelProps={{ sx: { color: "#ccc" } }}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password" // Disable browser auto-fill
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            sx={{
              marginTop: "24px",
              backgroundColor: "#2a5298",
              "&:hover": { backgroundColor: "#16345a" },
              padding: "12px",
              fontSize: "16px",
              fontWeight: "bold",
            }}
          >
            Login
          </Button>
        </form>
      </Container>
    </Box>
  );
};

export default LoginPage;