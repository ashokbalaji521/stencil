import React, { useState, useEffect } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { CircularProgress, Button, Box, TextField } from "@mui/material";
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import Header from "./Header";
import axios from "axios";
import { Data } from "../Custom/custom";
import * as XLSX from 'xlsx'; 
import { format, sub } from "date-fns";

function ExportData({ selectedRowData }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageSize, setPageSize] = useState(5);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await axios.post(`${Data.url}GetExportdatas`, {
        fromMaintenance_updated_datetime: fromDate,
        toMaintenance_updated_datetime: toDate,
      });

      function formatDateTime(dateTime, formatString = "dd/MM/yyyy HH:mm:ss") {
        if (!dateTime) return "";  
        const parsedDate = new Date(dateTime);
        return !isNaN(parsedDate) ? format(parsedDate, formatString) : "";
      }
      
      function formatDateTimeother(dateTime, formatString = "dd/MM/yyyy HH:mm:ss") {
        if (!dateTime) return ""; 
        const parsedDate = new Date(dateTime);
        const adjustedDate = sub(parsedDate, { hours: 5, minutes: 30 });
        return !isNaN(adjustedDate) ? format(adjustedDate, formatString) : "";
      }

      const TableData = res.data.map((item) => {
        return {
          Product: item.Product,
          BarcodeID: item.BarcodeID,
          PartNumber: item.PartNumber,
          Side: item.Side,
          StencilId: item.StencilID,
          PhysicalLocation: item.PhysicalLocation || "", 
          StencilThickness: item.StencilThickness,
          Remarks: item.Remarks,
          StatusOfStencil: item.StatusOfStencil,
          ModuleCode: item.ModuleCode || "", 
          StencilTension: item.StencilTension || "", 
          SupplierPartNumber: item.SupplierPartNumber || "", 
          DateofManufacturing: formatDateTime(item.DateofManufacturing, "dd/MM/yyyy"), 
          LastINDate: formatDateTimeother(item.LastINDate, "dd/MM/yyyy HH:mm:ss"), 
          LastOutDate: formatDateTimeother(item.LastOutDate, "dd/MM/yyyy HH:mm:ss"), 
          LastModifiedDate: formatDateTimeother(item.LastModifiedDate, "dd/MM/yyyy HH:mm:ss"), 
          ModifiedUserID: item.ModifiedUserID || "", 
          Maintenance_updated_datetime: formatDateTime(item.Maintenance_updated_datetime, "dd/MM/yyyy HH:mm:ss"), 
        };
      });

      setData(TableData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSearch = () => {
    fetchData();
  };

  const columns = [
    { field: "Product", headerName: "Product", width: 200, headerClassName: "super-app-theme--header" },
    { field: "Side", headerName: "Side", width: 110, headerClassName: "super-app-theme--header" },
    { field: "PartNumber", headerName: "Part Number", width: 150, headerClassName: "super-app-theme--header" },
    { field: "SupplierPartNumber", headerName: "Supplier Part Number", width: 200, headerClassName: "super-app-theme--header" },
    { field: "DateofManufacturing", headerName: "Date of Manufacturing", width: 180, headerClassName: "super-app-theme--header" },
    { field: "StencilThickness", headerName: "Stencil Thickness", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StencilId", headerName: "Stencil ID", width: 210, headerClassName: "super-app-theme--header" },
    { field: "BarcodeID", headerName: "Barcode ID", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StatusOfStencil", headerName: "Status", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StencilTension", headerName: "Stencil Tension", width: 200, headerClassName: "super-app-theme--header" },
    { field: "LastINDate", headerName: "Last IN Date", width: 150, headerClassName: "super-app-theme--header" },
    { field: "LastOutDate", headerName: "Last OUT Date", width: 150, headerClassName: "super-app-theme--header" },
    { field: "LastModifiedDate", headerName: "Last Modified Date", width: 180, headerClassName: "super-app-theme--header" },
    { field: "ModifiedUserID", headerName: "Modified User ID", width: 180, headerClassName: "super-app-theme--header" },
    { field: "Remarks", headerName: "Remarks", width: 150, headerClassName: "super-app-theme--header" },
  ];

  const handleDownload = () => {
    const orderedData = data.map((item, index) => ({
      "SL No": index + 1,
      Product: item.Product || "",
      Side: item.Side || "",
      "Part Number": item.PartNumber || "",
      "Supplier Partnumber": item.SupplierPartNumber || "",
      "Date of Manufacturing": item.DateofManufacturing || "",
      "Stencil Thickness": item.StencilThickness || "",
      "Stencil ID": item.StencilId || "",
      "Barcode ID": item.BarcodeID || "",
      "Status": item.StatusOfStencil || "",
      "Stencil Tension (N/CM)": item.StencilTension || "",
      "Last IN Date": item.LastINDate || "",
      "Last OUT Date": item.LastOutDate || "",
      "Last Modified Date": item.LastModifiedDate || "",
      "ModifiedUserID": item.ModifiedUserID || "",
      "Remarks": item.Remarks || "",
    }));

    const ws = XLSX.utils.json_to_sheet(orderedData);
    const headerKeys = Object.keys(orderedData[0]);
    const headerRange = XLSX.utils.decode_range(ws["!ref"]);

    for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellAddress]) continue;
      ws[cellAddress].s = {
        font: { bold: true, color: { rgb: "FFFFFF" } },
        fill: { fgColor: { rgb: "0000FF" } },
        alignment: { horizontal: "center" },
      };
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Maintenance Data");
    XLSX.writeFile(wb, "maintenance_data.xlsx");
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Header data={"Export Data"} />

      <Box sx={{ display: "flex", alignItems: "center", gap: 2, paddingBottom: 2 }}>
        <DateTimePicker
          label="From Date"
          value={fromDate}
          onChange={(newValue) => setFromDate(newValue)}
          renderInput={(params) => <TextField {...params} />}
        />
        <DateTimePicker
          label="To Date"
          value={toDate}
          onChange={(newValue) => setToDate(newValue)}
          renderInput={(params) => <TextField {...params} />}
        />
        <Button variant="contained" color="primary" onClick={handleSearch}>
          Search
        </Button>
        <Button variant="contained" color="secondary" onClick={handleDownload}>
          Download
        </Button>
      </Box>

      <Box
        sx={{
          height: 700,
          width: "100%",
          overflow: "hidden",
          "& .MuiDataGrid-cell": {
            borderRight: '1px solid #ddd',
          },
          "& .super-app-theme--header": {
            backgroundColor: '#f0f8ff',
            color: '#333',
 },
        }}
      >
        {loading ? (
          <CircularProgress />
        ) : (
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={pageSize}
            rowsPerPageOptions={[5, 10, 20]}
            getRowId={(row) => row.BarcodeID}
            pagination
            autoHeight={false}
            onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
            disableSelectionOnClick
            components={{ Toolbar: GridToolbar }}
            sx={{ "& .MuiDataGrid-cell": { backgroundColor: "white" } }}
          />
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default ExportData;