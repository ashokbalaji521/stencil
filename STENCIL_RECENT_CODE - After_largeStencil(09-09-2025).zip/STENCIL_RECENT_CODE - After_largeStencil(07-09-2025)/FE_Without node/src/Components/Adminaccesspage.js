import React, { useState, useEffect } from "react";
import axios from "axios";
import { Data } from "../Custom/custom";
import {
  Box,
  Typography,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  AppBar,
  Toolbar,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Menu,
  MenuItem,
  IconButton, // Import IconButton
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';

const AdminAccessPage = () => {
  const [roles, setRoles] = useState([]);
  const [users, setUsers] = useState([]);
  const [roleComponents, setRoleComponents] = useState({});
  const [newUser, setNewUser] = useState({ username: "", password: "", role: "" });
  const [editUser, setEditUser] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.post(`${Data.url}getusers`);
      const fetchedUsers = response.data.map(user => {
        console.log(user);
        if (!user.ID) {
          console.error("User ID is missing", user);
        }
        return user;
      });
      setUsers(fetchedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleAddUser = async () => {
    const { username, password, role } = newUser;
    if (!username || !password || !role) {
      alert("All fields are required!");
      return;
    }

    try {
      await axios.post(`${Data.url}users`, { Username: username, Password: password, Role: role });
      alert("User added successfully!");
      setNewUser({ username: "", password: "", role: "" });
      fetchUsers();
    } catch (error) {
      console.error("Error adding user:", error);
      alert("Error adding user. Please try again.");
    }
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  const handleEditUser = (user) => {
    if (user && user.ID) {
      console.log("Editing user with ID:", user.ID);
      setEditUser(user);
    } else {
      console.error("Invalid user ID:", user);
    }
  };

  const handleSaveEdit = async () => {
    const { ID, Username, Password, Role } = editUser;
    if (!Username || !Password || !Role) {
      alert("All fields are required!");
      return;
    }

    try {
      await axios.post(`${Data.url}users/${ID}`, {
        Username,
        Password,
        Role,
      });
      alert("User updated successfully!");
      setEditUser(null);
      fetchUsers();
    } catch (error) {
      console.error("Error updating user:", error);
      alert("Error updating user. Please try again.");
    }
  };

  const handleDeleteUser = (user) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!userToDelete || !userToDelete.ID) {
      alert("Invalid user selected for deletion!");
      return;
    }

    try {
      await axios.delete(`${Data.url}users/${userToDelete.ID}`);
      alert("User deleted successfully!");
      setDeleteDialogOpen(false);
      setUserToDelete(null);
      fetchUsers();
    } catch (error) {
      console.error("Error deleting user:", error);
      alert("Error deleting user. Please try again.");
    }
  };

  const cancelDelete = () => {
    setDeleteDialogOpen(false);
    setUserToDelete(null);
  };

  const [modules, setModules] = useState({});
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedRole, setSelectedRole] = useState('');

  useEffect(() => {
    const fetchRoleModules = async () => {
      try {
        const response = await axios.post(`${Data.url}getUserRoleModuleData`);
        setModules(response.data);
      } catch (error) {
        console.error('Error fetching role modules:', error);
      }
    };

    fetchRoleModules();
  }, []);

  const handleClick = (event, role) => {
    setAnchorEl(event.currentTarget);
    setSelectedRole(role);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setSelectedRole('');
  };

  const open = Boolean(anchorEl);
  const roleModules = modules[selectedRole] || [];

  return (
    <Box sx={{ backgroundColor: "#f4f6f8", minHeight: "100vh", padding: "20px" }}>
      <AppBar position="sticky" sx={{ backgroundColor: "#1E3C72" }}>
        <Toolbar>
          <Button
            color="inherit"
            style={{ color: "#FFFFFF", marginRight: "auto" }}
            onClick={handleHomeClick}
          >
            HOME
          </Button>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: "flex", gap: 3, justifyContent: "center", marginTop: 3 }}>
        <Box
          sx={{
            width: "200px",
            height: "50px",
            backgroundColor: "#4CAF50",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 2,
            boxShadow: 3,
          }}
        >
          <Button onClick={(event) => handleClick(event, 'TECH')}>
            <Typography variant="h6" sx={{ color: "#fff" }}>
              Role 1 - Tech
            </Typography>
          </Button>
        </Box>

        <Box
          sx={{
            width: "200px",
            height: "50px",
            backgroundColor: "#2196F3",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 2,
            boxShadow: 3,
          }}
        >
          <Button onClick={(event) => handleClick(event, 'ENGG')}>
            <Typography variant="h6" sx={{ color: "#fff" }}>
              Role 2 - Engg
            </Typography>
          </Button>
        </Box>

        <Box
          sx={{
            width: "200px",
            height: "50px",
            backgroundColor: "#FF5722",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 2,
            boxShadow: 3,
          }}
        >
          <Button onClick={(event) => handleClick(event, 'ADMIN')}>
            <Typography variant="h6" sx={{ color: "#fff" }}>
              Role 3 - Admin
            </Typography>
          </Button>
        </Box>

        <Box
          sx={{
            width: "220px",
            height: "50px",
            backgroundColor: "#EF2B4A",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 2,
            boxShadow: 3,
          }}
        >
          <Button onClick={(event) => handleClick(event, 'OPERATOR')}>
            <Typography variant="h6" sx={{ color: "#fff" }}>
              Role 5 - Operator
            </Typography>
          </Button>
        </Box>

        <Menu
          anchorEl={anchorEl}
          open={open}
          onClose={handleClose}
        >
          {roleModules.map((module, index) => (
            <MenuItem key={index} onClick={handleClose}>
              {module}
            </MenuItem>
          ))}
        </Menu>
      </Box>

      <Box sx={{ paddingTop: "80px", maxWidth: "1200px", margin: "0 auto" }}>
        <Typography variant="h4" align="center" gutterBottom sx={{ color: "#333" }}>
          Admin Access Management
        </Typography>

        {/* Add New User Section */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 2,
            marginBottom: "30px",
            padding: "20px",
            border: "1px solid #ddd",
            borderRadius: "8px",
            backgroundColor: "#fff",
            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
          }}
        >
          <Typography variant="h5" gutterBottom>
            Add New User
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Username"
                value={newUser.username}
                onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                fullWidth
                variant="outlined"
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Password"
                type="password"
                value={newUser.password}
                onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                fullWidth
                variant="outlined"
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Role"
                value={newUser.role}
                onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                fullWidth
                variant="outlined"
                required
              />
            </Grid>
          </Grid>
          <Button variant="contained" color="primary" onClick={handleAddUser} sx={{ marginTop: "20px" }}>
            Add User
          </Button>
        </Box>

        {/* Edit User Section */}
        {editUser && (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2,
              marginBottom: "30px",
              padding: "20px",
              border: "1px solid #ddd",
              borderRadius: "8px",
              backgroundColor: "#fff",
              boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
            }}
          >
            <Typography variant="h5" gutterBottom>
              Edit User - {editUser.Username}
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Username"
                  value={editUser.Username}
                  onChange={(e) => setEditUser({ ...editUser, Username: e.target.value })}
                  fullWidth
                  variant="outlined"
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Password"
                  type="password"
                  value={editUser.Password}
                  onChange={(e) => setEditUser({ ...editUser, Password: e.target.value })}
                  fullWidth
                  variant="outlined"
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Role"
                  value={editUser.Role}
                  onChange={(e) => setEditUser({ ...editUser, Role: e.target.value })}
                  fullWidth
                  variant="outlined"
                  required
                />
              </Grid>
            </Grid>
            <Box sx={{ display: "flex", gap: 2, marginTop: "20px" }}>
              <Button variant="contained" color="primary" onClick={handleSaveEdit}>
                Save Changes
              </Button>
              <Button variant="outlined" onClick={() => setEditUser(null)}>
                Cancel
              </Button>
            </Box>
          </Box>
        )}

        {/* Users Table */}
        <Typography variant="h5" gutterBottom sx={{ color: "#333", fontWeight: 600 }}>
          User Management
        </Typography>
        <TableContainer component={Paper} sx={{ boxShadow: 3, borderRadius: '12px', overflow: 'hidden' }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: "bold", fontSize: '16px', color: '#333', width: '30%' }}>Username</TableCell>
                <TableCell sx={{ fontWeight: "bold", fontSize: '16px', color: '#333', width: '25%' }}>Role</TableCell>
                <TableCell sx={{ fontWeight: "bold", fontSize: '16px', color: '#333', textAlign: 'center', width: '45%' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user, index) => (
                <TableRow
                  key={user.ID}
                  sx={{
                    '&:nth-of-type(odd)': { backgroundColor: '#fafafa' },
                    '&:hover': { backgroundColor: '#f0f8ff' },
                    transition: 'background-color 0.2s'
                  }}
                >
                  <TableCell sx={{ fontSize: '14px', fontWeight: 500 }}>{user.Username}</TableCell>
                  <TableCell>
                    <Box
                      sx={{
                        display: 'inline-block',
                        backgroundColor: user.Role === 'ADMIN' ? '#e8f5e8' :
                                             user.Role === 'TECH' ? '#e3f2fd' :
                                             user.Role === 'ENGG' ? '#fff3e0' : '#f3e5f5',
                        color: user.Role === 'ADMIN' ? '#2e7d32' :
                               user.Role === 'TECH' ? '#1565c0' :
                               user.Role === 'ENGG' ? '#ef6c00' : '#7b1fa2',
                        padding: '4px 12px',
                        borderRadius: '16px',
                        fontSize: '13px',
                        fontWeight: 600,
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px'
                      }}
                    >
                      {user.Role}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', justifyContent: 'center' }}>
                      {/* Edit Icon Button */}
                      <IconButton
                        onClick={() => handleEditUser(user)}
                        color="primary"
                        aria-label="edit user"
                        sx={{
                          '&:hover': {
                            backgroundColor: '#e3f2fd',
                            transform: 'scale(1.1)',
                          },
                          transition: 'transform 0.2s ease-in-out, background-color 0.2s',
                          padding: '8px',
                        }}
                      >
                        <EditIcon />
                      </IconButton>

                      {/* Delete Icon Button */}
                      <IconButton
                        onClick={() => handleDeleteUser(user)}
                        color="error"
                        aria-label="delete user"
                        sx={{
                          '&:hover': {
                            backgroundColor: '#ffebee',
                            transform: 'scale(1.1)',
                          },
                          transition: 'transform 0.2s ease-in-out, background-color 0.2s',
                          padding: '8px',
                        }}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteDialogOpen}
          onClose={cancelDelete}
          aria-labelledby="delete-dialog-title"
          aria-describedby="delete-dialog-description"
          PaperProps={{
            sx: {
              borderRadius: '12px',
              padding: '8px'
            }
          }}
        >
          <DialogTitle id="delete-dialog-title" sx={{
            color: '#d32f2f',
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: 1
          }}>
            <DeleteIcon />
            Confirm Delete
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="delete-dialog-description" sx={{ fontSize: '16px', color: '#333' }}>
              Are you sure you want to delete user <strong>"{userToDelete?.Username}"</strong>?
              <br />
              <Box component="span" sx={{ color: '#d32f2f', fontWeight: 500 }}>
                This action cannot be undone.
              </Box>
            </DialogContentText>
          </DialogContent>
          <DialogActions sx={{ padding: '16px 24px' }}>
            <Button
              onClick={cancelDelete}
              color="primary"
              variant="outlined"
              sx={{
                borderRadius: '8px',
                textTransform: 'none',
                fontWeight: 500
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDelete}
              color="error"
              variant="contained"
              sx={{
                borderRadius: '8px',
                textTransform: 'none',
                fontWeight: 500,
                backgroundColor: '#d32f2f',
                '&:hover': { backgroundColor: '#b71c1c' }
              }}
            >
              Delete User
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  );
};

export default AdminAccessPage;