import React, { useState, useMemo } from "react";

function Testfile() {
  const [number, setNumber] = useState(0);
  const squaredNum = useMemo(() => {
    return squareNum(number);
  }, [number]);
  const [counter, setCounter] = useState(0);

  const onChangeHandler = (e) => {
    setNumber(e.target.value);
  };

  // Increases the counter by 1
  const counterHander = () => {
    setCounter(counter + 1);
  };

  const TryPromise = new Promise((resolve, reject) => {
    let a = 1;
    if ((a = 1)) {
      resolve("Success");
    } else {
      reject("Failure");
    }
  });

  TryPromise.then((message) => {
    console.log(message);
  }).catch((message) => {
    console.log(message);
  });

  const x = fetch("https://jsonplaceholder.typicode.com/todos/1")
    .then((response) => response.json())
    .then((json) => console.log(json));

  const debounce = (mainfunction, delay) => {
    let timer;
    return function (...args) {
      clearTimeout(timer);

      timer = setTimeout(() => {
        mainfunction(...args);
      }, delay);
    };
  };

  const name = "Vishnu";
  console.log(name.split("").reverse().join(""));

  const debouncedClick = debounce(counterHander, 3000);
  return (
    <div className="App">
      <h1>Welcome to Geeksforgeeks</h1>
      <input
        type="number"
        placeholder="Enter a number"
        value={number}
        onChange={onChangeHandler}
      ></input>

      <div>OUTPUT: {squaredNum}</div>
      <button onClick={debouncedClick}>Counter ++</button>
      <div>Counter : {counter}</div>
    </div>
  );
  function squareNum(number) {
    console.log("Squaring will be done!");
    return Math.pow(number, 2);
  }
}

export default Testfile;
