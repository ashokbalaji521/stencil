// HomePage.js
import React, { useState, useEffect } from "react";
import {
  Button,
  Container,
  Typography,
  Box,
  Grid,
  AppBar,
  Toolbar,
  Avatar,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import logo from "../Utils/logo.png";
import PowerSettingsNewIcon from "@mui/icons-material/PowerSettingsNew";

const HomePage = () => {
  const [username, setUsername] = useState("");
  const [anchorEl, setAnchorEl] = React.useState(null);
  const navigate = useNavigate();

  const role = parseInt(sessionStorage.getItem("role"), 10);

  console.log("Role:", role);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  // Handle menu close
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const navigateToExportData = () => {
    navigate("/ExportData");
  };

  const navigateToAdminAccess = () => {
    navigate("/AdminAccessPage");
  };

  const navigateToStencilIn = () => {
    navigate("/StencilIn");
  };

  const navigateToTest = () => {
    navigate("/TestingPage");
  };

  const navigateToRackId = () => {
    navigate("/RackId");
  };

  const navigateToStencilOut = () => {
    navigate("/StencilOut");
  };

  const navigateToAvail = () => {
    navigate("/ViewLoadedStencil");
  };

  const navigateToNon = () => {
    navigate("/Noncompliant");
  };

  const navigateToRegister = () => {
    navigate("/StencilRegistration");
  };

  const navigateToHistory = () => {
    navigate("/OperatorHistory");
  };

  const navigateToAllHistory = () => {
    navigate("/AllHistory");
  };

  const navigateToBlock = () => {
    navigate("/BlockUnblock");
  };

  const navigateToEdit = () => {
    navigate("/editStencil");
  };

  useEffect(() => {
    // Retrieve the username from session storage
    const storedUsername = sessionStorage.getItem("username");
    if (storedUsername) {
      setUsername(storedUsername);
    }
  }, []);

  const hasAccessTechEnggAdmin = [1, 2, 3].includes(role); // Tech, Engg, Admin
  const hasAccessEnggAdmin = [2, 3].includes(role); // Engg, Admin
  const hasAccessAdmin = [3].includes(role); // Admin
  const hasAccessoperator = [1, 2, 3, 5].includes(role); // Tech, Engg, Admin, Operator

  const handleLogout = () => {
    sessionStorage.clear(); // Clear session storage
    navigate("/Login"); // Redirect to login page
  };

  return (
    <div>
      {/* Header */}
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar>
          <img
            src={logo} // Use the imported image
            alt="Logo"
            style={{
              height: 40, // Adjust the height of the image
              marginRight: 16, // Add margin for spacing
            }}
          />
          <Typography
            variant="h4"
            component="h1"
            sx={{
              flexGrow: 1,
              textAlign: "center",
              fontWeight: "bold",
              color: "#fff",
            }}
          >
            Stencil Management System
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Avatar
              sx={{ bgcolor: "#fff", color: "#1e3c72", marginRight: 1 }} // Set background color and text color
            >
              {username ? username.charAt(0).toUpperCase() : ""}
            </Avatar>
            <Typography sx={{ color: "#fff", fontWeight: "bold" }}>
              {username ? username : "Guest"}
            </Typography>
            <IconButton onClick={handleMenuOpen} color="inherit">
              <PowerSettingsNewIcon />
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>

      <Box
        sx={{
          height: "calc(100vh - 64px)", // Adjust height to exclude AppBar height
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          color: "#fff",
        }}
      >
        <Container
          sx={{
            backgroundColor: "rgba(255, 255, 255, 0.15)",
            borderRadius: "16px",
            padding: "50px",
            boxShadow: "0 12px 24px rgba(0,0,0,0.3)",
            backdropFilter: "blur(15px)",
            maxWidth: "500px",
            textAlign: "center",
          }}
        >
          <Grid container spacing={2} justifyContent="center">
            {/* Operator-accessible buttons */}
            {hasAccessoperator && (
              <>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={navigateToStencilIn}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#16345a" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Stencil In
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToStencilOut}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Stencil Out
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToAvail}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Available Stencils
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToNon}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Non-Compliant Stencils
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToHistory}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Operation History
                  </Button>
                </Grid>
              </>
            )}

            {/* Tech, Engg, Admin-accessible buttons */}
            {hasAccessTechEnggAdmin && (
              <>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToTest}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Test Page
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToRegister}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Stencil Registration
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={navigateToExportData}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#16345a" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Export Data
                  </Button>
                </Grid>
              </>
            )}

            {/* Engg, Admin-accessible buttons */}
            {hasAccessEnggAdmin && (
              <>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToBlock}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Block/Unblock/Scrap
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={navigateToEdit}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#1f4073" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Edit Stencil
                  </Button>
                </Grid>
              </>
            )}

            {/* Admin-accessible buttons */}
            {hasAccessAdmin && (
              <>
                <Grid item xs={12} sm={6} md={4}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={navigateToAdminAccess}
                    sx={{
                      backgroundColor: "#2a5298",
                      "&:hover": { backgroundColor: "#16345a" },
                      width: "100%",
                      padding: "12px 24px",
                      fontSize: "16px",
                      borderRadius: "8px",
                    }}
                  >
                    Admin Access
                  </Button>
                </Grid>
              </>
            )}

            {/* Maintenance button accessible to all roles */}
            <Grid item xs={12} sm={6} md={4}>
              <Button
                variant="contained"
                color="primary"
                onClick={navigateToRackId}
                sx={{
                  backgroundColor: "#2a5298",
                  "&:hover": { backgroundColor: "#16345a" },
                  width: "100%",
                  padding: "12px 24px",
                  fontSize: "16px",
                  borderRadius: "8px",
                }}
              >
                Maintenance
              </Button>
            </Grid>
          </Grid>

          {/* ALL History button */}
          <Grid container spacing={2} justifyContent="center" sx={{ marginTop: "20px" }}>
            <Grid item xs={12} sm={6} md={4}>
              <Button
                variant="contained"
                color="secondary"
                onClick={navigateToAllHistory}
                sx={{
                  backgroundColor: "#2a5298",
                  "&:hover": { backgroundColor: "#1f4073" },
                  width: "100%",
                  padding: "12px 24px",
                  fontSize: "16px",
                  borderRadius: "8px",
                }}
              >
                ALL History
              </Button>
            </Grid>
          </Grid>
          <br />
        </Container>
      </Box>
    </div>
  );
};

export default HomePage;