import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Autocomplete, TextField } from "@mui/material";
import { Data } from "../Custom/custom";
import logo from "../Utils/logo.png";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  AppBar,
} from "@mui/material";
import {
  Container,
  Button,
  Typography,
  Box,
  Select,
  MenuItem,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Toolbar,
} from "@mui/material";

function EditStencil() {
  const [selectedPartCode, setSelectedPartCode] = useState(null);
  const [Partcodedata, setData] = useState([]);
  const [originalPartCodeData, setOriginalPartCodeData] = useState([]);
  const [successAlert, setSuccessAlert] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [isWaitingVisible, setIsWaitingPopupVisible] = useState(false);
  const [selectedStencilId, setSelectedStencilId] = useState(null);
  const [selectedBarcodeId, setSelectedBarcodeId] = useState(null);
  const [selectedProduct, setSelectedProductName] = useState(null);
  const [Rackno, setRackno] = useState(null);
  const [stencilData, setStencilData] = useState([]);
  const [originalStencilData, setOriginalStencilData] = useState([]);
  const [barcodeData, setBarcodeData] = useState([]);
  const [checkRackStatus, setCheckRackStatus] = useState(false);
  const [changedRackBit, setChangedRackBit] = useState("");
  const [rackdata, setRackData] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [rackId, setRackId] = useState(0);
  const [physicalloc, setPhysicalLoc] = useState(0);
  const [wrongPickup, setWrongPickup] = useState(false);
  const navigate = useNavigate();
  const [productData, setProductData] = useState([]);
  const [originalProductData, setOriginalProductData] = useState([]);

  // Function to reset all data to original state
  const resetToOriginalData = () => {
    setData([...originalPartCodeData]);
    setStencilData([...originalStencilData]);
    setProductData([...originalProductData]);
    setTableData([]);
    setShowTable(false);
  };

  const handleCancelWaiting = () => {
    setIsWaitingPopupVisible(false);
  };

  useEffect(() => {
    let timer;

    if (wrongPickup) {
      timer = setTimeout(() => {
        setWrongPickup(false);
        navigate("/StencilIn");
      }, 5000);
    }

    return () => clearTimeout(timer);
  }, [wrongPickup, navigate]);

  const checkApiResponse = async () => {
    try {
      const response = await axios.post(`${Data.url}getRackStatus`);
      if (response.data.currentStatus !== rackdata) {
        const response = await axios.post(`${Data.url}getRackStatusindi`, {
          rackid: rackId,
        });
        if (response.data.currentStatus == 1) {
          console.log("Response", response.data);
          setCheckRackStatus(false);

          axios
            .post(`${Data.url}updateEmptyStencilData`, {
              barcode: inputValue.trim(),
            })
            .then((res) => {
              setIsWaitingPopupVisible(false);
              setSuccessAlert(true);
              setShowTable(false);
              setInputValue("");
            })
            .catch((err) => {
              console.log("Error Emptying Stencil Data");
            });
        } else {
          console.log("In else");
          setCheckRackStatus(false);
          setWrongPickup(true);
          axios
            .post(`${Data.url}removewrongpickup`, { barcode: inputValue.trim() })
            .then((res) => {
              console.log("Success");
            })
            .catch((err) => {
              console.log(err);
            });
        }
      } else {
        console.log("Response is the same, polling again...");
        setTimeout(checkApiResponse, 5000);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setTimeout(checkApiResponse, 5000);
    }
  };

  useEffect(() => {
    if (checkRackStatus) {
      checkApiResponse();
    }
  }, [checkRackStatus]);

  const handleeditClick = (barcodeId) => {
    axios
      .post(`${Data.url}getStencilDataByBarcodeID?BarcodeId=${barcodeId.trim()}`)
      .then((response) => {
        console.log("Stencil Data:", response.data);
        navigate("/UpdateStencilRegistration", {
          state: { stencilData: response.data[0] },
        });
      })
      .catch((error) => {
        console.error("Error fetching stencil data:", error);
      });
  };

  const handleSelectionChange = () => {
    if (selectedPartCode && selectedStencilId && selectedProduct) {
      axios
        .post(`${Data.url}getSelectedPartCodeDataforedit`, {
          partCode: selectedPartCode ? selectedPartCode.trim() : null,
          stencilId: selectedStencilId ? selectedStencilId.trim() : null,
          Product: selectedProduct ? selectedProduct.trim() : null,
        })
        .then((response) => {
          const tableDataWithStencilId = response.data.map((item) => ({
            ...item,
            stencilId: selectedStencilId.trim(),
          }));
          setTableData(tableDataWithStencilId);
          setShowTable(true);
        })
        .catch((error) => {
          console.error("Error fetching data:", error.response ? error.response.data : error.message);
        });
    }
  };

  useEffect(() => {
    axios.post(`${Data.url}getPartCodeDatabyall`)
      .then((response) => {
        const cleanedPartCodes = response.data.map((part) => part.PartNumber.trim());
        setData(cleanedPartCodes);
        setOriginalPartCodeData(cleanedPartCodes);
      })
      .catch((error) => {
        console.error("Error fetching part codes:", error.response ? error.response.data : error.message);
      });

    axios.post(`${Data.url}getallStencilIDDatabyall`)
      .then((response) => {
        const cleanedStencilIds = response.data.map((stencil) => stencil.StencilID.trim());
        setStencilData(cleanedStencilIds);
        setOriginalStencilData(cleanedStencilIds);
      })
      .catch((error) => {
        console.error("Error fetching stencil IDs:", error.response ? error.response.data : error.message);
      });

    axios.post(`${Data.url}getProductNameDatabyall`)
      .then((response) => {
        const cleanedProductNames = response.data.map((product) => product.Product.trim());
        setProductData(cleanedProductNames);
        setOriginalProductData(cleanedProductNames);
      })
      .catch((error) => {
        console.error("Error fetching product names:", error.response ? error.response.data : error.message);
      });
  }, []);

  const handlePartCodeChange = (newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedPartCode(trimmedValue);

    if (trimmedValue) {
      axios.post(`${Data.url}getSelectedPartCodeDataforedit`, { partCode: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedStencilIds = [...new Set(relevantData.map(item => item.StencilID.trim()))];
          const relatedProductNames = [...new Set(relevantData.map(item => item.Product.trim()))];
          
          setStencilData(relatedStencilIds);
          setProductData(relatedProductNames);
          
          if (selectedStencilId && !relatedStencilIds.includes(selectedStencilId.trim())) {
            setSelectedStencilId(null);
          }
          if (selectedProduct && !relatedProductNames.includes(selectedProduct.trim())) {
            setSelectedProductName(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!trimmedValue && !selectedStencilId && !selectedProduct) {
      resetToOriginalData();
    }
  };

  const handleStencilIdChange = (newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedStencilId(trimmedValue);

    if (trimmedValue) {
      axios.post(`${Data.url}getSelectedPartCodeDataforedit`, { stencilId: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedPartNumbers = [...new Set(relevantData.map(item => item.PartNumber.trim()))];
          const relatedProductNames = [...new Set(relevantData.map(item => item.Product.trim()))];
          
          setData(relatedPartNumbers);
          setProductData(relatedProductNames);
          
          if (selectedPartCode && !relatedPartNumbers.includes(selectedPartCode.trim())) {
            setSelectedPartCode(null);
          }
          if (selectedProduct && !relatedProductNames.includes(selectedProduct.trim())) {
            setSelectedProductName(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!selectedPartCode && !trimmedValue && !selectedProduct) {
      resetToOriginalData();
    }
  };

  const handleProductNameChange = (newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedProductName(trimmedValue);

    if (trimmedValue) {
      axios.post(`${Data.url}getSelectedPartCodeDataforedit`, { Product: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedPartNumbers = [...new Set(relevantData.map(item => item.PartNumber.trim()))];
          const relatedStencilIds = [...new Set(relevantData.map(item => item.StencilID.trim()))];
          
          setData(relatedPartNumbers);
          setStencilData(relatedStencilIds);
          
          if (selectedPartCode && !relatedPartNumbers.includes(selectedPartCode.trim())) {
            setSelectedPartCode(null);
          }
          if (selectedStencilId && !relatedStencilIds.includes(selectedStencilId.trim())) {
            setSelectedStencilId(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!selectedPartCode && !selectedStencilId && !trimmedValue) {
      resetToOriginalData();
    }
  };

  const handleSubmit = () => {
    axios
      .post(`${Data.url}getSelectedPartCodeDataforedit`, {
        partCode: selectedPartCode ? selectedPartCode.trim() : null,
        stencilId: selectedStencilId ? selectedStencilId.trim() : null,
        Product: selectedProduct ? selectedProduct.trim() : null,
        Rackno: Rackno ? Rackno.trim() : null,
      })
      .then((response) => {
        const tableDataWithStencilId = response.data.map(item => ({
          ...item,
          stencilId: selectedStencilId.trim(),
        }));
        setTableData(tableDataWithStencilId);
        setShowTable(true);
      })
      .catch((error) => {
        console.error("Error fetching data:", error.response ? error.response.data : error.message);
      });
  };

  const handleCloseAlert = () => {
    setSuccessAlert(false);
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar
          disableGutters
          sx={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              height: 40,
            }}
          />
          <Button
            color="inherit"
            onClick={handleHomeClick}
            sx={{ fontWeight: "bold" }}
          >
            Home
          </Button>
        </Toolbar>
      </AppBar>
      <Box
        sx={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          color: "#fff",
        }}
      >
        <Dialog
          open={isWaitingVisible}
          onClose={handleCancelWaiting}
          aria-labelledby="alert-dialog-title-waiting"
          aria-describedby="alert-dialog-description-waiting"
          PaperProps={{
            style: {
              backgroundColor: "Yellow",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-waiting">
            {"Please Pick from Location "}
            {physicalloc <= 60
              ? `Rack -1 ${physicalloc}`
              : `Rack -2 ${physicalloc}`}
          </DialogTitle>
        </Dialog>
        <Dialog
          open={wrongPickup}
          aria-labelledby="alert-dialog-title-waiting"
          aria-describedby="alert-dialog-description-waiting"
          PaperProps={{
            style: {
              backgroundColor: "Red",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-waiting">
            {"Wrong Stencil Picked!!!"}
          </DialogTitle>
        </Dialog>
        {successAlert && (
          <Alert
            variant="filled"
            severity="success"
            action={
              <Button color="inherit" size="small" onClick={handleCloseAlert}>
                Close
              </Button>
            }
          >
            Update Stencil Success!
          </Alert>
        )}
        <Container
          sx={{
            backgroundColor: "rgba(255, 255, 255, 0.2)",
            borderRadius: "12px",
            padding: "40px",
            boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
            backdropFilter: "blur(10px)",
            width: "65%",
            maxWidth: "400px",
            marginBottom: "40px",
          }}
        >
          <Typography
            variant="h4"
            component="h1"
            sx={{
              marginBottom: "20px",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            UPDATE STENCIL
          </Typography>
          
          <Autocomplete
            options={stencilData}
            value={selectedStencilId}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={(event, newValue) => handleStencilIdChange(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Stencil ID"
                onChange={(e) => handleStencilIdChange(e.target.value)}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />

          <Autocomplete
            options={Partcodedata}
            value={selectedPartCode}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={(event, newValue) => handlePartCodeChange(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Part Code"
                onChange={(e) => handlePartCodeChange(e.target.value)}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white", backgroundColor: "transparent" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />

          <Autocomplete
            options={productData}
            value={selectedProduct}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={(event, newValue) => handleProductNameChange(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Product Name"
                onChange={(e) => handleProductNameChange(e.target.value)}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />

          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!selectedPartCode || !selectedStencilId || !selectedProduct}
            sx={{
              backgroundColor: "#4CAF50",
              "&:hover": {
                backgroundColor: "#45a049",
              },
              padding: "10px 0",
              fontSize: "16px",
              fontWeight: "bold",
              width: "100%",
            }}
          >
            Submit
          </Button>
        </Container>
        {showTable && (
          <TableContainer
            component={Paper}
            sx={{ width: "80%", marginTop: "20px" }}
          >
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Product
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Side
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Part Number
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Barcode ID
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Stencil ID
                  </TableCell>
                    <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Rack No
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {tableData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>{row.Product.trim()}</TableCell>
                    <TableCell>{row.Side}</TableCell>
                    <TableCell>{row.PartNumber.trim()}</TableCell>
                    <TableCell>{row.BarcodeID.trim()}</TableCell>
                    <TableCell>{row.StencilID.trim()}</TableCell>
                    <TableCell>{row.Rackno}</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => handleeditClick(row.BarcodeID.trim())}
                      >
                        EDIT
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>
    </div>
  );
}

export default EditStencil;