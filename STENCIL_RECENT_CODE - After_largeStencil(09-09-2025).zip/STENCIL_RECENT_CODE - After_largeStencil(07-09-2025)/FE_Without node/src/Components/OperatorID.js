import React, { useState, useRef, useEffect } from "react";
import { Button, Typography, Box } from "@mui/material";

function OperatorId({ val, onclose }) {
  const Stencil = val;
  const [inputValue, setInputValue] = useState("");
  const inputRef = useRef(null);
  const scanBuffer = useRef("");
  const lastKeyTime = useRef(0);
  const isFirstKey = useRef(true);

  // Handle key presses
  const handleKeyPress = (event) => {
    const currentTime = Date.now();
    const timeDiff = currentTime - lastKeyTime.current;
    console.log("Key pressed:", event.key, "Time diff:", timeDiff);

    // Prevent Enter from being added to input
    if (event.key === "Enter") {
      event.preventDefault();
      // Submit the accumulated value
      if (scanBuffer.current) {
        console.log("Submitting scan buffer:", scanBuffer.current);
        handleSubmit(scanBuffer.current);
        scanBuffer.current = ""; // Clear buffer after submission
        setInputValue(""); // Clear visible input
        isFirstKey.current = true;
      }
      lastKeyTime.current = currentTime;
      return;
    }

    // Only allow numeric characters (0-9)
    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
      return;
    }

    // Always accept the first character if it's a number
    if (isFirstKey.current) {
      isFirstKey.current = false;
      scanBuffer.current = event.key;
      setInputValue(scanBuffer.current);
      lastKeyTime.current = currentTime;
      return;
    }

    // If this is a rapid keystroke (from scanner)
    if (timeDiff < 50) {
      // Accumulate the character
      scanBuffer.current += event.key;
      setInputValue(scanBuffer.current); // Update visible input

      // Check if 8 characters have been scanned
      if (scanBuffer.current.length === 8) {
        console.log("8 digits scanned, submitting:", scanBuffer.current);
        handleSubmit(scanBuffer.current);
        scanBuffer.current = ""; // Clear buffer after submission
        setInputValue(""); // Clear visible input
        isFirstKey.current = true;
      }
    } else {
      // Too slow - likely manual typing, but still allow it for numbers
      scanBuffer.current += event.key;
      setInputValue(scanBuffer.current);
      
      // Check if 8 characters have been entered manually
      if (scanBuffer.current.length === 8) {
        console.log("8 digits entered manually, submitting:", scanBuffer.current);
        handleSubmit(scanBuffer.current);
        scanBuffer.current = ""; // Clear buffer after submission
        setInputValue(""); // Clear visible input
        isFirstKey.current = true;
      }
    }

    lastKeyTime.current = currentTime;
  };

  // Submit handler
  const handleSubmit = (value) => {
    console.log("Submitting:", value);
    if (value && value.length === 8 && /^\d{8}$/.test(value)) {
      onclose(Stencil, value);
      scanBuffer.current = "";
      setInputValue("");
      isFirstKey.current = true;
    }
  };

  // Reset buffer if no activity for a while
  useEffect(() => {
    const resetInterval = setInterval(() => {
      if (Date.now() - lastKeyTime.current > 1000) { // Increased to 2 seconds
        scanBuffer.current = "";
        setInputValue("");
        isFirstKey.current = true;
      }
    }, 100);

    return () => clearInterval(resetInterval);
  }, []);

  // Focus input on mount and when window regains focus
  useEffect(() => {
    const focusInput = () => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    };

    window.addEventListener("focus", focusInput);
    focusInput();

    return () => window.removeEventListener("focus", focusInput);
  }, []);

  return (
    <div>
      <Box
        position="absolute"
        left="32%"
        top="25%"
        width="32%"
        height="auto"
        bgcolor="background.paper"
        boxShadow={5}
        p={2}
      >
        <Typography
          variant="h4"
          component="h1"
          sx={{
            marginBottom: "20px",
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          OPERATOR ID
        </Typography>

        <input
          ref={inputRef}
          type="text"
          placeholder="Scan  Operator ID"
          value={inputValue}
          onKeyPress={handleKeyPress}
          autoComplete="off"
          maxLength={8}
          style={{
            color: "black",
            fontSize: "20px",
            width: "95%",
            padding: "10px",
            border: "1px solid black",
            borderRadius: "4px",
            outline: "none",
            marginBottom: "10px",
            backgroundColor: "white",
          }}
        />

        <Button
          variant="contained"
          onClick={() => handleSubmit(inputValue)}
          disabled={inputValue.length !== 8 || !/^\d{8}$/.test(inputValue)}
          sx={{
            backgroundColor: "#4CAF50",
            "&:hover": {
              backgroundColor: "#45a049",
            },
            "&:disabled": {
              backgroundColor: "#cccccc",
            },
            padding: "10px 0",
            fontSize: "16px",
            fontWeight: "bold",
            width: "100%",
          }}
        >
          Submit
        </Button>
      </Box>
    </div>
  );
}

export default OperatorId;