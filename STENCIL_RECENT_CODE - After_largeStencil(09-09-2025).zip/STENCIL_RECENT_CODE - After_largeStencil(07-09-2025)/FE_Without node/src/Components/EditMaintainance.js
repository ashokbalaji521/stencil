import React, { useState, useEffect } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { CircularProgress, Button, Box, TextField } from "@mui/material";
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import Header from "./Header";
import axios from "axios";
import { format } from "date-fns";
import { Data } from "../Custom/custom";
import { useNavigate } from "react-router-dom";
import * as XLSX from 'xlsx';

function EditMaintainance({ selectedRowData }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageSize, setPageSize] = useState(5);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await axios.post(`${Data.url}getloadeddata`, {
        fromMaintenance_updated_datetime: fromDate,
        toMaintenance_updated_datetime: toDate,
      });
      const TableData = res.data.map((item) => {
        const maintenanceDate = item.Maintenance_updated_datetime 
          ? new Date(item.Maintenance_updated_datetime) 
          : null;

        return {
          Product: item.Product,
          BarcodeID: item.BarcodeID,
          PartNumber: item.PartNumber,
          Side: item.Side,
          StencilId: item.StencilID,
          StencilTension: item.StencilTension,
          PhysicalLocation: item.PhysicalLocation,
          StencilThickness: item.StencilThickness,
          Remarks: item.Remarks,
          Maintenance_updated_datetime: maintenanceDate 
            ? format(maintenanceDate, "dd/MM/yyyy HH:mm:ss") 
            : "",
        };
      });
      setData(TableData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSearch = () => {
    fetchData();
  };

  const handleEdit = async (params) => {
    try {
      const response = await axios.post(`${Data.url}getStencilDataByBarcodeID?BarcodeId=${params.row.BarcodeID}`);
      const stencilData = response.data[0];
      const stencilTensionsArray = stencilData.StencilTension ? stencilData.StencilTension.split(',').map(t => t.trim()) : Array(5).fill("");

      navigate("/AvailableStencilRegistration", { state: { editData: { ...stencilData, stencilTensions: stencilTensionsArray } } });
    } catch (error) {
      console.error("Error fetching stencil data:", error);
    }
  };

  const columns = [
    { field: "Product", headerName: "Product", width: 200, headerClassName: "super-app-theme--header" },
    { field: "StencilId", headerName: "Stencil ID", width: 210, headerClassName: "super-app-theme--header" },
    { field: "Side", headerName: "Side", width: 110, headerClassName: "super-app-theme--header" },
    { field: "PartNumber", headerName: "Part Number", width: 150, headerClassName: "super-app-theme--header" },
    { field: "PhysicalLocation", headerName: "Location", width: 180, headerClassName: "super-app-theme--header" },
    { field: "StencilThickness", headerName: "Stencil Thickness", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StencilTension", headerName: "Stencil Tension", width: 180, headerClassName: "super-app-theme--header" },
    { field: "Remarks", headerName: "Remarks", width: 150, headerClassName: "super-app-theme--header" },
    { field: "Maintenance_updated_datetime", headerName: "Maintenance Updated Datetime", width: 220, headerClassName: "super-app-theme--header" },
    { field: "BarcodeID", headerName: "BarCode ID", width: 150, headerClassName: "super-app-theme--header" },
    { field: "action", headerName: "ACTION", width: 150, headerClassName: "super-app-theme--header",
      renderCell: (params) => (
        <Button variant="contained" color="primary" onClick={() => handleEdit(params)}>
          EDIT
        </Button>
      ),
    },
  ];

  const handleDownload = () => {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Maintenance Data");
    XLSX.writeFile(wb, "maintenance_data.xlsx");
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Header data={"Maintainance Available Stencils"} />
      
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, paddingBottom: 2 }}>
        <DateTimePicker
          label="From Date"
          value={fromDate}
          onChange={(newValue) => setFromDate(newValue)}
          renderInput={(params) => <TextField {...params} />}
        />
        <DateTimePicker
          label="To Date"
          value={toDate}
          onChange={(newValue) => setToDate(newValue)}
          renderInput={(params) => <TextField {...params} />}
        />
        <Button variant="contained" color="primary" onClick={handleSearch}>
          Search
        </Button>
        <Button variant="contained" color="secondary" onClick={handleDownload}>
          Download 
        </Button>
      </Box>

      <Box
        sx={{
          height: 700,
          width: "100%",
          overflow: "hidden",
          "& .MuiDataGrid-cell": {
            borderRight: '1px solid #ddd', // Vertical lines between columns
          },
          "& .super-app-theme--header": {
            backgroundColor: '#f0f8ff', // Light blue
            color: '#333',
          },
        }}
      >
        {loading ? (
          <CircularProgress />
        ) : (
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={pageSize}
            rowsPerPageOptions={[5, 10, 20]}
            getRowId={(row) => row.BarcodeID}
            pagination
            autoHeight={false}
            onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
            disableSelectionOnClick
            components={{ Toolbar: GridToolbar }}
            sx={{ "& .MuiDataGrid-cell": { backgroundColor: "white" } }}
          />
        )}
      </Box>
    </LocalizationProvider>
  );
};

export default EditMaintainance;