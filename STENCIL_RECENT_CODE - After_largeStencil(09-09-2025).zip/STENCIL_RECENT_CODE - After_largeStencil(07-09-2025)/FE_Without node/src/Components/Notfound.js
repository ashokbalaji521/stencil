import React from "react";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate(); // Hook to navigate between routes

  const handleGoBack = () => {
    navigate("/HomePage"); // Navigate to the Home page
  };

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h1>404 - Page Not Found</h1>
      <p>The page you are looking for does not exist.</p>
      <button
        onClick={handleGoBack}
        style={{
          marginTop: "20px",
          padding: "10px 20px",
          fontSize: "16px",
          cursor: "pointer",
          backgroundColor: "#007BFF",
          color: "#FFFFFF",
          border: "none",
          borderRadius: "5px",
        }}
      >
        Go Back to Home
      </button>
    </div>
  );
};

export default NotFound;
