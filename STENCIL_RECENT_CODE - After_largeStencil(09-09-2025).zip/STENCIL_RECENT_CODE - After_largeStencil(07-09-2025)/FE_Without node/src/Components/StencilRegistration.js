import React, { useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { Data } from "../Custom/custom";
import { AppBar, Toolbar, Typography, Button, Container } from "@mui/material";
import { useNavigate } from "react-router-dom";
import Modal from "@mui/material/Modal";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
 
import "./StencilRegistration.css"; // Import the CSS file for custom styles
 
function StencilRegistration() {
  const [productName, setProductName] = useState("");
  const [pcbPartNumber, setPcbPartNumber] = useState("");
  const [stencilID, setStencilID] = useState("");
  const [barcodeID, setBarcodeID] = useState("");
  const [topBottom, setTopBottom] = useState(""); // Removed default value
  const [date, setDate] = useState(null); // Changed to null instead of dayjs()
  const [stencilTensions, setStencilTensions] = useState([]);
  const [remarks, setRemarks] = useState("");
  const [moduleCode, setModuleCode] = useState("");
  const [manufacturingPartNumber, setManufacturingPartNumber] = useState(""); // New state for Manufacturing Part Number
  const [stencilThickness, setStencilThickness] = useState(""); // New state for Stencil Thickness
  const [state, setState] = useState("idle");
  const [openModal, setOpenModal] = useState(false);
const [snackbarOpen, setSnackbarOpen] = useState(false);
const [snackbarMessage, setSnackbarMessage] = useState("");
 
  const navigate = useNavigate();
 
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
  
    // Validate form data
    if (
      !productName ||
      !pcbPartNumber ||
      !stencilID ||
      !barcodeID ||
      !date ||
      !manufacturingPartNumber || // Validate Manufacturing Part Number
      !stencilThickness || // Validate Stencil Thickness
      !topBottom // Added validation for topBottom
    ) {
      alert("Please fill in all required fields.");
      return;
    }
  
    // Retrieve modifierUser ID from session storage
    const ModifiedUserID = sessionStorage.getItem("username");
  
    try {
      const response = await fetch(`${Data.url}insertStencilData`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          productName,
          pcbPartNumber,
          stencilID,
          barcodeID,
          topBottom,
          date: date ? date.format("YYYY-MM-DD") : null, // Handle null date
          stencilTensions,
          remarks,
          moduleCode,
          supplierPartNumber: manufacturingPartNumber, // Add Manufacturing Part Number to the request body
          stencilThickness, // Add Stencil Thickness to the request body
          ModifiedUserID, // Include modifierUser ID in the request body
        }),
      });
      if (response.status === 400) {
        const errorData = await response.json();
        setSnackbarMessage(errorData.message || "Barcode ID already present.");
        setSnackbarOpen(true);
        return;
      }
  
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
  
      const result = await response.json();
      console.log(result);
      alert("Stencil registration added successfully");
  
      // Reset form values after successful submission
      setProductName("");
      setPcbPartNumber("");
      setStencilID("");
      setBarcodeID("");
      setTopBottom(""); // Reset to empty string
      setDate(null); // Reset to null
      setStencilTensions([]);
      setRemarks("");
      setModuleCode("");
      setManufacturingPartNumber("");
      setStencilThickness("");
      
    } catch (error) {
      console.error("Error:", error);
      alert("Error submitting form: " + error.message);
    }
  };
 
  // Handle input change for stencil tensions
  const handleTensionChange = (index, value) => {
    const newTensions = [...stencilTensions];
    newTensions[index] = value;
    setStencilTensions(newTensions);
  };
 
  // Handle form input change
  const handleInputChange = (setter) => (e) => {
    setter(e.target.value);
  };
 
  const handleHomeClick = () => {
    navigate("/Homepage"); // Navigate to the homepage
  };
 
  return (
    <>
      <div style={{ zoom: "80%" }} className="body">
        <AppBar position="static" style={{ backgroundColor: "#1E3C72" }}>
          <Toolbar>
            <Button
              color="inherit"
              onClick={handleHomeClick}
              style={{ color: "#FFFFFF", marginRight: "auto" }} // White color for the home button
            >
              HOME
            </Button>
            <Typography
              variant="h5"
              style={{
                flexGrow: 1,
                textAlign: "center", // Center the title
                color: "#FFFFFF", // White color for header text
              }}
            >
              NEW STENCIL REGISTRATION
            </Typography>
          </Toolbar>
        </AppBar>
        <Container
          style={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
            height: "100vh", // Set height to full viewport
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "70px",
          }}
        >
          <Box
            component="form"
            sx={{
              // display: "flex",
              //flexWrap: "wrap", // Allows items to wrap to the next line if necessary
              justifyContent: "space-between", // Space between items
              //alignItems: "flex-start", // Align items to the start
              width: "100%", // Make the form take the full width
              maxWidth: "1200px", // Maximum width for the form
              padding: "20px",
              backgroundColor: "rgba(255, 255, 255, 0.9)", // Slightly transparent white background for form
              borderRadius: "8px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)", // Add shadow for better visibility
            }}
            noValidate
            autoComplete="off"
            onSubmit={handleSubmit}
          >
            <div className="input-group">
              <TextField
                required
                id="productName"
                label="Product Name"
                variant="standard"
                margin="normal"
                value={productName}
                onChange={handleInputChange(setProductName)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="pcbPartNumber"
                label="PCB Part Number"
                variant="standard"
                margin="normal"
                value={pcbPartNumber}
                onChange={handleInputChange(setPcbPartNumber)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <TextField
                required
                id="stencilThickness" // Added Stencil Thickness
                label="Stencil Thickness"
                variant="standard"
                margin="normal"
                value={stencilThickness}
                onChange={handleInputChange(setStencilThickness)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="manufacturingPartNumber" // Added Manufacturing Part Number
                label="Manufacturing Part Number"
                variant="standard"
                margin="normal"
                value={manufacturingPartNumber}
                onChange={handleInputChange(setManufacturingPartNumber)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <TextField
                required
                id="stencilID"
                label="Stencil ID"
                variant="standard"
                margin="normal"
                value={stencilID}
                onChange={handleInputChange(setStencilID)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="barcodeID"
                label="Barcode ID"
                variant="standard"
                margin="normal"
                value={barcodeID}
                onChange={handleInputChange(setBarcodeID)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <FormControl
                margin="normal"
                sx={{ width: "45%", marginRight: "2%" }}
              >
                <InputLabel id="topBottom-label">Top/Bottom</InputLabel>
                <Select
                  labelId="topBottom-label"
                  id="topBottom"
                  value={topBottom}
                  onChange={(e) => setTopBottom(e.target.value)}
                  label="Top/Bottom"
                >
                  <MenuItem value="Top">Top</MenuItem>
                  <MenuItem value="Bottom">Bottom</MenuItem>
                </Select>
              </FormControl>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  value={date}
                  onChange={(newDate) => setDate(newDate)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      margin="normal"
                      sx={{ width: "45%" }} // Adjust width for the DatePicker
                    />
                  )}
                />
              </LocalizationProvider>
            </div>
          {/* Stencil Tension Inputs */}
{/* Stencil Tension Inputs */}
<div>
  <label>
    Stencil Tension:
    {["First", "Second", "Third", "Fourth", "Fifth"].map((name, index) => (
      <input
        key={name}
        type="number"
        value={stencilTensions[index] || ""}
        onChange={(e) => {
          // Validate to allow only up to 3 digits
          const value = e.target.value;
          if (/^\d{0,3}$/.test(value)) { // Allow only numbers up to 3 digits
            handleTensionChange(index, value);
          }
        }}
        maxLength={3} // Limit to 3 digits
        style={{ marginLeft: "5px", marginRight: "10px", width: "60px" }} // Fixed width for better UI
      />
    ))}
  </label>
</div>
 
 
            <TextField
              id="remarks"
              label="Remarks"
              variant="standard"
              margin="normal"
              multiline
              rows={4}
              value={remarks}
              onChange={handleInputChange(setRemarks)}
              sx={{ width: "100%", marginTop: "20px" }} // Full width for remarks
            />
            <TextField
              id="moduleCode"
              label="Module Code"
              variant="standard"
              margin="normal"
              value={moduleCode}
              onChange={handleInputChange(setModuleCode)}
              sx={{ width: "100%", marginTop: "20px" }} // Full width for module code
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                width: "100%",
                marginTop: "20px",
              }}
            >
              <button
                type="submit"
                onClick={() => {
                  setState("loading");
                  setTimeout(() => {
                    setState("success");
                  }, 2000);
                }}
                style={{
                  backgroundColor: "#1E3C72",
                  color: "white",
                  padding: "10px 20px",
                  border: "none",
                  borderRadius: "5px",
                  cursor: "pointer",
                }}
              >
                Submit
              </button>
            </div>
          </Box>
        </Container>
        <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <MuiAlert elevation={6} severity="error" onClose={() => setSnackbarOpen(false)}>
          {snackbarMessage}
        </MuiAlert>
      </Snackbar>
      </div>
    </>
  );
}
 
export default StencilRegistration;