var arr = [9, 8, 7, 6, 1, 2, 3];
var target = 9;
arr.sort();
function Search(arr, tar) {
  console.log(arr);
  let l = 0;
  let r = arr.length - 1;
  let mid = (l + r) / 2;

  // while (l < r) {
  //   mid = (l + r) % 2;
  //   console.log(mid, arr[mid]);
  //   if (arr[mid] == target) {
  //     return true;
  //   }
  //   if (arr[mid] > target) {
  //     r -= 1;
  //   }
  //   if (arr[mid] < target) {
  //     l += 1;
  //   }
  // }
  return false;
}

console.log(Search(arr, target));
