const UnauthorizedPage = () => {
    return <h1>Unauthorized Access</h1>;
  };
  
  export default UnauthorizedPage;
  