import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, TextField, Button, Container, AppBar, Toolbar, Typography, Snackbar, Alert, Modal } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import dayjs from "dayjs";
import axios from "axios";
import { Data } from "../Custom/custom";

function AvailableStencilRegistration() {
  const location = useLocation();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    Product: "",
    StencilId: "",
    Side: "",
    PartNumber: "",
    PhysicalLocation: "",
    BarcodeID: "",
    StencilThickness: "",
    ManufacturingPartNumber: "",
    Remarks: "",
    ModuleCode: "",
  });

  const [stencilTensions, setStencilTensions] = useState(Array(5).fill(""));
  const [originalData, setOriginalData] = useState(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [showOperatorModal, setShowOperatorModal] = useState(false);
  const [operatorId, setOperatorId] = useState("");
  const operatorInputRef = useRef(null);

  const { editData } = location.state || {};

  useEffect(() => {
    if (editData) {
      const formDataFromEdit = {
        Product: editData.Product || "",
        StencilId: editData.StencilID || "",
        Side: editData.Side || "",
        PartNumber: editData.PartNumber || "",
        PhysicalLocation: editData.PhysicalLocation || "",
        BarcodeID: editData.BarcodeID || "",
        StencilThickness: editData.StencilThickness || "",
        ManufacturingPartNumber: editData.SupplierPartNumber || "",
        Remarks: "",
        ModuleCode: "",
      };
      
      setFormData(formDataFromEdit);
      setOriginalData(editData);
      setStencilTensions(Array(5).fill(""));
    }
  }, [editData]);

  useEffect(() => {
    if (showOperatorModal && operatorInputRef.current) {
      operatorInputRef.current.focus();
    }
  }, [showOperatorModal]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleTensionChange = (index, value) => {
    if (/^\d{0,3}$/.test(value)) {
      const updatedTensions = [...stencilTensions];
      updatedTensions[index] = value;
      setStencilTensions(updatedTensions);
    }
  };

const handleOperatorIdChange = (e) => {
  const value = e.target.value.replace(/\D/g, ''); // Remove non-digits
  
  // Limit to 8 digits maximum
  const limitedValue = value.slice(0, 8);
  
  setOperatorId(limitedValue);
  
  // Auto-submit when exactly 8 digits are entered
  if (limitedValue.length === 8) {
    // Small delay to ensure state is updated
    setTimeout(() => {
      handleOperatorSubmit();
    }, 100);
  }
};
// Corrected handleOperatorSubmit function - calls storeEditableStencilRecord only once

const handleOperatorSubmit = async () => {
  if (operatorId.length !== 8 || !/^\d{8}$/.test(operatorId)) {
    setSnackbarMessage("Operator ID must be exactly 8 digits.");
    setSnackbarOpen(true);
    return;
  }

  if (!originalData) {
    setSnackbarMessage("Original data not available. Please try again.");
    setSnackbarOpen(true);
    return;
  }

  const stencilTension = stencilTensions.map(tension => tension ? parseInt(tension) : "").filter(tension => tension !== "");

  try {
    // Update the main table with new values and operatorid (as ModifiedUserID)
    const updateData = {
      barcodeID: formData.BarcodeID,
      stencilTensions: stencilTension,
      remarks: formData.Remarks,
      moduleCode: formData.ModuleCode,
      operatorid: operatorId,
    };

    await axios.post(`${Data.url}updateStencilTension`, updateData);

    // Store the updated record in EditableStencilrecord table (ONLY ONCE)
    const recordToStore = {
      Product: originalData.Product || "",
      StencilId: originalData.StencilID || "",
      Side: originalData.Side || "",
      PartNumber: originalData.PartNumber || "",
      PhysicalLocation: originalData.PhysicalLocation || "",
      BarcodeID: originalData.BarcodeID || "",
      StencilThickness: originalData.StencilThickness || "",
      SupplierPartNumber: originalData.SupplierPartNumber || "",
      Remarks: formData.Remarks || "", // Updated remarks
      ModuleCode: formData.ModuleCode || "", // Updated module code
      StencilTension: stencilTension.length > 0 ? stencilTension.join(",") : "", // Updated tension
      Rackno: originalData.Rackno || "",
      Maintenance_updated_datetime: new Date().toISOString(),
      operatorid: operatorId,
    };

    await axios.post(`${Data.url}storeEditableStencilRecord`, recordToStore);

    setSnackbarMessage("Stencil data updated successfully!");
    setSnackbarOpen(true);
    setShowOperatorModal(false);

    setTimeout(() => {
      setOperatorId("");
    }, 2000);

    setTimeout(() => navigate("/RackId"), 2000);
    
  } catch (error) {
    let errorMessage = "Failed to update stencil data.";
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message;
    }
    
    setSnackbarMessage(errorMessage);
    setSnackbarOpen(true);
  }
};

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowOperatorModal(true);
  };

  const handleCloseOperatorModal = () => {
    setShowOperatorModal(false);
    setOperatorId("");
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  const handleBackClick = () => {
    navigate("/RackId");
  };

  const handleCloseSnackbar = () => {
    setSnackbarOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-indigo-800">
      <AppBar position="static" sx={{ backgroundColor: "transparent", boxShadow: "none" }}>
        <Toolbar sx={{ background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)" }}>
          <Button 
            color="inherit" 
            onClick={handleBackClick} 
            sx={{ 
              fontWeight: "bold", 
              mr: 2,
              backgroundColor: "rgba(255, 255, 255, 0.1)",
              "&:hover": { backgroundColor: "rgba(255, 255, 255, 0.2)" },
              borderRadius: "8px",
              padding: "6px 12px"
            }}
            startIcon={<ArrowBackIcon />}
          >
            Back
          </Button>
          <Button 
            color="inherit" 
            onClick={handleHomeClick} 
            sx={{ 
              fontWeight: "bold",
              backgroundColor: "rgba(255, 255, 255, 0.1)",
              "&:hover": { backgroundColor: "rgba(255, 255, 255, 0.2)" },
              borderRadius: "8px",
              padding: "6px 12px"
            }}
          >
            Home
          </Button>
          <Typography 
            variant="h5" 
            sx={{ 
              flexGrow: 1, 
              textAlign: "center", 
              color: "#FFFFFF",
              fontWeight: "bold",
              letterSpacing: "1px"
            }}
          >
            MAINTENANCE STENCIL
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Container
        sx={{
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          py: 4,
        }}
      >
        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            width: "100%",
            maxWidth: "900px",
            p: 4,
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            borderRadius: "16px",
            boxShadow: "0 12px 24px rgba(0,0,0,0.3)",
            backdropFilter: "blur(10px)",
            transition: "all 0.3s ease-in-out",
            '&:hover': {
              boxShadow: "0 16px 32px rgba(0,0,0,0.4)"
            }
          }}
        >
          <Typography 
            variant="h4" 
            sx={{ 
              mb: 4, 
              textAlign: "center", 
              fontWeight: "bold",
              color: "#1e3c72",
              letterSpacing: "1px"
            }}
          >
            Update Stencil Details
          </Typography>

          <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 3, mb: 4 }}>
            {[
              { label: "Product Name", name: "Product" },
              { label: "PCB Part Number", name: "PartNumber" },
              { label: "Stencil Thickness", name: "StencilThickness" },
              { label: "Manufacturing Part Number", name: "ManufacturingPartNumber" },
              { label: "Stencil ID", name: "StencilId" },
              { label: "Barcode ID", name: "BarcodeID" },
              { label: "Side", name: "Side" },
            ].map((field, index) => (
              <TextField
                key={index}
                label={field.label}
                variant="outlined"
                value={formData[field.name]}
                name={field.name}
                onChange={handleChange}
                InputProps={{ readOnly: true }}
                fullWidth
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: "8px",
                    backgroundColor: "#f8fafc",
                    '&:hover fieldset': {
                      borderColor: "#1e3c72",
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: "#2a5298",
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: "#1e3c72",
                    fontWeight: "medium"
                  }
                }}
              />
            ))}
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                value={dayjs(editData?.Date || new Date())}
                renderInput={(params) => (
                  <TextField 
                    {...params} 
                    fullWidth 
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: "8px",
                        backgroundColor: "#f8fafc",
                        '&:hover fieldset': {
                          borderColor: "#1e3c72",
                        },
                        '&.Mui-focused fieldset': {
                          borderColor: "#2a5298",
                        }
                      },
                      '& .MuiInputLabel-root': {
                        color: "#1e3c72",
                        fontWeight: "medium"
                      }
                    }}
                  />
                )}
                disabled
              />
            </LocalizationProvider>
          </Box>

          <Box sx={{ textAlign: "center", mb: 4, p: 3, backgroundColor: "#f0fdf4", borderRadius: "12px" }}>
            <Typography 
              variant="subtitle1" 
              sx={{ 
                mb: 2, 
                fontWeight: "bold", 
                color: "#15803d",
                letterSpacing: "0.5px"
              }}
            >
              Stencil Tension (EDITABLE)
            </Typography>
            <Box sx={{ display: "flex", justifyContent: "center", gap: 2, flexWrap: "wrap" }}>
              {["LB", "RB", "LT", "RT", "M"].map((tension, index) => (
                <TextField
                  key={index}
                  type="number"
                  label={tension}
                  value={stencilTensions[index] || ""}
                  onChange={(e) => handleTensionChange(index, e.target.value)}
                  inputProps={{ maxLength: 3 }}
                  sx={{ 
                    width: "90px",
                    '& .MuiOutlinedInput-root': {
                      borderRadius: "8px",
                      backgroundColor: "#e8f5e8",
                      '&:hover fieldset': {
                        borderColor: "#15803d",
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: "#16a34a",
                      }
                    },
                    '& .MuiInputLabel-root': {
                      color: "#15803d",
                      fontWeight: "medium"
                    }
                  }}
                />
              ))}
            </Box>
          </Box>

          <Box sx={{ textAlign: "center", mb: 4, p: 3, backgroundColor: "#f0fdf4", borderRadius: "12px" }}>
            <Typography 
              variant="subtitle1" 
              sx={{ 
                mb: 2, 
                fontWeight: "bold", 
                color: "#15803d",
                letterSpacing: "0.5px"
              }}
            >
              Remarks (EDITABLE)
            </Typography>
            <TextField
              label="Remarks"
              variant="outlined"
              multiline
              rows={4}
              value={formData.Remarks}
              name="Remarks"
              onChange={handleChange}
              fullWidth
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: "8px",
                  backgroundColor: "#e8f5e8",
                  '&:hover fieldset': {
                    borderColor: "#15803d",
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: "#16a34a",
                  }
                },
                '& .MuiInputLabel-root': {
                  color: "#15803d",
                  fontWeight: "medium"
                }
              }}
            />
          </Box>

          <Box sx={{ textAlign: "center", mb: 4, p: 3, backgroundColor: "#f0fdf4", borderRadius: "12px" }}>
            <Typography 
              variant="subtitle1" 
              sx={{ 
                mb: 2, 
                fontWeight: "bold", 
                color: "#15803d",
                letterSpacing: "0.5px"
              }}
            >
              Module Code (EDITABLE)
            </Typography>
            <TextField
              label="Module Code"
              variant="outlined"
              value={formData.ModuleCode}
              name="ModuleCode"
              onChange={handleChange}
              fullWidth
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: "8px",
                  backgroundColor: "#e8f5e8",
                  '&:hover fieldset': {
                    borderColor: "#15803d",
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: "#16a34a",
                  }
                },
                '& .MuiInputLabel-root': {
                  color: "#15803d",
                  fontWeight: "medium"
                }
              }}
            />
          </Box>

          <Box sx={{ display: "flex", justifyContent: "center", gap: 2 }}>
            <Button
              type="submit"
              variant="contained"
              sx={{
                backgroundColor: "#1e3c72",
                "&:hover": { backgroundColor: "#2a5298" },
                px: 4,
                py: 1.5,
                fontSize: "16px",
                fontWeight: "bold",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
                transition: "all 0.3s ease-in-out"
              }}
            >
              Submit
            </Button>
            <Button
              variant="outlined"
              onClick={handleBackClick}
              sx={{
                borderColor: "#1e3c72",
                color: "#1e3c72",
                "&:hover": { borderColor: "#2a5298", color: "#2a5298" },
                px: 4,
                py: 1.5,
                fontSize: "16px",
                fontWeight: "bold",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                transition: "all 0.3s ease-in-out"
              }}
            >
              Cancel
            </Button>
          </Box>
        </Box>
      </Container>

      <Modal
        open={showOperatorModal}
        onClose={handleCloseOperatorModal}
        aria-labelledby="operator-modal-title"
        aria-describedby="operator-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "25%",
            left: "32%",
            width: "32%",
            bgcolor: "background.paper",
            boxShadow: 5,
            p: 2,
            borderRadius: "4px"
          }}
        >
          <Typography 
            id="operator-modal-title" 
            variant="h4" 
            component="h2" 
            sx={{ 
              mb: 2, 
              textAlign: "center",
              fontWeight: "bold"
            }}
          >
            OPERATOR ID
          </Typography>
          <TextField
            fullWidth
            variant="outlined"
            value={operatorId}
            onChange={handleOperatorIdChange}
            inputRef={operatorInputRef}
            inputProps={{ maxLength: 8 }}
            placeholder="Scan Operator ID"
            sx={{
              mb: 2,
              '& .MuiOutlinedInput-root': {
                borderRadius: "4px",
                backgroundColor: "white",
                '&:hover fieldset': {
                  borderColor: "black",
                },
                '&.Mui-focused fieldset': {
                  borderColor: "black",
                }
              },
              '& .MuiInputBase-input': {
                color: "black",
                fontSize: "20px",
                padding: "10px"
              }
            }}
          />
          <Box sx={{ display: "flex", justifyContent: "center", gap: 2 }}>
            <Button
              variant="contained"
              onClick={handleOperatorSubmit}
              disabled={operatorId.length !== 8 || !/^\d{8}$/.test(operatorId)}
              sx={{
                backgroundColor: "#4CAF50",
                "&:hover": { backgroundColor: "#45a049" },
                "&:disabled": { backgroundColor: "#cccccc" },
                padding: "10px 0",
                fontSize: "16px",
                fontWeight: "bold",
                width: "100%",
                borderRadius: "4px"
              }}
            >
              Submit
            </Button>
          </Box>
        </Box>
      </Modal>

      <Snackbar 
        open={snackbarOpen} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbarMessage.includes("Failed") ? "error" : "success"} 
          sx={{ 
            width: "100%",
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)"
          }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </div>
  );
}

export default AvailableStencilRegistration;