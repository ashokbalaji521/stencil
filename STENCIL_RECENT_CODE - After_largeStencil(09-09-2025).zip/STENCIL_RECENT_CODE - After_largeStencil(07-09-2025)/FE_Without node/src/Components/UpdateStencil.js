import React, { useState, useEffect } from "react"; // Ensure only one React import
import { useLocation } from "react-router-dom"; // Import useLocation
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { Data } from "../Custom/custom";
import { AppBar, Toolbar, Typography, Button, Container, Snackbar, Alert } from "@mui/material";
import { useNavigate } from "react-router-dom";
import "./StencilRegistration.css"; // Import the CSS file for custom styles
 
// Import the CSS file for custom styles
 
function UpdateStencilRegistration() {
  const location = useLocation(); // Get the location object
  const { stencilData } = location.state || {};
  const [productName, setProductName] = useState("");
  const [pcbPartNumber, setPcbPartNumber] = useState("");
  const [stencilID, setStencilID] = useState("");
  const [barcodeID, setBarcodeID] = useState("");
  const [topBottom, setTopBottom] = useState("Top");
  const [date, setDate] = useState(dayjs());
  //const [stencilTensions, setStencilTensions] = useState([]);
  const [stencilTensions, setStencilTensions] = useState([""]); // Initialize with an empty string
 
  const [remarks, setRemarks] = useState("");
  const [moduleCode, setModuleCode] = useState("");
  const [manufacturingPartNumber, setManufacturingPartNumber] = useState(""); // New state for Manufacturing Part Number
  const [stencilThickness, setStencilThickness] = useState(""); // New state for Stencil Thickness
  const [state, setState] = useState("idle");
  const [openSnackbar, setOpenSnackbar] = useState(false); // State for Snackbar
 
  const [snackbarMessage, setSnackbarMessage] = useState(""); // State for message in Snackbar
 
  const [snackbarSeverity, setSnackbarSeverity] = useState("success"); // State for Snackbar severity
  const navigate = useNavigate();
 
  useEffect(() => {
    if (stencilData) {
      setProductName(stencilData.Product || "");
      setPcbPartNumber(stencilData.PartNumber || "");
      setStencilID(stencilData.StencilID || "");
      setBarcodeID(stencilData.BarcodeID || "");
      setTopBottom(stencilData.Side === "TOP" ? "Top" : "Bottom");
      setDate(dayjs(stencilData.DateofManufacturing)); // Use dayjs to format the date
      setStencilThickness(stencilData.StencilThickness || "");
      setManufacturingPartNumber(stencilData.SupplierPartNumber || "");
      setRemarks(stencilData.Remarks || "");
      setModuleCode(stencilData.ModuleCode || "");
      // If there are stencil tensions, set them here
      // You may need to adjust this part based on your actual data structure
      if (stencilData.StencilTension) {
        setStencilTensions(stencilData.StencilTension.split(",").map(tension => tension.trim())); // Adjust as needed
      }
    }
  }, [stencilData]);
 
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    // Validate form data
    if (
      !productName ||
      !pcbPartNumber ||
      !stencilID ||
      !barcodeID ||
      !date ||
      !manufacturingPartNumber ||
      !stencilThickness
    ) {
      setSnackbarSeverity("error");
 
      setSnackbarMessage("Please fill in all required fields.");
 
      setOpenSnackbar(true);
    }
    const ModifiedUserID = sessionStorage.getItem("username");
    try {
      const response = await fetch(`${Data.url}updateStencilDataByBarcodeID`, {
        // Update the URL
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          BarcodeID: barcodeID,
          Product: productName,
 
          PartNumber: pcbPartNumber,
 
          StencilID: stencilID,
 
          Side: topBottom === "Top" ? "TOP" : "BOTTOM",
 
          DateofManufacturing: date.format("YYYY-MM-DD"),
 
          StencilThickness: stencilThickness,
 
          SupplierPartNumber: manufacturingPartNumber,
 
          Remarks: remarks,
 
          ModuleCode: moduleCode,
          ModifiedUserID:ModifiedUserID,
          StencilTension: stencilTensions.slice(0, 5),  
          //StencilTension: stencilTensions[0] || null,
        }),
      });
 
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
 
      const result = await response.json();
      setSnackbarSeverity("success");
 
      setSnackbarMessage(result.message || "Stencil registration updated successfully");
 
      setOpenSnackbar(true);
 
      setTimeout(() => navigate("/Homepage"), 2000); // Navigate to homepage after 2 seconds
    } catch (error) {
      setSnackbarSeverity("error");
 
      setSnackbarMessage("Error updating stencil data: " + error.message);
 
      setOpenSnackbar(true);
    }
  };
 
  const handleTensionChange = (index, value) => {
    const newTensions = [...stencilTensions];
    newTensions[index] = value; // Update the specific tension value
    setStencilTensions(newTensions); // Set the updated tensions
  };
 
  // Handle form input change
  const handleInputChange = (setter) => (e) => {
    setter(e.target.value);
  };
 
  const handleHomeClick = () => {
    navigate("/Homepage"); // Navigate to the homepage
   
  };
  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };
 
  return (
    <>
      <div style={{ zoom: "80%" }} className="body">
        <AppBar position="static" style={{ backgroundColor: "#1E3C72" }}>
          <Toolbar>
            <Button
              color="inherit"
              onClick={handleHomeClick}
              style={{ color: "#FFFFFF", marginRight: "auto" }} // White color for the home button
            >
              HOME
            </Button>
            <Typography
              variant="h6"
              style={{
                flexGrow: 1,
                textAlign: "center", // Center the title
                color: "#FFFFFF", // White color for header text
              }}
            >
              UPDATE STENCIL REGISTRATION
            </Typography>
          </Toolbar>
        </AppBar>
        <Container
          style={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
            height: "100vh", // Set height to full viewport
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginTop: "70px",
          }}
        >
          <Box
            component="form"
            sx={{
              display: "flex",
              flexWrap: "wrap", // Allows items to wrap to the next line if necessary
              justifyContent: "space-between", // Space between items
              alignItems: "flex-start", // Align items to the start
              width: "100%", // Make the form take the full width
              maxWidth: "1200px", // Maximum width for the form
              padding: "20px",
              backgroundColor: "rgba(255, 255, 255, 0.9)", // Slightly transparent white background for form
              borderRadius: "8px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)", // Add shadow for better visibility
            }}
            noValidate
            autoComplete="off"
            onSubmit={handleSubmit}
          >
            <div className="input-group">
              <TextField
                required
                id="productName"
                label="Product Name"
                variant="standard"
                margin="normal"
                value={productName}
                onChange={handleInputChange(setProductName)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="pcbPartNumber"
                label="PCB Part Number"
                variant="standard"
                margin="normal"
                value={pcbPartNumber}
                onChange={handleInputChange(setPcbPartNumber)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <TextField
                required
                id="stencilThickness" // Added Stencil Thickness
                label="Stencil Thickness"
                variant="standard"
                margin="normal"
                value={stencilThickness}
                onChange={handleInputChange(setStencilThickness)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="manufacturingPartNumber" // Added Manufacturing Part Number
                label="Manufacturing Part Number"
                variant="standard"
                margin="normal"
                value={manufacturingPartNumber}
                onChange={handleInputChange(setManufacturingPartNumber)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <TextField
                required
                id="stencilID"
                label="Stencil ID"
                variant="standard"
                margin="normal"
                value={stencilID}
                onChange={handleInputChange(setStencilID)}
                sx={{ width: "45%", marginRight: "2%" }} // Adjust width and margin
              />
              <TextField
                required
                id="barcodeID"
                label="Barcode ID"
                variant="standard"
                margin="normal"
                value={barcodeID}
                onChange={handleInputChange(setBarcodeID)}
                sx={{ width: "45%" }} // Adjust width
              />
            </div>
            <div className="input-group">
              <FormControl
                margin="normal"
                sx={{ width: "45%", marginRight: "2%" }}
              >
                <InputLabel id="topBottom-label">Top/Bottom</InputLabel>
                <Select
                  labelId="topBottom-label"
                  id="topBottom"
                  value={topBottom}
                  onChange={(e) => setTopBottom(e.target.value)}
                  label="Top/Bottom"
                >
                  <MenuItem value="Top">Top</MenuItem>
                  <MenuItem value="Bottom">Bottom</MenuItem>
                </Select>
              </FormControl>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  value={date}
                  onChange={(newDate) => setDate(newDate)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      margin="normal"
                      sx={{ width: "45%" }} // Adjust width for the DatePicker
                    />
                  )}
                />
              </LocalizationProvider>
            </div>
           
            <div className="input-group">
        <label>
          Stencil Tension:
          {["First", "Second", "Third", "Fourth", "Fifth"].map((name, index) => (
            <input
              key={name}
              type="number"
              value={stencilTensions[index] || ""}
              onChange={(e) => {
                const value = e.target.value;
                // Validate to allow only up to 3 digits
                if (/^\d{0,3}$/.test(value)) { // Allow only numbers up to 3 digits
                  handleTensionChange(index, value);
                }
              }}
              maxLength={3} // Limit to 3 digits
              style={{ marginLeft: "5px", marginRight: "10px", width: "60px" }} // Fixed width for better UI
            />
          ))}
        </label>
      </div>
            <TextField
              id="remarks"
              label="Remarks"
              variant="standard"
              margin="normal"
              multiline
              rows={4}
              value={remarks}
              onChange={handleInputChange(setRemarks)}
              sx={{ width: "100%", marginTop: "20px" }} // Full width for remarks
            />
            <TextField
              id="moduleCode"
              label="Module Code"
              variant="standard"
              margin="normal"
              value={moduleCode}
              onChange={handleInputChange(setModuleCode)}
              sx={{ width: "100%", marginTop: "20px" }} // Full width for module code
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                width: "100%",
                marginTop: "20px",
              }}
            >
              <button
                type="submit"
                style={{
                  backgroundColor: "#1E3C72",
                  color: "white",
                  padding: "10px 20px",
                  border: "none",
                  borderRadius: "5px",
                  cursor: "pointer",
                }}
              >
                UPDATE
              </button>
            </div>
          </Box>
        </Container>
      </div>
      <Snackbar
        open={openSnackbar}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbarSeverity} sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </>
  );
}
 
export default UpdateStencilRegistration;
 