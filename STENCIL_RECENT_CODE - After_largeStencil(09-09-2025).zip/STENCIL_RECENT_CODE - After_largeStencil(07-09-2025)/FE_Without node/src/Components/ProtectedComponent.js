import React, { useEffect } from "react";
import axios from "axios";
import { Data } from "../Custom/custom"; // Ensure the Data object is properly imported

const ProtectedComponent = () => {
  useEffect(() => {
    // Perform authenticated request when the component mounts
    axios
      .get(`${Data.url}/protectedRoute`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`, // Get the JWT token from sessionStorage
        },
      })
      .then((res) => {
        // Handle the response
        console.log("Protected data:", res.data);
      })
      .catch((err) => {
        console.error("Error fetching protected data:", err);
        alert("You are not authorized to view this content.");
      });
  }, []); // Empty dependency array ensures this runs only once when component mounts

  return (
    <div>
      <h1>Protected Content</h1>
      {/* Add protected content rendering logic here */}
    </div>
  );
};

export default ProtectedComponent;
