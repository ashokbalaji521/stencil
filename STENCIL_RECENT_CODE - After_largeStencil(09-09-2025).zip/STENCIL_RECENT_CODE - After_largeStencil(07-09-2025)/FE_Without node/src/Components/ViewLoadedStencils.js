import React, { useState, useEffect } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { CircularProgress, Box, Button } from "@mui/material";
import Header from "./Header";
import axios from "axios";
import { Data } from "../Custom/custom";
import * as XLSX from 'xlsx';

const DataTable = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageSize, setPageSize] = useState(5);

  useEffect(() => {
    axios
      .post(`${Data.url}getloadeddata
        `)
      .then((res) => {
        const TableData = res.data.map((item) => {
          // Handle PhysicalLocation and PairedPhysicalLocation
          let slotValue = "N/A";
          if (item.PhysicalLocation) {
            if (item.PairedPhysicalLocation) {
              // Combine and sort in ascending order
              const locations = [item.PhysicalLocation, item.PairedPhysicalLocation].sort((a, b) => a - b);
              slotValue = `[${locations.join(",")}]`;
            } else {
              slotValue = item.PhysicalLocation;
            }
          }

          return {
            Product: item.Product,
            BarcodeID: item.BarcodeID,
            PartNumber: item.PartNumber,
            Side: item.Side,
            StencilId: item.StencilID,
            Rackno: item.Rackno,
            PhysicalLocation: slotValue, // Updated to use formatted slotValue
            AvailableStatus: item.AvailableStatus,
          };
        });
        setData(TableData);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  const columns = [
    {
      field: "Product",
      headerName: "Product",
      width: 300,
      headerClassName: "super-app-theme--header-product",
    },
    {
      field: "StencilId",
      headerName: "Stencil ID",
      width: 250,
      headerClassName: "super-app-theme--header-stencil",
    },
    {
      field: "BarcodeID",
      headerName: "BarCode ID",
      width: 250,
      headerClassName: "super-app-theme--header-barcode",
    },
    {
      field: "PartNumber",
      headerName: "Part Number",
      width: 200,
      headerClassName: "super-app-theme--header-partnumber",
    },
    {
      field: "Side",
      headerName: "Side",
      width: 150,
      headerClassName: "super-app-theme--header-side",
    },
    {
      field: "Rackno",
      headerName: "Rack",
      width: 120,
      headerClassName: "super-app-theme--header-Rackno",
    },
    {
      field: "PhysicalLocation",
      headerName: "Slot",
      width: 150,
      headerClassName: "super-app-theme--header-location",
    },
    {
      field: "AvailableStatus",
      headerName: "AvailableStatus",
      width: 150,
      headerClassName: "super-app-theme--header-AvailableStatus",
    },
  ];

  const handleDownload = () => {
    const orderedData = data.map((item, index) => ({
      "SL No": index + 1,
      Product: item.Product || "",
      "Stencil ID": item.StencilId || "",
      Side: item.Side || "",
      "Part Number": item.PartNumber || "",
      Rack: item.Rackno || "",
      Slot: item.PhysicalLocation || "", // Use formatted PhysicalLocation (Slot)
      "Barcode ID": item.BarcodeID || "",
      AvailableStatus: item.AvailableStatus || "",
    }));

    const ws = XLSX.utils.json_to_sheet(orderedData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Available Stencils");
    XLSX.writeFile(wb, "available_stencils.xlsx");
  };

  return (
    <Box sx={{ height: 700, width: '100%' }}>
      <Header data={"Available Stencils"} />

      <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between' }}>
        <Button variant="contained" color="secondary" onClick={handleDownload}>
          Download
        </Button>
      </Box>

      {loading ? (
        <CircularProgress />
      ) : (
        <DataGrid
          rows={data}
          columns={columns}
          pageSize={pageSize}
          rowsPerPageOptions={[5, 10, 20]}
          getRowId={(row) => row.BarcodeID}
          pagination
          autoHeight
          onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
          disableSelectionOnClick
          components={{ Toolbar: GridToolbar }}
          sx={{
            '& .MuiDataGrid-cell ': {
              borderRight: '1px solid #ddd',
            },
            '& .super-app-theme--header-product': {
              backgroundColor: '#f0f8ff',
              color: '#333',
            },
            '& .super-app-theme--header-stencil': {
              backgroundColor: '#ffe4e1',
              color: '#333',
            },
            '& .super-app-theme--header-side': {
              backgroundColor: '#f5f5dc',
              color: '#333',
            },
            '& .super-app-theme--header-partnumber': {
              backgroundColor: '#e0ffff',
              color: '#333',
            },
            '& .super-app-theme--header-location': {
              backgroundColor: '#f8f8ff',
              color: '#333',
            },
            '& .super-app-theme--header-barcode': {
              backgroundColor: '#d3d3d3',
              color: '#333',
            },
            '& .super-app-theme--header-Rackno': {
              backgroundColor: '#d3d3d3',
              color: '#333',
            },
            '& .super-app-theme--header-AvailableStatus': {
              backgroundColor: 'violet',
              color: '#333',
            },
          }}
        />
      )}
    </Box>
  );
};

export default DataTable;