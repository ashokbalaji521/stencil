import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Autocomplete, TextField } from "@mui/material";
import { Data } from "../Custom/custom";
import logo from "../Utils/logo.png";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  AppBar,
  Modal,
} from "@mui/material";
import {
  Container,
  Button,
  Typography,
  Box,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Toolbar,
} from "@mui/material";
import OperatorIdOut from "./OperatorIDOut";

function PartCodeForm() {
  const [selectedPartCode, setSelectedPartCode] = useState(null);
  const [clickedID, setClickedID] = useState("");
  const [partCodeData, setPartCodeData] = useState([]);
  const [originalPartCodeData, setOriginalPartCodeData] = useState([]);
  const uniquePartCodeData = [...new Set(partCodeData)];
  const [successAlert, setSuccessAlert] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [selectedStencilId, setSelectedStencilId] = useState(null);
  const [selectedProductName, setSelectedProductName] = useState(null);
  const [Rackno, setRackno] = useState(null);
  const [stencilData, setStencilData] = useState([]);
  const [originalStencilData, setOriginalStencilData] = useState([]);
  const [productData, setProductData] = useState([]);
  const [originalProductData, setOriginalProductData] = useState([]);
  const [isWaitingVisible, setIsWaitingPopupVisible] = useState(false);
  const [checkRackStatus, setCheckRackStatus] = useState(false);
  const [initialRackData, setInitialRackData] = useState("");
  const [currentRackData, setCurrentRackData] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [rackId, setRackId] = useState("");
  const [physicalLoc, setPhysicalLoc] = useState("");
  const [pairedPhysicalLoc, setPairedPhysicalLoc] = useState(null); // Added for paired location
  const [rackNo, setRackNo] = useState("");
  const [wrongPickup, setWrongPickup] = useState(false);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleCancelWaiting = () => {
    setIsWaitingPopupVisible(false);
    setCheckRackStatus(false);
  };

  const handleCloseOperatorModal = () => {
    setOpen(false);
  };

  const resetToOriginalData = () => {
    setPartCodeData([...originalPartCodeData]);
    setStencilData([...originalStencilData]);
    setProductData([...originalProductData]);
    setTableData([]);
    setShowTable(false);
  };

  useEffect(() => {
    let timer;

    if (wrongPickup) {
      timer = setTimeout(() => {
        setWrongPickup(false);
        navigate("/StencilIn");
      }, 5000);
    }

    return () => clearTimeout(timer);
  }, [wrongPickup, navigate]);

  const checkApiResponse = async () => {
    if (!checkRackStatus) return;

    try {
      const response = await axios.post(`${Data.url}getRackStatus`);
      const currentStatus = response.data[rackNo];
      setCurrentRackData(currentStatus);
      
      console.log("Initial rack data:", initialRackData);
      console.log("Current rack data:", currentStatus);
      
      if (initialRackData !== currentStatus) {
        console.log("Rack status changed, checking individual status...");
        
        const statusResponse = await axios.post(`${Data.url}getRackStatusindi`, {
          barcode: inputValue,
        });
        
        if (statusResponse.data.currentStatus === "1") {
          console.log("Stencil successfully removed, status is 1");
          setCheckRackStatus(false);

          axios
            .post(`${Data.url}updateEmptyStencilData`, {
              barcode: inputValue,
            })
            .then((res) => {
              setIsWaitingPopupVisible(false);
              setSuccessAlert(true);
              setShowTable(false);
              setInputValue("");
              setSelectedPartCode(null);
              setSelectedStencilId(null);
              setSelectedProductName(null);
              resetToOriginalData();
            })
            .catch((err) => {
              console.log("Error Emptying Stencil Data", err);
            });
        } else {
          console.log("Wrong pickup detected - status is not 1");
          setCheckRackStatus(false);
          setWrongPickup(true);
          
          axios
            .post(`${Data.url}removeWrongStencil`, { barcode: inputValue })
            .then((res) => {
              console.log("Success removing wrong stencil");
              setSelectedPartCode(null);
              setSelectedStencilId(null);
              setSelectedProductName(null);
              resetToOriginalData();
            })
            .catch((err) => {
              console.log("Error removing wrong stencil", err);
            });
        }
      } else {
        console.log("Rack status unchanged, continuing to poll...");
        setTimeout(checkApiResponse, 2000);
      }
    } catch (error) {
      console.error("Error in checkApiResponse:", error);
      setTimeout(checkApiResponse, 2000);
    }
  };

  useEffect(() => {
    let pollingInterval;
    
    if (checkRackStatus) {
      checkApiResponse();
      pollingInterval = setTimeout(() => {
        console.log("Safety timeout reached - stopping polling");
        setCheckRackStatus(false);
        setIsWaitingPopupVisible(false);
      }, 300000);
    }
    
    return () => {
      clearTimeout(pollingInterval);
    };
  }, [checkRackStatus, initialRackData, rackNo, inputValue]);

  useEffect(() => {
    axios
      .post(`${Data.url}getPartCodes`)
      .then((response) => {
        const cleanedPartCodes = response.data.map((part) => part.PartNumber.trim());
        setPartCodeData(cleanedPartCodes);
        setOriginalPartCodeData(cleanedPartCodes);
      })
      .catch((error) => {
        console.error("Error fetching part codes:", error.response ? error.response.data : error.message);
      });

    axios
      .post(`${Data.url}getallStencilIDData`)
      .then((response) => {
        const cleanedStencilIds = response.data.map((stencil) => stencil.StencilID.trim());
        setStencilData(cleanedStencilIds);
        setOriginalStencilData(cleanedStencilIds);
      })
      .catch((error) => {
        console.error("Error fetching stencil IDs:", error.response ? error.response.data : error.message);
      });

    axios
      .post(`${Data.url}getProductNameData`)
      .then((response) => {
        const cleanedProductNames = response.data.map((product) => product.Product.trim());
        setProductData(cleanedProductNames);
        setOriginalProductData(cleanedProductNames);
      })
      .catch((error) => {
        console.error("Error fetching product names:", error.response ? error.response.data : error.message);
      });
  }, []);

  const handleSelectionChange = () => {
    if (selectedPartCode && selectedStencilId && selectedProductName) {
      axios
        .post(`${Data.url}getSelectedPartCodeData`, {
          partCode: selectedPartCode?.trim(),
          stencilId: selectedStencilId?.trim(),
          product: selectedProductName?.trim(),
        })
        .then((response) => {
          const tableDataWithStencilId = response.data.map((item) => ({
            ...item,
            stencilId: selectedStencilId?.trim(),
          }));
          setTableData(tableDataWithStencilId);
          setShowTable(true);
        })
        .catch((error) => {
          console.error("Error fetching data:", error.response ? error.response.data : error.message);
        });
    }
  };

  const handlePartCodeChange = (event, newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedPartCode(trimmedValue);

    if (trimmedValue) {
      axios
        .post(`${Data.url}getSelectedPartCodeData`, { partCode: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedStencilIds = [...new Set(relevantData.map((item) => item.StencilID.trim()))];
          const relatedProductNames = [...new Set(relevantData.map((item) => item.Product.trim()))];
          setStencilData(relatedStencilIds);
          setProductData(relatedProductNames);
          
          if (selectedStencilId && !relatedStencilIds.includes(selectedStencilId?.trim())) {
            setSelectedStencilId(null);
          }
          if (selectedProductName && !relatedProductNames.includes(selectedProductName?.trim())) {
            setSelectedProductName(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!trimmedValue && !selectedStencilId && !selectedProductName) {
      resetToOriginalData();
    }
  };

  const handleStencilIdChange = (event, newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedStencilId(trimmedValue);

    if (trimmedValue) {
      axios
        .post(`${Data.url}getSelectedPartCodeData`, { stencilId: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedPartNumbers = [...new Set(relevantData.map((item) => item.PartNumber.trim()))];
          const relatedProductNames = [...new Set(relevantData.map((item) => item.Product.trim()))];
          setPartCodeData(relatedPartNumbers);
          setProductData(relatedProductNames);
          
          if (selectedPartCode && !relatedPartNumbers.includes(selectedPartCode?.trim())) {
            setSelectedPartCode(null);
          }
          if (selectedProductName && !relatedProductNames.includes(selectedProductName?.trim())) {
            setSelectedProductName(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!selectedPartCode && !trimmedValue && !selectedProductName) {
      resetToOriginalData();
    }
  };

  const handleProductNameChange = (event, newValue) => {
    const trimmedValue = newValue ? newValue.trim() : null;
    setSelectedProductName(trimmedValue);

    if (trimmedValue) {
      axios
        .post(`${Data.url}getSelectedPartCodeData`, { Product: trimmedValue })
        .then((response) => {
          const relevantData = response.data;
          const relatedPartNumbers = [...new Set(relevantData.map((item) => item.PartNumber.trim()))];
          const relatedStencilIds = [...new Set(relevantData.map((item) => item.StencilID.trim()))];
          setPartCodeData(relatedPartNumbers);
          setStencilData(relatedStencilIds);
          
          if (selectedPartCode && !relatedPartNumbers.includes(selectedPartCode?.trim())) {
            setSelectedPartCode(null);
          }
          if (selectedStencilId && !relatedStencilIds.includes(selectedStencilId?.trim())) {
            setSelectedStencilId(null);
          }
          
          handleSelectionChange();
        })
        .catch((error) => {
          console.error("Error fetching related data:", error.response ? error.response.data : error.message);
        });
    }
    
    if (!selectedPartCode && !selectedStencilId && !trimmedValue) {
      resetToOriginalData();
    }
  };

  const handleSubmit = () => {
    axios
      .post(`${Data.url}getSelectedPartCodeData`, {
        partCode: selectedPartCode?.trim(),
        stencilId: selectedStencilId?.trim(),
        product: selectedProductName?.trim(),
        Rackno: Rackno?.trim(),
      })
      .then((response) => {
        const tableDataWithStencilId = response.data.map((item) => ({
          ...item,
          stencilId: selectedStencilId?.trim(),
        }));
        setTableData(tableDataWithStencilId);
        setShowTable(true);
      })
      .catch((error) => {
        console.error("Error fetching data:", error.response ? error.response.data : error.message);
      });
  };

  const handleCloseAlert = () => {
    setSuccessAlert(false);
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  const handleOutClick = (barcodeID) => {
    setClickedID(barcodeID);
    setOpen(true);
  };

  const handleClose = (barcodeID, inputOperatorValue) => {
    console.log("Input Operator Value:", inputOperatorValue);
    axios
      .post(`${Data.url}operatorid`, {
        barcodeID: barcodeID,
        operator: inputOperatorValue,
        action: "OUT",
      })
      .then((response) => {
        console.log("Operator ID recorded", response.data);
      })
      .catch((error) => {
        console.error("Error recording operator ID:", error);
      });

    setOpen(false);
    console.log("OUT button clicked for Barcode ID:", barcodeID);
    setIsWaitingPopupVisible(true);

    axios
      .post(`${Data.url}getRackStatus`)
      .then((rackStatusRes) => {
        axios
          .post(`${Data.url}getRackNo`, { barcode: barcodeID })
          .then((rackNoRes) => {
            const currentRackNo = rackNoRes.data.Rackno || "";
            setRackNo(currentRackNo);
            setInitialRackData(rackStatusRes.data[currentRackNo]);
            
            axios
              .post(`${Data.url}lightupStencil`, { barcode: barcodeID })
              .then((res) => {
                console.log("Lighted up", res.data);
                setInputValue(res.data.barcode);
                setRackId(res.data.RackID);
                setPhysicalLoc(res.data.physicalLocation);
                setPairedPhysicalLoc(res.data.pairedPhysicalLocation); // Set paired location
                setCheckRackStatus(true);
              })
              .catch((err) => {
                console.error("Error lighting up stencil:", err);
                setIsWaitingPopupVisible(false);
              });
          })
          .catch((err) => {
            console.error("Error fetching Rackno:", err);
            setIsWaitingPopupVisible(false);
          });
      })
      .catch((err) => {
        console.error("Error getting initial rack status:", err);
        setIsWaitingPopupVisible(false);
      });
  };

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar
          disableGutters
          sx={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              height: 40,
            }}
          />
          <Button
            color="inherit"
            onClick={handleHomeClick}
            sx={{ fontWeight: "bold" }}
          >
            Home
          </Button>
        </Toolbar>
      </AppBar>
      <Box
        sx={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          color: "#fff",
        }}
      >
        <Dialog
          open={isWaitingVisible}
          onClose={handleCancelWaiting}
          aria-labelledby="alert-dialog-title-waiting"
          aria-describedby="alert-dialog-description-waiting"
          PaperProps={{
            style: {
              backgroundColor: "Yellow",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-waiting">
            {rackNo === "Rack-3" || rackNo === "Rack-4" && pairedPhysicalLoc
              ? `Please Pick Stencil from  ${rackNo} Locations ${physicalLoc} and ${pairedPhysicalLoc}`
              : `Please Pick Stencil from  ${rackNo} Location ${physicalLoc}`}
          </DialogTitle>
          <DialogActions>
            <Button onClick={handleCancelWaiting} color="primary">
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
        <Dialog
          open={wrongPickup}
          aria-labelledby="alert-dialog-title-wrong-pickup"
          aria-describedby="alert-dialog-description-wrong-pickup"
          PaperProps={{
            style: {
              backgroundColor: "Red",
            },
          }}
        >
          <DialogTitle id="alert-dialog-title-wrong-pickup">
            {"Wrong Stencil Picked!!!"}
          </DialogTitle>
        </Dialog>
        {successAlert && (
          <Alert
            variant="filled"
            severity="success"
            action={
              <Button color="inherit" size="small" onClick={handleCloseAlert}>
                Close
              </Button>
            }
          >
            Stencil Out Process Success!
          </Alert>
        )}
        <Container
          sx={{
            backgroundColor: "rgba(255, 255, 255, 0.2)",
            borderRadius: "12px",
            padding: "40px",
            boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
            backdropFilter: "blur(10px)",
            width: "65%",
            maxWidth: "400px",
            marginBottom: "40px",
          }}
        >
          <Typography
            variant="h4"
            component="h1"
            sx={{
              marginBottom: "20px",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            STENCIL OUT
          </Typography>
          <Autocomplete
            options={stencilData}
            value={selectedStencilId}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={handleStencilIdChange}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Stencil ID"
                onChange={(e) => {
                  params.inputProps.onChange({
                    target: { value: e.target.value.trim() }
                  });
                }}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />
          <Autocomplete
            options={uniquePartCodeData}
            value={selectedPartCode}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={handlePartCodeChange}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Part Code"
                onChange={(e) => {
                  params.inputProps.onChange({
                    target: { value: e.target.value.trim() }
                  });
                }}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white", backgroundColor: "transparent" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />
          <Autocomplete
            options={productData}
            value={selectedProductName}
            getOptionLabel={(option) => (option ? option : "")}
            onChange={handleProductNameChange}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Product Name"
                onChange={(e) => {
                  params.inputProps.onChange({
                    target: { value: e.target.value.trim() }
                  });
                }}
                sx={{
                  width: "100%",
                  marginBottom: "20px",
                  "& .MuiInputBase-root": { color: "white" },
                  "& .MuiInputLabel-root": { color: "white" },
                }}
                InputLabelProps={{
                  style: { color: "white" },
                }}
              />
            )}
            disableClearable={false}
          />
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!selectedPartCode || !selectedStencilId || !selectedProductName}
            sx={{
              backgroundColor: "#4CAF50",
              "&:hover": {
                backgroundColor: "#45a049",
              },
              padding: "10px 0",
              fontSize: "16px",
              fontWeight: "bold",
              width: "100%",
            }}
          >
            Submit
          </Button>
        </Container>
        {showTable && (
          <TableContainer
            component={Paper}
            sx={{ width: "80%", marginTop: "20px" }}
          >
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Product
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Side
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Part Number
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Barcode ID
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Stencil ID
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Rack No
                  </TableCell>
                  <TableCell
                    sx={{
                      backgroundColor: "#333",
                      color: "#fff",
                      fontWeight: "bold",
                      fontSize: "16px",
                      padding: "12px",
                    }}
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {tableData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>{row.Product}</TableCell>
                    <TableCell>{row.Side}</TableCell>
                    <TableCell>{row.PartNumber}</TableCell>
                    <TableCell>{row.BarcodeID.trim()}</TableCell>
                    <TableCell>{row.StencilID}</TableCell>
                    <TableCell>{row.Rackno}</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => handleOutClick(row.BarcodeID)}
                      >
                        OUT
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleCloseOperatorModal}
      >
        <OperatorIdOut
          val={clickedID}
          onclose={(Stencil, inputValue) => handleClose(Stencil, inputValue)}
        />
      </Modal>
    </div>
  );
}

export default PartCodeForm;