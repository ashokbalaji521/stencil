import React, { useContext } from "react";
import { ThememmmContext } from "../App";
function Trial(props) {
  console.log("props", props);
  let name = useContext(ThememmmContext);
  console.log("name", name);
  const array = [1, 2, 3, 4, 5, 5, 5];

  let result = array.reduce((acc, val) => acc + val, 0);

  const cons = (array) => {
    return array.filter((item, index) => array.indexOf(item) === index);
  };
  setTimeout(() => console.log(cons(array)), 100);
  return (
    <div>
      {array.map((item) => (
        <div>{item * 2}</div>
      ))}
    </div>
  );
}

export default Trial;
