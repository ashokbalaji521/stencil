// Updated StencilIn.jsx (No major changes needed here, but ensuring consistency)
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../Utils/logo.png";
import { Alert, Container, TextField, Button, Typography, Box, Modal, CircularProgress, Toolbar, AppBar, Grid } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import axios from "axios";
import { format, parseISO } from "date-fns";
import { Data } from "../Custom/custom";
import OperatorId from "./OperatorID";

function StencilIn() {
  const [inputValue, setInputValue] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);
  const [changedRackBit, setChangedRackBit] = useState("");
  const [open, setOpen] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [isWaitingVisible, setIsWaitingPopupVisible] = useState(false);
  const [successAlert, setSuccessAlert] = useState(false);
  const [operatorId, setOperatorId] = useState("");
  const [showOperatorDiv, setShowOperatorDiv] = useState(false);
  const [abortAlert, setAbortAlert] = useState(false);
  const [maintenanceData, setMaintenanceData] = useState([]);
  const [editableRecords, setEditableRecords] = useState([]);
  const [showMaintenanceData, setShowMaintenanceData] = useState(false);
  const [showEditableRecords, setShowEditableRecords] = useState(false);
  const [isFetchingAll, setIsFetchingAll] = useState(false);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const navigate = useNavigate();

  const handleConfirm = () => {
    setIsPopupVisible(false);
    setLoading(false);
    handleOpen();
  };

  const handleCloseAlert = () => {
    setSuccessAlert(false);
  };

  const handleCloseop = () => {
    setOpen(false);
  };

  const handleOperatorIdChange = (event) => {
    setOperatorId(event.target.value);
  };

  const handleCancel = () => {
    setIsPopupVisible(false);
    setShowOperatorDiv(true);
  };

  const handleCancelWaiting = () => {
    setIsWaitingPopupVisible(false);
  };

  const handleCloseOperatorDiv = () => {
    setShowOperatorDiv(false);
    setOperatorId("");
  };

  const handleClose = (Stencil, inputValue) => {
    axios
      .post(`${Data.url}operatorid`, {
        stencilid: Stencil,
        operator: inputValue,
        action: "IN",
      })
      .then((response) => {
        console.log("Operator ID submitted successfully");
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
    setOpen(false);
    setIsPolling(true);
    setIsWaitingPopupVisible(true);
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleCloseAbortAlert = () => {
    setAbortAlert(false);
  };

  const checkApiResponse = async () => {
    try {
      const response = await axios.post(`${Data.url}getRackStatus`);
      if (response.data.currentStatus !== data) {
        setIsPolling(false);
        axios
          .post(`${Data.url}updateStencilStatus`, {
            key1: inputValue,
          })
          .then((postResponse) => {
            setChangedRackBit(postResponse.data);
            axios
              .post(`${Data.url}updateRackIDStencilTable`, {
                new: response.data.currentStatus,
                old: data,
                barcode: inputValue,
              })
              .then((res) => {
                setIsWaitingPopupVisible(false);
                setSuccessAlert(true);
                setInputValue("");
                inputRef.current.focus();
              })
              .catch((err) => {
                console.error("Error updating rack and led:", err);
              });
          })
          .catch((error) => {
            console.error("Error in post request:", error);
          });
      } else {
        setTimeout(checkApiResponse, 3000);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setTimeout(checkApiResponse, 3000);
    }
  };

  useEffect(() => {
    if (isPolling) {
      checkApiResponse();
    }
  }, [isPolling]);

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSubmitOperatorId = () => {
    if (operatorId) {
      axios
        .post(`${Data.url}abortUpdate`, { operator: operatorId })
        .then((response) => {
          setOperatorId("");
          setAbortAlert(true);
          setInputValue("");
        })
        .catch((error) => {
          console.error("Error posting user ID:", error);
          setOperatorId("");
        });
    } else {
      alert("Please enter a user ID.");
    }
    setShowOperatorDiv(false);
  };

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const formatDateTime = (dateString) => {
    try {
      if (!dateString) return { date: "", time: "" };
      const date = parseISO(dateString);
      return {
        date: format(date, "dd/MM/yyyy"),
        time: format(date, "HH:mm:ss"),
      };
    } catch (error) {
      console.error("Error formatting date:", error);
      return { date: "", time: "" };
    }
  };

  const fetchMaintenanceData = async () => {
    setLoading(true);
    try {
      const res = await axios.post(`${Data.url}getStencilDataByBarcodeID?BarcodeId=${encodeURIComponent(inputValue.trim())}`);
      const item = res.data[0];
      if (item) {
        const { date, time } = formatDateTime(item.Maintenance_updated_datetime);

        setMaintenanceData([{
          Product: item.Product,
          BarcodeID: item.BarcodeID,
          PartNumber: item.PartNumber,
          Side: item.Side,
          StencilId: item.StencilID,
          StencilTension: item.StencilTension,
             operatorid: item.operatorid,
          StencilThickness: item.StencilThickness,
          Remarks: item.Remarks,
        
          Maintenance_updated_datetime: date,
          Maintenance_updated_time: time,
        }]);
        setShowMaintenanceData(true);
        setShowEditableRecords(false);
      } else {
        setMaintenanceData([]);
        setShowMaintenanceData(true);
        alert("No data found for the provided Barcode ID.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("Error fetching data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const fetchAllEditableRecords = async () => {
    setLoading(true);
    setIsFetchingAll(true);
    try {
      let url = `${Data.url}getEditableStencilRecords`;
      const params = new URLSearchParams();
      if (fromDate) params.append('fromDate', fromDate);
      if (toDate) params.append('toDate', toDate);
      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const res = await axios.post(url);
      const items = res.data.data || res.data;
      if (items && items.length > 0) {
        setEditableRecords(items.map(item => {
          const { date, time } = formatDateTime(item.Maintenance_updated_datetime);
          return {
            id: `${item.BarcodeID}_${item.Maintenance_updated_datetime || new Date().toISOString()}`,
            SNO: item.SNO,
            Product: item.Product,
            BarcodeID: item.BarcodeID,
            PartNumber: item.PartNumber,
            Side: item.Side,
            StencilId: item.StencilID,
            StencilTension: item.StencilTension,
          
            StencilThickness: item.StencilThickness,
            Remarks: item.Remarks,
              operatorid: item.operatorid,
            Maintenance_updated_datetime: date,
            Maintenance_updated_time: time,
          };
        }));
        setShowEditableRecords(true);
        setShowMaintenanceData(false);
      } else {
        setEditableRecords([]);
        setShowEditableRecords(true);
        alert("No editable records found.");
      }
    } catch (error) {
      console.error("Error fetching all editable records:", error);
      alert("Error fetching all editable records. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (inputValue) {
      try {
        const response = await axios.post(
          `${Data.url}getStencilDataByBarcodeIDformaintain?BarcodeId=${encodeURIComponent(inputValue.trim())}`
        );
        const stencilData = response.data[0];
        if (stencilData) {
          const stencilTensionsArray = stencilData.StencilTension
            ? stencilData.StencilTension.split(",").map((t) => t.trim())
            : Array(5).fill("");
          navigate("/AvailableStencilRegistration", {
            state: { editData: { ...stencilData, stencilTensions: stencilTensionsArray } },
          });
        } else {
          alert("No data found for the provided Barcode ID.");
        }
      } catch (error) {
        console.error("Error fetching stencil data:", error);
        alert("Error fetching data. Please try again.");
      }
    } else {
      alert("Please scan a Barcode ID.");
    }
  };

  const handleViewAllEditableRecords = () => {
    fetchAllEditableRecords();
  };

  const handleApplyFilters = () => {
    fetchAllEditableRecords();
  };

const handleDownloadCSV = () => {
  if (editableRecords.length === 0) {
    alert("No data to download");
    return;
  }

  const headers = [
    "SNO",
    "Product",
    "BarcodeID",
    "PartNumber",
    "Side",
    "StencilId",
    "StencilTension",
    "PhysicalLocation",
    "StencilThickness",
    "Remarks",
    "Rackno",
    "operatorid",
    "Maintenance Date",
    "Maintenance Time",
  ];

  const csvContent = [
    headers.join(","),
    ...editableRecords.map((row) => [
      row.SNO || "",
      `"${row.Product || ""}"`,
      `"${row.BarcodeID || ""}"`,
      `"${row.PartNumber || ""}"`,
      `"${row.Side || ""}"`,
      `"${row.StencilId || ""}"`,
      `"${row.StencilTension || ""}"`,
      `"${row.PhysicalLocation || ""}"`,
      `"${row.StencilThickness || ""}"`,
      `"${row.Remarks || ""}"`,
      `"${row.Rackno || ""}"`,
      `"${row.operatorid || ""}"`,
      `"${row.Maintenance_updated_datetime || ""}"`, // Formatted date (dd/MM/yyyy)
      `"${row.Maintenance_updated_time || ""}"`, // Formatted time (HH:mm:ss)
    ].join(",")),
  ].join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", `editable_stencil_records_${format(new Date(), "yyyy-MM-dd_HH-mm-ss")}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

  const handleBackToMain = () => {
    setShowEditableRecords(false);
    setShowMaintenanceData(false);
    setIsFetchingAll(false);
    setEditableRecords([]);
    setMaintenanceData([]);
    setFromDate("");
    setToDate("");
  };

  const handleEdit = async (params) => {
    try {
      const response = await axios.post(
        `${Data.url}getStencilDataByBarcodeIDformaintain?BarcodeId=${encodeURIComponent(params.row.BarcodeID)}`
      );
      const stencilData = response.data[0];
      const stencilTensionsArray = stencilData.StencilTension
        ? stencilData.StencilTension.split(",").map((t) => t.trim())
        : Array(5).fill("");

      navigate("/AvailableStencilRegistration", {
        state: { editData: { ...stencilData, stencilTensions: stencilTensionsArray } },
      });
    } catch (error) {
      console.error("Error fetching stencil data:", error);
    }
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  const columns = [
    { field: "Product", headerName: "Product", width: 200, headerClassName: "super-app-theme--header" },
    { field: "StencilId", headerName: "Stencil ID", width: 210, headerClassName: "super-app-theme--header" },
    { field: "Side", headerName: "Side", width: 110, headerClassName: "super-app-theme--header" },
    { field: "PartNumber", headerName: "Part Number", width: 150, headerClassName: "super-app-theme--header" },

    { field: "StencilThickness", headerName: "Stencil Thickness", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StencilTension", headerName: "Stencil Tension", width: 180, headerClassName: "super-app-theme--header" },
    { field: "Remarks", headerName: "Remarks", width: 150, headerClassName: "super-app-theme--header" },

    {
      field: "Maintenance_updated_datetime",
      headerName: "Maintenance Date",
      width: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => params.value || "N/A"
    },
    {
      field: "Maintenance_updated_time",
      headerName: "Maintenance Time",
      width: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => params.value || "N/A"
    },
    { field: "BarcodeID", headerName: "BarCode ID", width: 150, headerClassName: "super-app-theme--header" },
    { field: "operatorid", headerName: "operatorid", width: 150, headerClassName: "super-app-theme--header" },
   
  ];

  const editableColumns = [
    { field: "Product", headerName: "Product", width: 200, headerClassName: "super-app-theme--header" },
    { field: "StencilId", headerName: "Stencil ID", width: 210, headerClassName: "super-app-theme--header" },
    { field: "Side", headerName: "Side", width: 110, headerClassName: "super-app-theme--header" },
    { field: "PartNumber", headerName: "Part Number", width: 150, headerClassName: "super-app-theme--header" },

    { field: "StencilThickness", headerName: "Stencil Thickness", width: 150, headerClassName: "super-app-theme--header" },
    { field: "StencilTension", headerName: "Stencil Tension", width: 180, headerClassName: "super-app-theme--header" },
    { field: "Remarks", headerName: "Remarks", width: 150, headerClassName: "super-app-theme--header" },
 
    {
      field: "Maintenance_updated_datetime",
      headerName: "Maintenance Date",
      width: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => params.value || "N/A"
    },
    {
      field: "Maintenance_updated_time",
      headerName: "Maintenance Time",
      width: 150,
      headerClassName: "super-app-theme--header",
      renderCell: (params) => params.value || "N/A"
    },
    { field: "BarcodeID", headerName: "BarCode ID", width: 150, headerClassName: "super-app-theme--header" },
    
    { field: "operatorid", headerName: "operatorid", width: 150, headerClassName: "super-app-theme--header" },
  
  ];

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar sx={{ background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)" }}>
          <img src={logo} alt="Logo" style={{ height: 40 }} />
          <Button color="inherit" onClick={handleHomeClick} sx={{ fontWeight: "bold" }}>
            Home
          </Button>
        </Toolbar>
      </AppBar>

      {!showMaintenanceData && !showEditableRecords ? (
        <Box
          sx={{
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
            color: "#fff",
          }}
        >
          <Container
            sx={{
              backgroundColor: "rgba(255, 255, 255, 0.2)",
              borderRadius: "12px",
              padding: "40px",
              boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
              backdropFilter: "blur(10px)",
              width: "65%",
              maxWidth: "400px",
            }}
          >
            <Typography
              variant="h4"
              component="h1"
              sx={{
                marginBottom: "20px",
                textAlign: "center",
                fontWeight: "bold",
              }}
            >
              SCAN BARCODE ID
            </Typography>

            <TextField
              placeholder="Scan Barcode ID"
              value={inputValue}
              onChange={handleInputChange}
              inputRef={inputRef}
              fullWidth
              InputProps={{
                style: {
                  color: "white",
                  fontSize: "20px",
                  borderRadius: "4px",
                  backgroundColor: "transparent",
                  border: "1px solid white",
                },
              }}
            />

            <Box sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 2 }}>
              <Button
                variant="contained"
                onClick={handleSubmit}
                sx={{
                  backgroundColor: "#1e3c72",
                  "&:hover": { backgroundColor: "#1e3c72" },
                  padding: "10px 0",
                  fontSize: "16px",
                  fontWeight: "bold",
                }}
              >
                STENCIL MAINTAINANCE
              </Button>
              <Button
                variant="contained"
                onClick={handleViewAllEditableRecords}
                sx={{
                  backgroundColor: "#1e3c72",
                  "&:hover": { backgroundColor: "#1e3c72" },
                  padding: "10px 0",
                  fontSize: "16px",
                  fontWeight: "bold",
                }}
              >
                MAINTAINANCE HISORY
              </Button>
            </Box>
          </Container>
        </Box>
      ) : showMaintenanceData ? (
        <Box sx={{ padding: 3 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
            <Typography variant="h4" component="h1" sx={{ fontWeight: "bold" }}>
              Data for Barcode ID: {inputValue}
            </Typography>
            <Button
              variant="outlined"
              onClick={handleBackToMain}
              sx={{
                borderColor: "#1e3c72",
                color: "#1e3c72",
                "&:hover": { backgroundColor: "#1e3c72", color: "white" }
              }}
            >
              Back
            </Button>
          </Box>
          <Box
            sx={{
              height: 400,
              width: "100%",
              overflow: "hidden",
              "& .MuiDataGrid-cell": { borderRight: "1px solid #ddd" },
              "& .super-app-theme--header": { backgroundColor: "#f0f8ff", color: "#333" },
            }}
          >
            {loading ? (
              <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%" }}>
                <CircularProgress />
              </Box>
            ) : (
              <DataGrid
                rows={maintenanceData}
                columns={columns}
                getRowId={(row) => row.BarcodeID}
                autoHeight
                disableSelectionOnClick
                components={{ Toolbar: GridToolbar }}
                sx={{ "& .MuiDataGrid-cell": { backgroundColor: "white" } }}
              />
            )}
          </Box>
        </Box>
      ) : (
        <Box sx={{ padding: 3 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
            <Typography variant="h4" component="h1" sx={{ fontWeight: "bold" }}>
              All Editable Records
            </Typography>
            <Button
              variant="outlined"
              onClick={handleBackToMain}
              sx={{
                borderColor: "#1e3c72",
                color: "#1e3c72",
                "&:hover": { backgroundColor: "#1e3c72", color: "white" }
              }}
            >
              Back
            </Button>
          </Box>

          <Box sx={{ mb: 3, p: 2, border: "1px solid #ddd", borderRadius: 2, backgroundColor: "#f9f9f9" }}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
              Filter by Date Range
            </Typography>
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} sm={2.5}>
                <TextField
                  label="From Date"
                  type="datetime-local"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  fullWidth
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <TextField
                  label="To Date"
                  type="datetime-local"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  fullWidth
                  size="small"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={1.5}>
                <Button
                  variant="contained"
                  onClick={handleApplyFilters}
                  fullWidth
                  size="small"
                  sx={{
                    backgroundColor: "#1e3c72",
                    "&:hover": { backgroundColor: "#2a5298" },
                    height: "40px",
                    fontSize: "12px",
                  }}
                >
                  Apply
                </Button>
              </Grid>
              <Grid item xs={12} sm={1.5}>
                <Button
                  variant="contained"
                  onClick={handleDownloadCSV}
                  fullWidth
                  size="small"
                  sx={{
                    backgroundColor: "#28a745",
                    "&:hover": { backgroundColor: "#218838" },
                    height: "40px",
                    fontSize: "12px",
                  }}
                >
                  Download
                </Button>
              </Grid>
            </Grid>
          </Box>

          <Box
            sx={{
              height: 400,
              width: "100%",
              overflow: "hidden",
              "& .MuiDataGrid-cell": { borderRight: "1px solid #ddd" },
              "& .super-app-theme--header": { backgroundColor: "#f0f8ff", color: "#333" },
            }}
          >
            {loading ? (
              <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%" }}>
                <CircularProgress />
              </Box>
            ) : (
              <DataGrid
                rows={editableRecords}
                columns={editableColumns}
                getRowId={(row) => row.id}
                autoHeight
                disableSelectionOnClick
                components={{ Toolbar: GridToolbar }}
                sx={{ "& .MuiDataGrid-cell": { backgroundColor: "white" } }}
              />
            )}
          </Box>
        </Box>
      )}

      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleCloseop}
      >
        <OperatorId
          val={inputValue}
          onclose={(Stencil, inputValue) => handleClose(Stencil, inputValue)}
        />
      </Modal>

      {successAlert && (
        <Alert severity="success" onClose={handleCloseAlert}>
          Operation completed successfully!
        </Alert>
      )}
      {abortAlert && (
        <Alert severity="warning" onClose={handleCloseAbortAlert}>
          Operation aborted!
        </Alert>
      )}
    </div>
  );
}

export default StencilIn;