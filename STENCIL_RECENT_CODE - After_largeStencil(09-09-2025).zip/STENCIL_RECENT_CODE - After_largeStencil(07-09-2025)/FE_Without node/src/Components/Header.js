import React from "react";
import { AppBar, Toolbar, Typography, Button, Container } from "@mui/material";
import { useNavigate } from "react-router-dom";

const Header = (data) => {
  const navigate = useNavigate();
  const val = data.data;
  const handleHomeClick = () => {
    navigate("/Homepage"); // Navigate to the homepage
  };

  return (
    <AppBar
      position="static"
      sx={{ backgroundColor: "#1976d2", marginBottom: "1rem" }}
    >
      <Container maxWidth="lg">
        <Toolbar disableGutters>
          <Typography
            variant="h4"
            component="div"
            sx={{ flexGrow: 1, fontWeight: "bold" }}
          >
            {val}
          </Typography>
          <Button
            color="inherit"
            onClick={handleHomeClick} // Use handleHomeClick to navigate
            sx={{ fontWeight: "bold" }}
          >
            Home
          </Button>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;
