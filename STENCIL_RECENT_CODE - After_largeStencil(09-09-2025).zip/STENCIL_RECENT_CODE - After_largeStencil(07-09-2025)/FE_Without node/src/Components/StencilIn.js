import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../Utils/logo.png";
import { Alert, Button, Container, TextField, Typography, Box, Dialog, DialogTitle, DialogActions, Toolbar,DialogContent, AppBar, Modal } from "@mui/material";
import axios from "axios";
import { Data } from "../Custom/custom";
import OperatorId from "./OperatorID";

function StencilIn() {
  const [inputValue, setInputValue] = useState("");
  const [allRackData, setAllRackData] = useState({});
  const [previousRackData, setPreviousRackData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);
  const [changedRackInfo, setChangedRackInfo] = useState(null);
  const [open, setOpen] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [isWaitingVisible, setIsWaitingPopupVisible] = useState(false);
  const [successAlert, setSuccessAlert] = useState(false);
  const [operatorId, setOperatorId] = useState("");
  const [showOperatorDiv, setShowOperatorDiv] = useState(false);
  const [abortAlert, setAbortAlert] = useState(false);
  const [physicalLocation, setPhysicalLocation] = useState("");
  const [pairedPhysicalLocation, setPairedPhysicalLocation] = useState(null); // New state for paired location
  const typingTimeoutRef = useRef(null);
  const submitTimeoutRef = useRef(null);

  const navigate = useNavigate();

  // Focus input field on component mount
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  const handleConfirm = () => {
    console.log("Yes clicked");
    setIsPopupVisible(false);
    setLoading(false);
    handleOpen();
  };

  const handleCloseAlert = () => {
    setSuccessAlert(false);
  };

  const handleCloseop = () => {
    setOpen(false);
  };

  const handleOperatorIdChange = (event) => {
    const value = event.target.value;
    setOperatorId(value);

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      setOperatorId("");
    }, 1000);
  };

  const handleCancel = () => {
    console.log("No clicked");
    setIsPopupVisible(false);
    setShowOperatorDiv(true);
  };

  const handleCancelWaiting = () => {
    setIsWaitingPopupVisible(false);
  };

  const handleCloseOperatorDiv = () => {
    setShowOperatorDiv(false);
    setOperatorId("");
  };

  const handleClose = (barcodeID, inputValue) => {
    console.log("Input Value:", inputValue);
    axios
      .post(`${Data.url}operatorid`, {
        barcodeID: barcodeID,
        operator: inputValue,
        action: "IN",
      })
      .then((response) => {
        console.log("in here");
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
    setOpen(false);
    setIsPolling(true);
    setIsWaitingPopupVisible(true);
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleCloseAbortAlert = () => {
    setAbortAlert(false);
  };

  // Function to compare rack data and detect changes
  const findChangedRack = (newData, oldData) => {
    if (!oldData || Object.keys(oldData).length === 0) {
      return null;
    }
    
    for (const rackId in newData) {
      if (oldData[rackId] && newData[rackId] !== oldData[rackId]) {
        return {
          rackId,
          old: oldData[rackId],
          new: newData[rackId]
        };
      }
    }
    
    return null;
  };

  const checkApiResponse = async () => {
    try {
      const response = await axios.post(`${Data.url}getRackStatus`);
      const newRackData = response.data;
      
      const changedRack = findChangedRack(newRackData, previousRackData);
      
      if (changedRack) {
        console.log("Rack changed:", changedRack);
        setChangedRackInfo(changedRack);
        setIsPolling(false);
        
        axios
          .post(`${Data.url}updateStencilStatus`, {
            key1: inputValue,
            rackNo: changedRack.rackId
          })
          .then((postResponse) => {
            console.log("Post request successful:", postResponse.data);
            
            axios
              .post(`${Data.url}updateRackIDStencilTable`, {
                changedRacks: changedRack,
                barcode: inputValue,
              })
              .then((res) => {
                console.log("updateRackIDStencilTable response:", res.data);
                // Store both physical location and paired physical location
                if (res.data) {
                  setPhysicalLocation(res.data.physicalLocation || "");
                  setPairedPhysicalLocation(res.data.pairedPhysicalLocation || null); // Store paired location
                }
                setIsWaitingPopupVisible(false);
                setSuccessAlert(true);
                setInputValue("");
                inputRef.current.focus();
              })
              .catch((err) => {
                console.log("Error updating rack and led:", err);
              });
          })
          .catch((error) => {
            console.error("Error in post request:", error);
          });
      } else {
        console.log("No racks changed, polling again...");
        setPreviousRackData(newRackData);
        setTimeout(checkApiResponse, 3000);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setTimeout(checkApiResponse, 3000);
    }
  };

  useEffect(() => {
    if (isPolling) {
      checkApiResponse();
    }
  }, [isPolling]);

  const handleInputChange = (event) => {
    const value = event.target.value;
    setInputValue(value);

    if (submitTimeoutRef.current) {
      clearTimeout(submitTimeoutRef.current);
    }
  };

  useEffect(() => {
    if (inputValue) {
      const stencilPattern = /^[A-Za-z]{2}\d{6}$/;
      if (stencilPattern.test(inputValue)) {
        submitTimeoutRef.current = setTimeout(() => {
          handleSubmit();
        }, 500);
      }
    }
    
    return () => {
      if (submitTimeoutRef.current) {
        clearTimeout(submitTimeoutRef.current);
      }
    };
  }, [inputValue]);

  const handleSubmitOperatorId = () => {
    const value = operatorId;
    const operatorPattern = /^\d{8}$/;
    if (operatorPattern.test(value)) {
      if (value) {
        axios
          .post(`${Data.url}abortUpdate`, { operator: value })
          .then((response) => {
            console.log("API Response:", response.data);
            setOperatorId("");
            setAbortAlert(true);
            setInputValue("");
          })
          .catch((error) => {
            console.error("Error posting user ID:", error);
            setOperatorId("");
          });
        setShowOperatorDiv(false);
        console.log("Submit Clicked");
      } else {
        alert("Please enter a user ID.");
      }
    }
  };

  const handleSubmit = () => {
    console.log("Input Value:", inputValue);
    axios
      .post(`${Data.url}getRackStatus`, { stencilId: inputValue })
      .then((response) => {
        console.log("response", response);
        if (response.status === 204) {
          console.log("Response is zero");
          window.alert(response.data || "Not registered");
        } else {
          console.log("Starting loop");
          setPreviousRackData(response.data);
          setAllRackData(response.data);
          handleOpen();
        }
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  };

  const handleHomeClick = () => {
    navigate("/Homepage");
  };

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: "#1e3c72" }}>
        <Toolbar
          disableGutters
          sx={{
            background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              height: 40,
            }}
          />
          <Button
            color="inherit"
            onClick={handleHomeClick}
            sx={{ fontWeight: "bold" }}
          >
            Home
          </Button>
        </Toolbar>
      </AppBar>
      <Dialog
        open={isPopupVisible}
        onClose={handleCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {"Proceed to Load Stencil?"}
        </DialogTitle>
        <DialogActions>
          <Button onClick={handleCancel} color="primary">
            No
          </Button>
          <Button onClick={handleConfirm} color="primary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={isWaitingVisible}
        onClose={handleCancelWaiting}
        aria-labelledby="alert-dialog-title-waiting"
        aria-describedby="alert-dialog-description-waiting"
      >
        <DialogTitle id="alert-dialog-title-waiting">
          {"Waiting for insert stencil..."}
        </DialogTitle>
      </Dialog>
  {successAlert && (
  <Alert
    variant="filled"
    severity="success"
    action={
      <Button color="inherit" size="small" onClick={handleCloseAlert}>
        Close
      </Button>
    }
  >
    {changedRackInfo?.rackId === "Rack-4" && pairedPhysicalLocation
      ? `Stencil Loaded Successfully in ${changedRackInfo?.rackId} at Slots ${
          physicalLocation < pairedPhysicalLocation
            ? `${physicalLocation} and ${pairedPhysicalLocation}`
            : `${pairedPhysicalLocation} and ${physicalLocation}`
        }`
      : `Stencil Loaded Successfully in ${changedRackInfo?.rackId || "rack"} at Slot ${physicalLocation}`}
  </Alert>
)}
      {abortAlert && (
        <Alert
          severity="error"
          action={
            <Button
              color="inherit"
              size="small"
              onClick={handleCloseAbortAlert}
            >
              Close
            </Button>
          }
        >
          Stencil Loaded Aborted.
        </Alert>
      )}

      <Dialog open={showOperatorDiv} onClose={handleCloseOperatorDiv}>
        <DialogTitle>Enter Operator ID</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="User ID"
            type="text"
            fullWidth
            value={operatorId}
            onChange={handleOperatorIdChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSubmitOperatorId();
              }
            }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseOperatorDiv} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmitOperatorId} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
      <Box
        sx={{
          height: "calc(100vh - 64px)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          background: "linear-gradient(135deg, #1e3c72 30%, #2a5298 90%)",
          color: "#fff",
        }}
      >
        <Container
          sx={{
            backgroundColor: "rgba(255, 255, 255, 0.2)",
            borderRadius: "12px",
            padding: "40px",
            boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
            backdropFilter: "blur(10px)",
            width: "65%",
            maxWidth: "400px",
          }}
        >
          <Typography
            variant="h4"
            component="h1"
            sx={{
              marginBottom: "20px",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            STENCIL IN
          </Typography>
          <input
            ref={inputRef}
            placeholder="Enter Barcode ID"
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSubmit();
              }
            }}
            style={{
              color: "white",
              fontSize: "20px",
              width: "97%",
              padding: "10px",
              border: "1px solid white",
              borderRadius: "4px",
              backgroundColor: "transparent",
              outline: "none",
              marginBottom: "10px",
            }}
          />

          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{
              backgroundColor: "#4CAF50",
              "&:hover": {
                backgroundColor: "#45a049",
              },
              padding: "10px 0",
              fontSize: "16px",
              fontWeight: "bold",
              width: "100%",
            }}
          >
            Submit
          </Button>
        </Container>
      </Box>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleCloseop}
      >
        <OperatorId
          val={inputValue}
          onclose={(Stencil, inputValue) => handleClose(Stencil, inputValue)}
        />
      </Modal>
    </div>
  );
}

export default StencilIn;