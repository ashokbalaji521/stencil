import React, { useState, useEffect } from "react";
import {
  Container,
  CircularProgress,
  Button,
  IconButton,
  Box,
  Typography,
} from "@mui/material";
import Header from "./Header";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DesktopDateTimePicker } from "@mui/x-date-pickers/DesktopDateTimePicker";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import axios from "axios";
import * as XLSX from "xlsx";
import DownloadIcon from "@mui/icons-material/Download";
import { Data } from "../Custom/custom";
import { formatISO } from "date-fns";

const NonCompliant = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  useEffect(() => {
    // Fetch initial data on page load with empty dates
    fetchData(null, null);
  }, []);

  const fetchData = (fromDate, toDate) => {
    setLoading(true);
    axios
      .post(`${Data.url}getNoncompliantdatetimefilter`, {
        fromDate: fromDate ? formatISO(fromDate) : "",
        toDate: toDate ? formatISO(toDate) : "",
      })
      .then((res) => {
        const extractedData = res.data.map((item) => ({
         // TimeColumn: new Date(item.TimeColumn).toLocaleString(),
          PhysicalLocation: item["Physical Location"],
          RackNo: item.RackNo,
        }));
        setData(extractedData);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  };

  const handleSearch = () => {
    fetchData(fromDate, toDate);
  };

  const exportToExcel = () => {
    if (data.length === 0) {
      alert("No data available to export.");
      return;
    }
    const ws = XLSX.utils.json_to_sheet(
      data.map((item) => ({
      //  TimeColumn: item.TimeColumn,
        PhysicalLocation: item.PhysicalLocation,
        RackNo: item.RackNo,
      }))
    );
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "NonCompliantData");
    XLSX.writeFile(wb, "NonCompliantData.xlsx");
  };

  const listStyle = {
    listStyleType: "none",
    padding: 0,
    margin: 0,
  };

  const listItemStyle = {
    padding: "10px",
    margin: "10px 0",
    borderRadius: "8px",
    backgroundColor: "#f5f5f5",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  };

  const timeBoxStyle = {
    flex: 1,
    marginRight: "10px",
    padding: "10px",
    borderRadius: "4px",
    backgroundColor: "#e0f7fa",
    color: "#00695c",
    fontFamily: "Arial, sans-serif",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    textAlign: "center",
  };

  const locationBoxStyle = {
    flex: 1,
    marginRight: "10px",
    padding: "10px",
    borderRadius: "4px",
    backgroundColor: "#fbe9e7",
    color: "#d84315",
    fontFamily: "Arial, sans-serif",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    textAlign: "center",
  };

  const rackBoxStyle = {
    flex: 1,
    padding: "10px",
    borderRadius: "4px",
    backgroundColor: "#f3e5f5",
    color: "#7b1fa2",
    fontFamily: "Arial, sans-serif",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    textAlign: "center",
  };

  const paginationStyle = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: "20px",
  };

  const goToNextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const goToPreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const totalPages = Math.ceil(data.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = data.slice(startIndex, endIndex);

  return (
    <div>
      <Header data={"Noncompliant Stencils"} />
      <Container
        style={{
          margin: "20px auto",
          padding: "20px",
          maxWidth: "600px",
          border: "1px solid #ddd",
          borderRadius: "8px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
          backgroundColor: "#fff",
        }}
      >
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <Box display="flex" justifyContent="space-between" marginBottom={2} gap={2}>
            <DesktopDateTimePicker
              label="From Date"
              value={fromDate}
              onChange={setFromDate}
              slotProps={{
                textField: { variant: "outlined", fullWidth: true, style: { borderRadius: "12px" } },
              }}
            />
            <DesktopDateTimePicker
              label="To Date"
              value={toDate}
              onChange={setToDate}
              slotProps={{
                textField: { variant: "outlined", fullWidth: true, style: { borderRadius: "12px" } },
              }}
            />
          </Box>
        </LocalizationProvider>
        <Box display="flex" alignItems="center" gap={2}>
          <Button
            onClick={handleSearch}
            style={{
              padding: "10px 20px",
              margin: "10px 0",
              backgroundColor: "blue",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontFamily: "Arial, sans-serif",
              fontSize: "14px",
              fontWeight: "bold",
              transition: "background-color 0.3s ease",
            }}
            disabled={!fromDate && !toDate} // Allow search with at least one date
          >
            Search
          </Button>
          <IconButton
            onClick={exportToExcel}
            style={{
              margin: "10px 0",
              backgroundColor: "#4CAF50",
              color: "#fff",
              borderRadius: "5px",
            }}
          >
            <DownloadIcon />
          </IconButton>
        </Box>

        {loading ? (
          <Box display="flex" justifyContent="center" marginTop={2}>
            <CircularProgress />
          </Box>
        ) : data.length === 0 ? (
          <Typography variant="body1" align="center" marginTop={2}>
            No data available for the selected date range.
          </Typography>
        ) : (
          <>
            <div style={{ marginBottom: "10px", textAlign: "center" }}>
               <strong>Location</strong> | <strong>Rack No</strong>
            </div>
            <ul style={listStyle}>
              {currentItems.map((item, index) => (
                <li key={index} style={listItemStyle}>

                  <div style={locationBoxStyle}>{item.PhysicalLocation}</div>
                  <div style={rackBoxStyle}>{item.RackNo}</div>
                </li>
              ))}
            </ul>

            <div style={paginationStyle}>
              <button onClick={goToPreviousPage} disabled={currentPage === 1}>
                Previous
              </button>
              <span>
                Page {currentPage} of {totalPages}
              </span>
              <button onClick={goToNextPage} disabled={currentPage === totalPages}>
                Next
              </button>
            </div>
          </>
        )}
      </Container>
    </div>
  );
};

export default NonCompliant;