import React, { Suspense, useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import UnauthorizedPage from "./Components/UnauthorizedPage";
import NotFound from "./Components/Notfound";

// Lazy-loaded components for better performance
const LoginPage = React.lazy(() => import("./Components/Login"));
const HomePage = React.lazy(() => import("./Components/HomePage"));
const StencilIn = React.lazy(() => import("./Components/StencilIn"));
const StencilOut = React.lazy(() => import("./Components/StencilOut"));
const OperatorId = React.lazy(() => import("./Components/OperatorID"));
const OperatorIdOut = React.lazy(() => import("./Components/OperatorIDOut"));
const OperatorHistory = React.lazy(() => import("./Components/OperatorHistory"));
const AllHistory = React.lazy(() => import("./Components/AllHistory"));
const BlockUnblock = React.lazy(() => import("./Components/BlockUnBlock"));
const EditStencil = React.lazy(() => import("./Components/EditStencil"));
const RackDataTable = React.lazy(() => import("./Components/TestingPage"));
const ViewLoadedStencils = React.lazy(() => import("./Components/ViewLoadedStencils"));
const StencilRegistration = React.lazy(() => import("./Components/StencilRegistration"));
const UpdateStencilRegistration = React.lazy(() => import("./Components/UpdateStencil"));
const NonCompliant = React.lazy(() => import("./Components/NonCompliant"));
const RackId = React.lazy(() => import("./Components/RackId"));
const EditMaintenance = React.lazy(() => import("./Components/EditMaintainance"));
const ExportData = React.lazy(() => import("./Components/ExportData"));
const AvailableStencilRegistration = React.lazy(() => import("./Components/AvailableStencilRegistration"));
const AdminAccessPage = React.lazy(() => import("./Components/Adminaccesspage"));

const App = () => {
  const [role, setRole] = useState(null);

  // Fetch role from sessionStorage
  useEffect(() => {
    const storedRole = sessionStorage.getItem("role"); // Fetch role from session storage
    setRole(Number(storedRole)); // Set role state
  }, []);

  if (role === null) {
    // If role is still being loaded or not found, render a fallback.
    return <div>Loading...</div>;
  }

  const isOperator = [1, 2, 3, 5].includes(role); // Corrected: check if role is in this array
  const isAdmin = role === 3; // Admin role (all routes)
  const isTechEnggAdmin = [1, 2, 3].includes(role); // Tech, Engg, Admin
  const hasAccessEnggAdmin = [2, 3].includes(role);

  return (
    <Router basename="Stencil_Management">
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {/* Public routes */}
          <Route path="/Login" element={<LoginPage />} />
          <Route path="/unauthorized" element={<UnauthorizedPage />} />

          {/* Admin has access to all pages */}
          {isAdmin && (
            <>
              <Route path="/HomePage" element={<HomePage />} />
              <Route path="/StencilIn" element={<StencilIn />} />
              <Route path="/StencilOut" element={<StencilOut />} />
              <Route path="/OperatorId" element={<OperatorId />} />
              <Route path="/OperatorIdOut" element={<OperatorIdOut />} />
              <Route path="/OperatorHistory" element={<OperatorHistory />} />
              <Route path="/AllHistory" element={<AllHistory />} />
              <Route path="/BlockUnblock" element={<BlockUnblock />} />
              <Route path="/editStencil" element={<EditStencil />} />
              <Route path="/TestingPage" element={<RackDataTable />} />
              <Route path="/ViewLoadedStencil" element={<ViewLoadedStencils />} />
              <Route path="/StencilRegistration" element={<StencilRegistration />} />
              <Route path="/UpdateStencilRegistration" element={<UpdateStencilRegistration />} />
              <Route path="/Noncompliant" element={<NonCompliant />} />
              <Route path="/rackid" element={<RackId />} />
              <Route path="/EditMaintainance" element={<EditMaintenance />} />
              <Route path="/ExportData" element={<ExportData />} />
              <Route path="/AvailableStencilRegistration" element={<AvailableStencilRegistration />} />
              <Route path="/AdminAccessPage" element={<AdminAccessPage />} />
            </>
          )}

          {/* Operator has limited access */}
          {isOperator && (
            <>
              <Route path="/HomePage" element={<HomePage />} />
              <Route path="/StencilIn" element={<StencilIn />} />
              <Route path="/StencilOut" element={<StencilOut />} />
              <Route path="/OperatorHistory" element={<OperatorHistory />} />
                 <Route path="/rackid" element={<RackId />} />
                  <Route path="/AvailableStencilRegistration" element={<AvailableStencilRegistration />} />
              <Route path="/Noncompliant" element={<NonCompliant />} />
              
              <Route path="/ViewLoadedStencil" element={<ViewLoadedStencils />} />
            </>
          )}

          {/* Tech/Engg/Admin has specific routes */}
          {isTechEnggAdmin && (
            <>
              <Route path="/HomePage" element={<HomePage />} />
              <Route path="/TestingPage" element={<RackDataTable />} />
              <Route path="/StencilRegistration" element={<StencilRegistration />} />
              <Route path="/EditMaintainance" element={<EditMaintenance />} />
              <Route path="/rackid" element={<RackId />} />
                  <Route path="/AvailableStencilRegistration" element={<AvailableStencilRegistration />} />
              <Route path="/ExportData" element={<ExportData />} />
            </>
          )}

          {hasAccessEnggAdmin && (
            <>
              <Route path="/HomePage" element={<HomePage />} />
              <Route path="/StencilIn" element={<StencilIn />} />
              <Route path="/StencilOut" element={<StencilOut />} />
              <Route path="/OperatorId" element={<OperatorId />} />
              <Route path="/OperatorIdOut" element={<OperatorIdOut />} />
              <Route path="/OperatorHistory" element={<OperatorHistory />} />
            
              <Route path="/BlockUnblock" element={<BlockUnblock />} />
              <Route path="/editStencil" element={<EditStencil />} />
              <Route path="/TestingPage" element={<RackDataTable />} />
              <Route path="/ViewLoadedStencil" element={<ViewLoadedStencils />} />
              <Route path="/StencilRegistration" element={<StencilRegistration />} />
              <Route path="/UpdateStencilRegistration" element={<UpdateStencilRegistration />} />
              <Route path="/Noncompliant" element={<NonCompliant />} />
              <Route path="/rackid" element={<RackId />} />
              <Route path="/EditMaintainance" element={<EditMaintenance />} />
              <Route path="/ExportData" element={<ExportData />} />
              <Route path="/AvailableStencilRegistration" element={<AvailableStencilRegistration />} />
              
            </>
          )}

          {/* 404 Page for unauthorized access */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </Router>
  );
};

export default App;
