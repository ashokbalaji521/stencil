import React, { createContext, useState, useContext, useEffect } from "react";

// Create AuthContext
const AuthContext = createContext();

// Create a provider for AuthContext
export const AuthProvider = ({ children }) => {
  // Initialize role state
  const [role, setRole] = useState(null);

  useEffect(() => {
    // Get the role from sessionStorage and parse it as an integer
    const storedRole = sessionStorage.getItem("role");
    if (storedRole) {
      setRole(parseInt(storedRole, 10)); // Parse the role as integer
    }
  }, []); // Run only once when the component mounts

  return (
    <AuthContext.Provider value={{ role, setRole }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the Auth context
export const useAuth = () => useContext(AuthContext);
