const host = window.location.hostname;
export const Data = {
  url: `http://${host}:4000/Stencil_Management_API/`,
  // url: `https://${host}/Stencil_Management_API/`,
 // url: `http://${host}/Stencil_Management_API/`,  //in use for prod
  //url: `https://${host}/AKS_BackEnd/data/api/`,

  //imagePath: `http://${host}:8081/AKS_API/`
};
